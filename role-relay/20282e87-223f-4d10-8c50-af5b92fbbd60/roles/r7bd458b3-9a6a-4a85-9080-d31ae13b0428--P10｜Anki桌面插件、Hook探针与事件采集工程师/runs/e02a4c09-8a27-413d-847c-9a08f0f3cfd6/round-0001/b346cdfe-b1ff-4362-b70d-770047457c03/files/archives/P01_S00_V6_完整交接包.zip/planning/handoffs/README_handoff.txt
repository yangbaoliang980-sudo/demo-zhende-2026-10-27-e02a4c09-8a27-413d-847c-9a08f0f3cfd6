P01 / S00 V6.0 LOCAL HANDOFF  —  V0.1
Date: 2026-10-27
Producer: P01; independent reviewer: P35 (not yet acknowledged)
Repository ref: https://github.com/yangbaoliang980-sudo/juesedemo-2026-10-27-01b55988-26e9-4763-a710-e5ba81986b3c/tree/8c370d731c323f86ff19642f4cc73f818498f641

FOLDER PURPOSE
spec/product/          Requirements baseline, PRD, 41 evidence-traced requirements and scope.
planning/decisions/    12 pending decision records, ADR, 6 proposed change requests.
planning/handoffs/    14 tasks, 43 role status records, 10 prepared receipts, 26 legacy D issues + 13 blockers, 12 gates, sources.
manifest.sha256.tsv   Local bytes/sha256, provenance, receiving roles, planned write whitelist.

STAGED ONLY — DO NOT COPY OVER AN EXISTING ENGINE WITHOUT P13 actual_path_mapping AND AUTHORIZATION.
Paths shown are a proposed design namespace rather than proven actual repository paths.
Only P01 source-appropriate docs are produced. No source code, art, game runtime or Anki database was modified.

TO RECEIVE
1. Verify all file hashes using manifest.sha256.tsv against extracted files. ZIP testzip/CRC must pass.
2. Treat source SHA-256 for upstream material as manifest-reported, NOT independently re-hashed from downloaded bytes.
3. Confirm baseline P01-REQ-V0.1 and source git commit 8c370d731c323f86ff19642f4cc73f818498f641. Reject handoff when revision/sha mismatches.
4. Actual consumer writes a new receipt: ACCEPTED_FOR_REVIEW / REJECTED / BLOCKED; never infer it from this package.
5. P13 maps real engine paths/owner/allowed changes, P22 defines content IDs, P34 confirms OS/Anki, P32 independent tests, P35 reviews.
6. Numeric MVP content scale, four-key benefits, Undo spent resources, free-day actions, engine/platform, release, integrator remain unapproved.
7. External integration remains user-only appointment; G4/G5 BLOCKED.

TEST STATUS: P01 bundle deterministic consistency check planned; third-party independent review NOT_RUN. All program/Anki/E2E tests NOT_RUN.
SOURCE GAP: user chat full raw message bytes unavailable; exact excerpts are hashed individually and referenced, without claiming a full-message digest.
CONFLICT RULE: preserve two base SHA versions and create ChangeRequest, no overwrite / forced merge. Same issue two rounds with no new evidence -> P01 scope arbitration.
