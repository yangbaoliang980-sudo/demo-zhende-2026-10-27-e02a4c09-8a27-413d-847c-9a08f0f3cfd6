# 原始输入核验凭证

input_inventory.json 保存 14 个上传件、108 个去重 ZIP、8,198 个展开文件成员和 787 条 relay manifest 检查的实际结果。这里两个 Git tree 是本轮从固定提交读取的完整树索引；只记录项目文件元数据，没有凭据。

inspect_inputs.py 是实际执行的脚本原字节。原执行布局为 `<临时根>/p21_work/inspect_inputs.py`、同目录两个 github_tree JSON，14 个上传件位于 `<临时根>/upload/`。复现完整输入检查需要原上传件；本交付只随包保留了 128 份相关原件，没有再次重复附上所有上传 ZIP。

脚本递归解包、检查安全路径与 CRC、读所有成员原字节、计算 SHA-256/Git blob SHA-1，再验证 relay manifest。完整索引位于本目录上一级。文件读取/哈希不表示所有成员都已作语义审查；具体被复用的原件见 source_input_receipt.json。
