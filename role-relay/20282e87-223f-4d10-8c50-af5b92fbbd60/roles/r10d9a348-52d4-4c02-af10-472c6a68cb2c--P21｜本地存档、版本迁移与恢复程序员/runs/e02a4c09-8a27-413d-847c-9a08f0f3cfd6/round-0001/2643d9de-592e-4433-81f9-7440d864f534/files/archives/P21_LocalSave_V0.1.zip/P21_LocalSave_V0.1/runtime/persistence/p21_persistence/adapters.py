"""P21-owned, isolated adapters to the unchanged P11/P13/P17/P18 proposals.

No authority is installed from JSON. Composition supplies pure validators and
coherent read ports. Production acceptance remains BLOCKED. The P11 wallet
mapping has no built-in implementation: P17 must supply an approved lossless
binding; tests supply an explicitly synthetic one in tests/save_unit/support.
"""
from __future__ import annotations
from typing import Protocol
from .model import (Request, Record, Update, Mutation, Claim, SaveError, CommitUnknown,
                    need, digest, encode)

INTERNAL_VERSION='YLTT-INTERNAL/0.1.0-isolated'


def _frozen(raw):
    from yltt_framework.codec import FrozenMessage
    return FrozenMessage(raw)


class P17CommitAdapter:
    def __init__(self,store,planner):self.store,self.planner=store,planner

    def submit(self,candidate,proposal=None):
        from character_party_runtime import atomic_proposal
        c=candidate.value
        need(digest(c['request'])==c['request_sha256'],'E_REQUEST_HASH_BINDING')
        expected=atomic_proposal(candidate)  # rejects a missing P11/P18 counterpart
        if proposal is not None:need(proposal.raw==expected.raw,'E_PROJECTION_CANDIDATE_BINDING')
        p=expected.value
        request=Request(p['transaction_id'],p['request_sha256'],'CHARACTER_WALLET',
                        p['expected_store_instance'],c['request']['continuity_ref'])
        def decide(s):
            current=_frozen(s.records['meta'].payload)
            result=self.planner.validate_for_commit(candidate,current)
            need(result.status=='CANDIDATE','E_DOMAIN_ALREADY_COMMITTED_WITHOUT_P21_RECEIPT')
            after=c['after_state']
            return Mutation((Update(Record.from_value('meta',after['revision'],after),current.sha256),),
                            result={'candidate_sha256':candidate.sha256,'owner':'P17'})
        return self.store.execute_once(request,decide)


class StoreFenceAuthority:
    """P21's store fence over one locked snapshot; other evidence stays with owners."""
    def __init__(self,snapshot,domain_authority):self.snapshot,self.delegate=snapshot,domain_authority
    def resolve_store(self,scope):
        from yltt_framework.codec import FrozenMessage
        record=self.snapshot.records['stage'];s=record.value
        if scope!=self.snapshot.profile_id:return None
        need((s['player_save_scope_id'],s['store_instance'],s['continuity_ref'])==
             (scope,self.snapshot.store_instance,self.snapshot.continuity_ref),'E_DOMAIN_STORE_FENCE')
        return FrozenMessage.from_value({'schema_version':'P18-STORE-FENCE/0.1.0-proposal',
            'player_save_scope_id':scope,'store_instance':self.snapshot.store_instance,
            'continuity_ref':self.snapshot.continuity_ref,'revision':s['revision'],
            'state_sha256':record.sha256,'status':'CONSISTENT'})
    def resolve_entry(self,ref):
        proof=self.delegate.resolve_entry(ref)
        if proof is not None:
            need(proof.value['party_source_sha256']==self.snapshot.records['meta'].sha256,'E_ENTRY_META_SOURCE_STALE')
        return proof
    def resolve_battle(self,ref):return self.delegate.resolve_battle(ref)
    def resolve_control(self,ref):return self.delegate.resolve_control(ref)


class P18CommitAdapter:
    """Factories are trusted code, invoked inside the physical transaction.

    planner_factory(snapshot) must bind immutable/coherent P13/P14 evidence and
    StoreFenceAuthority. wallet_factory(snapshot) supplies P17's pure validator.
    """
    def __init__(self,store,planner_factory,wallet_factory):
        self.store,self.planner_factory,self.wallet_factory=store,planner_factory,wallet_factory

    def submit(self,bundle):
        from stage_runtime.transactions import validate_atomic
        from yltt_framework.contracts import validate
        b=bundle.value;p=b['p13_projection'];candidate=b['body']['stage_candidate']
        validate(p,'AtomicCommitProposal')
        raw_request=candidate['request']
        need(digest(raw_request)==candidate['request_sha256']==p['request_sha256'],'E_REQUEST_HASH_BINDING')
        need(p['transaction_id']=='p18.tx.'+digest([raw_request['player_save_scope_id'],raw_request['request_id']]),'E_TRANSACTION_ID_BINDING')
        need(p['transaction_kind']=='STAGE_PROGRESS_WALLET','E_TRANSACTION_KIND')
        req=Request(p['transaction_id'],p['request_sha256'],'STAGE_PROGRESS_WALLET',
                    p['expected_store_instance'],candidate['request']['continuity_ref'])
        def decide(s):
            stage=_frozen(s.records['stage'].payload);meta=_frozen(s.records['meta'].payload)
            checked=validate_atomic(bundle,self.planner_factory(s),stage,meta,self.wallet_factory(s))
            need(checked.status=='CANDIDATE','E_DOMAIN_ALREADY_COMMITTED_WITHOUT_P21_RECEIPT')
            after=candidate['after_state']
            updates=[Update(Record.from_value('stage',after['revision'],after),stage.sha256)]
            mc=b['body']['wallet_character_candidate']
            if mc is not None:
                updates.append(Update(Record.from_value('meta',mc['after_state']['revision'],mc['after_state']),meta.sha256))
            claims=[]
            for key in candidate['new_first_clear_keys']:
                row=next(x for x in after['first_clears'] if x['key']==key)
                claims.append(Claim('STAGE_FIRST_CLEAR',key,digest(row)))
            return Mutation(tuple(updates),tuple(claims),
                            {'bundle_sha256':bundle.sha256,'body_sha256':b['body_sha256'],
                             'decision':candidate['decision'],'owners':['P18','P17'] if mc else ['P18']})
        return self.store.execute_once(req,decide)


class LegacyWalletBinding(Protocol):
    """Required P17 port. No approved production provider has been received."""
    def project(self,meta_record:Record)->dict: ...
    def materialize(self,delta,meta_record:Record)->Record: ...
    def validate(self,delta,before:Record,after:Record)->None: ...


class UnboundLegacyWallet:
    def project(self,meta_record):raise SaveError('E_P11_P17_WALLET_BINDING_UNBOUND')
    def materialize(self,delta,meta_record):raise SaveError('E_P11_P17_WALLET_BINDING_UNBOUND')
    def validate(self,delta,before,after):raise SaveError('E_P11_P17_WALLET_BINDING_UNBOUND')


class P11AtomicAdapter:
    """P11 port implementation with its old origin enum preserved for isolation.

    P21's actual receipt remains P21_SQLITE_ISOLATED. The legacy P11 projection
    uses P21_SIMULATOR (P11 rejects any other non-production value), never
    P21_PRODUCTION. This adapter cannot activate P20's real-income branch.
    """
    def __init__(self,store,wallet_binding=None):
        self.store=store;self.binding=wallet_binding or UnboundLegacyWallet()

    def _snapshot(self,s):
        from ledger_runtime.types import Snapshot
        return Snapshot(s.records['ledger'].value,self.binding.project(s.records['meta']),
                        True,s.continuity_ref,s.store_instance,s.sequence)

    def snapshot(self):return self.store.read_consistent(self._snapshot)

    @staticmethod
    def _receipt(proof):
        from ledger_runtime.types import CommitReceipt
        r=proof['receipt'];p=r['result']
        need(r['kind']=='STUDY_LEDGER_WALLET' and p.get('adapter')=='P11-PORTS/0.1.0-proposal','E_P11_RECEIPT_BINDING')
        return CommitReceipt(r['transaction_id'],r['request_sha256'],r['store_instance'],r['sequence'],
                             p['p11_ledger_sha256'],p['p11_wallet_sha256'],'P21_SIMULATOR',True)

    def lookup(self,transaction_id):
        from ledger_runtime.types import Lookup
        value=self.store.lookup(transaction_id)
        return Lookup(value['status'],self._receipt(value['proof']) if value['proof'] else None)

    def execute_once(self,transaction_id,request_sha256,decide):
        from ledger_runtime.types import Mutation as P11Mutation, CommitUnknown as P11Unknown, PortViolation
        from ledger_runtime.audit import verify_audit
        try:
            # The locked execution checks this fence again. It cannot switch stores.
            head=self.store.snapshot()
            request=Request(transaction_id,request_sha256,'STUDY_LEDGER_WALLET',head.store_instance,head.continuity_ref)
            def physical_decide(s):
                mutation=decide(self._snapshot(s))
                need(type(mutation) is P11Mutation,'E_P11_MUTATION_TYPE')
                verify_audit(mutation.ledger)  # owner's audit validator, no state-machine rewrite
                ledger=Record.from_value('ledger',s.records['ledger'].revision+1,mutation.ledger)
                updates=[Update(ledger,s.records['ledger'].sha256)]
                after=s.records['meta']
                if mutation.wallet_delta is not None:
                    after=self.binding.materialize(mutation.wallet_delta,s.records['meta'])
                    self.binding.validate(mutation.wallet_delta,s.records['meta'],after)
                    updates.append(Update(after,s.records['meta'].sha256))
                return Mutation(tuple(updates),result={'adapter':'P11-PORTS/0.1.0-proposal',
                    'p11_ledger_sha256':digest(mutation.ledger),
                    'p11_wallet_sha256':digest(self.binding.project(after)),
                    'wallet_binding_scope':'OWNER_SUPPLIED_ISOLATED_PORT_NOT_PRODUCTION_ACCEPTANCE'})
            result=self.store.execute_once(request,physical_decide)
            return self._receipt(result['proof'])
        except CommitUnknown as exc:raise P11Unknown(str(exc)) from exc
        except SaveError as exc:raise PortViolation(str(exc)) from exc


def p13_lookup(store,transaction_id,request_sha256=None):
    from yltt_framework.contracts import validate
    result=store.lookup(transaction_id,request_sha256)
    proof=None
    if result['proof']:
        r=result['proof']['receipt']
        proof={'contract_version':INTERNAL_VERSION,'dto_type':'CommitProofView',
            'transaction_id':transaction_id,'request_sha256':r['request_sha256'],
            'store_instance':r['store_instance'],'sequence':r['sequence'],
            'receipt_sha256':result['proof']['receipt_sha256'],'snapshot_sha256':r['state_sha256'],
            'high_watermark':result['high_watermark'],'continuity_ref':r['continuity_ref']}
    return validate({'contract_version':INTERNAL_VERSION,'dto_type':'CommitLookupView',
        'transaction_id':transaction_id,'status':result['status'],'proof':proof,
        'observed_store_instance':result['store_instance'],'observed_high_watermark':result['high_watermark'],
        'continuity_ref':result['continuity_ref']},'CommitLookupView')


def p13_status(store):
    from yltt_framework.contracts import validate
    status=store.status()
    return validate({'contract_version':INTERNAL_VERSION,'dto_type':'SaveStatusView',
        'store_instance':status['store_instance'],'state':'READ_ONLY' if status['state']=='MIGRATION_REQUIRED' else status['state'],
        'save_format_version':status['save_format_version'],'high_watermark':status['high_watermark'],
        'reason_code':status['reason_code']},'SaveStatusView')
