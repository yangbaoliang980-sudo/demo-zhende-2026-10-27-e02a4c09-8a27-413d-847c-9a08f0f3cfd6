"""P21 author-test fixtures only. Never import from production composition."""
