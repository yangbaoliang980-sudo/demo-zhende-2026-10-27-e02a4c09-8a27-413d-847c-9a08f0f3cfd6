from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
import errno
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from p21_persistence import *
from p21_persistence.model import encode,decode
from support.fixtures import (ROOT,INSTANCE,CONTINUITY,create_simple,open_simple,
                              request,increment,trace)


class AtomicTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-atomic-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.store=create_simple(self.root)
    def assertCode(self,code,fn):
        with self.assertRaises(SaveError) as e:fn()
        self.assertEqual(e.exception.code,code)
    def test_multi_record_commit_and_real_process_restart(self):
        self.store.execute_once(request(),increment)
        cmd=[sys.executable,'-B',str(ROOT/'tools/fault_worker.py'),str(self.root),'--mode','read']
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=15)
        self.assertEqual(p.returncode,0,p.stderr);data=json.loads(p.stdout)
        self.assertEqual(data['sequence'],1)
        self.assertEqual([data['records'][n]['counter'] for n in ('ledger','meta','stage')],[1,1,0])
        trace(self._testMethodName,{'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    def test_duplicate_after_reopen_never_reruns_owner_callback(self):
        first=self.store.execute_once(request(),increment)
        second=open_simple(self.root).execute_once(request(),lambda s:self.fail('duplicate invoked callback'))
        self.assertTrue(second['duplicate']);self.assertEqual(first['proof'],second['proof'])
        self.assertEqual(self.store.snapshot().sequence,1)
    def test_transaction_id_payload_collision(self):
        self.store.execute_once(request(),increment)
        self.assertCode('E_TRANSACTION_ID_COLLISION',lambda:self.store.execute_once(request(body='other'),increment))
        self.assertCode('E_TRANSACTION_ID_COLLISION',lambda:self.store.lookup('fixture.tx',digest('other')))
        self.assertEqual(self.store.snapshot().sequence,1)
    def test_callback_exception_rolls_back(self):
        def fail(s):raise RuntimeError('owner refused')
        with self.assertRaises(RuntimeError):self.store.execute_once(request(),fail)
        self.assertEqual(self.store.snapshot().sequence,0)
    def test_later_record_stale_rejects_entire_candidate(self):
        def decide(s):
            m=increment(s);return Mutation((m.updates[0],Update(m.updates[1].record,'a'*64)))
        self.assertCode('E_STALE_RECORD',lambda:self.store.execute_once(request(),decide))
        self.assertEqual(self.store.snapshot().records['ledger'].value['counter'],0)
    def test_domain_boundary_wallet_cannot_be_submitted_without_ledger(self):
        self.assertCode('E_TRANSACTION_DOMAIN_BOUNDARY',lambda:self.store.execute_once(request(),lambda s:increment(s,('meta',))))
        self.assertEqual(self.store.snapshot().sequence,0)
    def test_domain_schema_change_requires_owner_migration(self):
        def decide(s):
            v=s.records['meta'].value;v['schema_version']='UNAPPROVED/2'
            return Mutation((Update(Record.from_value('meta',1,v),s.records['meta'].sha256),))
        self.assertCode('E_DOMAIN_SCHEMA_CHANGE_REQUIRES_OWNER',lambda:self.store.execute_once(request(kind='CHARACTER_WALLET'),decide))
    def test_revision_jump_rejected(self):
        def decide(s):return Mutation((Update(Record.from_value('meta',3,s.records['meta'].value),s.records['meta'].sha256),))
        self.assertCode('E_RECORD_REVISION',lambda:self.store.execute_once(request(kind='CHARACTER_WALLET'),decide))
    def test_wrong_store_fence_before_any_write(self):
        r=Request('fence',digest('fence'),'STUDY_LEDGER_WALLET','other.store',CONTINUITY)
        self.assertCode('E_REQUEST_FENCE',lambda:self.store.execute_once(r,increment))
    def test_claim_is_permanent_and_second_award_atomic_rollback(self):
        claim=Claim('STAGE_FIRST_CLEAR','stage.stable',digest('approved-fixture'))
        self.store.execute_once(request('claim.1','STAGE_PROGRESS_WALLET'),lambda s:increment(s,('stage','meta'),(claim,)))
        head=self.store.snapshot()
        self.assertCode('E_CLAIM_ALREADY_CONSUMED',lambda:self.store.execute_once(request('claim.2','STAGE_PROGRESS_WALLET'),lambda s:increment(s,('stage','meta'),(claim,))))
        self.assertEqual(self.store.snapshot(),head)
    def test_claim_changed_semantics_rejected(self):
        self.store.execute_once(request('claim.1','STAGE_PROGRESS_WALLET'),lambda s:increment(s,('stage','meta'),(Claim('FIRST','key',digest(1)),)))
        self.assertCode('E_CLAIM_COLLISION',lambda:self.store.execute_once(request('claim.2','STAGE_PROGRESS_WALLET'),lambda s:increment(s,('stage','meta'),(Claim('FIRST','key',digest(2)),))))
    def test_snapshot_is_independent_immutable_bytes(self):
        snapshot=self.store.snapshot();v=snapshot.records['meta'].value;v['counter']=999
        with self.assertRaises(TypeError):snapshot.records['meta']=None
        self.assertEqual(self.store.snapshot().records['meta'].value['counter'],0)
    def test_confirmed_absence_has_continuity(self):
        value=self.store.lookup('never.committed')
        self.assertEqual(value['status'],'ABSENT');self.assertTrue(value['continuity_verified'])
        self.assertEqual(value['high_watermark'],0)
    def test_response_loss_after_sql_commit_resolved_by_original_id(self):
        def fail(point,c):
            if point=='after_sql_commit':raise ConnectionError('injected reply path failure')
        self.store.fault=fail
        with self.assertRaises(CommitUnknown):self.store.execute_once(request(),increment)
        self.store.fault=None
        self.assertEqual(self.store.lookup('fixture.tx')['status'],'COMMITTED')
        self.assertTrue(self.store.execute_once(request(),lambda s:self.fail('retry mutation'))['duplicate'])
        self.assertEqual(self.store.snapshot().records['meta'].value['counter'],1)
    def test_anchor_enospc_after_commit_never_returns_false_absent(self):
        from p21_persistence import store as module
        with patch.object(module,'write_json',side_effect=OSError(errno.ENOSPC,'controlled anchor full')):
            with self.assertRaises(CommitUnknown):self.store.execute_once(request(),increment)
        value=open_simple(self.root).lookup('fixture.tx')
        self.assertEqual(value['status'],'COMMITTED')
        trace(self._testMethodName,{'fault':'INJECTED_OS_ENOSPC_ON_ANCHOR_WRITE','lookup':value,'real_filesystem_full':False})
    def test_real_sqlite_full_no_half_commit(self):
        def limit(point,c):
            if point=='after_begin':
                pages=c.execute('PRAGMA page_count').fetchone()[0]
                c.execute('PRAGMA max_page_count='+str(pages))
        self.store.fault=limit
        def decide(s):
            first=increment(s).updates[0];v=s.records['meta'].value;v['padding']='x'*850_000;v['counter']=1
            return Mutation((first,Update(Record.from_value('meta',1,v),s.records['meta'].sha256)))
        with self.assertRaises(SaveError) as e:self.store.execute_once(request(),decide)
        self.assertEqual(e.exception.code,'E_DISK_FULL');self.store.fault=None
        after=open_simple(self.root).snapshot()
        self.assertEqual(after.sequence,0);self.assertEqual([after.records[n].value['counter'] for n in ('ledger','meta')],[0,0])
        trace(self._testMethodName,{'fault':'SQLITE_FULL_FROM_REAL_MAX_PAGE_COUNT_LIMIT','error':e.exception.as_dict(),
            'sequence_after':after.sequence,'ledger_sha256':after.records['ledger'].sha256,'meta_sha256':after.records['meta'].sha256,
            'physical_volume_filled':False})
    def test_cross_process_same_request_exactly_one_commit(self):
        base=[sys.executable,'-B',str(ROOT/'tools/fault_worker.py'),str(self.root),'--tx','concurrent.same']
        def child(_):
            p=subprocess.run(base,capture_output=True,text=True,timeout=20)
            return {'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        with ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(child,range(6)))
        self.assertTrue(all(x['exit_code']==0 for x in results),results)
        self.assertEqual(sum(not json.loads(x['stdout'])['duplicate'] for x in results),1)
        self.assertEqual(self.store.snapshot().sequence,1)
        trace(self._testMethodName,{'argv':base,'children':results,'process_count':6})
    def test_concurrent_readers_never_observe_mixed_domains(self):
        def writer():
            for i in range(12):self.store.execute_once(request('multi.'+str(i)),increment)
        def reader():
            for _ in range(16):
                s=self.store.snapshot();self.assertEqual(s.records['ledger'].value['counter'],s.records['meta'].value['counter'])
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures=[pool.submit(writer),pool.submit(reader),pool.submit(reader)]
            for f in futures:f.result()
        self.assertEqual(self.store.snapshot().sequence,12)
    def test_preexisting_directory_cannot_be_reinitialized(self):
        self.assertCode('E_ANCHOR_EXISTS',lambda:create_simple(self.root))
    def test_original_file_deleted_does_not_create_empty_game(self):
        self.store.db.unlink()
        self.assertEqual(self.store.lookup('fixture.tx')['status'],'UNKNOWN')
        self.assertFalse(self.store.db.exists())
    def test_production_mode_cannot_be_enabled_by_boolean(self):
        from support.fixtures import simple_records
        self.assertCode('E_PRODUCTION_NOT_AUTHORIZED',lambda:Store.create(self.root/'prod',self.root/'authority/prod.json',simple_records(),profile_id='p',mode='production'))
    def test_symlink_save_path_rejected(self):
        link=self.root/'linked';link.symlink_to(self.root/'save',target_is_directory=True)
        self.assertCode('E_SYMLINK_PATH',lambda:Store(link,self.root/'authority/head.json',expected_store_instance=INSTANCE))
    def test_arbitrary_json_owner_flag_is_not_mutation(self):
        self.assertCode('E_MUTATION_TYPE',lambda:self.store.execute_once(request(),lambda s:{'owner':'P21','durable':True}))


def rollback_test(point):
    def test(self):
        def fault(p,c):
            if p==point:raise RuntimeError('injected '+point)
        self.store.fault=fault
        with self.assertRaises(RuntimeError):self.store.execute_once(request(),increment)
        self.store.fault=None;s=self.store.snapshot()
        self.assertEqual(s.sequence,0);self.assertEqual([s.records[n].value['counter'] for n in ('ledger','meta')],[0,0])
        self.assertEqual(self.store.lookup('fixture.tx')['status'],'ABSENT')
    return test


for point in ['after_begin','after_validate','after_record:ledger','after_record:meta','after_claims','after_receipt','before_commit']:
    setattr(AtomicTests,'test_exception_rollback_'+point.replace(':','_'),rollback_test(point))


class SerializationTests(unittest.TestCase):
    def test_duplicate_keys(self):
        with self.assertRaises(SaveError):decode(b'{"a":1,"a":2}')
    def test_float_and_nonfinite(self):
        for raw in [b'{"a":1.2}',b'{"a":1e2}',b'{"a":NaN}']:
            with self.assertRaises(SaveError):decode(raw)
    def test_unsafe_integer(self):
        with self.assertRaises(SaveError):encode({'a':2**53})
    def test_bool_revision_is_not_integer(self):
        with self.assertRaises(SaveError):Record.from_value('meta',True,{'schema_version':'TEST/1'})
    def test_noncanonical_bytes(self):
        with self.assertRaises(SaveError):Record('meta','P17','TEST/1',0,b'{ "schema_version": "TEST/1" }')
    def test_unicode_roundtrip(self):
        v={'schema_version':'TEST/1','name':'言灵旅团・ことだま'}
        self.assertEqual(decode(encode(v)),v)
    def test_record_size_limit_no_truncation(self):
        with self.assertRaises(SaveError):Record.from_value('ledger',1,{'schema_version':'TEST/1','too_big':'x'*1_048_576})


if __name__=='__main__':unittest.main()
