"""Author-test child process. Hard termination never runs in the caller process."""
import bootstrap  # noqa: F401
from pathlib import Path
import argparse
import json
import os
import signal
import sys

sys.path.insert(0,str(bootstrap.ROOT/'tests/save_unit'))
from support.fixtures import open_simple,request,increment
from p21_persistence import SaveError


def main():
    p=argparse.ArgumentParser()
    p.add_argument('root');p.add_argument('--point',default='');p.add_argument('--mode',choices=['commit','migration','read','native_study','native_stage','native_upgrade'],default='commit')
    p.add_argument('--tx',default='fixture.crash')
    args=p.parse_args()
    def fault(point,c):
        if point==args.point:
            print(json.dumps({'event':'fault_reached','point':point,'pid':os.getpid(),'termination':'SIGKILL'}),flush=True)
            os.kill(os.getpid(),signal.SIGKILL)
    store=open_simple(args.root,fault=fault)
    try:
        if args.mode=='commit':out=store.execute_once(request(args.tx),increment)
        elif args.mode=='migration':out=store.migrate(Path(args.root)/'migration-backup')
        elif args.mode=='native_study':
            from support.fixtures import originals,SyntheticLegacyWalletBinding
            from p21_persistence.adapters import P11AtomicAdapter
            from ledger_runtime import StudyLedger
            _,_,ports=originals()
            ledger=StudyLedger(P11AtomicAdapter(store,SyntheticLegacyWalletBinding()),ports.FixtureWallet(),ports.FixtureEvidence(),ports.FixturePolicy())
            inbox=json.loads((Path(args.root)/'native_input.json').read_text())['inbox_id']
            result=ledger.process(inbox);out={'state':result.state}
        elif args.mode in ('native_stage','native_upgrade'):
            from support.fixtures import NativeStageFixture
            data=json.loads((Path(args.root)/'native_input.json').read_text())
            h=NativeStageFixture.attach(args.root,data.get('authority'))
            h.store.fault=fault
            if args.mode=='native_stage':out=h.adapter.submit(h.FrozenMessage.from_value(data['bundle']))
            else:
                from character_party_runtime import MetaPlanner
                from p21_persistence.adapters import P17CommitAdapter
                out=P17CommitAdapter(h.store,MetaPlanner(h.wallet.catalog)).submit(h.FrozenMessage.from_value(data['candidate']))
        else:
            s=store.snapshot();out={'sequence':s.sequence,'records':{k:r.value for k,r in s.records.items()}}
        print(json.dumps(out,sort_keys=True),flush=True)
        return 0
    except SaveError as exc:
        print(json.dumps({'error':exc.as_dict()}),flush=True);return 4


if __name__=='__main__':raise SystemExit(main())
