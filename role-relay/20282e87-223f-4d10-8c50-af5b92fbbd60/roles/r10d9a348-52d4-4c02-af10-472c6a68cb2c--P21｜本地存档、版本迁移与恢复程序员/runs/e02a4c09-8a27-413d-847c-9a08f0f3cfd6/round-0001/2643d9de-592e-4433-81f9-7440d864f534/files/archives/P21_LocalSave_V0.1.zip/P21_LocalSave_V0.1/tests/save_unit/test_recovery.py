from pathlib import Path
from unittest.mock import patch
import errno
import json
import os
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import unittest
from p21_persistence import *
from p21_persistence.model import byte_hash
from p21_persistence.recovery import inspect_backup,compare_backup,stage_restore,rehearse_migration
from support.fixtures import ROOT,INSTANCE,create_simple,open_simple,request,increment,trace


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-recovery-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.store=create_simple(self.root)
    def assertCode(self,code,fn):
        with self.assertRaises(SaveError) as e:fn()
        self.assertEqual(e.exception.code,code)
    def test_backup_readonly_verified_and_byte_stable(self):
        self.store.execute_once(request(),increment)
        b=self.store.backup(self.root/'backup');m,s,raw=inspect_backup(self.root/'backup')
        self.assertEqual(s.sequence,1);self.assertEqual(byte_hash(raw),m['sha256'])
        for p in (self.root/'backup').iterdir():self.assertEqual(stat.S_IMODE(p.stat().st_mode)&0o222,0)
        self.store.execute_once(request('next'),increment)
        self.assertEqual(byte_hash((self.root/'backup/snapshot.sqlite3').read_bytes()),m['sha256'])
        diff=compare_backup(self.store,self.root/'backup');self.assertEqual(diff['current_sequence'],2)
        self.assertEqual(len(diff['changed_records']),2);trace(self._testMethodName,{'backup':b,'diff':diff})
    def test_checksum_corruption_freezes_without_repairing_source(self):
        c=sqlite3.connect(self.store.db);c.execute("UPDATE documents SET payload=? WHERE name='meta'",(b'{"counter":9,"schema_version":"P21-TEST-DOMAIN/1"}',));c.commit();c.close()
        damaged=self.store.db.read_bytes()
        self.assertCode('E_RECORD_CHECKSUM',self.store.snapshot)
        self.assertEqual(self.store.db.read_bytes(),damaged)
        self.assertCode('E_FROZEN',lambda:self.store.execute_once(request(),increment))
        self.assertTrue((self.store.root/'FROZEN.json').exists())
        captures=list((self.store.root/'recovery_evidence').glob('*/'+self.store.db.name))
        self.assertTrue(any(p.read_bytes()==damaged for p in captures))
    def test_broken_database_header_is_preserved(self):
        data=bytearray(self.store.db.read_bytes());data[:16]=b'BROKEN-P21-TEST!!';self.store.db.write_bytes(data)
        damaged=bytes(data)
        self.assertEqual(self.store.lookup('unseen')['status'],'UNKNOWN')
        self.assertEqual(self.store.db.read_bytes(),damaged)
        self.assertTrue((self.store.root/'FROZEN.json').exists())
    def test_receipt_checksum_corruption_detected(self):
        self.store.execute_once(request(),increment)
        c=sqlite3.connect(self.store.db);c.execute("UPDATE transactions SET receipt_sha256=?",('f'*64,));c.commit();c.close()
        self.assertCode('E_RECEIPT_CHECKSUM',self.store.snapshot)
    def test_claim_deletion_detected(self):
        self.store.execute_once(request('claim','STAGE_PROGRESS_WALLET'),lambda s:increment(s,('stage','meta'),(Claim('FIRST','stage',digest('one')),)))
        c=sqlite3.connect(self.store.db);c.execute('DELETE FROM claims');c.commit();c.close()
        self.assertCode('E_STATE_CHECKSUM',self.store.snapshot)
    def test_receipt_truncation_detected(self):
        self.store.execute_once(request(),increment)
        c=sqlite3.connect(self.store.db);c.execute('DELETE FROM transactions');c.commit();c.close()
        self.assertCode('E_HEAD_CHECKSUM',self.store.snapshot)
    def test_old_backup_swap_blocked_by_external_head(self):
        self.store.backup(self.root/'old');self.store.execute_once(request(),increment)
        self.store.db.write_bytes((self.root/'old/snapshot.sqlite3').read_bytes())
        self.assertCode('E_ROLLBACK_DETECTED',self.store.snapshot)
        self.assertEqual(self.store.lookup('fixture.tx')['status'],'UNKNOWN')
        trace(self._testMethodName,{'result':'E_ROLLBACK_DETECTED','external_head_sequence':1,'restored_database_sequence':0,'new_awards':0})
    def test_missing_anchor_never_self_certifies_latest(self):
        self.store.anchor_path.unlink()
        self.assertCode('E_CONTINUITY_MISSING',self.store.snapshot)
        self.assertFalse(self.store.anchor_path.exists())
        self.assertEqual(self.store.lookup('unknown')['status'],'UNKNOWN')
    def test_foreign_anchor_rejected(self):
        raw=json.loads(self.store.anchor_path.read_text());raw['store_instance']='foreign.store'
        self.store.anchor_path.write_text(json.dumps(raw))
        self.assertCode('E_CONTINUITY_IDENTITY',self.store.snapshot)
    def test_backup_tamper_rejected_without_touching_active(self):
        self.store.backup(self.root/'backup');head=self.store.snapshot()
        p=self.root/'backup/snapshot.sqlite3';p.chmod(0o600);p.write_bytes(p.read_bytes()+b'bad')
        self.assertCode('E_BACKUP_CHECKSUM',lambda:inspect_backup(self.root/'backup'))
        self.assertEqual(self.store.snapshot(),head)
    def test_interrupted_backup_not_published(self):
        def fault(point,c):
            if point=='backup_after_copy':raise RuntimeError('interrupted backup')
        self.store.fault=fault
        with self.assertRaises(RuntimeError):self.store.backup(self.root/'partial')
        self.store.fault=None
        self.assertCode('E_FILE_MISSING',lambda:inspect_backup(self.root/'partial'))
        self.assertEqual(self.store.snapshot().sequence,0)
    def test_backup_enospc_preserves_active(self):
        def fault(point,c):
            if point=='backup_after_copy':raise OSError(errno.ENOSPC,'controlled backup disk full')
        self.store.fault=fault
        self.assertCode('E_DISK_FULL',lambda:self.store.backup(self.root/'full'))
        self.store.fault=None;self.assertEqual(self.store.snapshot().sequence,0)
    def test_exact_recovery_preserves_original_and_never_reawards(self):
        self.store.execute_once(request(),increment);self.store.backup(self.root/'latest')
        data=bytearray(self.store.db.read_bytes());data[:16]=b'BROKEN-P21-TEST!!';self.store.db.write_bytes(data)
        self.store.status()
        result=self.store.recover_exact(self.root/'latest')
        self.assertEqual(result['status'],'EXACT_HEAD_RECOVERED');self.assertEqual(result['awards_replayed'],0)
        original=self.store.root/result['raw_evidence']/self.store.db.name
        self.assertEqual(original.read_bytes(),bytes(data))
        self.assertTrue(self.store.execute_once(request(),lambda s:self.fail('duplicate recovery award'))['duplicate'])
        self.assertEqual(self.store.snapshot().records['meta'].value['counter'],1)
        trace(self._testMethodName,result)
    def test_old_backup_cannot_be_activated_as_lossy_repair(self):
        self.store.backup(self.root/'old');self.store.execute_once(request(),increment)
        original=self.store.db.read_bytes()
        self.assertCode('E_DATA_LOSS_OR_FOREIGN_RESTORE_BLOCKED',lambda:self.store.recover_exact(self.root/'old'))
        self.assertEqual(self.store.db.read_bytes(),original)
    def test_staged_restore_never_becomes_writable(self):
        self.store.backup(self.root/'backup');r=stage_restore(self.root/'backup',self.root/'review')
        s=Store(self.root/'review',self.store.anchor_path,expected_store_instance=INSTANCE)
        self.assertCode('E_FROZEN',lambda:s.execute_once(request(),increment))
        self.assertFalse((self.root/'review/head.json').exists());self.assertFalse(r['new_authority_created'])
    def test_recovery_interruption_keeps_write_fence(self):
        self.store.execute_once(request(),increment);self.store.backup(self.root/'backup')
        def fault(point,c):
            if point=='recovery_after_replace':raise RuntimeError('interrupted before validation')
        self.store.fault=fault
        with self.assertRaises(RuntimeError):self.store.recover_exact(self.root/'backup')
        self.assertCode('E_FROZEN',self.store.snapshot)
        self.store.fault=None;self.store.recover_exact(self.root/'backup')
        self.assertEqual(self.store.snapshot().sequence,1)
    def test_future_format_refuses_without_rewrite(self):
        c=sqlite3.connect(self.store.db);c.execute('PRAGMA user_version=88');c.close()
        original=self.store.db.read_bytes()
        self.assertCode('E_SCHEMA_TOO_NEW',self.store.snapshot)
        self.assertEqual(self.store.db.read_bytes(),original)


class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-migration-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.store=create_simple(self.root,schema=1)
    def test_explicit_migration_preserves_domain_bytes_and_old_source(self):
        before=self.store.snapshot()
        with self.assertRaises(SaveError) as e:self.store.execute_once(request(),increment)
        self.assertEqual(e.exception.code,'E_MIGRATION_REQUIRED')
        self.store.migrate(self.root/'backup')
        after=self.store.snapshot();self.assertEqual(after.schema_version,2);self.assertEqual(after.sequence,1)
        self.assertEqual(dict(after.records),dict(before.records))
        m,old,_=inspect_backup(self.root/'backup');self.assertEqual(old.schema_version,1)
        self.assertEqual(self.store.migrate(self.root/'unused')['status'],'ALREADY_CURRENT')
        self.assertFalse((self.root/'unused').exists())
        trace(self._testMethodName,{'source_backup_sha256':m['sha256'],'before_sequence':0,'after_sequence':1,
            'domain_hashes_before':{k:v.sha256 for k,v in before.records.items()},'domain_hashes_after':{k:v.sha256 for k,v in after.records.items()}})
    def test_old_reader_cannot_read_migrated_save(self):
        self.store.migrate(self.root/'backup');original=self.store.db.read_bytes()
        old=open_simple(self.root,reader_version=1)
        with self.assertRaises(SaveError) as e:old.snapshot()
        self.assertEqual(e.exception.code,'E_READER_TOO_OLD')
        self.assertEqual(self.store.db.read_bytes(),original)
        self.assertEqual(self.store.snapshot().schema_version,2)
    def test_migration_can_run_on_backup_without_promoting_it(self):
        self.store.backup(self.root/'source');m,_,_=inspect_backup(self.root/'source')
        result=rehearse_migration(self.root/'source',self.root/'rehearsal')
        self.assertEqual(result['status'],'REHEARSAL_MIGRATED_REVIEW_ONLY')
        self.assertEqual(byte_hash((self.root/'source/snapshot.sqlite3').read_bytes()),m['sha256'])
        self.assertEqual(self.store.snapshot().schema_version,1)
        candidate=Store(self.root/'rehearsal',self.store.anchor_path,expected_store_instance=INSTANCE)
        self.assertEqual(candidate.lookup('any')['status'],'UNKNOWN')
        trace(self._testMethodName,result)
    def test_migration_ddl_error_is_fully_rolled_back(self):
        def fault(point,c):
            if point=='after_migration_ddl':raise RuntimeError('injected ddl interruption')
        self.store.fault=fault
        with self.assertRaises(RuntimeError):self.store.migrate(self.root/'backup')
        self.store.fault=None;s=open_simple(self.root).snapshot()
        self.assertEqual(s.schema_version,1);self.assertEqual(s.sequence,0)
        c=sqlite3.connect(self.store.db)
        self.assertIsNone(c.execute("SELECT name FROM sqlite_master WHERE name='maintenance_audit'").fetchone());c.close()


def crash_test(point,mode='commit'):
    def test(self):
        with tempfile.TemporaryDirectory(prefix='p21-kill-') as t:
            root=Path(t);store=create_simple(root,schema=1 if mode=='migration' else 2)
            before=store.snapshot()
            argv=[sys.executable,'-B',str(ROOT/'tools/fault_worker.py'),str(root),'--point',point,'--mode',mode]
            process=subprocess.run(argv,capture_output=True,text=True,timeout=15)
            self.assertEqual(process.returncode,-9,process.stdout+process.stderr)
            self.assertEqual(json.loads(process.stdout)['point'],point)
            reopened=open_simple(root);s=reopened.snapshot()
            committed=point in ('after_sql_commit','after_anchor','before_reply')
            self.assertEqual(s.sequence,int(committed))
            if mode=='commit':
                self.assertEqual([s.records[n].value['counter'] for n in ('ledger','meta')],[int(committed)]*2)
                result=reopened.execute_once(request('fixture.crash'),increment)
                self.assertEqual(result['duplicate'],committed)
                self.assertEqual(reopened.snapshot().records['meta'].value['counter'],1)
            else:
                self.assertEqual(s.schema_version,2 if committed else 1)
                self.assertEqual(dict(s.records),dict(before.records))
            trace(self._testMethodName,{'argv':argv,'exit_code':process.returncode,'stdout':process.stdout,'stderr':process.stderr,
                'mode':mode,'checkpoint':point,'sequence_after_restart':s.sequence,'schema_after_restart':s.schema_version,
                'domain_hashes':{k:r.sha256 for k,r in s.records.items()},'real_process_SIGKILL':True,'physical_power_cut':False})
    return test


class CrashProcessTests(unittest.TestCase):pass
for point in ['after_begin','after_record:ledger','after_record:meta','after_receipt','before_commit','after_sql_commit','after_anchor','before_reply']:
    setattr(CrashProcessTests,'test_kill_commit_'+point.replace(':','_'),crash_test(point))
for point in ['after_migration_ddl','before_commit','after_sql_commit','after_anchor']:
    setattr(CrashProcessTests,'test_kill_migration_'+point,crash_test(point,'migration'))


if __name__=='__main__':unittest.main()
