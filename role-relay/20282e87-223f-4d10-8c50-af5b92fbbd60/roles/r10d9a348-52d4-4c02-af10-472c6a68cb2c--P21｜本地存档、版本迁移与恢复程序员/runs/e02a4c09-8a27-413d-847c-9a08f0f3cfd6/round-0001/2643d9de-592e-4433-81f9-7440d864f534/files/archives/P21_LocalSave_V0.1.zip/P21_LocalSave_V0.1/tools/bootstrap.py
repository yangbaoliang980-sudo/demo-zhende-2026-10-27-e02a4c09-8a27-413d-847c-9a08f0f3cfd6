"""Local launcher path setup; never modifies any supplied source file."""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
for p in [ROOT/'runtime/persistence',ROOT/'sources/P11',ROOT/'sources/P18',
          ROOT/'sources/P18/upstream/P17',ROOT/'sources/P18/upstream/P13/runtime/framework']:
    sys.path.insert(0,str(p))
