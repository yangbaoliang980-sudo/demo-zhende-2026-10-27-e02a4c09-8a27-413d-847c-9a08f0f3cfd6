"""Verified immutable backups, exact no-loss recovery and format migration.

Older/foreign backups are inspectable and stageable, never automatically
promoted. Discarding newer domain history requires P01/user authorization AND
P11/P17/P18 reconciliation; this release exposes no lossy activation shortcut.
"""
from __future__ import annotations
from pathlib import Path
import os
import sqlite3
import uuid
from .model import SaveError, need, encode, decode, byte_hash, digest
from .fs import no_symlinks, atomic_bytes, write_json, read_json, sync_dir, sync_file, file_lock, io_error
from .store import Store, DB_NAME, CURRENT_SCHEMA, SQL_DIR, _sql_script, _sqlite_error


def _fresh_dir(destination):
    p=no_symlinks(destination)
    need(p.parent.is_dir(),'E_PARENT_MISSING')
    need(not p.exists(),'E_DESTINATION_EXISTS')
    p.mkdir();sync_dir(p.parent)
    return p


def backup(store,destination):
    destination=no_symlinks(destination)
    need(not destination.is_relative_to(store.root),'E_BACKUP_INSIDE_ACTIVE_STORE')
    with store._session() as (c,s):
        out=_fresh_dir(destination)
        target=out/'snapshot.sqlite3.partial'
        dst=None
        try:
            dst=sqlite3.connect(str(target),isolation_level=None)
            c.backup(dst)
            dst.close();dst=None
            sync_file(target);store._hit('backup_after_copy',c)
            data=target.read_bytes()
            marker=store._marker()
            final=out/'snapshot.sqlite3'
            os.chmod(target,0o400);os.replace(target,final);sync_dir(out)
            manifest={'schema_version':'P21-BACKUP/1','database_file':'snapshot.sqlite3',
                      'size_bytes':len(data),'sha256':byte_hash(data),'head':s.anchor(),
                      'store_marker':marker,'authority':False,
                      'notice':'Copy of a coherent save; the embedded head is NOT an external continuity authority.'}
            write_json(out/'manifest.json',manifest,new=True,mode=0o400)
            store._hit('backup_before_complete',c)
            write_json(out/'complete.json',{'manifest_sha256':byte_hash((out/'manifest.json').read_bytes())},new=True,mode=0o400)
            sync_dir(out)
            return {'status':'BACKUP_VERIFIED','directory':str(out),'manifest':manifest}
        except sqlite3.Error as exc:raise _sqlite_error(exc) from exc
        except OSError as exc:raise io_error(exc) from exc
        finally:
            if dst is not None:dst.close()


def inspect_backup(directory):
    root=no_symlinks(directory)
    seal=read_json(root/'complete.json')
    manifest=read_json(root/'manifest.json')
    need(type(manifest) is dict and set(manifest)==set('schema_version database_file size_bytes sha256 head store_marker authority notice'.split()),'E_BACKUP_FORMAT')
    need(seal=={'manifest_sha256':byte_hash((root/'manifest.json').read_bytes())},'E_BACKUP_MANIFEST_CHECKSUM')
    need(manifest.get('schema_version')=='P21-BACKUP/1' and manifest.get('database_file')=='snapshot.sqlite3'
         and manifest.get('authority') is False,'E_BACKUP_FORMAT')
    p=no_symlinks(root/'snapshot.sqlite3')
    need(p.is_file() and p.stat().st_size<=134_217_728,'E_BACKUP_SIZE')
    data=p.read_bytes()
    need(len(data)==manifest['size_bytes'] and byte_hash(data)==manifest['sha256'],'E_BACKUP_CHECKSUM')
    inspector=Store.__new__(Store);inspector.reader_version=CURRENT_SCHEMA
    c=sqlite3.connect(p.as_uri()+'?mode=ro',uri=True,isolation_level=None);c.row_factory=sqlite3.Row
    try:
        c.execute('BEGIN')
        snapshot=inspector._verify_db(c,manifest['store_marker'])
        need(snapshot.anchor()==manifest['head'],'E_BACKUP_HEAD')
    except sqlite3.Error as exc:raise _sqlite_error(exc) from exc
    finally:c.close()
    return manifest,snapshot,data


def compare_backup(store,directory):
    manifest,old,_=inspect_backup(directory)
    current=store.snapshot()
    same_identity=(old.store_instance,old.continuity_ref,old.profile_id)==(
        current.store_instance,current.continuity_ref,current.profile_id)
    return {'schema_version':'P21-RECOVERY-DIFF/1','same_identity':same_identity,
            'backup_sequence':old.sequence,'current_sequence':current.sequence,
            'backup_state_sha256':old.state_sha256,'current_state_sha256':current.state_sha256,
            'changed_records':[{'name':name,'backup_sha256':old.records[name].sha256,
                                'current_sha256':current.records[name].sha256,
                                'backup_revision':old.records[name].revision,'current_revision':current.records[name].revision}
                               for name in sorted(current.records) if old.records[name]!=current.records[name]],
            'activation':'EXACT_HEAD_ONLY' if same_identity and old.anchor()==current.anchor() else 'BLOCKED_REQUIRES_RECONCILIATION',
            'backup_sha256':manifest['sha256'],'automatic_reward_replay':False}


def stage_restore(directory,destination):
    manifest,snapshot,data=inspect_backup(directory)
    out=_fresh_dir(destination)
    atomic_bytes(out/DB_NAME,data,new=True)
    marker=dict(manifest['store_marker']);marker['mode']='RECOVERY_REVIEW_ONLY'
    write_json(out/'store_marker.json',marker,new=True)
    write_json(out/'FROZEN.json',{'schema_version':'P21-FREEZE/1','reason':'RECOVERY_REVIEW_ONLY',
                                'source_backup_sha256':manifest['sha256']},new=True)
    report={'status':'STAGED_READ_ONLY','sequence':snapshot.sequence,'source_backup_sha256':manifest['sha256'],
            'directory':str(out),'new_authority_created':False,'activation':'BLOCKED_DOMAIN_RECONCILIATION_REQUIRED'}
    write_json(out/'restore_report.json',report,new=True)
    return report


def recover_exact(store,directory):
    manifest,snapshot,data=inspect_backup(directory)
    with file_lock(store.lock_path):
        marker=store._marker()
        anchor=read_json(store.anchor_path)
        need(snapshot.anchor()==anchor,'E_DATA_LOSS_OR_FOREIGN_RESTORE_BLOCKED',
             'Only the independently witnessed exact head can be restored; no older-head activation API is supplied.')
        need(manifest['store_marker']==marker,'E_STORE_IDENTITY')
        evidence=store._capture_raw('BEFORE_EXACT_HEAD_RECOVERY')
        write_json(store.root/'FROZEN.json',{'schema_version':'P21-FREEZE/1','reason':'RECOVERY_IN_PROGRESS','evidence':evidence})
        store._frozen='RECOVERY_IN_PROGRESS'
        displaced=store.root/evidence
        try:
            # A stale journal must never be attached to the restored snapshot.
            # Preserve each original sidecar under the same exclusive lock.
            for suffix in ('-journal','-wal','-shm'):
                p=Path(str(store.db)+suffix)
                if p.exists():os.replace(p,displaced/('displaced-'+p.name))
            sync_dir(displaced);sync_dir(store.root)
            store._hit('recovery_before_replace',None)
            atomic_bytes(store.db,data)
            store._hit('recovery_after_replace',None)
            c=store._connect()
            try:
                c.execute('BEGIN')
                loaded=store._verify_db(c,marker)
                need(loaded.anchor()==anchor,'E_RECOVERY_VERIFY')
            finally:c.close()
            report={'status':'EXACT_HEAD_RECOVERED','data_loss':False,'awards_replayed':0,
                    'sequence':snapshot.sequence,'source_backup_sha256':manifest['sha256'],'raw_evidence':evidence}
            write_json(displaced/'recovery_result.json',report,new=True)
            (store.root/'FROZEN.json').unlink();sync_dir(store.root);store._frozen=None
            return report
        except sqlite3.Error as exc:raise _sqlite_error(exc) from exc
        except OSError as exc:raise io_error(exc) from exc


def _upgrade(store,c,s,backup_sha256):
    need(s.schema_version==1,'E_MIGRATION_STEP')
    _sql_script(c,SQL_DIR/'002_maintenance_audit.sql')
    c.execute('UPDATE store_meta SET schema_version=2,min_reader_version=2 WHERE singleton=1')
    c.execute('PRAGMA user_version=2')
    store._hit('after_migration_ddl',c)
    result={'migration':{'from_version':1,'to_version':2,'backup_sha256':backup_sha256,
                         'source_chain_sha256':s.chain_sha256},'domain_bytes_changed':False}
    tx='p21.migrate.'+digest([s.store_instance,s.chain_sha256,1,2])
    proof=store._receipt(c,s,tx,digest(result),'SCHEMA_MIGRATION',result,version=2)
    c.execute('INSERT INTO maintenance_audit VALUES(?,?,?,?,?)',
              (s.sequence+1,1,2,backup_sha256,s.chain_sha256))
    return proof


def migrate(store,backup_destination):
    initial=store.snapshot()
    if initial.schema_version==CURRENT_SCHEMA:return {'status':'ALREADY_CURRENT','sequence':initial.sequence}
    before=backup(store,backup_destination)
    with store._session(writable=True,allow_v1=True) as (c,s):
        need(s.anchor()==before['manifest']['head'],'E_MIGRATION_BACKUP_STALE')
        try:
            proof=_upgrade(store,c,s,before['manifest']['sha256'])
            return store._publish(c,proof)
        except sqlite3.Error as exc:
            if c.in_transaction:c.rollback()
            raise _sqlite_error(exc) from exc


def rehearse_migration(directory,destination,*,fault=None):
    """Upgrade an expendable copy; it remains fenced and cannot serve gameplay."""
    manifest,snapshot,data=inspect_backup(directory)
    need(snapshot.schema_version==1,'E_MIGRATION_STEP')
    staged=stage_restore(directory,destination)
    out=Path(staged['directory'])
    rehearsal=Store.__new__(Store);rehearsal.reader_version=2;rehearsal.fault=fault
    c=sqlite3.connect(str(out/DB_NAME),isolation_level=None);c.row_factory=sqlite3.Row
    try:
        c.execute('PRAGMA synchronous=EXTRA');c.execute('PRAGMA foreign_keys=ON')
        c.execute('BEGIN IMMEDIATE')
        proof=_upgrade(rehearsal,c,snapshot,manifest['sha256'])
        rehearsal._hit('before_commit',c);c.commit();sync_file(out/DB_NAME)
        c.execute('BEGIN');after=rehearsal._verify_db(c,manifest['store_marker']);c.rollback()
        need(all(after.records[k].payload==snapshot.records[k].payload for k in snapshot.records),'E_MIGRATION_DOMAIN_BYTES')
        need(byte_hash((Path(directory)/'snapshot.sqlite3').read_bytes())==manifest['sha256'],'E_SOURCE_BACKUP_CHANGED')
        report={'status':'REHEARSAL_MIGRATED_REVIEW_ONLY','from_version':1,'to_version':2,
                'domain_bytes_changed':False,'source_backup_sha256':manifest['sha256'],
                'source_backup_unchanged':True,'candidate_sequence':after.sequence,
                'candidate_state_sha256':after.state_sha256,'directory':str(out),
                'activation':'BLOCKED_RECONCILIATION_REQUIRED','new_authority_created':False}
        write_json(out/'migration_rehearsal.json',report,new=True)
        return report
    except sqlite3.Error as exc:raise _sqlite_error(exc) from exc
    finally:
        if c.in_transaction:c.rollback()
        c.close()
