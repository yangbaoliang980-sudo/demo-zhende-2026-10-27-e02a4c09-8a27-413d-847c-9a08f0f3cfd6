"""Observe the CURRENT scratch host; never infer a target Windows installation."""
import bootstrap  # noqa: F401
import argparse
import datetime
import json
import os
from pathlib import Path
import platform
import sqlite3
import tempfile
from p21_persistence.fs import sync_dir,file_lock


def probe():
    checks={}
    with tempfile.TemporaryDirectory(prefix='p21-probe-') as t:
        root=Path(t)
        try:sync_dir(root);checks['directory_fsync']='PASS'
        except OSError as e:checks['directory_fsync']='FAIL:'+type(e).__name__
        try:
            with file_lock(root/'probe.lock'):checks['posix_lock']='PASS'
        except Exception as e:checks['posix_lock']='BLOCKED:'+type(e).__name__
        c=sqlite3.connect(str(root/'probe.sqlite3'),isolation_level=None)
        c.execute('PRAGMA journal_mode=DELETE');c.execute('PRAGMA synchronous=EXTRA');c.execute('PRAGMA foreign_keys=ON')
        checks['sqlite_journal_mode']=c.execute('PRAGMA journal_mode').fetchone()[0]
        checks['sqlite_synchronous']=c.execute('PRAGMA synchronous').fetchone()[0]
        checks['sqlite_foreign_keys']=c.execute('PRAGMA foreign_keys').fetchone()[0]
        c.close()
    return {'schema_version':'P21-ENVIRONMENT-PROBE/1','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'observed_host':{'system':platform.system(),'release':platform.release(),'machine':platform.machine(),
                             'python':platform.python_version(),'sqlite':sqlite3.sqlite_version,'os_name':os.name},
            'checks':checks,'target_platform':{'status':'BLOCKED','os':None,'engine':None,'actual_project':None},
            'Windows':'NOT_RUN','actual_power_cut':'NOT_RUN','Anki':'NOT_RUN',
            'network_policy_snapshot':'UNAVAILABLE_IN_CURRENT_EXECUTOR','environment_status_tool':'NOT_EXPOSED',
            'note':'Current Linux execution evidence only; not a P13/P34 target platform acceptance.'}


def main():
    p=argparse.ArgumentParser();p.add_argument('--output');a=p.parse_args();value=probe()
    text=json.dumps(value,ensure_ascii=False,indent=2)+'\n'
    if a.output:Path(a.output).write_text(text,encoding='utf-8')
    print(text,end='')
    return 0


if __name__=='__main__':raise SystemExit(main())
