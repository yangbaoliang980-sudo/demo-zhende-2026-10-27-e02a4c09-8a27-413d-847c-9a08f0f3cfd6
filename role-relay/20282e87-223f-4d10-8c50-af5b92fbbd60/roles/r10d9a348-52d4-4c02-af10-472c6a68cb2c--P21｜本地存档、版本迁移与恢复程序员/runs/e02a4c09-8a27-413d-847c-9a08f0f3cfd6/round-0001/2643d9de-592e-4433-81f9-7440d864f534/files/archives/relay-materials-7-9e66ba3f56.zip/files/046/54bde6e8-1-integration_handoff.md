# P19 接收与正式接线说明

本包只交付本岗源码与作者证据，跨岗位最终合并由用户指定的 EXT-INTEGRATOR 执行。所有上游原件在 `upstream/` 按原字节保存，禁止在这里替其 owner 修复。

## 1. 验收前先复现

1. 校验外层交付回执中的 ZIP 大小/SHA-256，解压进入 `P19_BattleHUD_V0.1`。
2. 执行 `python -B tools/verify_delivery.py`，核对逐文件完整性及上游原件。
3. 执行 `python -B battle_command_tests.py`，应看到 98 个 JS case 与 18 个 Python case；不要把 Node 文件级加载结果当逐项测试结果。本包使用直接测试入口规避已观测的报告粒度问题。
4. 执行 `python -B run_ui.py`，本机浏览器访问终端打印的地址；可按 README 操作并复核 `control_state_table.tsv`。
5. 审阅 `verification_status.json`、失败历史及 `blockers.json`。`preflight.py` 返回 3/BLOCKED 是当前正式门禁的预期结果。

## 2. 下一位接收内容

| 接收方 | 工件 | 要求 |
| --- | --- | --- |
| P23 | HUD 页面/CSS、截图、控件状态表、锚点提案 | 接收或修改 UX/分辨率/目标选择与回合按钮锚点 |
| P29 | presentation_adapter 实现、spec、事件边界测试 | 通过公共 bridge 装配真实动效，不修改 P19 业务绑定 |
| P32 | 完整源码、fixtures、作者日志、浏览器脚本 | 独立复测；不得以作者测试代签 |
| P33 | 启动入口、操作说明、错误/后台场景 | 目标 Windows 浏览器/引擎、输入设备、缩放、窗口切换人工验收 |
| P39 | 整包、manifest、receipt、preflight | 在正式引擎/路径/依赖门禁通过后处理候选构建 |
| P13/P14/P15/P16 | API、状态绑定、RFC、原 schema 哈希 | 受理正式一致读取、合法性显示查询、已提交意图与恢复端口 |
| P24/P25/P37 | 占位说明、字体来源/许可、实际截图 | 正式素材替换、风格与合规各自验收 |
| P35 | 全部运行回执和证据分层 | 独立决定接收，不把 BLOCKED/NOT_RUN 改写为 PASS |

回执中的 `PREPARED_NOT_ACKNOWLEDGED` 仅代表待交接材料已就绪，没有发送消息或宣称对方确认。

## 3. 未来真实工程装配门禁

先由 P13 给出 actual_path_mapping、引擎/目标 OS、固定 base commit、do_not_touch 和可写白名单。当前收到的 3 条 P19 路径全部空且禁止正式写入；本轮新建隔离包依据的是用户允许隔离研发的任务授权，不等于 P13 已授权正式路径。

接线顺序：由正式宿主提供原 BattleSnapshot 一致读取与用户命令通道 → 由 P15/P13 提供只读卡牌合法性/费用视图 → 由 P14/P16/P13 给出原子提交后可读的意图 → P23/P24 确认布局与资产 → P29 驱动经公共 bridge 接入 → P32/P33/P35 运行各自门禁。不得把 `native_fixture.py`、`support.py` 的默认种子/HP/固定敌动作移植为正式内容政策。

P19 本地 Context 绑定 battle_id/revision/snapshot SHA，当前版本只接受 FIXTURE 来源。P13 若新增正式共享 view，必须批准新的版本并安排 P19 明确转换，不能通过把来源字段改为字符串“生产”绕过门禁。原 `BattleSnapshot` 关闭附加字段，所以不得直接往里塞 intent 或 card cost。

## 4. 执行真实浏览器检查

本轮已使用 Playwright 1.62.1 + Chromium 153.0.8010.0；这些测试工具不是 UI 运行时依赖。其他机器安装可用的 Playwright/Chromium 后：

```bash
node tests/battle_ui_unit/browser_tests.mjs /absolute/path/to/new-evidence
```

脚本自行启动临时 loopback host，结束时关闭。`P19_PLAYWRIGHT_MODULE` 可指向已安装 Playwright 包；`P19_BROWSER_EXECUTABLE` 可指定已有 Chromium；`P19_PYTHON` 可指定 Python 3.12。命令前请使用当前 shell 的环境变量设置语法，不要把 Linux 写法直接粘贴进 Windows CMD。

所有截图来自实际 DOM 渲染，不是效果图。人物和敌方编号只是占位。390 宽度检查仅用于发现溢出，不代表启动 P42 移动移植。

## 5. 异常处理与所有权

UI 自身布局/输入/绑定问题归 P19；UX 锚点归 P23；共享字段归 P13/P14；卡牌校验归 P15；AI 预告身份归 P16；物理去重/恢复承诺归 P21/P14；正式美术归 P24/P25/P26/P27。发现非本岗缺陷时保留 base SHA 并交 RFC，不覆盖上游。

UNKNOWN 命令在当前页面生命周期内保留原 ID；刷新整个浏览器页面会失去该内存命令，正式重启恢复需 owner 提供持久命令回执/查询协议，当前为 BLOCKED。测试 host 关闭后内存战斗消失是夹具限制，不是存档功能。

P19 已修复的作者缺陷及原失败日志保留在 `defect_log.json` 和 `evidence/`。独立关单仍为 NOT_RUN。正式验收不可只看最后一份成功日志。
