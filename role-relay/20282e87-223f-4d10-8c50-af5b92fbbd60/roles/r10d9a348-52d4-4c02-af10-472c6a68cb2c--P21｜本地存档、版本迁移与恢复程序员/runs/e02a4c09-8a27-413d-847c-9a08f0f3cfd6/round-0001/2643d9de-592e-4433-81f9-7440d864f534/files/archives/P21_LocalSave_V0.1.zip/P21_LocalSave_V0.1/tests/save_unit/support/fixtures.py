from pathlib import Path
from copy import deepcopy
import importlib.util
import json
import os
import sys
import tempfile
import uuid
from p21_persistence import Store,Record,Update,Mutation,Claim,Request,digest
from p21_persistence.adapters import (P17CommitAdapter,P18CommitAdapter,P11AtomicAdapter,
                                     StoreFenceAuthority)

ROOT=Path(__file__).resolve().parents[3]
INSTANCE='fixture.store'
CONTINUITY='fixture.continuity'
PROFILE='fixture.save.A'


def trace(name,value):
    path=os.environ.get('P21_EVIDENCE_DIR')
    if path:
        out=Path(path)/'cases';out.mkdir(exist_ok=True)
        (out/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def simple_records():
    return [Record.from_value(n,0,{'schema_version':'P21-TEST-DOMAIN/1','counter':0})
            for n in ['ledger','meta','stage']]


def create_simple(root,schema=2):
    root=Path(root);(root/'authority').mkdir(exist_ok=True)
    return Store.create(root/'save',root/'authority/head.json',simple_records(),profile_id=PROFILE,
                        store_instance=INSTANCE,continuity_ref=CONTINUITY,schema_version=schema)


def open_simple(root,**kwargs):
    root=Path(root)
    return Store(root/'save',root/'authority/head.json',expected_store_instance=INSTANCE,**kwargs)


def request(tx='fixture.tx',kind='STUDY_LEDGER_WALLET',body=None):
    return Request(tx,digest(body if body is not None else ['original-request',tx]),kind,INSTANCE,CONTINUITY)


def increment(s,names=('ledger','meta'),claims=()):
    rows=[]
    for name in names:
        old=s.records[name];v=old.value;v['counter']+=1
        rows.append(Update(Record.from_value(name,old.revision+1,v),old.sha256))
    return Mutation(tuple(rows),tuple(claims))


def load_module(name,path,package=False):
    if name in sys.modules:return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path,submodule_search_locations=[str(path.parent)] if package else None)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return module


def originals():
    support=ROOT/'sources/P18/tests/support'
    load_module('_p21_original_p18_support',support/'__init__.py',True)
    a=load_module('_p21_original_p18_support.authority',support/'authority.py')
    w=load_module('_p21_original_p18_support.p17_port',support/'p17_port.py')
    p=load_module('_p21_original_p11_ports',ROOT/'sources/P11/tests/support/simulated_ports.py')
    return a,w,p


class NativeStageFixture:
    """Original P17/P18 algorithms; synthetic entry/battle evidence only."""
    def __init__(self,root):
        from stage_runtime import load_catalog,empty_state,StagePlanner,FrozenMessage
        from ledger_runtime.types import new_ledger
        a,w,_=originals();self.authority=a.FixtureAuthority();self.wallet=w.P17ContractPort()
        self.catalog=load_catalog();self._planner_type=StagePlanner;self.FrozenMessage=FrozenMessage
        meta=self.wallet.bootstrap(PROFILE,INSTANCE,CONTINUITY)
        stage=empty_state(self.catalog,player_save_scope_id=PROFILE,store_instance=INSTANCE,continuity_ref=CONTINUITY)
        root=Path(root);(root/'authority').mkdir()
        self.store=Store.create(root/'save',root/'authority/head.json',[
            Record.from_value('meta',meta.value['revision'],meta.value),
            Record.from_value('stage',0,stage.value),Record.from_value('ledger',0,new_ledger())],
            profile_id=PROFILE,store_instance=INSTANCE,continuity_ref=CONTINUITY)
        self.adapter=P18CommitAdapter(self.store,self.planner,lambda s:self.wallet)
        self.serial=0

    def planner(self,s):
        a,_,_=originals();copy=a.FixtureAuthority()
        for name in ['entries','battles','controls']:
            setattr(copy,name,dict(getattr(self.authority,name)))
        return self._planner_type(self.catalog,StoreFenceAuthority(s,copy))

    @classmethod
    def attach(cls,root,authority_data=None):
        from stage_runtime import load_catalog,StagePlanner,FrozenMessage
        obj=cls.__new__(cls);a,w,_=originals()
        obj.authority=a.FixtureAuthority();obj.wallet=w.P17ContractPort();obj.catalog=load_catalog()
        obj._planner_type=StagePlanner;obj.FrozenMessage=FrozenMessage;obj.serial=0
        obj.store=open_simple(root)
        for name,items in (authority_data or {}).items():
            assert name in ('entries','battles','controls')
            setattr(obj.authority,name,{k:FrozenMessage.from_value(v) for k,v in items.items()})
        obj.adapter=P18CommitAdapter(obj.store,obj.planner,lambda s:obj.wallet)
        return obj

    def snapshots(self):
        s=self.store.snapshot()
        return self.FrozenMessage(s.records['stage'].payload),self.FrozenMessage(s.records['meta'].payload)

    def prepare(self,kind,payload,request_id=None):
        from stage_runtime import command
        from stage_runtime.transactions import prepare_atomic
        self.serial+=1
        def project(s):
            stage=self.FrozenMessage(s.records['stage'].payload);meta=self.FrozenMessage(s.records['meta'].payload)
            planner=self.planner(s)
            req=command(stage,self.catalog,request_id or 'native.req.'+str(self.serial),kind,payload)
            r=planner.plan(req,stage)
            if r.status!='CANDIDATE':return r
            return prepare_atomic(planner,r.candidate,stage,meta,self.wallet)
        return self.store.read_consistent(project)

    def enter(self,battle_id='native.battle.A',stage_id='MOCK_P07_STAGE_001'):
        stage,meta=self.snapshots()
        ref=self.authority.issue_entry(self.catalog,stage,meta,self.wallet,stage_id,battle_id)
        bundle=self.prepare('ENTER',{'stage_id':stage_id,'battle_id':battle_id,'entry_ref':ref,'seed':1})
        return bundle,self.adapter.submit(bundle)

    def settle(self,battle_id='native.battle.A',outcome='WIN'):
        stage,_=self.snapshots()
        result=self.authority.issue_battle(stage,self.catalog,battle_id,outcome=outcome)
        bundle=self.prepare('SETTLE',{'result':result.value})
        return bundle,self.adapter.submit(bundle)

    def balance(self):
        _,meta=self.snapshots();_,w,_=originals()
        return next((r['available'] for r in self.wallet.balances(meta) if r['resource_id']==w.TOKEN),0)


class SyntheticLegacyWalletBinding:
    """TEST ONLY conversion in a synthetic meta envelope, NOT P17's real model.

    This verifies P21's P11-port atomicity without silently inventing a native
    P11-to-P17 mapping. It has exactly one wallet, inside the meta document.
    """
    def project(self,record):
        assert record.schema_version=='P21-TEST-LEGACY-WALLET/1'
        return deepcopy(record.value['wallet'])
    def materialize(self,delta,before):
        from ledger_runtime.types import digest as p11_digest
        v=before.value;wallet=v['wallet']
        if delta.expected_wallet_version!=wallet['version'] or delta.wallet_before_sha256!=p11_digest(wallet):
            raise AssertionError('synthetic wallet CAS')
        for unit,amount in delta.changes.items():
            wallet['balances'][unit]=wallet['balances'].get(unit,0)+amount
            assert wallet['balances'][unit]>=0
        wallet['sources'][delta.family_key]=deepcopy(delta.source_after);wallet['version']+=1
        return Record.from_value('meta',before.revision+1,v)
    def validate(self,delta,before,after):
        assert self.materialize(delta,before)==after


class NativeLedgerFixture:
    def __init__(self,root):
        from ledger_runtime import StudyLedger
        from ledger_runtime.types import new_ledger
        _,_,p=originals();self.ports=p;self.policy=p.FixturePolicy();self.wallet=p.FixtureWallet();self.evidence=p.FixtureEvidence()
        root=Path(root);(root/'authority').mkdir()
        self.store=Store.create(root/'save',root/'authority/head.json',[
            Record.from_value('ledger',0,new_ledger()),
            Record.from_value('meta',0,{'schema_version':'P21-TEST-LEGACY-WALLET/1','wallet':{'version':0,'balances':{},'sources':{}}}),
            Record.from_value('stage',0,{'schema_version':'P21-TEST-DOMAIN/1','counter':0})],
            profile_id='fixture:player',store_instance=INSTANCE,continuity_ref=CONTINUITY)
        self.adapter=P11AtomicAdapter(self.store,SyntheticLegacyWalletBinding())
        self.ledger=StudyLedger(self.adapter,self.wallet,self.evidence,self.policy)
    def balance(self):
        return self.adapter.snapshot().wallet['balances'].get(self.ports.UNIT,0)
