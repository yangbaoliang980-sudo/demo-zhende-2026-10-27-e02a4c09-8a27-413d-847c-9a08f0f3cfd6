from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, io, stat

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'p21_work'
OUT = WORK / 'input_archives'
OUT.mkdir(parents=True, exist_ok=True)
archives, members, checks, attachments = {}, [], [], []
trees = [json.loads((WORK / f'github_tree_{i}.json').read_text()) for i in (1,2)]
git_index = {}
for tree in trees:
    for f in tree['tree']:
        if f['type'] == 'blob': git_index.setdefault(f['sha'], []).append({'commit':tree['sha'], 'path':f['path'], 'size_bytes':f['size']})

def digest(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def walk(data, origin, depth=0):
    h = digest(data)
    if h in archives:
        archives[h]['also_seen_at'].append(origin)
        return
    if depth > 20: raise ValueError('archive depth limit')
    z = zipfile.ZipFile(io.BytesIO(data))
    total = sum(f.file_size for f in z.infolist())
    if total > 1_000_000_000: raise ValueError('expanded size limit')
    bad = z.testzip()
    if bad: raise ValueError(('CRC',origin,bad))
    folder = OUT / h[:16]
    folder.mkdir(exist_ok=True)
    archives[h] = {'origin':origin,'also_seen_at':[],'size_bytes':len(data),'sha256':h,'git_blob_sha1':blob(data),'git_matches':git_index.get(blob(data),[]),'members':len(z.infolist()),'expanded_bytes':total,'crc':'PASS','local_dir':str(folder.relative_to(ROOT))}
    names = z.namelist()
    if len(names) != len(set(names)): raise ValueError('duplicate members')
    for f in z.infolist():
        p = PurePosixPath(f.filename)
        if p.is_absolute() or '..' in p.parts or '\\' in f.filename or stat.S_ISLNK(f.external_attr >> 16): raise ValueError('unsafe member')
        if f.is_dir(): continue
        b = z.read(f.filename)
        dst = folder.joinpath(*p.parts);dst.parent.mkdir(parents=True, exist_ok=True);dst.write_bytes(b)
        members.append({'archive_sha256':h,'member_path':f.filename,'size_bytes':len(b),'sha256':digest(b),'git_blob_sha1':blob(b),'local_path':str(dst.relative_to(ROOT))})
        if f.filename.lower().endswith('.zip'): walk(b,origin+'!/'+f.filename,depth+1)
    if 'manifest.json' in names:
        m = json.loads(z.read('manifest.json').decode('utf-8-sig'))
        if isinstance(m,dict) and 'Original relay attachments' in m.get('purpose',''):
            for f in m['files']:
                b=z.read(f['path']);ok=len(b)==f['size'] and digest(b)==f['sha256']
                checks.append({'archive_sha256':h,'path':f['path'],'original_name':f['originalName'],'size_bytes':len(b),'sha256':digest(b),'status':'PASS' if ok else 'FAIL'})
                if not ok:raise ValueError(('manifest mismatch',origin,f['path']))

for p in sorted((ROOT/'upload').iterdir()):
    b=p.read_bytes()
    attachments.append({'filename':p.name,'local_path':str(p.relative_to(ROOT)),'size_bytes':len(b),'sha256':digest(b),'git_blob_sha1':blob(b),'git_matches':git_index.get(blob(b),[])})
    if p.suffix=='.zip':walk(b,p.name)
result={'attachments':attachments,'archives':list(archives.values()),'members':members,'relay_checks':checks,'summary':{'attachments':len(attachments),'unique_archives':len(archives),'expanded_file_members':len(members),'relay_checks':len(checks),'failures':sum(c['status']!='PASS' for c in checks)}}
(WORK/'input_inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result['summary'],ensure_ascii=False))
for a in archives.values():
    if any(x in a['origin'].split('!/')[-1] for x in ['P11_','P13_','P17_','P18_','P20_','V6.0_完整']): print(a['origin'].split('!/')[-1],a['local_dir'],a['sha256'])
