"""SQLite transaction owner. One file contains all domains and durable receipts.

This is a real on-disk isolated implementation, not a game integration. The
composition root must provide owner validators. A string in a request cannot
install a validator or grant authority. Never point this API at an Anki file.
"""
from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
import os
import sqlite3
import time
import uuid
from .model import (SaveError, CommitUnknown, Record, Mutation, Request, Snapshot,
                    OWNERS, KINDS, need, integer, identifier, hash_value,
                    encode, decode, digest, byte_hash)
from .fs import (no_symlinks, file_lock, sync_dir, sync_file, write_json, read_json,
                 atomic_bytes, platform_check, io_error)

APPLICATION_ID = 0x50323153
CURRENT_SCHEMA = 2
PACKAGE_ROOT = Path(__file__).resolve().parents[3]
SQL_DIR = PACKAGE_ROOT / 'schema/save'
DB_NAME = 'game.p21-save.sqlite3'
ORIGIN = 'P21_SQLITE_ISOLATED'
VERSION_ERRORS = {'E_READER_TOO_OLD','E_SCHEMA_TOO_NEW','E_MIGRATION_REQUIRED'}


def _sql_script(c, path):
    # Versioned P21-owned static SQL, never caller input. No executescript's implicit COMMIT.
    for statement in path.read_text(encoding='utf-8').split(';'):
        if statement.strip(): c.execute(statement)


def _sqlite_error(exc):
    code = getattr(exc,'sqlite_errorcode',0) & 255
    if code == sqlite3.SQLITE_FULL: return SaveError('E_DISK_FULL',retryable=True)
    if code in (sqlite3.SQLITE_BUSY,sqlite3.SQLITE_LOCKED): return SaveError('E_BUSY',retryable=True)
    if code in (sqlite3.SQLITE_CORRUPT,sqlite3.SQLITE_NOTADB): return SaveError('E_CORRUPT')
    if code == sqlite3.SQLITE_READONLY: return SaveError('E_READ_ONLY')
    if code == sqlite3.SQLITE_CONSTRAINT: return SaveError('E_CONSTRAINT')
    return SaveError('E_SQLITE_IO',getattr(exc,'sqlite_errorname',type(exc).__name__))


class Store:
    """Opening never creates a save, resets a fence, or grants resources.

    All runtime operations take the same cross-process exclusive lock before
    opening SQLite; domain validators run inside BEGIN IMMEDIATE. This small
    isolated release favors an explicit consistent boundary over read throughput.
    """
    def __init__(self, directory, anchor_path, *, expected_store_instance,
                 reader_version=CURRENT_SCHEMA, fault=None):
        platform_check()
        self.root = no_symlinks(directory)
        self.anchor_path = no_symlinks(anchor_path)
        need(self.root.is_dir(),'E_STORE_MISSING')
        need(not self.anchor_path.is_relative_to(self.root),'E_ANCHOR_MUST_BE_OUTSIDE_SAVE')
        identifier(expected_store_instance)
        need(type(reader_version) is int and 1 <= reader_version <= CURRENT_SCHEMA,'E_READER_VERSION')
        self.expected_instance=expected_store_instance
        self.reader_version=reader_version
        self.db=self.root/DB_NAME
        self.lock_path=self.root/'.p21.lock'
        self.fault=fault
        self._frozen=None

    @classmethod
    def create(cls, directory, anchor_path, records, *, profile_id,
               store_instance=None, continuity_ref=None, schema_version=CURRENT_SCHEMA,
               mode='isolated'):
        platform_check(); need(mode=='isolated','E_PRODUCTION_NOT_AUTHORIZED')
        root=no_symlinks(directory); anchor=no_symlinks(anchor_path)
        identifier(profile_id)
        instance=store_instance or 'p21.store.'+uuid.uuid4().hex
        continuity=continuity_ref or 'p21.continuity.'+uuid.uuid4().hex
        identifier(instance);identifier(continuity)
        need(schema_version in (1,2),'E_SCHEMA_VERSION')
        need(not anchor.is_relative_to(root),'E_ANCHOR_MUST_BE_OUTSIDE_SAVE')
        need(not anchor.exists(),'E_ANCHOR_EXISTS')
        need(anchor.parent.is_dir(),'E_PARENT_MISSING','create a separate authority directory explicitly')
        if root.exists():need(root.is_dir() and not any(root.iterdir()),'E_DESTINATION_NOT_EMPTY')
        else:root.mkdir(parents=False);sync_dir(root.parent)
        records=tuple(records)
        need({r.name for r in records} == set(OWNERS) and len(records)==3,'E_GENESIS_RECORD_SET')
        need(all(type(r) is Record for r in records),'E_RECORD_TYPE')
        marker={'schema_version':'P21-STORE-MARKER/1','mode':'ISOLATED',
                'store_instance':instance,'continuity_ref':continuity,'profile_id':profile_id}
        write_json(root/'store_marker.json',marker,new=True)
        c=sqlite3.connect(str(root/DB_NAME),isolation_level=None,timeout=2)
        c.row_factory=sqlite3.Row
        try:
            need(c.execute('PRAGMA journal_mode=DELETE').fetchone()[0]=='delete','E_JOURNAL_MODE')
            c.execute('PRAGMA synchronous=EXTRA');c.execute('PRAGMA foreign_keys=ON')
            c.execute('BEGIN IMMEDIATE')
            c.execute(f'PRAGMA application_id={APPLICATION_ID}')
            _sql_script(c,SQL_DIR/'001_initial.sql')
            if schema_version==2:_sql_script(c,SQL_DIR/'002_maintenance_audit.sql')
            for r in records:
                c.execute('INSERT INTO documents VALUES(?,?,?,?,?,?)',
                          (r.name,r.owner,r.schema_version,r.revision,r.payload,r.sha256))
            state=cls._state_hash(c)
            chain=digest(['P21-GENESIS/1',instance,continuity,profile_id,schema_version,state])
            c.execute('INSERT INTO store_meta VALUES(1,?,?,?,?,?,?,?,?,?,?,?)',
                      (instance,continuity,profile_id,schema_version,schema_version,
                       state,chain,schema_version,0,state,chain))
            c.execute(f'PRAGMA user_version={schema_version}')
            c.commit()
            sync_file(root/DB_NAME);sync_dir(root)
            head={'schema_version':'P21-CONTINUITY/1','store_instance':instance,
                  'continuity_ref':continuity,'profile_id':profile_id,'sequence':0,
                  'state_sha256':state,'chain_sha256':chain,'save_schema_version':schema_version}
            write_json(anchor,head,new=True)
        except BaseException:
            if c.in_transaction:c.rollback()
            # Preserve incomplete creation. Opening without a completed anchor is blocked.
            raise
        finally:c.close()
        return cls(root,anchor,expected_store_instance=instance)

    def _hit(self,point,c=None):
        if self.fault is not None:self.fault(point,c)

    def _marker(self):
        marker=read_json(self.root/'store_marker.json')
        need(type(marker) is dict and set(marker)==set('schema_version mode store_instance continuity_ref profile_id'.split()),'E_STORE_MARKER')
        need(marker.get('schema_version')=='P21-STORE-MARKER/1','E_STORE_MARKER')
        need(marker.get('mode')=='ISOLATED','E_RECOVERY_REVIEW_ONLY')
        need(marker.get('store_instance')==self.expected_instance,'E_STORE_INSTANCE')
        return marker

    def _connect(self):
        no_symlinks(self.db);need(self.db.is_file(),'E_STORE_MISSING')
        c=sqlite3.connect(self.db.as_uri()+'?mode=rw',uri=True,isolation_level=None,timeout=2)
        try:
            c.row_factory=sqlite3.Row
            c.execute('PRAGMA synchronous=EXTRA')
            c.execute('PRAGMA foreign_keys=ON')
            c.execute('PRAGMA busy_timeout=2000')
            need(c.execute('PRAGMA synchronous').fetchone()[0]==3,'E_SYNCHRONOUS_MODE')
            return c
        except BaseException:
            c.close();raise

    @staticmethod
    def _state_hash(c):
        docs=[dict(r) for r in c.execute('SELECT name,owner,schema_version,revision,sha256 FROM documents ORDER BY name')]
        claims=[dict(r) for r in c.execute('SELECT * FROM claims ORDER BY profile_id,namespace,claim_key')]
        return digest({'documents':docs,'claims':claims})

    def _verify_db(self,c,marker=None):
        """Verify all receipts and the live state before serving a trusted read."""
        need(c.execute('PRAGMA application_id').fetchone()[0]==APPLICATION_ID,'E_APPLICATION_ID')
        version=c.execute('PRAGMA user_version').fetchone()[0]
        need(version in (1,2),'E_SCHEMA_TOO_NEW' if version>2 else 'E_SCHEMA_INVALID')
        need(version<=self.reader_version,'E_READER_TOO_OLD')
        need(c.execute('PRAGMA journal_mode').fetchone()[0]=='delete','E_JOURNAL_MODE')
        need([r[0] for r in c.execute('PRAGMA integrity_check')] == ['ok'],'E_CORRUPT')
        need(not c.execute('PRAGMA foreign_key_check').fetchall(),'E_FOREIGN_KEY_CORRUPT')
        rows=c.execute('SELECT * FROM store_meta').fetchall()
        need(len(rows)==1,'E_STORE_META');m=dict(rows[0])
        need(m['schema_version']==version and m['min_reader_version']==version,'E_SCHEMA_META')
        marker=self._marker() if marker is None else marker
        for k in ('store_instance','continuity_ref','profile_id'):
            identifier(m[k]);need(m[k]==marker[k],'E_STORE_IDENTITY',k)
        need(m['min_reader_version']<=self.reader_version,'E_READER_TOO_OLD')
        records={}
        for row in c.execute('SELECT * FROM documents ORDER BY name'):
            r=Record(row['name'],row['owner'],row['schema_version'],row['revision'],row['payload'])
            need(r.sha256==row['sha256'],'E_RECORD_CHECKSUM',r.name);records[r.name]=r
        need(set(records)==set(OWNERS),'E_RECORD_SET')
        previous=m['genesis_chain_sha256'];state=m['genesis_state_sha256']
        need(previous==digest(['P21-GENESIS/1',m['store_instance'],m['continuity_ref'],m['profile_id'],m['genesis_schema_version'],state]),'E_GENESIS_CHECKSUM')
        sequence=0;schema=m['genesis_schema_version'];expected_audits={}
        for row in c.execute('SELECT * FROM transactions ORDER BY sequence'):
            sequence+=1;r=decode(row['receipt'])
            need(encode(r)==row['receipt'] and byte_hash(row['receipt'])==row['receipt_sha256'],'E_RECEIPT_CHECKSUM')
            need(type(r) is dict and set(r)==set('schema_version transaction_id request_sha256 kind store_instance continuity_ref profile_id sequence previous_chain_sha256 before_state_sha256 state_sha256 previous_schema_version save_schema_version document_heads result origin durable'.split()),'E_RECEIPT_FORMAT')
            need(r['schema_version']=='P21-COMMIT-RECEIPT/1' and r['origin']==ORIGIN and r['durable'] is True,'E_RECEIPT_FORMAT')
            need(type(r['result']) is dict and r['kind'] in {*KINDS,'SCHEMA_MIGRATION'},'E_RECEIPT_FORMAT')
            need(row['sequence']==sequence==r['sequence'],'E_RECEIPT_SEQUENCE')
            need(row['transaction_id']==r['transaction_id'] and row['request_sha256']==r['request_sha256'],'E_RECEIPT_BINDING')
            need(row['previous_chain_sha256']==previous==r['previous_chain_sha256'],'E_CHAIN_LINK')
            need(r['before_state_sha256']==state and r['previous_schema_version']==schema,'E_STATE_CHAIN')
            need(r['store_instance']==m['store_instance'] and r['continuity_ref']==m['continuity_ref'] and r['profile_id']==m['profile_id'],'E_RECEIPT_IDENTITY')
            previous=digest(['P21-CHAIN/1',previous,row['receipt_sha256']])
            need(previous==row['chain_sha256'],'E_CHAIN_CHECKSUM')
            state=r['state_sha256'];schema=r['save_schema_version']
            if r['kind']=='SCHEMA_MIGRATION':
                need(r['previous_schema_version']==1 and schema==2 and 'migration' in r['result'],'E_MIGRATION_AUDIT')
                expected_audits[sequence]=r['result']['migration']
            else:need(r['previous_schema_version']==schema,'E_SCHEMA_CHAIN')
        need(sequence==m['sequence'] and previous==m['chain_sha256'],'E_HEAD_CHECKSUM')
        need(state==m['state_sha256']==self._state_hash(c),'E_STATE_CHECKSUM')
        need(schema==version,'E_SCHEMA_CHAIN')
        for claim in c.execute('SELECT * FROM claims'):
            need(claim['profile_id']==m['profile_id'],'E_CLAIM_SCOPE')
        if version==2:
            actual_audits={}
            for audit in c.execute('SELECT * FROM maintenance_audit'):
                r=c.execute('SELECT receipt FROM transactions WHERE sequence=?',(audit['sequence'],)).fetchone()
                need(r is not None,'E_MIGRATION_AUDIT')
                actual_audits[audit['sequence']]={
                    'from_version':audit['from_version'],'to_version':audit['to_version'],
                    'backup_sha256':audit['backup_sha256'],'source_chain_sha256':audit['source_chain_sha256']}
            need(actual_audits==expected_audits,'E_MIGRATION_AUDIT')
        else:need(not expected_audits,'E_MIGRATION_AUDIT')
        return Snapshot(m['store_instance'],m['continuity_ref'],m['profile_id'],sequence,
                        version,state,previous,records)

    def _sync_anchor(self,c,snapshot):
        need(self.anchor_path.is_file(),'E_CONTINUITY_MISSING')
        a=read_json(self.anchor_path)
        need(set(a)==set(snapshot.anchor()),'E_CONTINUITY_SHAPE')
        need(a['schema_version']=='P21-CONTINUITY/1','E_CONTINUITY_VERSION')
        for k in ('store_instance','continuity_ref','profile_id'):
            need(a[k]==getattr(snapshot,k),'E_CONTINUITY_IDENTITY',k)
        integer(a['sequence'])
        need(a['sequence']<=snapshot.sequence,'E_ROLLBACK_DETECTED')
        if a['sequence']==snapshot.sequence:
            need(a==snapshot.anchor(),'E_CONTINUITY_MISMATCH');return
        # SQLite committed, but the process died before publishing the external
        # acknowledged high-water mark. Recover only a verified descendant.
        if a['sequence']==0:
            m=c.execute('SELECT * FROM store_meta').fetchone()
            checkpoint=(m['genesis_chain_sha256'],m['genesis_state_sha256'],m['genesis_schema_version'])
        else:
            r=c.execute('SELECT chain_sha256,receipt FROM transactions WHERE sequence=?',(a['sequence'],)).fetchone()
            need(r is not None,'E_CONTINUITY_GAP');v=decode(r['receipt'])
            checkpoint=(r['chain_sha256'],v['state_sha256'],v['save_schema_version'])
        need(checkpoint==(a['chain_sha256'],a['state_sha256'],a['save_schema_version']),'E_CONTINUITY_FORK')
        write_json(self.anchor_path,snapshot.anchor())

    def _capture_raw(self,reason):
        """Copy raw files before any recovery; never open corrupt data for repair."""
        out=no_symlinks(self.root/'recovery_evidence'/('raw-'+uuid.uuid4().hex))
        out.mkdir(parents=True)
        files=[]
        for path in [self.db,Path(str(self.db)+'-journal'),Path(str(self.db)+'-wal'),Path(str(self.db)+'-shm'),self.root/'store_marker.json']:
            no_symlinks(path)
            if path.is_file():
                b=path.read_bytes();dst=out/path.name
                atomic_bytes(dst,b,new=True,mode=0o400)
                files.append({'filename':path.name,'size_bytes':len(b),'sha256':byte_hash(b)})
        write_json(out/'capture.json',{'reason':reason,'files':files,'scope':'RAW_COPY_NOT_VALIDATED_BACKUP'},new=True,mode=0o400)
        sync_dir(out.parent)
        return str(out.relative_to(self.root))

    def _freeze(self,error):
        self._frozen=error.code
        try:
            evidence=self._capture_raw(error.code)
            write_json(self.root/'FROZEN.json',{'schema_version':'P21-FREEZE/1','reason':error.code,'evidence':evidence})
        except (OSError,SaveError):
            # A full/failed disk may prevent even a marker. The current object
            # remains frozen; each new opener performs the same failing checks.
            pass

    @contextmanager
    def _session(self, *, writable=False, allow_v1=False):
        with file_lock(self.lock_path):
            need(self._frozen is None and not (self.root/'FROZEN.json').exists(),'E_FROZEN',self._frozen or '')
            c=None
            try:
                marker=self._marker()
                journal=Path(str(self.db)+'-journal')
                if journal.exists() and journal.stat().st_size:
                    self._capture_raw('PRE_SQLITE_JOURNAL_RECOVERY')
                c=self._connect()
                c.execute('BEGIN IMMEDIATE' if writable else 'BEGIN')
                snapshot=self._verify_db(c,marker)
                self._sync_anchor(c,snapshot)
            except sqlite3.Error as exc:
                if c is not None:
                    if c.in_transaction:c.rollback()
                    c.close()
                err=_sqlite_error(exc)
                if err.code not in ('E_BUSY','E_DISK_FULL','E_READ_ONLY'):self._freeze(err)
                raise err from exc
            except SaveError as exc:
                if c is not None:
                    if c.in_transaction:c.rollback()
                    c.close()
                if exc.code not in VERSION_ERRORS:self._freeze(exc)
                raise
            except OSError as exc:
                if c is not None:
                    if c.in_transaction:c.rollback()
                    c.close()
                raise io_error(exc) from exc
            except (KeyError,IndexError,TypeError,ValueError) as exc:
                if c is not None:
                    if c.in_transaction:c.rollback()
                    c.close()
                err=SaveError('E_STRUCTURE_CORRUPT',type(exc).__name__);self._freeze(err)
                raise err from exc
            try:
                if writable and not allow_v1:need(snapshot.schema_version==CURRENT_SCHEMA,'E_MIGRATION_REQUIRED')
                yield c,snapshot
            finally:
                if c.in_transaction:c.rollback()
                c.close()

    def snapshot(self):
        with self._session() as (_,s):return s

    def read_consistent(self,project):
        """Trusted, pure projector runs once on the exact same immutable snapshot."""
        with self._session() as (_,s):return project(s)

    @staticmethod
    def _lookup_row(c,tx):
        row=c.execute('SELECT receipt,receipt_sha256,chain_sha256 FROM transactions WHERE transaction_id=?',(tx,)).fetchone()
        if row is None:return None
        value=decode(row['receipt'])
        return {'receipt':value,'receipt_sha256':row['receipt_sha256'],'chain_sha256':row['chain_sha256']}

    def lookup(self,transaction_id,request_sha256=None):
        identifier(transaction_id)
        if request_sha256 is not None:hash_value(request_sha256)
        try:
            with self._session() as (c,s):
                r=self._lookup_row(c,transaction_id)
                if r and request_sha256 is not None:
                    need(r['receipt']['request_sha256']==request_sha256,'E_TRANSACTION_ID_COLLISION')
                return {'status':'COMMITTED' if r else 'ABSENT','proof':r,
                        'store_instance':s.store_instance,'continuity_ref':s.continuity_ref,
                        'high_watermark':s.sequence,'continuity_verified':True}
        except SaveError as exc:
            if exc.code=='E_TRANSACTION_ID_COLLISION':raise
            return {'status':'UNKNOWN','proof':None,'reason':exc.code,
                    'store_instance':None,'continuity_ref':None,'high_watermark':None,'continuity_verified':False}

    def status(self):
        try:
            s=self.snapshot()
            return {'state':'READY' if s.schema_version==CURRENT_SCHEMA else 'MIGRATION_REQUIRED',
                    'store_instance':s.store_instance,'save_format_version':'P21-SQLITE/'+str(s.schema_version),
                    'high_watermark':s.sequence,'reason_code':'OK' if s.schema_version==CURRENT_SCHEMA else 'MIGRATION_REQUIRED',
                    'origin':ORIGIN,'scope':'ISOLATED'}
        except SaveError as exc:
            return {'state':'RECOVERY_REQUIRED','store_instance':None,'save_format_version':None,
                    'high_watermark':None,'reason_code':exc.code,'origin':ORIGIN,'scope':'ISOLATED'}

    def _receipt(self,c,before,tx,req,kind,result, *, version=None):
        seq=before.sequence+1;integer(seq)
        version=version or before.schema_version
        state=self._state_hash(c)
        heads=[dict(row) for row in c.execute('SELECT name,owner,schema_version,revision,sha256 FROM documents ORDER BY name')]
        r={'schema_version':'P21-COMMIT-RECEIPT/1','transaction_id':tx,'request_sha256':req,
           'kind':kind,'store_instance':before.store_instance,'continuity_ref':before.continuity_ref,
           'profile_id':before.profile_id,'sequence':seq,'previous_chain_sha256':before.chain_sha256,
           'before_state_sha256':before.state_sha256,'state_sha256':state,
           'previous_schema_version':before.schema_version,'save_schema_version':version,
           'document_heads':heads,'result':result,'origin':ORIGIN,'durable':True}
        raw=encode(r);rh=byte_hash(raw);chain=digest(['P21-CHAIN/1',before.chain_sha256,rh])
        c.execute('INSERT INTO transactions VALUES(?,?,?,?,?,?,?)',(tx,req,seq,before.chain_sha256,raw,rh,chain))
        c.execute('UPDATE store_meta SET sequence=?,state_sha256=?,chain_sha256=? WHERE singleton=1',(seq,state,chain))
        return {'receipt':r,'receipt_sha256':rh,'chain_sha256':chain}

    def _publish(self,c,proof):
        self._hit('before_commit',c)
        try:c.commit()
        except sqlite3.Error as exc:
            code=getattr(exc,'sqlite_errorcode',0)&255
            if c.in_transaction and code in (sqlite3.SQLITE_BUSY,sqlite3.SQLITE_LOCKED,sqlite3.SQLITE_FULL):raise
            raise CommitUnknown('COMMIT result is uncertain; verify the original receipt') from exc
        try:
            self._hit('after_sql_commit',c)
            r=proof['receipt']
            write_json(self.anchor_path,{'schema_version':'P21-CONTINUITY/1','store_instance':r['store_instance'],
                'continuity_ref':r['continuity_ref'],'profile_id':r['profile_id'],'sequence':r['sequence'],
                'state_sha256':r['state_sha256'],'chain_sha256':proof['chain_sha256'],
                'save_schema_version':r['save_schema_version']})
            self._hit('after_anchor',c);self._hit('before_reply',c)
        except Exception as exc:
            raise CommitUnknown('SQL committed; success response withheld: '+type(exc).__name__) from exc
        return {'status':'COMMITTED','proof':proof,'duplicate':False}

    def execute_once(self,request,decide):
        """Caller is a trusted owner adapter, not a wire callback or JSON owner flag.

        decide runs under BEGIN IMMEDIATE. It may only compute; network and
        side effects are forbidden by the port contract. P21 rechecks CAS,
        ownership, complete records and permanent uniqueness, then writes all.
        """
        need(type(request) is Request,'E_REQUEST_TYPE')
        with self._session(writable=True) as (c,s):
            need((request.expected_store_instance,request.expected_continuity_ref)==
                 (s.store_instance,s.continuity_ref),'E_REQUEST_FENCE')
            prior=self._lookup_row(c,request.transaction_id)
            if prior:
                need(prior['receipt']['request_sha256']==request.request_sha256 and
                     prior['receipt']['kind']==request.kind,'E_TRANSACTION_ID_COLLISION')
                return {'status':'COMMITTED','proof':prior,'duplicate':True}
            try:
                self._hit('after_begin',c)
                mutation=decide(s)
                need(type(mutation) is Mutation,'E_MUTATION_TYPE')
                updates=mutation.updates
                need(type(updates) is tuple and bool(updates),'E_EMPTY_MUTATION')
                names=[u.record.name for u in updates]
                allowed,required=KINDS[request.kind]
                need(len(names)==len(set(names)) and required <= set(names) <= allowed,'E_TRANSACTION_DOMAIN_BOUNDARY')
                for u in updates:
                    old=s.records[u.record.name]
                    need(u.before_sha256==old.sha256,'E_STALE_RECORD',u.record.name)
                    need(u.record.owner==old.owner and u.record.schema_version==old.schema_version,'E_DOMAIN_SCHEMA_CHANGE_REQUIRES_OWNER')
                    need(u.record.revision==old.revision+1,'E_RECORD_REVISION')
                need(type(mutation.claims) is tuple,'E_CLAIMS_TYPE')
                need(len({(x.namespace,x.key) for x in mutation.claims})==len(mutation.claims),'E_DUPLICATE_CLAIM')
                need(type(mutation.result) is dict,'E_MUTATION_RESULT')
                encode(mutation.result)
                self._hit('after_validate',c)
                for u in updates:
                    r=u.record
                    c.execute('UPDATE documents SET revision=?,payload=?,sha256=? WHERE name=?',
                              (r.revision,r.payload,r.sha256,r.name))
                    self._hit('after_record:'+r.name,c)
                for claim in mutation.claims:
                    old=c.execute('SELECT semantic_sha256 FROM claims WHERE profile_id=? AND namespace=? AND claim_key=?',
                                  (s.profile_id,claim.namespace,claim.key)).fetchone()
                    if old:raise SaveError('E_CLAIM_ALREADY_CONSUMED' if old[0]==claim.semantic_sha256 else 'E_CLAIM_COLLISION')
                    c.execute('INSERT INTO claims VALUES(?,?,?,?,?)',(s.profile_id,claim.namespace,claim.key,
                              claim.semantic_sha256,request.transaction_id))
                self._hit('after_claims',c)
                proof=self._receipt(c,s,request.transaction_id,request.request_sha256,request.kind,mutation.result)
                self._hit('after_receipt',c)
                return self._publish(c,proof)
            except sqlite3.Error as exc:
                # COMMIT failure is not an ACK. If rollback fails, outcome is unknown.
                try:
                    if c.in_transaction:c.rollback()
                except sqlite3.Error as rollback_error:raise CommitUnknown('rollback could not be confirmed') from rollback_error
                raise _sqlite_error(exc) from exc
            except OSError as exc:
                if c.in_transaction:c.rollback()
                raise io_error(exc) from exc

    def backup(self,destination):
        from .recovery import backup
        return backup(self,destination)

    def migrate(self,backup_destination):
        from .recovery import migrate
        return migrate(self,backup_destination)

    def recover_exact(self,backup_directory):
        from .recovery import recover_exact
        return recover_exact(self,backup_directory)
