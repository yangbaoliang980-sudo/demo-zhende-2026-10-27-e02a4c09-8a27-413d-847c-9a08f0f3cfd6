"""An invalid trusted callback must not create an unreadable durable receipt."""
from pathlib import Path
import tempfile
import unittest
from p21_persistence import Mutation, SaveError
from support.fixtures import create_simple, request, increment


class EnvelopeRegression(unittest.TestCase):
    def test_malformed_store_marker_freezes_and_preserves_source(self):
        with tempfile.TemporaryDirectory(prefix='p21-marker-') as directory:
            store=create_simple(Path(directory));database=store.db.read_bytes()
            marker=store.root/'store_marker.json';marker.write_bytes(b'[]')
            with self.assertRaises(SaveError) as error:store.snapshot()
            self.assertEqual(error.exception.code,'E_STORE_MARKER')
            self.assertTrue((store.root/'FROZEN.json').exists())
            self.assertEqual(store.db.read_bytes(),database)
            self.assertTrue(any(p.read_bytes()==b'[]' for p in
                (store.root/'recovery_evidence').glob('*/store_marker.json')))
            self.assertEqual(store.lookup('any')['status'],'UNKNOWN')

    def test_non_object_result_rejected_before_any_commit(self):
        with tempfile.TemporaryDirectory(prefix='p21-envelope-') as directory:
            store=create_simple(Path(directory));before=store.snapshot()
            def malformed(snapshot):
                valid=increment(snapshot)
                return Mutation(valid.updates,valid.claims,['not-an-object'])
            with self.assertRaises(SaveError) as error:
                store.execute_once(request(),malformed)
            self.assertEqual(error.exception.code,'E_MUTATION_RESULT')
            self.assertEqual(store.snapshot(),before)
            self.assertEqual(store.lookup('fixture.tx')['status'],'ABSENT')


if __name__=='__main__':unittest.main()
