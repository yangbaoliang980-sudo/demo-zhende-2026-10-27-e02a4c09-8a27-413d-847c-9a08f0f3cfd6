"""Launch the explicitly isolated P19 author contract fixture."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).parent/'tests/battle_ui_unit/fixture_host.py'),run_name='__main__')
