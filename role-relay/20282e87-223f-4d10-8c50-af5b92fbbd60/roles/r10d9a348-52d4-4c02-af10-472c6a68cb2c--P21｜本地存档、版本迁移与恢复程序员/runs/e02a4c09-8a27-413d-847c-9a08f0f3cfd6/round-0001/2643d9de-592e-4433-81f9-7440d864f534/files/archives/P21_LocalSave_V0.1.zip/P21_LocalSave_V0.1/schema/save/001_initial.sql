CREATE TABLE store_meta (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  store_instance TEXT NOT NULL,
  continuity_ref TEXT NOT NULL,
  profile_id TEXT NOT NULL,
  schema_version INTEGER NOT NULL,
  min_reader_version INTEGER NOT NULL,
  genesis_state_sha256 TEXT NOT NULL,
  genesis_chain_sha256 TEXT NOT NULL,
  genesis_schema_version INTEGER NOT NULL,
  sequence INTEGER NOT NULL CHECK(sequence>=0),
  state_sha256 TEXT NOT NULL,
  chain_sha256 TEXT NOT NULL
);
CREATE TABLE documents (
  name TEXT PRIMARY KEY CHECK(name IN ('ledger','meta','stage')),
  owner TEXT NOT NULL,
  schema_version TEXT NOT NULL,
  revision INTEGER NOT NULL CHECK(revision>=0),
  payload BLOB NOT NULL,
  sha256 TEXT NOT NULL
);
CREATE TABLE transactions (
  transaction_id TEXT PRIMARY KEY,
  request_sha256 TEXT NOT NULL,
  sequence INTEGER NOT NULL UNIQUE CHECK(sequence>0),
  previous_chain_sha256 TEXT NOT NULL,
  receipt BLOB NOT NULL,
  receipt_sha256 TEXT NOT NULL,
  chain_sha256 TEXT NOT NULL
);
CREATE TABLE claims (
  profile_id TEXT NOT NULL,
  namespace TEXT NOT NULL,
  claim_key TEXT NOT NULL,
  semantic_sha256 TEXT NOT NULL,
  transaction_id TEXT NOT NULL REFERENCES transactions(transaction_id)
    DEFERRABLE INITIALLY DEFERRED,
  PRIMARY KEY(profile_id,namespace,claim_key)
);
