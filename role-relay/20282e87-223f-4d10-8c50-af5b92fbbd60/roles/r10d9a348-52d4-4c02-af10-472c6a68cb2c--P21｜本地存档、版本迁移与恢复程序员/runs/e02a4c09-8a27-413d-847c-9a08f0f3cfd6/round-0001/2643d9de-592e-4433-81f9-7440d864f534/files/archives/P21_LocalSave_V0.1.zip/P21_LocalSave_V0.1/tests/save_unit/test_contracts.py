from pathlib import Path
from copy import deepcopy
from dataclasses import replace
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from p21_persistence import *
from p21_persistence.adapters import P17CommitAdapter,P11AtomicAdapter,p13_lookup,p13_status
from support.fixtures import (ROOT,INSTANCE,NativeStageFixture,NativeLedgerFixture,
                              open_simple,originals,trace)


class P17P18Contracts(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-domain-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.h=NativeStageFixture(self.root)
    def test_original_p18_entry_commits_without_changing_wallet(self):
        before=self.h.store.snapshot();bundle,result=self.h.enter()
        after=self.h.store.snapshot()
        self.assertEqual(after.records['meta'],before.records['meta'])
        self.assertEqual(after.records['stage'].value['active_battle_id'],'native.battle.A')
        self.assertTrue(result['proof']['receipt']['durable'])
        self.assertEqual(result['proof']['receipt']['origin'],'P21_SQLITE_ISOLATED')
    def test_original_p18_p17_first_clear_and_xp_survive_restart(self):
        self.h.enter();bundle,result=self.h.settle()
        self.assertEqual(self.h.balance(),3)
        s=open_simple(self.root).snapshot()
        self.assertEqual([x['xp_total'] for x in s.records['meta'].value['characters']],[4,4,4])
        self.assertEqual(len(s.records['stage'].value['first_clears']),1)
        c=sqlite3.connect(self.h.store.db)
        self.assertEqual(c.execute('SELECT COUNT(*) FROM claims').fetchone()[0],1);c.close()
        trace(self._testMethodName,{'scope':'ORIGINAL_P17_P18_WITH_SYNTHETIC_BATTLE_EVIDENCE',
             'receipt':result['proof'],'wallet_available':3,'character_xp':[4,4,4],'first_clear_count':1})
    def test_duplicate_settlement_after_restart_keeps_same_receipt(self):
        self.h.enter();bundle,first=self.h.settle();before=self.h.store.snapshot()
        self.h.store=open_simple(self.root);self.h.adapter.store=self.h.store
        second=self.h.adapter.submit(bundle)
        self.assertTrue(second['duplicate']);self.assertEqual(first['proof'],second['proof'])
        self.assertEqual(self.h.store.snapshot(),before);self.assertEqual(self.h.balance(),3)
    def test_second_battle_does_not_reset_stage_first_clear(self):
        self.h.enter();self.h.settle();self.h.enter('native.battle.B');self.h.settle('native.battle.B')
        self.assertEqual(self.h.balance(),3)
        stage,_=self.h.snapshots();self.assertEqual(len(stage.value['first_clears']),1)
    def test_loss_closes_attempt_without_reward(self):
        self.h.enter();self.h.settle(outcome='LOSS')
        stage,_=self.h.snapshots();self.assertIsNone(stage.value['active_battle_id'])
        self.assertEqual(self.h.balance(),0);self.assertEqual(stage.value['first_clears'],[])
    def test_original_p17_upgrade_debit_and_character_are_one_commit(self):
        from character_party_runtime import MetaPlanner,command
        self.h.enter();self.h.settle();self.h.enter('native.boss','MOCK_P07_STAGE_002');self.h.settle('native.boss')
        _,meta=self.h.snapshots();planner=MetaPlanner(self.h.wallet.catalog)
        cid=meta.value['characters'][0]['character_id'];req=command(meta,'upgrade.once','LEVEL_UP',{'character_id':cid,'from_rank':1,'to_rank':2})
        plan=planner.plan(req,meta);self.assertEqual(plan.status,'CANDIDATE',plan.reason)
        adapter=P17CommitAdapter(self.h.store,planner);receipt=adapter.submit(plan.candidate)
        self.assertEqual(self.h.balance(),11)
        s=open_simple(self.root).snapshot();ch=next(c for c in s.records['meta'].value['characters'] if c['character_id']==cid)
        self.assertEqual(ch['level'],2);self.assertTrue(adapter.submit(plan.candidate)['duplicate'])
        self.assertEqual(self.h.balance(),11)
        trace(self._testMethodName,{'receipt':receipt,'level':ch['level'],'wallet_available':11,'scope':'ORIGINAL_P17_WITH_SYNTHETIC_STAGE_EVIDENCE'})
    def test_original_p17_party_order_saved_and_loaded(self):
        from character_party_runtime import MetaPlanner,command
        _,meta=self.h.snapshots();planner=MetaPlanner(self.h.wallet.catalog)
        ids=[x['character_id'] for x in meta.value['characters']][::-1]
        req=command(meta,'party.once','SET_PARTY',{'ordered_character_ids':ids})
        plan=planner.plan(req,meta);P17CommitAdapter(self.h.store,planner).submit(plan.candidate)
        s=open_simple(self.root).snapshot()
        party=planner.party_snapshot(self.h.FrozenMessage(s.records['meta'].payload)).value
        self.assertEqual([m['character_id'] for m in party['members']],ids)
    def test_single_p17_adapter_rejects_stage_counterpart(self):
        from character_party_runtime import MetaPlanner
        from character_party_runtime.common import DomainError
        self.h.enter();stage,_=self.h.snapshots()
        result=self.h.authority.issue_battle(stage,self.h.catalog,'native.battle.A')
        bundle=self.h.prepare('SETTLE',{'result':result.value})
        c=self.h.FrozenMessage.from_value(bundle.value['body']['wallet_character_candidate'])
        with self.assertRaises(DomainError):P17CommitAdapter(self.h.store,MetaPlanner(self.h.wallet.catalog)).submit(c)
        self.assertEqual(self.h.balance(),0)
    def test_joint_candidate_tampering_rejected_before_commit(self):
        self.h.enter();stage,_=self.h.snapshots()
        result=self.h.authority.issue_battle(stage,self.h.catalog,'native.battle.A')
        original=self.h.prepare('SETTLE',{'result':result.value});v=original.value
        v['body']['wallet_character_candidate']['after_state']['revision']+=99
        tampered=self.h.FrozenMessage.from_value(v);before=self.h.store.snapshot()
        with self.assertRaises(Exception):self.h.adapter.submit(tampered)
        self.assertEqual(self.h.store.snapshot(),before)
    def test_authority_is_rechecked_under_physical_transaction(self):
        self.h.enter();stage,_=self.h.snapshots()
        result=self.h.authority.issue_battle(stage,self.h.catalog,'native.battle.A')
        bundle=self.h.prepare('SETTLE',{'result':result.value});self.h.authority.battles.clear()
        before=self.h.store.snapshot()
        with self.assertRaises(Exception):self.h.adapter.submit(bundle)
        self.assertEqual(self.h.store.snapshot(),before)
    def test_stale_party_evidence_cannot_enter_after_party_change(self):
        from character_party_runtime import MetaPlanner,command
        stage,meta=self.h.snapshots()
        ref=self.h.authority.issue_entry(self.h.catalog,stage,meta,self.h.wallet,'MOCK_P07_STAGE_001','stale.battle')
        bundle=self.h.prepare('ENTER',{'stage_id':'MOCK_P07_STAGE_001','battle_id':'stale.battle','entry_ref':ref,'seed':1})
        planner=MetaPlanner(self.h.wallet.catalog);ids=[x['character_id'] for x in meta.value['characters']][::-1]
        req=command(meta,'change.party','SET_PARTY',{'ordered_character_ids':ids})
        P17CommitAdapter(self.h.store,planner).submit(planner.plan(req,meta).candidate)
        with self.assertRaises(SaveError) as e:self.h.adapter.submit(bundle)
        self.assertEqual(e.exception.code,'E_ENTRY_META_SOURCE_STALE')
        self.assertIsNone(self.h.snapshots()[0].value['active_battle_id'])
    def test_p13_original_projections_are_validated(self):
        bundle,result=self.h.enter();tx=result['proof']['receipt']['transaction_id']
        view=p13_lookup(self.h.store,tx).value;status=p13_status(self.h.store).value
        self.assertEqual(view['status'],'COMMITTED');self.assertEqual(view['proof']['sequence'],1)
        self.assertEqual(status['state'],'READY')
        self.assertEqual(p13_lookup(self.h.store,'absent').value['status'],'ABSENT')
        self.h.store.anchor_path.unlink()
        self.assertEqual(p13_lookup(self.h.store,tx).value['status'],'UNKNOWN')
        self.assertEqual(p13_status(self.h.store).value['state'],'RECOVERY_REQUIRED')


class P11Contracts(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-ledger-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup);self.h=NativeLedgerFixture(self.root)
    def test_original_ledger_review_once_and_duplicate_across_restart(self):
        raw=encode(self.h.ports.event());first=self.h.ledger.handle(raw)
        self.assertEqual(first.state,'APPLIED');self.assertEqual(self.h.balance(),10)
        before=self.h.store.snapshot();again=self.h.ledger.handle(raw)
        self.assertEqual(again.state,'APPLIED');self.assertEqual(self.h.store.snapshot(),before)
        self.assertEqual(first.receipt.origin,'P21_SIMULATOR')
        self.assertEqual(self.h.store.lookup(first.receipt.transaction_id)['proof']['receipt']['origin'],'P21_SQLITE_ISOLATED')
        self.assertEqual(open_simple(self.root).snapshot().records['meta'],before.records['meta'])
        trace(self._testMethodName,{'scope':'ORIGINAL_P11_WITH_SYNTHETIC_LEGACY_WALLET_BINDING',
             'available':10,'duplicate_available':self.h.balance(),'P11_origin':first.receipt.origin,'P21_origin':'P21_SQLITE_ISOLATED'})
    def test_original_ledger_undo_and_restore_net_persists(self):
        p=self.h.ports
        self.h.ledger.handle(encode(p.event()))
        undo=self.h.ledger.handle(encode(p.control('UNDO','undo-1','review-1',1)))
        self.assertEqual(undo.state,'REVERTED');self.assertEqual(self.h.balance(),0)
        restore=self.h.ledger.handle(encode(p.control('RESTORE','restore-1','undo-1',2)))
        self.assertEqual(restore.state,'APPLIED');self.assertEqual(self.h.balance(),10)
        self.h.ledger.handle(encode(p.control('RESTORE','restore-1','undo-1',2)))
        self.assertEqual(self.h.balance(),10)
        after=open_simple(self.root).snapshot();self.assertEqual(after.records['meta'].value['wallet']['balances'][p.UNIT],10)
        trace(self._testMethodName,{'states':['APPLIED',undo.state,restore.state],'net_amounts':[10,0,10],
              'scope':'SYNTHETIC_P08_ARITHMETIC_NOT_APPROVED_RATING_POLICY'})
    def test_quarantine_is_durable_without_wallet_change(self):
        self.h.evidence.blocked.add('review-1');before=self.h.store.snapshot().records['meta']
        r=self.h.ledger.handle(encode(self.h.ports.event()))
        self.assertEqual(r.state,'QUARANTINED');self.assertEqual(self.h.balance(),0)
        self.assertEqual(self.h.store.snapshot().records['meta'],before)
        self.assertTrue(r.receipt.durable)
    def test_binding_absence_blocks_instead_of_minting_second_wallet(self):
        a=P11AtomicAdapter(self.h.store);before=self.h.store.snapshot()
        with self.assertRaises(SaveError) as e:a.snapshot()
        self.assertEqual(e.exception.code,'E_P11_P17_WALLET_BINDING_UNBOUND')
        self.assertEqual(self.h.store.snapshot(),before)
    def test_old_backup_restore_cannot_reapply_confirmed_learning(self):
        self.h.store.backup(self.root/'old');self.h.ledger.handle(encode(self.h.ports.event()))
        self.h.store.db.write_bytes((self.root/'old/snapshot.sqlite3').read_bytes())
        found=self.h.adapter.lookup('process:'+digest(self.h.ports.event()))
        self.assertEqual(found.status,'UNKNOWN')
        self.assertTrue((self.h.store.root/'FROZEN.json').exists())
    def test_bad_delta_rolls_back_ledger_together_with_wallet(self):
        from ledger_runtime.types import Mutation as LM,WalletDelta,PortViolation
        before=self.h.store.snapshot()
        delta=WalletDelta('a'*64,'b'*64,88,'c'*64,{}, {},False,'TEST','d'*64)
        def decide(s):return LM(deepcopy(s.ledger),delta)
        with self.assertRaises(AssertionError):self.h.adapter.execute_once('invalid.delta',digest('invalid'),decide)
        self.assertEqual(self.h.store.snapshot(),before)


class SourceImmutability(unittest.TestCase):
    def test_all_bundled_upstream_bytes_still_match_receipt(self):
        import hashlib
        receipt=json.loads((ROOT/'source_input_receipt.json').read_text())
        for item in receipt['selected_originals']:
            p=ROOT/item['path'];b=p.read_bytes()
            self.assertEqual(len(b),item['size_bytes'],item['path'])
            self.assertEqual(hashlib.sha256(b).hexdigest(),item['sha256'],item['path'])
    def test_runtime_has_no_test_support_or_anki_database_dependency(self):
        import ast
        for p in (ROOT/'runtime/persistence/p21_persistence').glob('*.py'):
            for n in ast.walk(ast.parse(p.read_text())):
                if isinstance(n,(ast.Import,ast.ImportFrom)):
                    names=[x.name for x in n.names]+([n.module or ''] if isinstance(n,ast.ImportFrom) else [])
                    self.assertFalse(any('tests' in x.split('.') or x.startswith(('aqt','anki')) for x in names),(p,names))


if __name__=='__main__':unittest.main()
