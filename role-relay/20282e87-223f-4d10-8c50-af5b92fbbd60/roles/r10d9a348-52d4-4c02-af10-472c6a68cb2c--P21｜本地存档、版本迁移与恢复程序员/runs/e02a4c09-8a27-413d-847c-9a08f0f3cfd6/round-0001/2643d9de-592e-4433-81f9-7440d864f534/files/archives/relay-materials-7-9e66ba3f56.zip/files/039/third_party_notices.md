# 字体与作者测试环境依赖

## 随包字体

包名：`@fontsource/noto-sans-sc`；版本：`5.3.1`。来源：npm 官方 registry，来源包的解析 URL 与 integrity 在 `evidence/dependencies/font_package-lock.json`。

使用文件：`ui/battle/widgets/fonts/noto-sans-sc-chinese-simplified-400-normal.woff2`，1,142,552 字节，SHA-256 `95e3633b6a98f764ba3adfb54504a0cd4799328c009adf9081d6c1850f9c4c78`。

该字体原件按 SIL Open Font License 1.1 提供。原 `LICENSE` 与 `package.json` 随包保存，字体字节未修改。P19 新写的 `font.css` 仅本地引用字体，解决无中文系统字体时的缺字；这不代表 P24/P25 已批准正式字体风格或 P37 已独立合规验收。

## 测试工具

Python 3.12.14 与 Node 24.22.1：本次实际执行环境，未随 ZIP 分发运行时。

Playwright 1.62.1 与 `@sparticuz/chromium@153.0.0`：仅本轮真实浏览器测试环境使用。Chromium 实际版本 153.0.8010.0。浏览器二进制、node_modules 和安装缓存不包含在交付 ZIP；`browser_package-lock.json` 保存来源元数据。

初次 Playwright 默认下载地址返回 Site Unavailable HTML，未得到可用 ZIP；替代测试依赖通过 npm 正常获取，没有关闭 TLS 验证或修改网络策略。Sparticuz 自动解包遇到当前文件系统 chown 限制，随后仅从同包原 brotli 解出二进制到可写测试目录，使用系统现有动态库。保留环境失败日志，不把安装失败记作 UI 测试失败或通过。
