"""Explicit synthetic demonstration using original domain code and real P21 files."""
import bootstrap
from pathlib import Path
import argparse
import json
import sys
from dataclasses import asdict
sys.path.insert(0,str(bootstrap.ROOT/'tests/save_unit'))
from support.fixtures import NativeStageFixture,NativeLedgerFixture,open_simple,create_simple
from p21_persistence import encode
from p21_persistence.adapters import P17CommitAdapter


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args()
    out=Path(a.output).resolve();out.mkdir(parents=False,exist_ok=False)
    stage_root=out/'stage';stage_root.mkdir();h=NativeStageFixture(stage_root)
    steps=[]
    def note(name):
        s=h.store.snapshot();steps.append({'step':name,'sequence':s.sequence,'wallet_available':h.balance(),
          'characters':[{'character_id':x['character_id'],'level':x['level'],'xp_total':x['xp_total']} for x in s.records['meta'].value['characters']],
          'first_clear_count':len(s.records['stage'].value['first_clears']),'state_sha256':s.state_sha256})
    note('SYNTHETIC_GENESIS')
    h.enter();normal,receipt=h.settle();note('NORMAL_FIRST_CLEAR')
    h.adapter.submit(normal);note('DUPLICATE_SAME_SETTLEMENT')
    h.enter('demo.boss','MOCK_P07_STAGE_002');h.settle('demo.boss');note('BOSS_FIRST_CLEAR')
    from character_party_runtime import MetaPlanner,command
    planner=MetaPlanner(h.wallet.catalog);_,meta=h.snapshots();cid=meta.value['characters'][0]['character_id']
    req=command(meta,'demo.upgrade','LEVEL_UP',{'character_id':cid,'from_rank':1,'to_rank':2})
    candidate=planner.plan(req,meta).candidate;P17CommitAdapter(h.store,planner).submit(candidate);note('LEVEL_UP')
    h.store=open_simple(stage_root);h.adapter.store=h.store;note('REOPEN_IDENTICAL_NET')
    h.store.backup(out/'stage_backup')
    ledger_root=out/'study';ledger_root.mkdir();l=NativeLedgerFixture(ledger_root);study=[]
    for value in [l.ports.event(),l.ports.control('UNDO','undo-1','review-1',1),l.ports.control('RESTORE','restore-1','undo-1',2)]:
        result=l.ledger.handle(encode(value));study.append({'state':result.state,'net':l.balance(),'legacy_receipt':asdict(result.receipt)})
    legacy_root=out/'legacy';legacy_root.mkdir();legacy=create_simple(legacy_root,schema=1);legacy.backup(out/'v1_backup')
    report={'schema_version':'P21-EXECUTED-DEMO/1','scope':'ISOLATED_SYNTHETIC_EVIDENCE_REAL_P21_SQLITE',
            'stage_steps':steps,'study_steps':study,'study_wallet':'SYNTHETIC_LEGACY_BINDING_NOT_NATIVE_P17',
            'paths':{'stage_store':str(stage_root/'save'),'stage_anchor':str(stage_root/'authority/head.json'),
                     'stage_backup':str(out/'stage_backup'),'v1_backup':str(out/'v1_backup')},
            'production_integration':'BLOCKED','real_Anki':'NOT_RUN'}
    (out/'demo_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
