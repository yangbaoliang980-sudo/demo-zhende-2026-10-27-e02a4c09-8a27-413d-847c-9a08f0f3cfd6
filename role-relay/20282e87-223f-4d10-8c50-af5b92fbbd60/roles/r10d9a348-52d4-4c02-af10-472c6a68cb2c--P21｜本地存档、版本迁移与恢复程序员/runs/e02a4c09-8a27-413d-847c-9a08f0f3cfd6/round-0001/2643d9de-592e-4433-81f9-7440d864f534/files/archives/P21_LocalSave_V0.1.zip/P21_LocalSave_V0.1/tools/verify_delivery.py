"""Verify exact delivered bytes and unchanged upstream originals; no writes."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[1]


def main():
    path=ROOT/'delivery_manifest.json'
    if not path.is_file():
        print(json.dumps({'status':'BLOCKED','reason':'delivery_manifest.json missing'}));return 3
    manifest=json.loads(path.read_text(encoding='utf-8'));entries=manifest['files'];failures=[]
    expected={row['relative_path'] for row in entries}
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    if actual != expected|{'delivery_manifest.json'}:
        failures.append({'missing':sorted(expected-actual),'unexpected':sorted(actual-expected-{'delivery_manifest.json'})})
    for row in entries:
        target=ROOT/row['relative_path']
        if not target.is_file() or target.is_symlink():
            failures.append({'path':row['relative_path'],'reason':'missing or symlink'});continue
        raw=target.read_bytes()
        if len(raw)!=row['size_bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            failures.append({'path':row['relative_path'],'reason':'size or sha256 mismatch'})
    source=json.loads((ROOT/'source_input_receipt.json').read_text(encoding='utf-8'))
    originals=source['selected_originals']
    for row in originals:
        raw=(ROOT/row['path']).read_bytes()
        if len(raw)!=row['size_bytes'] or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            failures.append({'path':row['path'],'reason':'upstream original changed'})
    result={'status':'PASS' if not failures else 'FAIL','package_files':len(actual),
            'manifest_entries':len(entries),'upstream_originals_checked':len(originals),'failures':failures,
            'manifest_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'manifest_binding':'This digest must match the separate delivery receipt; manifest cannot hash itself.',
            'runtime_execution':'NOT_RUN_BY_THIS_COMMAND','independent_acceptance':'NOT_RUN'}
    print(json.dumps(result,ensure_ascii=False,indent=2));return 1 if failures else 0


if __name__=='__main__':raise SystemExit(main())
