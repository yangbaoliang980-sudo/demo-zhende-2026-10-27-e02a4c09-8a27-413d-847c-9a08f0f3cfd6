"""Reproducible P19 author unit/contract entry. Requires Python 3.12 + Node >=20."""
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
commands=[['node','tests/battle_ui_unit/all_tests.mjs'],[sys.executable,'-B','-m','unittest','discover','-s','tests/battle_ui_unit','-p','test_native_contract.py','-v']]
for command in commands:
    print('RUN', ' '.join(command),flush=True)
    result=subprocess.run(command,cwd=ROOT)
    if result.returncode:raise SystemExit(result.returncode)
