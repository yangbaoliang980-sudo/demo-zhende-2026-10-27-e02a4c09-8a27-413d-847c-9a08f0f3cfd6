/** P19 owns final values. P29 receives only copied events and numeric rectangles. */
import {clone, freeze} from './wire.mjs';

export class PresentationBridge {
  constructor({driver = null, anchors = () => ({}), onStatus = () => {}} = {}) {
    this.driver = driver; this.anchors = anchors; this.onStatus = onStatus;
    this.mode = 'none'; this.epoch = 0; this.lastSeq = 0; this.status = 'NO_DRIVER';
  }
  cancel(reason = 'SNAPSHOT_REFRESH') {
    const token = ++this.epoch;
    try { Promise.resolve(this.driver?.cancel?.(reason,token)).catch(()=>{}); } catch {}
    this.status = reason; this.onStatus(reason);
  }
  setMode(mode) {
    if (!['none','reduced','normal','fast'].includes(mode)) throw new Error('PRESENTATION_MODE');
    this.mode = mode; this.cancel('MODE_CHANGED');
  }
  async present(batch, priorSeq, finalSnapshot) {
    // Snapshot values have already been bound before this optional method runs.
    this.cancel('SUPERSEDED'); this.lastSeq = finalSnapshot.last_event_seq;
    const events = batch.events;
    const ordered = events.length > 0 && events.every((e,i) =>
      e.seq === priorSeq + i + 1 && e.battle_id === finalSnapshot.battle_id &&
      e.revision === finalSnapshot.revision && e.command_id === batch.command_id) &&
      events.at(-1).seq === finalSnapshot.last_event_seq;
    if (!ordered) {this.status = 'SEQUENCE_GAP_SNAP_TO_FINAL'; this.onStatus(this.status); return;}
    if (!this.driver || this.mode === 'none' || this.mode === 'reduced') {
      this.status = 'STATIC_FINAL'; this.onStatus(this.status); return;
    }
    const epoch = this.epoch;
    try {
      const dto = freeze({version:'P19-PRESENTATION/0.1.0-proposal', epoch,
        battle_id:finalSnapshot.battle_id, revision:finalSnapshot.revision,
        last_event_seq:finalSnapshot.last_event_seq, mode:this.mode,
        events:clone(events), anchors:clone(this.anchors())});
      // P29 is a trusted in-process collaborator, not a JavaScript sandbox.
      // No DOM nodes, controller, command port, or writeable snapshots are passed.
      await this.driver.present(dto);
      if (epoch !== this.epoch) return;
      this.status = 'PRESENTED'; this.onStatus(this.status);
    } catch {
      if (epoch !== this.epoch) return;
      this.cancel('DRIVER_FAILED_STATIC_FINAL');
    }
  }
  dispose() {this.cancel('DISPOSED'); this.driver = null;}
}
