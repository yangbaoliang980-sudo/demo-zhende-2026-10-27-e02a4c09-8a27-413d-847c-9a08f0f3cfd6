"""Real process kills using original domain payloads, still synthetic eligibility."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
from p21_persistence import encode
from p21_persistence.model import byte_hash
from p21_persistence.adapters import P17CommitAdapter
from support.fixtures import ROOT,NativeStageFixture,NativeLedgerFixture,open_simple,trace


def kill(root,mode,point,data):
    path=root/'native_input.json';raw=encode(data);path.write_bytes(raw)
    argv=[sys.executable,'-B',str(ROOT/'tools/fault_worker.py'),str(root),'--mode',mode,'--point',point]
    p=subprocess.run(argv,capture_output=True,text=True,timeout=20)
    return p,{'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,
              'input_sha256':byte_hash(raw),'input_size_bytes':len(raw),'input':data,
              'physical_power_cut':False,'real_process_SIGKILL':True}


def study_case(point):
    def test(self):
        with tempfile.TemporaryDirectory(prefix='p21-native-study-') as t:
            root=Path(t);h=NativeLedgerFixture(root);raw=encode(h.ports.event())
            received=h.ledger.receive(raw);self.assertEqual(h.store.snapshot().sequence,1)
            p,log=kill(root,'native_study',point,{'inbox_id':received.inbox_id})
            self.assertEqual(p.returncode,-9,p.stdout+p.stderr)
            s=open_simple(root).snapshot();committed=point=='after_sql_commit'
            state=s.records['ledger'].value['inbox'][received.inbox_id]['state']
            self.assertEqual(state,'APPLIED' if committed else 'PENDING_RECONCILIATION')
            self.assertEqual(h.balance(),10 if committed else 0)
            h.ledger.process(received.inbox_id);self.assertEqual(h.balance(),10)
            h.ledger.handle(raw);self.assertEqual(h.balance(),10)
            log.update({'state_after_restart':state,'balance_after_restart':10 if committed else 0,
                        'balance_after_original_retry':10,'scope':'ORIGINAL_P11_SYNTHETIC_WALLET_POLICY_AND_EVIDENCE'})
            trace(self._testMethodName,log)
    return test


def stage_case(point):
    def test(self):
        with tempfile.TemporaryDirectory(prefix='p21-native-stage-') as t:
            root=Path(t);h=NativeStageFixture(root);h.enter();stage,_=h.snapshots()
            result=h.authority.issue_battle(stage,h.catalog,'native.battle.A')
            bundle=h.prepare('SETTLE',{'result':result.value})
            data={'bundle':bundle.value,'authority':{name:{k:v.value for k,v in getattr(h.authority,name).items()} for name in ('entries','battles','controls')}}
            p,log=kill(root,'native_stage',point,data);self.assertEqual(p.returncode,-9,p.stdout+p.stderr)
            s=open_simple(root).snapshot();committed=point=='after_sql_commit'
            self.assertEqual(len(s.records['stage'].value['first_clears']),int(committed))
            self.assertEqual(h.balance(),3 if committed else 0)
            self.assertEqual([x['xp_total'] for x in s.records['meta'].value['characters']],[4 if committed else 0]*3)
            reply=h.adapter.submit(bundle);self.assertEqual(reply['duplicate'],committed)
            self.assertEqual(h.balance(),3)
            log.update({'first_clears_after_restart':int(committed),'balance_after_restart':3 if committed else 0,
                        'balance_after_original_retry':3,'scope':'ORIGINAL_P17_P18_SYNTHETIC_BATTLE_EVIDENCE'})
            trace(self._testMethodName,log)
    return test


def upgrade_case(point):
    def test(self):
        from character_party_runtime import MetaPlanner,command
        with tempfile.TemporaryDirectory(prefix='p21-native-upgrade-') as t:
            root=Path(t);h=NativeStageFixture(root)
            h.enter();h.settle();h.enter('boss.A','MOCK_P07_STAGE_002');h.settle('boss.A')
            _,meta=h.snapshots();planner=MetaPlanner(h.wallet.catalog);cid=meta.value['characters'][0]['character_id']
            req=command(meta,'kill.upgrade','LEVEL_UP',{'character_id':cid,'from_rank':1,'to_rank':2})
            candidate=planner.plan(req,meta).candidate
            p,log=kill(root,'native_upgrade',point,{'candidate':candidate.value})
            self.assertEqual(p.returncode,-9,p.stdout+p.stderr);committed=point=='after_sql_commit'
            s=open_simple(root).snapshot();character=next(x for x in s.records['meta'].value['characters'] if x['character_id']==cid)
            self.assertEqual(character['level'],2 if committed else 1)
            self.assertEqual(h.balance(),11 if committed else 15)
            reply=P17CommitAdapter(h.store,planner).submit(candidate);self.assertEqual(reply['duplicate'],committed)
            self.assertEqual(h.balance(),11)
            log.update({'level_after_restart':character['level'],'balance_after_restart':11 if committed else 15,
                        'balance_after_original_retry':11,'scope':'ORIGINAL_P17_WITH_SYNTHETIC_STAGE_EVIDENCE'})
            trace(self._testMethodName,log)
    return test


class NativeCrashTests(unittest.TestCase):pass
for point in ['after_record:ledger','after_sql_commit']:
    setattr(NativeCrashTests,'test_native_study_kill_'+point.replace(':','_'),study_case(point))
for point in ['after_record:stage','after_record:meta','after_sql_commit']:
    setattr(NativeCrashTests,'test_native_stage_kill_'+point.replace(':','_'),stage_case(point))
for point in ['after_record:meta','after_sql_commit']:
    setattr(NativeCrashTests,'test_native_upgrade_kill_'+point.replace(':','_'),upgrade_case(point))


if __name__=='__main__':unittest.main()
