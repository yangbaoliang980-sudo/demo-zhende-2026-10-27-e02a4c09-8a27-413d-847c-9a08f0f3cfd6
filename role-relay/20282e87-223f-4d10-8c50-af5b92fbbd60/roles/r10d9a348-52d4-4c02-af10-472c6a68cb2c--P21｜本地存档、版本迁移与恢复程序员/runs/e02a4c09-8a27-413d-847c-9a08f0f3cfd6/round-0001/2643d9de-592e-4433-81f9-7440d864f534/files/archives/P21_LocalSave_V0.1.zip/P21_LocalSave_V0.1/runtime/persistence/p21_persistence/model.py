"""Physical envelopes only; domain bytes and business rules belong to owners."""
from __future__ import annotations
from dataclasses import dataclass, field
from types import MappingProxyType
from collections.abc import Mapping
import hashlib
import json
import re

MAX_BYTES = 1_048_576
MAX_INTEGER = 2**53 - 1
OWNERS = {'ledger': 'P11', 'meta': 'P17', 'stage': 'P18'}
KINDS = {
    'STUDY_LEDGER_WALLET': ({'ledger', 'meta'}, {'ledger'}),
    'CHARACTER_WALLET': ({'meta'}, {'meta'}),
    'STAGE_PROGRESS_WALLET': ({'stage', 'meta'}, {'stage'}),
}


class SaveError(Exception):
    def __init__(self, code, detail='', *, retryable=False):
        self.code, self.detail, self.retryable = code, detail, retryable
        super().__init__(code + (': ' + detail if detail else ''))

    def as_dict(self):
        return {'code': self.code, 'detail': self.detail, 'retryable': self.retryable}


class CommitUnknown(SaveError):
    def __init__(self, detail='query the original transaction with its original hash'):
        super().__init__('E_COMMIT_UNKNOWN', detail)


def need(test, code, detail=''):
    if not test: raise SaveError(code, detail)


def identifier(value):
    need(type(value) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,255}', value),
         'E_IDENTIFIER')
    return value


def hash_value(value):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'E_HASH_FORMAT')
    return value


def integer(value):
    need(type(value) is int and 0 <= value <= MAX_INTEGER, 'E_INTEGER')
    return value


def _walk(value, depth=0, count=None):
    count = [0] if count is None else count
    count[0] += 1
    need(depth <= 32 and count[0] <= 100_000, 'E_JSON_COMPLEXITY')
    if value is None or type(value) is bool: return
    if type(value) is int:
        need(abs(value) <= MAX_INTEGER, 'E_JSON_INTEGER'); return
    if type(value) is str:
        need(not any(ord(c) < 32 or ord(c) == 127 or 0xD800 <= ord(c) <= 0xDFFF for c in value),
             'E_JSON_STRING'); return
    if type(value) is list:
        for item in value: _walk(item, depth+1, count)
        return
    if type(value) is dict:
        for key, item in value.items():
            need(type(key) is str, 'E_JSON_KEY')
            _walk(key, depth+1, count); _walk(item, depth+1, count)
        return
    raise SaveError('E_JSON_TYPE')


def encode(value):
    _walk(value)
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                     allow_nan=False).encode('utf-8')
    need(len(raw) <= MAX_BYTES, 'E_JSON_SIZE')
    return raw


def decode(raw):
    need(type(raw) is bytes and len(raw) <= MAX_BYTES and not raw.startswith(b'\xef\xbb\xbf'),
         'E_JSON_BYTES')
    def pairs(items):
        result = {}
        for k,v in items:
            need(k not in result, 'E_JSON_DUPLICATE_KEY'); result[k]=v
        return result
    def reject(_): raise SaveError('E_JSON_NUMBER')
    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                           parse_float=reject, parse_constant=reject)
        _walk(value)
        return value
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise SaveError('E_JSON_INVALID', type(exc).__name__) from exc


def digest(value): return hashlib.sha256(encode(value)).hexdigest()
def byte_hash(raw): return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class Record:
    name: str
    owner: str
    schema_version: str
    revision: int
    payload: bytes

    def __post_init__(self):
        need(self.name in OWNERS and self.owner == OWNERS[self.name], 'E_RECORD_OWNER')
        identifier(self.schema_version); integer(self.revision)
        value = decode(self.payload)
        need(type(value) is dict and value.get('schema_version') == self.schema_version, 'E_DOMAIN_SCHEMA_TAG')
        need(encode(value) == self.payload, 'E_NONCANONICAL_RECORD')

    @classmethod
    def from_value(cls, name, revision, value):
        return cls(name, OWNERS[name], value['schema_version'], revision, encode(value))

    @property
    def sha256(self): return byte_hash(self.payload)
    @property
    def value(self): return decode(self.payload)
    def head(self):
        return {'name':self.name,'owner':self.owner,'schema_version':self.schema_version,
                'revision':self.revision,'sha256':self.sha256}


@dataclass(frozen=True)
class Update:
    record: Record
    before_sha256: str
    def __post_init__(self): hash_value(self.before_sha256)


@dataclass(frozen=True)
class Claim:
    namespace: str
    key: str
    semantic_sha256: str
    def __post_init__(self):
        identifier(self.namespace); identifier(self.key); hash_value(self.semantic_sha256)


@dataclass(frozen=True)
class Mutation:
    updates: tuple[Update, ...]
    claims: tuple[Claim, ...] = ()
    result: dict = field(default_factory=dict)


@dataclass(frozen=True)
class Request:
    transaction_id: str
    request_sha256: str
    kind: str
    expected_store_instance: str
    expected_continuity_ref: str
    def __post_init__(self):
        identifier(self.transaction_id); hash_value(self.request_sha256)
        need(self.kind in KINDS, 'E_TRANSACTION_KIND')
        identifier(self.expected_store_instance); identifier(self.expected_continuity_ref)


@dataclass(frozen=True)
class Snapshot:
    store_instance: str
    continuity_ref: str
    profile_id: str
    sequence: int
    schema_version: int
    state_sha256: str
    chain_sha256: str
    records: Mapping[str, Record]

    def __post_init__(self):
        object.__setattr__(self, 'records', MappingProxyType(dict(self.records)))

    def anchor(self):
        return {'schema_version':'P21-CONTINUITY/1','store_instance':self.store_instance,
                'continuity_ref':self.continuity_ref,'profile_id':self.profile_id,
                'sequence':self.sequence,'state_sha256':self.state_sha256,
                'chain_sha256':self.chain_sha256,'save_schema_version':self.schema_version}
