"""Filesystem operations for the observed POSIX isolated runtime.

Windows production support is deliberately gated until P13/P34 provide a target
probe. All successful publication uses fsync + atomic replace + directory fsync.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import errno
import os
import time
import uuid
from .model import SaveError, need, encode, decode


def platform_check():
    need(os.name == 'posix', 'E_PLATFORM_NOT_PROBED', 'P13/P34 Windows filesystem/locking probe required')


def no_symlinks(path):
    p = Path(os.path.abspath(path))
    for component in (p, *p.parents):
        need(not component.is_symlink(), 'E_SYMLINK_PATH', str(component))
    return p


def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | getattr(os,'O_DIRECTORY',0))
    try: os.fsync(fd)
    finally: os.close(fd)


def sync_file(path):
    with open(path, 'rb') as f: os.fsync(f.fileno())


def atomic_bytes(path, raw, *, new=False, mode=0o600):
    path=no_symlinks(path)
    need(path.parent.is_dir(), 'E_PARENT_MISSING')
    if new: need(not path.exists(), 'E_DESTINATION_EXISTS')
    tmp=path.with_name(path.name+'.partial.'+uuid.uuid4().hex)
    try:
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,mode)
        with os.fdopen(fd,'wb') as f:
            f.write(raw);f.flush();os.fsync(f.fileno())
        if new:
            # link refuses to replace an existing destination. Both paths have the same parent.
            os.link(tmp,path);tmp.unlink()
        else: os.replace(tmp,path)
        sync_dir(path.parent)
    finally:
        if tmp.exists(): tmp.unlink()


def write_json(path, value, *, new=False, mode=0o600):
    atomic_bytes(path,encode(value),new=new,mode=mode)


def read_json(path):
    path=no_symlinks(path)
    need(path.is_file(), 'E_FILE_MISSING', path.name)
    with path.open('rb') as f: return decode(f.read(1_048_577))


@contextmanager
def file_lock(path, timeout=2.0):
    platform_check()
    import fcntl
    path=no_symlinks(path)
    fd=os.open(path,os.O_CREAT|os.O_RDWR,0o600)
    deadline=time.monotonic()+timeout
    try:
        while True:
            try:
                fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);break
            except BlockingIOError:
                if time.monotonic()>=deadline:raise SaveError('E_BUSY',retryable=True)
                time.sleep(0.01)
        yield
    finally:
        fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)


def io_error(exc):
    if isinstance(exc,OSError) and exc.errno in (errno.ENOSPC,errno.EDQUOT):
        return SaveError('E_DISK_FULL',retryable=True)
    if isinstance(exc,PermissionError): return SaveError('E_PERMISSION')
    return SaveError('E_IO',type(exc).__name__)
