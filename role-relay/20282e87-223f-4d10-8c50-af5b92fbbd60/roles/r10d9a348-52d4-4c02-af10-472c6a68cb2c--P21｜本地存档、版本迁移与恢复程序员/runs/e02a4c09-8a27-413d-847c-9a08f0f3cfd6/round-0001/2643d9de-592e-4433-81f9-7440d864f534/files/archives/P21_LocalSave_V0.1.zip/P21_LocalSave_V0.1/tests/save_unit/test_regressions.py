"""Counterexamples found in P21 author code review; retained with failure evidence."""
from pathlib import Path
import json
import sqlite3
import tempfile
import unittest
from p21_persistence import *
from p21_persistence.model import byte_hash
from p21_persistence.adapters import P17CommitAdapter
from support.fixtures import create_simple,request,increment,NativeStageFixture


class ReviewRegressions(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='p21-review-');self.root=Path(self.tmp.name)
        self.addCleanup(self.tmp.cleanup)
    def test_duplicate_p17_cannot_change_raw_request_and_reuse_claimed_hash(self):
        from character_party_runtime import MetaPlanner,command
        h=NativeStageFixture(self.root);_,meta=h.snapshots();planner=MetaPlanner(h.wallet.catalog)
        ids=[x['character_id'] for x in meta.value['characters']]
        req=command(meta,'review.party','SET_PARTY',{'ordered_character_ids':ids})
        c=planner.plan(req,meta).candidate;adapter=P17CommitAdapter(h.store,planner);adapter.submit(c)
        modified=c.value;modified['request']['payload']['ordered_character_ids']=ids[::-1]
        with self.assertRaises(SaveError):adapter.submit(h.FrozenMessage.from_value(modified))
    def test_duplicate_p18_cannot_change_raw_request_and_reuse_claimed_hash(self):
        h=NativeStageFixture(self.root);bundle,_=h.enter()
        modified=bundle.value;modified['body']['stage_candidate']['request']['payload']['seed']=99
        with self.assertRaises(SaveError):h.adapter.submit(h.FrozenMessage.from_value(modified))
    def test_commit_error_after_database_commit_must_be_unknown(self):
        store=create_simple(self.root);original=store._connect
        class CommitReplyFailure:
            def __init__(self,c):self.c=c
            def __getattr__(self,k):return getattr(self.c,k)
            def commit(self):
                self.c.commit();exc=sqlite3.OperationalError('controlled result loss after COMMIT')
                exc.sqlite_errorcode=sqlite3.SQLITE_IOERR;exc.sqlite_errorname='SQLITE_IOERR'
                raise exc
        store._connect=lambda:CommitReplyFailure(original())
        with self.assertRaises(CommitUnknown):store.execute_once(request(),increment)
        store._connect=original
        self.assertEqual(store.lookup('fixture.tx')['status'],'COMMITTED')
    def test_deleted_migration_audit_is_detected(self):
        store=create_simple(self.root,schema=1);store.migrate(self.root/'backup')
        c=sqlite3.connect(store.db);c.execute('DELETE FROM maintenance_audit');c.commit();c.close()
        with self.assertRaises(SaveError) as err:store.snapshot()
        self.assertEqual(err.exception.code,'E_MIGRATION_AUDIT')
    def test_malformed_receipt_shape_freezes_with_typed_error(self):
        store=create_simple(self.root);store.execute_once(request(),increment)
        c=sqlite3.connect(store.db);c.execute('UPDATE transactions SET receipt=?,receipt_sha256=?',(b'{}',byte_hash(b'{}')));c.commit();c.close()
        with self.assertRaises(SaveError):store.snapshot()
        self.assertTrue((store.root/'FROZEN.json').exists())


if __name__=='__main__':unittest.main()
