CREATE TABLE maintenance_audit (
  sequence INTEGER PRIMARY KEY REFERENCES transactions(sequence)
    DEFERRABLE INITIALLY DEFERRED,
  from_version INTEGER NOT NULL,
  to_version INTEGER NOT NULL,
  backup_sha256 TEXT NOT NULL,
  source_chain_sha256 TEXT NOT NULL
);
