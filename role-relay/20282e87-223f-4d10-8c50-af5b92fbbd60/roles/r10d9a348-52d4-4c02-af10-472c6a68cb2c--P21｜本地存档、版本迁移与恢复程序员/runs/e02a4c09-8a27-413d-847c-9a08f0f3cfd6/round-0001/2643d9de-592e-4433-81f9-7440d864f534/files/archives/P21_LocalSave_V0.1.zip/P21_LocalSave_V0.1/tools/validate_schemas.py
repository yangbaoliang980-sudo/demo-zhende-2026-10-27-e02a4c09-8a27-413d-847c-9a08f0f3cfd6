"""Optional Draft 2020-12 oracle, separate from the stdlib-only runtime/tests.

Use jsonschema==4.23.0. --dependency-path can point to an isolated test install.
No dependencies are installed, downloaded or modified by this program.
"""
import bootstrap
import argparse
import copy
from dataclasses import asdict
import importlib.metadata
import json
from pathlib import Path
import sys
import tempfile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dependency-path');parser.add_argument('--output')
    args=parser.parse_args()
    if args.dependency_path:sys.path.insert(0,str(Path(args.dependency_path).resolve()))
    try:from jsonschema import Draft202012Validator
    except ImportError:
        print(json.dumps({'status':'NOT_RUN','reason':'jsonschema test dependency unavailable','exit_code':3}))
        return 3
    sys.path.insert(0,str(bootstrap.ROOT/'tests/save_unit'))
    from support.fixtures import create_simple,request,increment,NativeStageFixture,NativeLedgerFixture
    from p21_persistence import encode
    schemas={p.stem:json.loads(p.read_text()) for p in sorted((bootstrap.ROOT/'schema/save').glob('*.schema.json'))}
    checks=[]
    for name,value in schemas.items():
        Draft202012Validator.check_schema(value)
        checks.append({'case':name+':metaschema','status':'PASS'})
    validators={name:Draft202012Validator(value) for name,value in schemas.items()}
    def positive(name,label,value):
        validators[name].validate(value)
        checks.append({'case':label,'status':'PASS'})
    def negative(name,label,value):
        if not list(validators[name].iter_errors(value)):
            raise AssertionError(label+' unexpectedly accepted')
        checks.append({'case':label,'status':'PASS'})
    with tempfile.TemporaryDirectory(prefix='p21-schema-') as directory:
        root=Path(directory);simple=root/'simple';simple.mkdir();store=create_simple(simple)
        req=request();receipt=store.execute_once(req,increment)['proof']['receipt']
        backup=store.backup(root/'backup')['manifest']
        samples={
            'P21_save_head.schema':store.snapshot().anchor(),
            'P21_atomic_request.schema':asdict(req),
            'P21_commit_receipt.schema':receipt,
            'P21_backup_manifest.schema':backup,
        }
        for name,value in samples.items():
            positive(name,name+':actual-output',value)
            changed=copy.deepcopy(value);changed['unapproved_extra']=True
            negative(name,name+':reject-extra',changed)
            changed=copy.deepcopy(value);del changed[schemas[name]['required'][0]]
            negative(name,name+':reject-missing',changed)
        legacy=root/'legacy';legacy.mkdir();old=create_simple(legacy,schema=1)
        positive('P21_save_head.schema','v1-live-head',old.snapshot().anchor())
        migrated=old.migrate(root/'before_upgrade')['proof']['receipt']
        positive('P21_commit_receipt.schema','v1-to-v2-migration-receipt',migrated)
        native=root/'native';native.mkdir();h=NativeStageFixture(native)
        _,enter=h.enter();_,settlement=h.settle()
        for label,r in [('native-stage-entry',enter),('native-stage-settlement',settlement)]:
            positive('P21_commit_receipt.schema',label,r['proof']['receipt'])
        study=root/'study';study.mkdir();l=NativeLedgerFixture(study)
        r=l.ledger.handle(encode(l.ports.event())).receipt
        physical=l.store.lookup(r.transaction_id)['proof']['receipt']
        positive('P21_commit_receipt.schema','native-P11-with-synthetic-wallet-binding',physical)
        changed=copy.deepcopy(backup);changed['authority']=True
        negative('P21_backup_manifest.schema','backup-cannot-be-authority',changed)
        changed=copy.deepcopy(receipt);changed['origin']='P21_PRODUCTION'
        negative('P21_commit_receipt.schema','isolated-receipt-cannot-claim-production',changed)
        changed=copy.deepcopy(receipt);changed['sequence']=True
        negative('P21_commit_receipt.schema','boolean-is-not-integer-sequence',changed)
        changed=copy.deepcopy(receipt);changed['request_sha256']='not-a-hash'
        negative('P21_commit_receipt.schema','receipt-rejects-malformed-hash',changed)
    names=['jsonschema','attrs','jsonschema-specifications','referencing','rpds-py','typing-extensions']
    report={'scope':'AUTHOR_JSON_SCHEMA_ORACLE_ISOLATED','status':'PASS','checks_run':len(checks),
            'checks':checks,'dependencies':{name:importlib.metadata.version(name) for name in names},
            'P32_independent_schema_acceptance':'NOT_RUN'}
    raw=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
    if args.output:Path(args.output).write_text(raw,encoding='utf-8')
    print(raw,end='');return 0


if __name__=='__main__':raise SystemExit(main())
