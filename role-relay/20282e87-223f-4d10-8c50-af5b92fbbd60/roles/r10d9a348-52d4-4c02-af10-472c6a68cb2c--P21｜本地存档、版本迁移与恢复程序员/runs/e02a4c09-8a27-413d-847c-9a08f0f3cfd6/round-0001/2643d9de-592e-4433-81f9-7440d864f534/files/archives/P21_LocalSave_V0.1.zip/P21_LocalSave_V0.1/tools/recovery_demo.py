"""Create NEW synthetic data, deliberately damage it, preserve and recover it.

Never accepts an existing directory. No real game or Anki data is inspected.
"""
import bootstrap
import argparse
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0,str(bootstrap.ROOT/'tests/save_unit'))
from support.fixtures import create_simple,request,increment
from p21_persistence import SaveError


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    args=parser.parse_args();out=Path(args.output).resolve();out.mkdir(parents=False,exist_ok=False)
    store=create_simple(out);store.backup(out/'older_backup')
    first=store.execute_once(request(),increment);store.backup(out/'latest_backup')
    before=store.snapshot();damaged=bytearray(store.db.read_bytes());damaged[:16]=b'BROKEN-P21-TEST!!'
    store.db.write_bytes(damaged);status=store.status()
    assert status['state']=='RECOVERY_REQUIRED'
    rejected=None
    try:store.recover_exact(out/'older_backup')
    except SaveError as error:rejected=error.code
    assert rejected=='E_DATA_LOSS_OR_FOREIGN_RESTORE_BLOCKED'
    recovered=store.recover_exact(out/'latest_backup')
    def forbidden(_):raise AssertionError('recovery attempted a second award')
    duplicate=store.execute_once(request(),forbidden);after=store.snapshot()
    assert duplicate['duplicate'] and duplicate['proof']==first['proof'] and before==after
    captured=store.root/recovered['raw_evidence']/store.db.name
    assert captured.read_bytes()==bytes(damaged)
    report={'schema_version':'P21-FORENSIC-DEMO/1','scope':'NEW_SYNTHETIC_FIXTURE_REAL_FILES_ONLY',
        'status':'PASS','detection':status,'old_backup_activation':rejected,
        'recovery':recovered,'duplicate_request_returned_original_receipt':True,
        'counter_net':after.records['meta'].value['counter'],'ledger_counter':after.records['ledger'].value['counter'],
        'before_head':before.anchor(),'after_head':after.anchor(),
        'damaged_source_sha256':hashlib.sha256(damaged).hexdigest(),
        'captured_original_sha256':hashlib.sha256(captured.read_bytes()).hexdigest(),
        'real_Anki':'NOT_RUN','physical_power_cut':'NOT_RUN'}
    raw=json.dumps(report,ensure_ascii=False,indent=2)+'\n';(out/'forensic_result.json').write_text(raw,encoding='utf-8')
    print(raw,end='');return 0


if __name__=='__main__':raise SystemExit(main())
