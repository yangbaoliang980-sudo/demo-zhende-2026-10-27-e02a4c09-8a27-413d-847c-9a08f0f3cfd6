#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V6.0 independent artifact integrity and static consistency test.
Does NOT test Unity, Anki hooks, application E2E, or visual quality.
Usage: python 第六轮_静态自检程序V6.0.py [<v6_archive.zip>]
"""
from pathlib import Path
import json,csv,re,hashlib,zipfile,sys

ROOT=Path(__file__).resolve().parent
checks=[]

def check(cond,explanation):
    if not cond: raise AssertionError('FAIL: '+explanation)
    checks.append('PASS: '+explanation)

def rows(n):
    with (ROOT/n).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f,delimiter='\t'))

def data(n):return json.loads((ROOT/n).read_text(encoding='utf-8-sig'))

roledata=data('第六轮_43岗独立职责与激活状态V6.0.json')
roles=roledata['roles']
ids={x['role_id'] for x in roles}
check(len(roles)==43 and len(ids)==43 and ids=={f'P{i:02d}' for i in range(1,44)},'P01—P43 unique role IDs')
check(len([x for x in roles if x['active_in_current_scope']])==39,'39 current logical positions')
cat={s:sum(1 for x in roles if x['category']==s) for s in ['核心常驻岗位','阶段性专业岗位','可兼任独立交付岗位','暂不设置/条件保留岗位']}
check(cat=={'核心常驻岗位':14,'阶段性专业岗位':17,'可兼任独立交付岗位':8,'暂不设置/条件保留岗位':4},'14/17/8/4 classification and count')
check({x['role_id'] for x in roles if not x['active_in_current_scope']}=={'P31','P41','P42','P43'},'conditional roles not auto-activated')
required=['一、定位与激活：','二、负责范围及文件：','三、上游输入：','四、必须完成的工作：','五、具体交付：','六、验收与验证：','七、可决定与须上报：','八、协作顺序与接口：','九、禁止事项：','十、异常与交接恢复：','思考强度：极高','会话：新建']
for x in roles:
    check(all(k in x['copy_card'] for k in required),x['role_id']+' all 10 clauses and exact fields')
copy=(ROOT/'第六轮_全部岗位职责_可复制版V6.0.txt').read_text(encoding='utf-8')
check(copy.count('\n---\n')==42,'42 separators, 43 copy blocks')
check(len(re.findall(r'(?m)^角色：P\d\d｜',copy))==43 and len(re.findall(r'(?m)^职责：$',copy))==43,'role/copy header counts')
check(len(re.findall(r'(?m)^思考强度：极高$',copy))==43 and len(re.findall(r'(?m)^会话：新建$',copy))==43,'exact model/session fields')
work=rows('第六轮_92项职责冻结映射V6.0.tsv')
check(len(work)==92 and [x['职责ID'] for x in work]==[f'{i:03d}' for i in range(1,93)],'92 unique atomic work IDs')
check(all(x['V6唯一主责'] in ids for x in work),'all work items have existing owners')
check('P14' in work[13]['冻结工作项'] and work[13]['V6唯一主责']=='P15','014 P15 validates candidate, P14 submits real fee')
check(all(x['是否当前设岗']=='否-条件保留' for x in work if x['V6唯一主责'] in {'P31','P41','P42','P43'}),'deferred responsibilities are flagged')
contracts=data('第六轮_27项接口契约冻结修订V6.0.json')['contracts']
check(len(contracts)==27 and {x['id'] for x in contracts}=={f'IC-{i:02d}' for i in range(1,28)},'27 unique IC IDs')
rm={x['role_id']:x for x in roles}
check(all(x['id'] in rm[x['owner']]['contract_ids'] for x in contracts),'every IC contract listed by own role')
check('IC-19' in rm['P21']['contract_ids'],'P21 IC-19 reference corrected')
check('runtime/meta/wallet/**' in rm['P17']['allowed_planning_paths'],'P17 wallet unique planned path')
check('P19' in rm['P29']['v6_priority'] and 'P14' in rm['P29']['v6_priority'],'P29 cannot own HUD/HP truth')
issues=rows('第六轮_26项问题最终责任状态V6.0.tsv')
check(len(issues)==26 and {x['问题ID'] for x in issues}=={f'D{i:02d}' for i in range(1,27)},'26 defect IDs retained')
status={x['问题ID']:x['V6状态'] for x in issues}
check(status['D08'].startswith('OPEN') and status['D11'].startswith('OPEN') and status['D26'].startswith('OPEN'),'identity, policy, external integration remain open')
check('HISTORICAL_BROKEN' in status['D01'],'D01 legacy damaged file not described as fixed')
stress=rows('第六轮_22个压力场景冻结用例V6.0.tsv')
check(len(stress)==22 and {x['案例ID'] for x in stress}=={f'T{i:02d}' for i in range(1,23)},'22 design stress cases retained')
check(all(x['V6验收状态']=='SPEC_CASE_READY_RUNTIME_NOT_RUN' for x in stress),'stress cases not misrepresented as executed')
phases=rows('第六轮_阶段与岗位激活计划V6.0.tsv')
check(len(phases)==12 and {x['阶段'] for x in phases}=={'PRE-S03'}|{f'S{i:02d}' for i in range(11)},'S00-S10 + PRE-S03 with distinct owners')
check(all(x['唯一阶段负责人'] in ids for x in phases),'all stage leads valid')
hist=rows('第六轮_43岗位历次演变裁定表V6.0.tsv')
check(len(hist)==43 and {x['V6编号'] for x in hist}==ids,'43 historic disposition records')
pending=rows('第六轮_实施前待核验及阻塞清单V6.0.tsv')
check(len(pending)==10 and all(x['实际解除']=='否' for x in pending),'10 known implementation blockers remain visible')
report=(ROOT/'第六轮_游戏研发岗位体系最终冻结版V6.0.txt').read_text(encoding='utf-8')
check(copy in report,'full report embeds exact copy blocks')
check('BLOCKED' in report and 'NOT_RUN' in report,'report discloses unverified capabilities')
manifestpath=ROOT/'SHA256_MANIFEST.json'
if manifestpath.exists():
    man=data('SHA256_MANIFEST.json')
    for f in man['files']:
        p=ROOT/f['name'];check(p.is_file() and p.stat().st_size==f['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],'manifest bytes '+f['name'])
if len(sys.argv)>1:
    with zipfile.ZipFile(sys.argv[1]) as z:
        check(z.testzip() is None,'external delivery zip CRC')
        for obj in z.infolist():
            p=ROOT/obj.filename
            check(p.exists() and z.read(obj.filename)==p.read_bytes(),'external ZIP matches independent file '+obj.filename)
print('\n'.join(checks))
print(f'RESULT: STATIC_VERIFIED ({len(checks)} checks); GAME_RUNTIME=NOT_RUN; ANKI_RUNTIME=NOT_RUN; E2E=NOT_RUN; GA=BLOCKED')
