"""Explicit definitions and references for the received, pinned owner formats.

Narrative text is not parsed as an ID. Mirrors create references, not duplicate
definitions. Compatibility relationships never become identity aliases.
"""
from .index import Index
from .io import pointer

def collect(documents,descriptors,finish=True):
    x=Index(documents,descriptors)
    d=documents
    k='P03_card_catalog';c=d[k]
    for bucket,kind,idfield in [('fixture_only_character_slots','character','character_id'),('skills','skill','skill_id'),('effects','effect','effect_id'),('cards','card','card_id')]:
        for i,o in enumerate(c[bucket]):x.define(k,pointer([bucket,i,idfield]),kind,o[idfield])
    for i,o in enumerate(c['fixture_only_character_slots']):
        for field,kind in [('skill_id','skill'),('signature_card_id','card')]:x.ref(k,pointer(['fixture_only_character_slots',i,field]),kind,o[field])
    for i,o in enumerate(c['skills']):
        for field,kind in [('character_id','character'),('card_id','card')]:x.ref(k,pointer(['skills',i,field]),kind,o[field])
    for i,o in enumerate(c['effects']):
        if 'status_id' in o:x.define(k,pointer(['effects',i,'status_id']),'status',o['status_id'])
    chars={o['character_id']:o for o in c['fixture_only_character_slots']}
    skills={o['skill_id']:o for o in c['skills']}
    cards={o['card_id']:o for o in c['cards']}
    for i,o in enumerate(c['cards']):
        for field,kind in [('owner_character_id','character'),('skill_id','skill')]:x.ref(k,pointer(['cards',i,field]),kind,o[field])
        for j,e in enumerate(o['effect_ids']):x.ref(k,pointer(['cards',i,'effect_ids',j]),'effect',e)
        if o['scope']=='SIGNATURE' and o['skill_id'] in skills:
            x.equal(k,pointer(['cards',i,'owner_character_id']),o['owner_character_id'],skills[o['skill_id']]['character_id'],'E_SIGNATURE_BINDING')
            x.equal(k,pointer(['cards',i,'card_id']),o['card_id'],skills[o['skill_id']]['card_id'],'E_SIGNATURE_BINDING')
    x.equal(k,'/active_mock_card_count',c['active_mock_card_count'],sum(o['mock_playable'] for o in c['cards']))
    k='P03_card_dictionary'
    seen=set()
    for i,r in enumerate(d[k]):
        if r['card_id'] in seen:x.issue('E_DUPLICATE_VIEW_ROW',k,pointer([i,'card_id']),'Repeated card dictionary row')
        seen.add(r['card_id']);x.ref(k,pointer([i,'card_id']),'card',r['card_id'])
        for f,t in [('owner_character_id','character'),('skill_id','skill')]:
            if r[f]:x.ref(k,pointer([i,f]),t,r[f])
        effects=r['effect_ids'].split(';') if r['effect_ids'] else []
        for j,e in enumerate(effects):x.ref(k,pointer([i,'effect_ids',j]),'effect',e)
        if r['card_id'] in cards:
            o=cards[r['card_id']]
            expected={'display_name':o['display_name'],'category':o['category'],'stage':o['introduction_stage'],'scope':o['scope'],'mock_playable':o['mock_playable'],'cost_energy_TEST_ONLY':o['cost']['amount'],'target_side':o['target_rule']['side'],'target_count':o['target_rule']['target_count'],'owner_character_id':o['owner_character_id'] or '','skill_id':o['skill_id'] or '','gate':o['gate']}
            for f,v in expected.items():x.equal(k,pointer([i,f]),r[f],v)
            x.equal(k,pointer([i,'effect_ids']),effects,o['effect_ids'])
    x.equal(k,'',sorted(seen),sorted(cards),'E_VIEW_COVERAGE')
    k='P03_character_card_pool';seen=set()
    for i,r in enumerate(d[k]):
        if r['character_id'] in seen:x.issue('E_DUPLICATE_VIEW_ROW',k,pointer([i,'character_id']),'Repeated pool row')
        seen.add(r['character_id'])
        for f,t in [('character_id','character'),('skill_id','skill'),('signature_card_id','card')]:x.ref(k,pointer([i,f]),t,r[f])
        if r['character_id'] in chars:
            for f in ['skill_id','signature_card_id']:x.equal(k,pointer([i,f]),r[f],chars[r['character_id']][f])
    x.equal(k,'',sorted(seen),sorted(chars),'E_VIEW_COVERAGE')

    k='P04_character_skeleton';s=d[k]
    for f in ['xp_kind','cost_resource']:x.define(k,pointer(['economy_fixture',f]),'resource',s['economy_fixture'][f])
    p04chars={o['character_id']:o for o in s['characters']}
    for i,o in enumerate(s['characters']):
        x.define(k,pointer(['characters',i,'character_id']),'character',o['character_id'])
        x.define(k,pointer(['characters',i,'skill','local_skill_id']),'skill',o['skill']['local_skill_id'])
        x.ref(k,pointer(['characters',i,'skill','p03_fixture_skill_id']),'skill',o['skill']['p03_fixture_skill_id'],relation='COMPATIBILITY_NOT_IDENTITY')
        comp=o['p03_fixture_compatibility']
        x.ref(k,pointer(['characters',i,'p03_fixture_compatibility','p03_slot_character_id']),'character',comp['p03_slot_character_id'],relation='COMPATIBILITY_NOT_IDENTITY')
        x.ref(k,pointer(['characters',i,'p03_fixture_compatibility','signature_card_id']),'card',comp['signature_card_id'])
        if comp['p03_slot_character_id'] in chars:
            slot=chars[comp['p03_slot_character_id']]
            x.equal(k,pointer(['characters',i,'p03_fixture_compatibility','signature_card_id']),comp['signature_card_id'],slot['signature_card_id'],'E_COMPATIBILITY_BINDING')
            x.equal(k,pointer(['characters',i,'skill','p03_fixture_skill_id']),o['skill']['p03_fixture_skill_id'],slot['skill_id'],'E_COMPATIBILITY_BINDING')
        art=o['art']
        if art['asset_id'] is None:x.block('B_CHARACTER_ART_UNBOUND',k,pointer(['characters',i,'art','asset_id']),'No delivered character asset ID/hash binding','P26/P30')
        else:x.ref(k,pointer(['characters',i,'art','asset_id']),'asset',art['asset_id'])
    x.equal(k,'/character_count',s['character_count'],len(s['characters']))
    k='P04_progression_costs'
    for i,r in enumerate(d[k]):
        x.define(k,pointer([i,'row_id']),'progression_row',r['row_id'])
        x.ref(k,pointer([i,'character_id']),'character',r['character_id'])
        if r['spend_resource']!='NONE':x.ref(k,pointer([i,'spend_resource']),'resource',r['spend_resource'])
        if r['spend_resource']=='NONE' and r['spend_amount']!=0:x.issue('E_RESOURCE_SENTINEL',k,pointer([i,'spend_amount']),'NONE resource cannot carry a nonzero cost')
    k='P04_character_deck_contribution';seen=set()
    for i,r in enumerate(d[k]):
        key=(r['row_kind'],r['p04_character_id'],r['p03_card_id'])
        if key in seen:x.issue('E_DUPLICATE_VIEW_ROW',k,pointer([i]),'Repeated deck contribution')
        seen.add(key)
        for f,t in [('p04_character_id','character'),('p03_fixture_slot_id','character'),('p03_card_id','card'),('p03_skill_id','skill')]:
            if r[f]:x.ref(k,pointer([i,f]),t,r[f],relation='COMPATIBILITY_NOT_IDENTITY' if f=='p03_fixture_slot_id' else 'REFERENCE')
        x.equal(k,pointer([i,'p03_source_sha256']),r['p03_source_sha256'],descriptors['P03_card_catalog']['actual_sha256'],'E_SOURCE_BINDING')
        if r['p04_character_id'] in p04chars:
            pc=p04chars[r['p04_character_id']]
            for field,expected in [('p03_fixture_slot_id',pc['p03_fixture_compatibility']['p03_slot_character_id']),('p03_card_id',pc['p03_fixture_compatibility']['signature_card_id']),('p03_skill_id',pc['skill']['p03_fixture_skill_id'])]:x.equal(k,pointer([i,field]),r[field],expected,'E_COMPATIBILITY_BINDING')

    k='P06_enemy_specs';es=d[k];enemy_by_id={o['enemy_id']:o for o in es['enemies']};p06skills={o['skill_id']:o for o in es['skills']}
    for i,o in enumerate(es['skills']):
        x.define(k,pointer(['skills',i,'skill_id']),'skill',o['skill_id'])
        x.ref(k,pointer(['skills',i,'intent_id']),'intent',o['intent_id'])
        if o.get('charge_requirement') and isinstance(o['charge_requirement'],dict):
            for field in ['release_skill_id','charge_skill_id']:
                if field in o['charge_requirement']:x.ref(k,pointer(['skills',i,'charge_requirement',field]),'skill',o['charge_requirement'][field])
    for i,o in enumerate(es['enemies']):
        x.define(k,pointer(['enemies',i,'enemy_id']),'enemy',o['enemy_id'])
        states={st['state_id']:st for st in o['states']}
        for j,state in enumerate(o['states']):
            x.define(k,pointer(['enemies',i,'states',j,'state_id']),'behavior_state',state['state_id'],scope=o['enemy_id'])
            x.ref(k,pointer(['enemies',i,'states',j,'next_state_id']),'behavior_state',state['next_state_id'],scope=o['enemy_id'],relation='BEHAVIOR_CYCLE_ALLOWED')
            x.ref(k,pointer(['enemies',i,'states',j,'skill_id']),'skill',state['skill_id'])
            if 'phase_id' in state:x.ref(k,pointer(['enemies',i,'states',j,'phase_id']),'phase',state['phase_id'])
            next_state=states.get(state['next_state_id'])
            if next_state and state.get('phase_id')!=next_state.get('phase_id'):x.issue('E_BEHAVIOR_PHASE_CROSS',k,pointer(['enemies',i,'states',j,'next_state_id']),'Behavior successor cannot replace an authoritative phase transition')
        x.ref(k,pointer(['enemies',i,'initial_state_id']),'behavior_state',o['initial_state_id'],scope=o['enemy_id'])
        for phase,state in o.get('phase_initial_state_ids',{}).items():
            x.ref(k,pointer(['enemies',i,'phase_initial_state_ids',phase]),'phase',phase)
            x.ref(k,pointer(['enemies',i,'phase_initial_state_ids',phase]),'behavior_state',state,scope=o['enemy_id'])
        for field,t in [('phase_graph_id','phase_graph'),('degraded_basic_skill_id','skill')]:
            if field in o:x.ref(k,pointer(['enemies',i,field]),t,o[field])
        for j,v in enumerate(o['allowed_new_status_ids']):x.ref(k,pointer(['enemies',i,'allowed_new_status_ids',j]),'status',v)
        for j,v in enumerate(o['on_death_reaction_ids']):x.ref(k,pointer(['enemies',i,'on_death_reaction_ids',j]),'effect',v)
        if o['asset_registry_id'] is None:x.block('B_ENEMY_ART_UNBOUND',k,pointer(['enemies',i,'asset_registry_id']),'Enemy asset catalog entry is missing','P27/P30')
        else:x.ref(k,pointer(['enemies',i,'asset_registry_id']),'asset',o['asset_registry_id'])
    k='P06_intent_dictionary'
    for i,r in enumerate(d[k]):
        x.define(k,pointer([i,'intent_id']),'intent',r['intent_id']);x.ref(k,pointer([i,'skill_id']),'skill',r['skill_id'])
        if r['skill_id'] in p06skills:
            o=p06skills[r['skill_id']]
            for f,cf in [('intent_id','intent_id'),('semantic_kind','action_kind'),('current_base_amount_per_hit','base_amount_per_hit'),('current_hit_count','hit_count'),('future_base_amount_per_hit','future_release_base_amount'),('target_policy','target_policy')]:x.equal(k,pointer([i,f]),r[f],o[cf])
    k='P06_asset_requests'
    for i,r in enumerate(d[k]):
        x.define(k,pointer([i,'request_key']),'asset_request',r['request_key']);x.ref(k,pointer([i,'enemy_id']),'enemy',r['enemy_id'])
        if r['phase_id']!='NONE':x.ref(k,pointer([i,'phase_id']),'phase',r['phase_id'])
        if r['asset_id']=='UNREGISTERED':
            x.block('B_ASSET_REQUEST_UNFULFILLED',k,pointer([i,'asset_id']),'Art request is not an asset definition','P27/P30')
            if r['actual_asset_sha256']!='NOT_RECEIVED':x.issue('E_ASSET_REQUEST_BINDING',k,pointer([i,'actual_asset_sha256']),'Unregistered art request cannot assert a delivered asset digest')
        else:x.ref(k,pointer([i,'asset_id']),'asset',r['asset_id'])
    k='P06_boss_phase_graph';g=d[k];ranks={p['phase_id']:p['rank'] for p in g['phases']}
    if len(set(ranks.values()))!=len(g['phases']):x.issue('E_PHASE_RANK_DUPLICATE',k,'/phases','Phase ranks must be distinct')
    bound_enemy=enemy_by_id.get(g['enemy_id'])
    if bound_enemy:
        x.equal(k,'/graph_id',g['graph_id'],bound_enemy.get('phase_graph_id'),'E_BOSS_GRAPH_BINDING')
        x.equal(k,'/max_hp_fixture',g['max_hp_fixture'],bound_enemy['max_hp'],'E_BOSS_GRAPH_BINDING')
        for phase in g['phases']:
            x.equal(k,'/phases/'+str(g['phases'].index(phase))+'/initial_state_id',phase['initial_state_id'],bound_enemy.get('phase_initial_state_ids',{}).get(phase['phase_id']),'E_BOSS_GRAPH_BINDING')
    for i,enemy in enumerate(es['enemies']):
        if enemy.get('phase_graph_id')==g['graph_id'] and enemy['enemy_id']!=g['enemy_id']:x.issue('E_BOSS_GRAPH_BINDING','P06_enemy_specs',pointer(['enemies',i,'phase_graph_id']),'Referenced phase graph belongs to another enemy')
    x.define(k,'/graph_id','phase_graph',g['graph_id']);x.ref(k,'/enemy_id','enemy',g['enemy_id']);x.ref(k,'/initial_phase_id','phase',g['initial_phase_id'])
    for i,p in enumerate(g['phases']):
        x.define(k,pointer(['phases',i,'phase_id']),'phase',p['phase_id'])
        x.ref(k,pointer(['phases',i,'entry_wait_skill_id']),'skill',p['entry_wait_skill_id'])
        x.ref(k,pointer(['phases',i,'initial_state_id']),'behavior_state',p['initial_state_id'],scope=g['enemy_id'])
        x.ref(k,pointer(['phases',i,'asset_request_key']),'asset_request',p['asset_request_key'])
    phase_edges=[]
    for i,t in enumerate(g['transitions']):
        x.define(k,pointer(['transitions',i,'transition_id']),'phase_transition',t['transition_id'])
        for f in ['from_phase_id','to_phase_id']:x.ref(k,pointer(['transitions',i,f]),'phase',t[f])
        phase_edges.append((t['from_phase_id'],t['to_phase_id']))
        if t['from_phase_id'] in ranks and t['to_phase_id'] in ranks and ranks[t['from_phase_id']]>=ranks[t['to_phase_id']]:x.issue('E_PHASE_REGRESSION',k,pointer(['transitions',i]),'Phase transition must increase rank')
        f=t['threshold_max_hp_fraction']
        if f['denominator']<=0 or f['numerator']*100!=t['threshold_percent']*f['denominator']:x.issue('E_THRESHOLD_MIRROR',k,pointer(['transitions',i,'threshold_max_hp_fraction']),'Threshold fraction and percentage disagree')
    x.dag('phase_transitions',phase_edges,k,'/transitions')
    for i,t in enumerate(g['terminal_exits']):x.ref(k,pointer(['terminal_exits',i,'from_phase_id']),'phase',t['from_phase_id'])
    for f in ['first_skill_id','then_skill_id']:x.ref(k,pointer(['degraded_exit',f]),'skill',g['degraded_exit'][f])

    k='P07_stage_graph';g=d[k];stage_by_id={s['stage_id']:s for s in g['stages']};chapter=g['chapter'];unlock=[]
    x.define(k,'/chapter/chapter_id','chapter',chapter['chapter_id'])
    for f in ['entry_stage_ids','completion_stage_ids']:
        for i,v in enumerate(chapter[f]):x.ref(k,pointer(['chapter',f,i]),'stage',v)
    if chapter['next_chapter_id'] is not None:x.ref(k,'/chapter/next_chapter_id','chapter',chapter['next_chapter_id'])
    if chapter['chapter_completion_reward_id'] is not None:x.ref(k,'/chapter/chapter_completion_reward_id','reward',chapter['chapter_completion_reward_id'])
    for i,s in enumerate(g['stages']):
        x.define(k,pointer(['stages',i,'stage_id']),'stage',s['stage_id']);x.ref(k,pointer(['stages',i,'canonical_stage_id']),'stage',s['canonical_stage_id'])
        x.equal(k,pointer(['stages',i,'canonical_stage_id']),s['canonical_stage_id'],s['stage_id'],'E_CANONICAL_CHANGE_UNAPPROVED')
        x.ref(k,pointer(['stages',i,'chapter_id']),'chapter',s['chapter_id'])
        for j,e in enumerate(s['enemy_refs']):
            x.ref(k,pointer(['stages',i,'enemy_refs',j,'enemy_id']),'enemy',e['enemy_id'])
            x.equal(k,pointer(['stages',i,'enemy_refs',j,'source_sha256']),e['source_sha256'],descriptors['P06_enemy_specs']['actual_sha256'],'E_SOURCE_BINDING')
        x.ref(k,pointer(['stages',i,'boss_phase_graph_id']),'phase_graph',s['boss_phase_graph_id'])
        if s['boss_phase_graph_id']==d['P06_boss_phase_graph']['graph_id'] and d['P06_boss_phase_graph']['enemy_id'] not in [e['enemy_id'] for e in s['enemy_refs']]:x.issue('E_STAGE_BOSS_BINDING',k,pointer(['stages',i,'boss_phase_graph_id']),'Boss graph must belong to an enemy admitted by this stage')
        for domain,rid in s['reward_ids'].items():x.ref(k,pointer(['stages',i,'reward_ids',domain]),'reward',rid)
        for j,p in enumerate(s['unlock_rule']['requires_stage_ids']):
            x.ref(k,pointer(['stages',i,'unlock_rule','requires_stage_ids',j]),'stage',p);unlock.append((p,s['stage_id']))
    edges=[]
    for i,e in enumerate(g['unlock_edges']):
        x.define(k,pointer(['unlock_edges',i,'edge_id']),'stage_edge',e['edge_id'])
        for f in ['from_stage_id','to_stage_id']:x.ref(k,pointer(['unlock_edges',i,f]),'stage',e[f])
        edges.append((e['from_stage_id'],e['to_stage_id']))
    x.equal(k,'/unlock_edges',sorted(edges),sorted(unlock),'E_UNLOCK_MIRROR');x.dag('stage_unlocks',unlock,k,'/stages')
    for i,r in enumerate(g['reserved_entries']):
        x.define(k,pointer(['reserved_entries',i,'reservation_id']),'reservation',r['reservation_id'])
        x.ref(k,pointer(['reserved_entries',i,'enemy_id']),'enemy',r['enemy_id'])
    k='P07_stage_content_catalog';catalog=d[k];reward_by_id={r['reward_id']:r for r in catalog['reward_bundles']}
    for i,r in enumerate(catalog['reward_bundles']):
        x.define(k,pointer(['reward_bundles',i,'reward_id']),'reward',r['reward_id']);x.ref(k,pointer(['reward_bundles',i,'stage_id']),'stage',r['stage_id'])
    for i,r in enumerate(catalog['resources']):x.ref(k,pointer(['resources',i,'resource_id']),'resource',r['resource_id'])
    for f,t in [('character_ids','character'),('stage_ids','stage')]:
        for i,v in enumerate(catalog[f]):x.ref(k,pointer([f,i]),t,v)
    x.equal(k,'/stage_ids',sorted(catalog['stage_ids']),sorted(stage_by_id),'E_VIEW_COVERAGE')
    k='P07_stage_rewards';reward_values={};seen=set()
    for i,r in enumerate(d[k]):
        for f,t in [('stage_id','stage'),('reward_id','reward'),('resource_id','resource')]:x.ref(k,pointer([i,f]),t,r[f])
        identity=(r['reward_id'],r['grant_kind'])
        if identity in seen:x.issue('E_DUPLICATE_REWARD_COMPONENT',k,pointer([i]),'Repeated reward/grant kind')
        seen.add(identity);reward_values[identity]=r['quantity']
        if r['reward_id'] in reward_by_id:
            bundle=reward_by_id[r['reward_id']]
            for f,bf in [('stage_id','stage_id'),('reward_domain','domain'),('enabled_in_candidate','enabled_in_candidate')]:x.equal(k,pointer([i,f]),r[f],bundle[bf])
    k='P07_stage_table';seen=set()
    for i,r in enumerate(d[k]):
        if r['stage_id'] in seen:x.issue('E_DUPLICATE_VIEW_ROW',k,pointer([i,'stage_id']),'Repeated stage row')
        seen.add(r['stage_id'])
        for f,t in [('stage_id','stage'),('chapter_id','chapter'),('enemy_id','enemy'),('requires_stage_id','stage'),('boss_phase_graph_id','phase_graph'),('first_clear_reward_id','reward'),('repeat_reward_id','reward')]:
            if r[f]:x.ref(k,pointer([i,f]),t,r[f])
        if r['stage_id'] in stage_by_id:
            s=stage_by_id[r['stage_id']]
            for f in ['chapter_id','order','tier','display_name','on_failure','production_enabled']:x.equal(k,pointer([i,f]),r[f],s[f])
            x.equal(k,pointer([i,'enemy_id']),r['enemy_id'],s['enemy_refs'][0]['enemy_id'])
            x.equal(k,pointer([i,'enemy_count']),r['enemy_count'],s['enemy_refs'][0]['count'])
            x.equal(k,pointer([i,'requires_stage_id']),r['requires_stage_id'],';'.join(s['unlock_rule']['requires_stage_ids']))
            x.equal(k,pointer([i,'boss_phase_graph_id']),r['boss_phase_graph_id'],s['boss_phase_graph_id'] or '')
            for f,domain in [('first_clear_reward_id','FIRST_CLEAR'),('repeat_reward_id','REPEAT_CLEAR')]:x.equal(k,pointer([i,f]),r[f],s['reward_ids'][domain])
            for f,domain,gk in [('first_tokens_shared','FIRST_CLEAR','SHARED_TOKEN'),('first_xp_each_admitted_character','FIRST_CLEAR','CHARACTER_XP'),('repeat_tokens','REPEAT_CLEAR','SHARED_TOKEN'),('repeat_xp','REPEAT_CLEAR','CHARACTER_XP')]:x.equal(k,pointer([i,f]),r[f],reward_values.get((s['reward_ids'][domain],gk)))
    x.equal(k,'',sorted(seen),sorted(stage_by_id),'E_VIEW_COVERAGE')

    k='P09_pos_mapping_rules';rules=d[k];scope=rules['mapping_version']
    for i,c in enumerate(rules['categories']):
        x.define(k,pointer(['categories',i,'code']),'category',c['code'],scope=scope)
        for field,kind,owner in [('formal_category_id','category','P22/P09'),('formal_resource_id','resource','P01/P08/P22')]:
            if c[field] is None:x.block('B_FORMAL_LINGUISTIC_BINDING',k,pointer(['categories',i,field]),'Proposal has no approved formal '+kind+' identity',owner)
            else:x.ref(k,pointer(['categories',i,field]),kind,c[field])
    x.ref(k,'/unknown_category','category',rules['unknown_category'],scope)
    for alias,target in rules['category_aliases'].items():x.ref(k,pointer(['category_aliases',alias]),'category',target,scope)
    for alias,targets in rules['compound_pos_labels'].items():
        for i,target in enumerate(targets):x.ref(k,pointer(['compound_pos_labels',alias,i]),'category',target,scope)
    x.ref(k,'/mapping_version','mapping_release',scope)
    k='P09_category_dictionary';x.equal(k,'/categories',d[k]['categories'],rules['categories'])
    x.ref(k,'/mapping_version','mapping_release',d[k]['mapping_version'])
    for i,c in enumerate(d[k]['categories']):x.ref(k,pointer(['categories',i,'code']),'category',c['code'],scope)
    k='P09_mapping_release_registry';seen=set()
    for i,r in enumerate(d[k]['releases']):
        x.define(k,pointer(['releases',i,'version']),'mapping_release',r['version'])
        x.equal(k,pointer(['releases',i,'rules_path']),r['rules_path'],'content/linguistic/pos_mapping_rules.json','E_RELEASE_PATH')
        x.equal(k,pointer(['releases',i,'sha256']),r['sha256'],descriptors['P09_pos_mapping_rules']['actual_sha256'],'E_RELEASE_HASH')
    k='P09_resource_affinity_candidates'
    for i,r in enumerate(d[k]):
        x.ref(k,pointer([i,'category']),'category',r['category'],scope)
        if r['formal_resource_id']!='UNSET':x.ref(k,pointer([i,'formal_resource_id']),'resource',r['formal_resource_id'])
        cat=next((c for c in rules['categories'] if c['code']==r['category']),None)
        if cat is not None:x.equal(k,pointer([i,'resource_role_proposal']),r['resource_role_proposal'],cat['resource_role_proposal'])
    return x.finish() if finish else x
