import copy
from .io import read_json,read_bytes,sha256
from .schema import SchemaBank
from .pipeline import load_dataset
from .references import collect
from .assets import check_assets

def run_samples(root):
    bank=SchemaBank(root);plan,docs,descs,checks,issues=load_dataset(root,bank)
    if issues:return {'status':'FAIL','reason':'Baseline inputs are invalid','issues':issues}
    base='tools/content_validation/fixtures/'
    catalog=read_json(root,base+'negative_sample_catalog.json');results=[]
    for case in catalog['cases']:
        path=base+case['file'];data=read_json(root,path);key=case['document_key']
        if key=='asset_catalog':errors=check_assets(root,data,bank)['issues']
        else:
            errors=bank.errors(descs[key]['schema'],data)
            errors=[dict(e,file=path) for e in errors]
            if not errors:
                altered=copy.deepcopy(docs);altered[key]=data
                ds=copy.deepcopy(descs);ds[key]['path']=path;ds[key]['actual_sha256']=sha256(read_bytes(root,path))
                errors=collect(altered,ds).issues
        found=[e for e in errors if e['code']==case['expected']]
        results.append({'case_id':case['id'],'file':path,'sample_sha256':sha256(read_bytes(root,path)),'expected_code':case['expected'],'observed_codes':sorted(set(e['code'] for e in errors)),'validation_exit_code':2 if errors else 0,'sample_data_status':'REJECTED' if errors else 'UNEXPECTEDLY_ACCEPTED','test_status':'PASS' if found else 'FAIL','matching_diagnostics':found})
    return {'scope':'AUTHOR_NEGATIVE_TESTS_SYNTHETIC_COPIES','status':'PASS' if all(r['test_status']=='PASS' for r in results) else 'FAIL','cases':results}
