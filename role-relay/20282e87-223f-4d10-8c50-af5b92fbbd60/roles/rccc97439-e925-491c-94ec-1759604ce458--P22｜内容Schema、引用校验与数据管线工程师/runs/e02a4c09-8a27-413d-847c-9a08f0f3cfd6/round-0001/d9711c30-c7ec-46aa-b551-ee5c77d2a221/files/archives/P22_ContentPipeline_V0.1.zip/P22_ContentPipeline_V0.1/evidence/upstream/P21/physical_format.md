# P21-SQLITE 物理格式

版本：1、2；封装：P21-PERSISTENCE/0.1.0-isolated。这里只定义 P21 的物理容器，领域 payload 的 schema/规则属于 P11/P17/P18。

## 数据布局

| 表/工件 | 所有者与内容 |
| --- | --- |
| documents | 恰好 ledger/P11、meta/P17、stage/P18 三行；完整规范 JSON bytes、owner、schema_version、revision、SHA-256 |
| store_meta | 单行身份与连续性引用、schema/min_reader、genesis state/chain、最新 sequence/state/chain |
| transactions | transaction_id 主键、原请求 hash、连续唯一 sequence、原回执 bytes/hash、前后 chain |
| claims | profile + namespace + claim_key 永久唯一，语义 hash、关联 transaction_id |
| maintenance_audit（v2） | 迁移 sequence、源/目标版本、源备份 hash、源 chain；与迁移回执一一对应 |
| store_marker.json | ISOLATED 模式、实例、profile、连续性引用；不赋予生产资格 |
| 保存目录外的 head.json | 已确认提交位置，P21-CONTINUITY/1；必须由装配层提供固定路径 |
| FROZEN.json | 写入冻结原因及证据目录；恢复审查候选保持冻结 |

数据库 application_id 为十六进制 `0x50323153`。SQLite 使用 DELETE rollback journal，不使用 WAL。Sidecar 若存在会在恢复前保全，不能把别的数据库 journal 附到已恢复的快照。

## 规范 JSON 与哈希

`encode` 对合法对象使用 UTF-8、键排序、无非必要空格、非 ASCII 字符原文、禁止 NaN。解码拒绝重复键、BOM、浮点、非有限数、控制字符、代理码点和过大输入。整数必须在 ±(2^53−1) 内；revision/sequence 为非负整数且 bool 不算整数。对象深度不超过 32、遍历节点不超过 100,000、bytes 不超过 1 MiB。

`digest(x) = SHA256(encode(x))`，`byte_hash(raw) = SHA256(raw)`。原 request hash 使用上游规范原请求，不以外层自报 hash 替代原文。

state hash 对按 name 排序的文档头与按 profile/namespace/key 排序的完整 claims 做规范编码。不包含业务重算；钱包净额由完整 meta 文档携带。

genesis chain：

```text
digest(["P21-GENESIS/1", store_instance, continuity_ref, profile_id,
        genesis_schema_version, genesis_state_sha256])
```

每次事务 chain：

```text
receipt_sha256 = SHA256(canonical_receipt_bytes)
chain_sha256 = digest(["P21-CHAIN/1", previous_chain_sha256, receipt_sha256])
```

回执绑定前 state、后 state、前版本、后版本、三个文档头、请求、身份和序号。验证从 genesis 遍历所有回执；live state 必须等于最终 state head。迁移 audit 表需与回执中的迁移集合完全相同。SHA 提供意外损坏检测；没有签名/加密，不作为恶意本地管理员的防篡改承诺。

## 备份格式

每个有效备份目录只有快照数据库 `snapshot.sqlite3`、`manifest.json`、最后写入的 `complete.json`。manifest 记录数据库大小和 SHA、同一次一致读取的 head、原 store marker；`authority=false`。complete 绑定 manifest 的原字节 SHA。未完成目录、大小不符、SHA 不符、链不符或 head 不符均拒绝。

备份三个文件以只读权限创建。本程序不会修改已有备份目录；这不等于操作系统管理员无法修改。解压工具可能改变文件权限；每次使用仍重新验证大小和哈希。备份嵌入的 head 不能反过来充当独立连续性权威。

## Schema 清单

| 文件 | 用途 |
| --- | --- |
| 001_initial.sql | 物理 v1 建表 |
| 002_maintenance_audit.sql | 邻接 v1→v2 新表 |
| P21_save_head.schema.json | 独立连续性记录形状 |
| P21_atomic_request.schema.json | 受信任调用者的物理请求包装 |
| P21_commit_receipt.schema.json | 物理持久回执，origin 固定隔离，文档头覆盖三个 owner |
| P21_backup_manifest.schema.json | 一致备份元数据与 authority=false |

JSON Schema 使用 Draft 2020-12。它检查表示层形状；规范 bytes、SHA 正确性、跨记录守恒、请求身份与业务合法性由运行时及领域 owner 校验。`tools/validate_schemas.py` 的独立 jsonschema oracle 对真实程序输出及拒绝样例执行验证，运行证据在 `recovery_logs/schema_oracle_001/`。该验证仍是作者执行，不代替 P32。

## 容量与部署边界

单记录/回执/状态摘要规范编码 1 MiB；备份检查读取上限 128 MiB；本版完整文档与全历史逐次校验，未做长期数据量验收。运行时不截断记录、不清理首通或事务防重键。达到限制返回错误并回滚，不接受半个 JSON。

外部连续性文件应与保存目录分离；当前没有 OS 安全区、跨设备防回滚服务或 Windows 锁实现。生产格式、容量、存储目录和备份保留策略等待 P13/P34/P36/P01 受理。没有涉及 Anki 原数据库/outbox。
