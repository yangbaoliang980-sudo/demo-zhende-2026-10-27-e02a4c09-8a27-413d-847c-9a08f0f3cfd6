# P05｜接口 RFC、正式参数冻结条件与阻塞

**源版本**：P01-S00-V0.1 / P02-BATTLE-0.1.0-draft / P03-CARDS-0.1.0-draft / P04-SKELETON-0.1.0-draft；P05候选= `P05-BALANCE-0.1.0-provisional`。源 ZIP 哈希在 `evidence/source_input_receipt.tsv`。本地仓库未更改，不存在可提交的正式 base SHA、正式参数 DTO 或集成签名。

| ID | 状态 | Owner | 所缺明确材料或裁决 | P05 可独立完成的部分 |
|---|---|---|---|---|
| P05-BLK-01 | BLOCKED | P13 | `actual_path_mapping.json`、`do_not_touch.txt`、目标引擎/OS 和经济/战斗 DTO 版本、工程写入白名单 | 本包规划路径输出和隔离脚本 |
| P05-BLK-02 | BLOCKED | P22 | `content_id_registry.tsv`、正式 card/character/enemy ID 及 Schema、引用完整性 lint | 使用源中 `MOCK_*` fixture，禁止注册 ID |
| P05-BLK-03 | BLOCKED | P06 | 固定提交的怪物/BOSS 配置、意图、阶段、盾与反应机制、数字字段及哈希 | 使用标为 `SYNTHETIC` 的 HP/攻击样本，阶段不模拟 |
| P05-BLK-04 | BLOCKED | P08/P01/USER | 四键权益、Undo 已消费补偿、0学习日基础行动的批准 `PolicyRecord`；DEC-001–003 | 等额/反激励影子方案和反例，不调用 Anki |
| P05-BLK-05 | BLOCKED | P18 | 真实关卡普通/精英/BOSS资源和 XP 授予配置，首通唯一事件合同、重复掉落 | 数值化首通预算，仅供试验 |
| P05-BLK-06 | BLOCKED | P03/P15/P14 | 固定能量刷新/抽牌/弃牌/手牌上限策略、效果倍率与盾 cap 合同、权威事件 DTO | 临时 3 能量/4 抽牌/5 手牌/40 盾 cap，均明示 Mock |
| P05-BLK-07 | BLOCKED | P04/P17/P21 | 正式技能升级影响战斗与否、P17余额业务、P21落盘交易；DEC-009 | 按 P04 原测试表计算升级门槛，无角色数值接入卡牌公式 |
| P05-BLK-08 | NOT_RUN | P32/P35 | 对本包进行独立源验收、场景/数值/边界自测和审计签署 | 本地作者测试记录已提供 |
| P05-BLK-09 | NOT_RUN | P39 | 真实玩家战斗策略、体验回合数、操作负担、0学习是否可玩 | 有策略敏感性与预算样本，可供试玩参数选择 |

## 版本化 RFC（全部仅 PROPOSED）

- `P05-RFC-IC04-001 → P02/P03/P14/P15`：确认能量曲线、手牌行为、盾上限、卡牌成本结算接口。复用 P02 的单一事实来源与盾先抵伤；正式语义从 P14 已提交事件计算，P05 不改 P14 源码。需要 `EffectValueContract` 的 base blob SHA 和版本签名。
- `P05-RFC-IC06-001 → P08/P01/USER`：冻结合法 Anki 四键收益、叠加/撤销/无学习权益、日收益与公平性；提交本包 AB-01–10 做激励压力测试。需要 `PolicyRecord`、原始事件能力证据和审批回执；不建议以答错更高收益作为默认值。
- `P05-RFC-IC11-001 → P04/P17/P18/P21/P01`：正式区分共享训练代币与每角色累计 XP、首通是否可重复领、零学习日最低可玩经济、升级消耗原子交易。P05 报告仅提供成本与敏感性，不重写角色表/钱包。
- `P05-RFC-BOSS-001 → P06/P14/P39`：签署 BOSS 生命、意图、伤害、每阶段防御机制和平均目标回合区间；在真实场景中复测。当前 `boss_long` 仅是无阶段合成 HP 桩，不可按此验收 P06。
- `P05-RFC-CARDS-001 → P03/P14`：单体 2 费用专属卡的数值候选见 `design/balance/card_adjustment_candidates.tsv`。未经签批不改 P03 card_catalog；没有已签 base SHA 和接口 DTO，不能做覆盖补丁。

**冲突升级**：冻结 `source_input_receipt.tsv` 中对应文件 SHA 与双方 base SHA，开 ChangeRequest；未收到正式来源则 `base_sha=MISSING`。连续两轮返工无新增证据报 P01，不得强制覆盖。最终工程合并仅由用户指定的 EXT-INTEGRATOR 执行。

**本交付修改白名单**：本 ZIP 内 `design/balance/**`、`content/balance/**`、`analysis/simulations/**`；`evidence/**` 和根 `README.md` 仅作为包级元数据/只读快照。真实仓库任何路径写入均 `BLOCKED_PENDING_P13_MAPPING`。无仓库写入、无 P03/P04/P14/P11 修改。
