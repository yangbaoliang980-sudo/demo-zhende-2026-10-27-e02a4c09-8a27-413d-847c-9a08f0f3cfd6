import copy,json,os,shutil,subprocess,sys,tempfile,unittest,builtins
from pathlib import Path
from unittest.mock import patch
from p22_content.io import sha256,verify_report_directory,ContentError,json_bytes
from p22_content.pipeline import validate
from p22_content.schema import SchemaBank

ROOT=Path(__file__).resolve().parents[3]
CLI=ROOT/'tools/content_validation/schema_linter.py'

class CLITests(unittest.TestCase):
    def run_cli(self,*args,seed='0'):
        env=dict(os.environ);env['PYTHONHASHSEED']=seed;env['PYTHONDONTWRITEBYTECODE']='1'
        return subprocess.run([sys.executable,'-B',str(CLI),*map(str,args)],env=env,capture_output=True,text=True,timeout=45)

    def test_candidate_success_and_production_blocked_exit_codes(self):
        a=self.run_cli('lint');b=self.run_cli('preflight')
        self.assertEqual(a.returncode,0,a.stderr+a.stdout);self.assertEqual(b.returncode,3,b.stderr+b.stdout)
        self.assertEqual(json.loads(b.stdout)['production_gate'],'BLOCKED')

    def test_identical_reports_across_process_hash_seeds_and_output_paths(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);a=self.run_cli('lint','--output',p/'a',seed='1');b=self.run_cli('lint','--output',p/'b',seed='777')
            self.assertEqual(a.returncode,0,a.stderr);self.assertEqual(b.returncode,0,b.stderr)
            files={x.relative_to(p/'a').as_posix() for x in (p/'a').rglob('*') if x.is_file()}
            self.assertEqual(files,{x.relative_to(p/'b').as_posix() for x in (p/'b').rglob('*') if x.is_file()})
            for f in files:self.assertEqual((p/'a'/f).read_bytes(),(p/'b'/f).read_bytes(),f)
            self.assertTrue(verify_report_directory(p/'a'));self.assertTrue(verify_report_directory(p/'b'))

    def test_source_bytes_unchanged_after_cli(self):
        before={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()) for p in (ROOT/'evidence/upstream').rglob('*') if p.is_file()}
        result=self.run_cli('lint');self.assertEqual(result.returncode,0,result.stderr)
        after={p.relative_to(ROOT).as_posix():sha256(p.read_bytes()) for p in (ROOT/'evidence/upstream').rglob('*') if p.is_file()}
        self.assertEqual(before,after)

    def test_input_tamper_never_reaches_reference_pass(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'copy';shutil.copytree(ROOT,p)
            source=p/'evidence/upstream/P03/card_catalog.json';source.write_bytes(source.read_bytes()+b'\n')
            r=validate(p);self.assertEqual(r['exit_code'],2);self.assertEqual(r['reference_status'],'NOT_RUN')
            self.assertTrue(any(e['code']=='E_INPUT_HASH' for e in r['issues']))

    def test_omitted_document_cannot_make_dataset_pass(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'copy';shutil.copytree(ROOT,p);plan=p/'content/manifest/dataset.plan.json';d=json.loads(plan.read_text());d['documents'].pop();plan.write_bytes(json_bytes(d))
            r=validate(p);self.assertEqual(r['exit_code'],2);self.assertTrue(any(e['code']=='E_DOCUMENT_SET' for e in r['issues']))

    def test_missing_source_is_reported_not_synthesized(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'copy';shutil.copytree(ROOT,p);(p/'evidence/upstream/P04/character_skeleton.json').unlink()
            r=validate(p);self.assertEqual(r['exit_code'],2);self.assertTrue(any(e['code']=='E_FILE_MISSING' for e in r['issues']))

    def test_dependency_failure_is_blocked(self):
        actual=builtins.__import__
        def imported(name,*args,**kwargs):
            if name=='jsonschema':raise ImportError('TEST_ONLY_MISSING_DEPENDENCY')
            return actual(name,*args,**kwargs)
        with patch('builtins.__import__',side_effect=imported):r=validate(ROOT)
        self.assertEqual(r['exit_code'],3);self.assertEqual(r['structural_status'],'NOT_RUN')
        self.assertTrue(any(e['code']=='B_DEPENDENCY' for e in r['issues']))

    def test_malformed_schema_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);s=p/'schema/content/bad.schema.json';s.parent.mkdir(parents=True);s.write_bytes(json_bytes({'$schema':'https://json-schema.org/draft/2020-12/schema','$id':'urn:test:bad','type':'no_such_type'}))
            with self.assertRaises(ContentError) as caught:SchemaBank(p)
            self.assertEqual(caught.exception.code,'E_SCHEMA_DEFINITION')

    def test_manifest_migration_cli_preserves_original_bytes(self):
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)/'migrated';relative='tools/content_validation/fixtures/manifest_v1.synthetic.json';before=(ROOT/relative).read_bytes()
            r=self.run_cli('migrate-manifest','--input',relative,'--output',dest)
            self.assertEqual(r.returncode,0,r.stderr);self.assertEqual((dest/'original_manifest.json').read_bytes(),before)
            self.assertEqual((ROOT/relative).read_bytes(),before);self.assertTrue(verify_report_directory(dest))

    def test_negative_samples_cli(self):
        r=self.run_cli('negative-samples');self.assertEqual(r.returncode,0,r.stderr+r.stdout)
        self.assertTrue(all(c['validation_exit_code']==2 for c in json.loads(r.stdout)['cases']))

    def test_optional_asset_catalog_is_read_and_hashed(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'copy';shutil.copytree(ROOT,p);base=p/'test_assets';base.mkdir()
            raw=b'P22 SYNTHETIC ASSET BYTES ONLY';(base/'data.bin').write_bytes(raw)
            a={'asset_id':'TEST_P22_OPTIONAL_ASSET','asset_type':'TEST_DATA','status':'TEST_ONLY','path':'test_assets/data.bin','size_bytes':len(raw),'sha256':sha256(raw),'source_path':'test_assets/data.bin','source_sha256':sha256(raw),'license_receipt_path':None,'license_receipt_sha256':None,'quality_receipt_path':None,'quality_receipt_sha256':None}
            catalog={'schema_version':'P22-ASSET-CATALOG/0.1.0','contract_owner':'P30','contract_status':'PROPOSAL','records':[a]}
            rel='test_assets/catalog.json';(p/rel).write_bytes(json_bytes(catalog));planp=p/'content/manifest/dataset.plan.json';plan=json.loads(planp.read_text());plan['asset_catalog_path']=rel;plan['source_bindings']['P22-TEST-ASSET-CATALOG']={'path':rel,'sha256':sha256((p/rel).read_bytes())};planp.write_bytes(json_bytes(plan))
            r=validate(p);self.assertEqual(r['exit_code'],0,r['issues']);self.assertEqual(r['summary']['registered_assets'],1);self.assertEqual(r['production_gate'],'BLOCKED')
            (base/'data.bin').write_bytes(b'altered');bad=validate(p);self.assertEqual(bad['exit_code'],2);self.assertTrue(any(e['code']=='E_ASSET_HASH' for e in bad['issues']))
