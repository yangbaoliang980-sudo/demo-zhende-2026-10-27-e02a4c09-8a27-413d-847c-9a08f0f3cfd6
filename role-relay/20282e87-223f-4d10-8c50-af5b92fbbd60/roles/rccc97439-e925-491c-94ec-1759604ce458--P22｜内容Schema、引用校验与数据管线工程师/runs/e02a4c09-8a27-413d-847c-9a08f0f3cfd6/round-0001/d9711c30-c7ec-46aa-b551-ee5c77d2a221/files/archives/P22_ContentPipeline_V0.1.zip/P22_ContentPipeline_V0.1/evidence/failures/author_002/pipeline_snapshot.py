from __future__ import annotations
import csv,io
from collections import Counter
from pathlib import Path
from . import VERSION
from .io import ContentError,read_json,read_bytes,parse_json,parse_tsv,sha256,json_bytes,compact_hash,tsv_bytes
from .schema import SchemaBank
from .references import collect

REQUIRED_KEYS=frozenset('P03_card_catalog P03_card_dictionary P03_character_card_pool P04_character_skeleton P04_progression_costs P04_character_deck_contribution P06_enemy_specs P06_boss_phase_graph P06_intent_dictionary P06_asset_requests P07_stage_graph P07_stage_content_catalog P07_stage_rewards P07_stage_table P09_pos_mapping_rules P09_category_dictionary P09_mapping_release_registry P09_resource_affinity_candidates'.split())
REGISTRY_COLUMNS=['kind','scope','id','canonical_id','lifecycle','owner','source_path','pointer','source_sha256','production_allowed']

def error_record(e):return {'code':e.code,'severity':'BLOCKED' if e.code.startswith('B_') else 'ERROR','file':e.path,'pointer':e.pointer,'message':e.message,'owner':'P22'}

def governance(root):
    base='evidence/upstream/V6/'
    roles=read_json(root,base+'第六轮_43岗独立职责与激活状态V6.0.json')
    contracts=read_json(root,base+'第六轮_27项接口契约冻结修订V6.0.json')
    raw=read_bytes(root,base+'第六轮_92项职责冻结映射V6.0.tsv')
    rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8')),delimiter='\t'))
    rids=[r['role_id'] for r in roles['roles']];cids=[c['id'] for c in contracts['contracts']];ids=[r['职责ID'] for r in rows]
    checks={'43_distinct_roles':sorted(rids)==[f'P{i:02}' for i in range(1,44)],'92_distinct_duties':sorted(ids)==[f'{i:03}' for i in range(1,93)],'27_distinct_interfaces':sorted(cids)==[f'IC-{i:02}' for i in range(1,28)],'duty_owners_exist':all(r['V6唯一主责'] in rids for r in rows),'interface_owners_exist':all(c['owner'] in rids for c in contracts['contracts']),'p22_053_082':{r['职责ID'] for r in rows if r['V6唯一主责']=='P22'}=={'053','082'},'ic03_owner_p22':next(c for c in contracts['contracts'] if c['id']=='IC-03')['owner']=='P22','deferred_roles_retained':sorted(roles['deferred_legacy_reserved'])==['P31','P41','P42','P43']}
    return {'status':'PASS' if all(checks.values()) else 'FAIL','scope':'STATIC_OWNERSHIP_MAPPING_ONLY_NOT_IMPLEMENTATION_ACCEPTANCE','checks':checks,'counts':{'roles':len(rids),'duties':len(ids),'interfaces':len(cids)},'p22_duties':[r for r in rows if r['V6唯一主责']=='P22'],'p22_interfaces':[c for c in contracts['contracts'] if c['id'] in ['IC-03','IC-06','IC-09','IC-11','IC-22']]}

def load_dataset(root,bank):
    plan=read_json(root,'content/manifest/dataset.plan.json')
    errs=bank.errors('schema/content/dataset_plan.schema.json',plan)
    if errs:raise ContentError('E_DATASET_SCHEMA',str(errs),'content/manifest/dataset.plan.json')
    keys=[d['key'] for d in plan['documents']]
    if len(keys)!=len(set(keys)) or set(keys)!=REQUIRED_KEYS:raise ContentError('E_DOCUMENT_SET','The fixed compatibility profile requires exactly its 18 distinct document keys','content/manifest/dataset.plan.json')
    paths=[d['path'] for d in plan['documents']]
    if len(paths)!=len(set(paths)) or len({p.casefold() for p in paths})!=len(paths):raise ContentError('E_DOCUMENT_PATH_COLLISION','Duplicate/case-colliding document paths','content/manifest/dataset.plan.json')
    documents={};descriptors={};checks=[];issues=[]
    for desc in sorted(plan['documents'],key=lambda d:d['key']):
        e=dict(desc);key=e['key'];path=e['path']
        if e['schema']!='schema/content/compat/'+key+'.schema.json' or e['owner']!=key.split('_')[0]:raise ContentError('E_PROFILE_BINDING','Schema and owner must match the declared compatibility document key',path)
        try:
            raw=read_bytes(root,path);e['actual_sha256']=sha256(raw);e['size_bytes']=len(raw)
            if e['actual_sha256']!=e['sha256']:issues.append({'code':'E_INPUT_HASH','severity':'ERROR','file':path,'pointer':'','message':'Pinned source hash mismatch','owner':e['owner'],'expected':e['sha256'],'actual':e['actual_sha256']})
            data=parse_json(raw,path) if e['format']=='json' else parse_tsv(raw,e['tsv_columns'],path)
            errors=bank.errors(e['schema'],data)
            for err in errors:
                row={**err,'severity':'ERROR','file':path,'owner':e['owner']}
                if e['format']=='tsv':
                    try:row['line']=int(err['pointer'].split('/')[1])+2
                    except (ValueError,IndexError):pass
                issues.append(row)
            checks.append({'file':path,'key':key,'sha256':e['actual_sha256'],'size_bytes':len(raw),'schema':e['schema'],'schema_status':'FAIL' if errors else 'PASS','pin_status':'PASS' if e['actual_sha256']==e['sha256'] else 'FAIL'})
            documents[key]=data;descriptors[key]=e
        except ContentError as error:issues.append(error_record(error));checks.append({'file':path,'key':key,'schema_status':'NOT_RUN','pin_status':'FAIL'})
    for sid,binding in sorted(plan['source_bindings'].items()):
        try:
            actual=sha256(read_bytes(root,binding['path']))
            if actual!=binding['sha256']:issues.append({'code':'E_SUPPORT_HASH','severity':'ERROR','file':binding['path'],'pointer':'','message':'Support source hash mismatch for '+sid,'owner':'UPSTREAM'})
        except ContentError as e:issues.append(error_record(e))
    return plan,documents,descriptors,checks,issues

def validate(root,profile='candidate'):
    root=Path(root).resolve();report={'validator_version':VERSION,'profile':profile,'structural_status':'NOT_RUN','reference_status':'NOT_RUN','production_gate':'BLOCKED','issues':[],'registry':[],'references':[],'source_checks':[],'cycle_checks':[]}
    try:
        bank=SchemaBank(root);report['schema_meta_checks']={'count':len(bank.schemas),'status':'PASS'}
        plan,docs,descs,checks,issues=load_dataset(root,bank);report['source_checks']=checks;report['issues']=issues
        g=governance(root);report['governance']=g
        if g['status']!='PASS':report['issues'].append({'code':'E_V6_MAPPING','severity':'ERROR','file':'evidence/upstream/V6','pointer':'','message':'V6 static mapping failed','owner':'P22'})
        report['structural_status']='FAIL' if any(i['severity']=='ERROR' for i in report['issues']) else 'PASS'
        if report['structural_status']=='PASS':
            x=collect(docs,descs)
            for key,data in docs.items():
                if not isinstance(data,dict):continue
                for sid,h in data.get('source_hashes',{}).items():
                    binding=plan['source_bindings'].get(sid)
                    if binding is None:x.issue('E_SOURCE_UNKNOWN',key,'/source_hashes/'+sid,'No pinned source binding')
                    elif h!=binding['sha256']:x.issue('E_SOURCE_BINDING',key,'/source_hashes/'+sid,'Declared source hash disagrees with pinned bytes')
            for i,r in enumerate(docs['P07_stage_rewards']):
                if r['source_id']=='P07-LOCAL-FAIL-CLOSED':
                    if r['quantity']!=0 or r['source_sha256']:x.issue('E_FAIL_CLOSED_ROW','P07_stage_rewards',f'/{i}','Unbound sentinel must carry zero quantity and no false source hash')
                else:
                    b=plan['source_bindings'].get(r['source_id'])
                    if b is None or b['sha256']!=r['source_sha256']:x.issue('E_SOURCE_BINDING','P07_stage_rewards',f'/{i}/source_sha256','Reward source binding mismatch')
            for i,sid in enumerate(docs['P09_pos_mapping_rules']['source_ids']):
                if sid not in plan['source_bindings']:x.issue('E_SOURCE_UNKNOWN','P09_pos_mapping_rules',f'/source_ids/{i}','No pinned linguistic source')
            report['issues']+=x.issues;report['registry']=sorted(x.defs.values(),key=lambda x:(x['kind'],x['scope'],x['id']))
            report['references']=sorted(x.references,key=lambda r:(r['file'],r['pointer'],r['target_kind'],r['target_scope'],str(r['target_id'])))
            report['cycle_checks']=x.cycle_checks
            report['reference_status']='FAIL' if any(i['severity']=='ERROR' for i in x.issues) else 'PASS'
            registry_errors=bank.errors('schema/content/id_registry.schema.json',report['registry'])
            for e in registry_errors:report['issues'].append({**e,'severity':'ERROR','file':'<generated registry>','owner':'P22'})
        def block(code,message,owner,file='',ptr=''):
            report['issues'].append({'code':code,'severity':'BLOCKED','file':file,'pointer':ptr,'message':message,'owner':owner})
        p13=read_json(root,plan['p13_mapping_path'])
        mappings=[m for m in p13['mappings'] if m['owner']=='P22']
        if not p13.get('production_write_authorized') or len(mappings)!=3 or any(m.get('actual_production_path') is None or not m.get('write_allowed') for m in mappings):block('B_P13_PRODUCTION_MAPPING','P22 production paths are not mapped and authorized','P13',plan['p13_mapping_path'],'/mappings')
        if p13.get('target_os') is None or p13.get('actual_engine') is None:block('B_TARGET_ENVIRONMENT','Target OS/engine and executable project evidence are missing','P13/P34',plan['p13_mapping_path'])
        if plan['asset_catalog_path'] is None or plan['p30_contract_path'] is None:block('B_P30_ASSET_CONTRACT','P30 resource directory contract and approved asset catalog were not delivered','P30','content/manifest/dataset.plan.json','/asset_catalog_path')
        block('B_CONTENT_CANDIDATE','All received design inputs remain draft/test/proposal; no production promotion performed','P01/P03/P04/P06/P07/P09')
        block('B_ID_MAP_ACCEPTANCE','No issued-ID rename/delete approval or accepted production content contract is available','P13/P21/P01')
        block('B_INDEPENDENT_GATES','P32 independent testing and P35 gate receipts are NOT_RUN','P32/P35')
        report['schema_set_sha256']=compact_hash(bank.hashes)
        report['input_set_sha256']=compact_hash(sorted([{'path':v['path'],'sha256':v['actual_sha256']} for v in descs.values()],key=lambda v:v['path']))
        report['content_manifest']={'schema_version':'P22-CONTENT-MANIFEST/0.2.0','content_version':'P22-CANDIDATE/'+report['input_set_sha256'],'documents':sorted([{'path':v['path'],'sha256':v['actual_sha256'],'format_version':plan['upstream_versions'][v['owner']],'owner':v['owner']} for v in descs.values()],key=lambda v:v['path']),'lifecycle':'CANDIDATE','production_allowed':False,'tags':['UPSTREAM_CANDIDATE_READONLY']}
        for e in bank.errors('schema/content/content_manifest_v2.schema.json',report['content_manifest']):report['issues'].append({**e,'severity':'ERROR','file':'<generated manifest>','owner':'P22'})
    except ContentError as e:report['issues'].append(error_record(e))
    except (KeyError,TypeError,ValueError,OSError,RecursionError) as e:report['issues'].append({'code':'E_INVALID_STRUCTURE','severity':'ERROR','file':'','pointer':'','message':str(e),'owner':'P22'})
    report['issues']=sorted(report['issues'],key=lambda e:(e['severity'],e.get('file',''),e.get('pointer',''),e['code'],e['message']))
    report['summary']={'errors':sum(e['severity']=='ERROR' for e in report['issues']),'blockers':sum(e['severity']=='BLOCKED' for e in report['issues']),'validated_documents':sum(c.get('schema_status')=='PASS' for c in report['source_checks']),'registered_definitions':len(report['registry']),'definition_counts':dict(sorted(Counter(r['kind'] for r in report['registry']).items())),'references_checked':len(report['references']),'dangling_references':sum(r['status']=='UNRESOLVED' for r in report['references']),'duplicate_ids':sum(e['code']=='E_DUPLICATE_ID' for e in report['issues']),'registered_assets':sum(r['kind']=='asset' for r in report['registry'])}
    report['exit_code']=2 if report['summary']['errors'] else 3 if profile=='production' or report['structural_status']!='PASS' else 0
    report['local_status']='PASS' if report['exit_code']==0 or (profile=='production' and report['summary']['errors']==0 and report['structural_status']=='PASS') else 'FAIL'
    return report

def output_files(report):
    summary=report['summary']
    lines=[VERSION,'STATIC_CHECKS='+report['local_status'],'PRODUCTION_GATE=BLOCKED','EXIT_CODE='+str(report['exit_code']), 'COUNTS='+str(summary),'']
    for e in report['issues']:lines.append(f"{e['severity']} {e['code']} {e.get('file','')}#{e.get('pointer','')} owner={e['owner']} {e['message']}")
    files={'reference_check_log.txt':('\n'.join(lines)+'\n').encode('utf-8'),'reference_report.json':json_bytes(report),'content_id_registry.tsv':tsv_bytes(report['registry'],REGISTRY_COLUMNS),'references.tsv':tsv_bytes(report['references'],['file','pointer','target_kind','target_scope','target_id','relation','status','target_file','target_pointer']),'missing_bindings.tsv':tsv_bytes([e for e in report['issues'] if e['severity']=='BLOCKED'],['code','file','pointer','owner','message']),'resource_manifest.json':json_bytes({'schema_version':'P22-RESOURCE-INVENTORY/0.1.0','status':'BLOCKED_MISSING_P30','asset_count':0,'assets':[],'placeholder_is_approved':False,'visual_validation':'NOT_RUN'})}
    if 'content_manifest' in report:files['content_manifest.json']=json_bytes(report['content_manifest'])
    if 'governance' in report:files['v6_static_review.json']=json_bytes(report['governance'])
    return files
