# P07｜版本化接口提案、阻塞与接收约束

任务 `P07-S07-STAGES-001`，提案版本 `P07-STAGES-0.1.0-proposal`。全部 RFC 状态：**PREPARED_NOT_SENT / NOT_ACKNOWLEDGED**。没有向其他人发送消息、提交 GitHub 评论、开 PR、修改其他岗位源码或替代整合人员。

## P07-RFC-IC11-001 v0.1.0

契约 owner：P07；正式内部 DTO owner：P13；接收 P18/P20/P22，并送 P05/P06/P04核对内容。正式 base SHA：`null / MISSING`，不是已接受接口升级。

候选输入为 `stage_graph.json`、`stage_rewards.tsv`、`stage_content_catalog.json` 与固定源哈希。需要 P18 确认两关前置、入场固定快照、失败/重试/退出语义；P20 只消费 `LOCKED/AVAILABLE/IN_PROGRESS/PENDING_RECONCILIATION/CLEARED/REVIEW_REQUIRED` 等候选语义，不自行发奖；最终枚举名由 P13冻结。

接受条件：P13给实际路径和 DTO 文件的固定提交、SHA-256、接口版本及白名单；P22给 stage/reward/resource ID 对应的注册表和 Schema；P18/P20提供接收回执和当前实现版本。P06需确认将其 `eligible_stage=S03` 的普通敌样本用于 S07 候选，不修改上游文件来伪造批准。

## P07-RFC-IC13-001 v0.1.0

契约 owner：P18；P14提供权威 BattleResult，P17校验钱包/角色，P21物理事务，P13定义内部 DTO。正式 base SHA：`null / MISSING`。

请求确认：stage 永久首通键与 battle/terminal_revision 运行键分域；权威入场绑定、结果指纹、旧修订拒绝、同 battle 更高修订只对账；三名入场角色 XP 与共享钱包代币同事务；响应丢失和提交结果未知时查询原回执；撤回已提交胜利保留首通墓碑并隔离依赖结果。P07没有定义签名算法、存储表结构、锁实现、事务代码或实际 DTO 字段类型。

消费证据：`stage_retry_cases.json` 的 67 个固定场景。P18/P32需要执行实际状态投影比较，并给出原始结果、命令、环境、固定提交、逐条结果及修复 owner。不得把本包“期望字段静态一致”当作“运行通过”。

## P07-RFC-ECONOMY-001 v0.1.0

owner 路由：关卡预算 P05；学习政策与关卡分域 P08；角色 XP/代币语义 P04；涉及权益裁决由 P01登记报用户。

请求确认普通首通 3/4、BOSS 首通 12/18 的预算，三名入场成员包括阵亡者均获 XP、共享币只发一次、重打无额外奖励的临时停用口径、入口/重试成本及零学习日政策。原 P05预算未覆盖 P06三阶段实战节奏，必须重新评估。本包不引入日限额、四键权重或自动债务。

## P07-CR-CONTENT-001 v0.1.0

内容 ID 唯一 owner：P22。拟登记 1 个 chapter、2 个 stage、4 个 reward bundle；复用 P06 的敌人/阶段图与 P04资源 kind。全部 `MOCK_*` 仍是本地提案，不能把这份列表当正式 ID 注册表。

实际冲突状态：`NO_VERIFIED_CONFLICT`。本岗 base SHA-256 是当前候选实体哈希（见清单）；其他分支 base SHA、现有正式 ID映射均为 `MISSING`。若接收时存在同名/同 ID内容，先保留双方固定 base SHA与 ChangeRequest，再由 P22裁定映射、P13确认消费路径，拒绝覆盖式合并。两轮同一问题无新增证据，升级 P01。

## 具体阻塞

| 编号 | 状态 | 唯一跟进 owner | 必须补齐的证据 | 本岗已提供的可接收内容 |
|---|---|---|---|---|
| P07-BLK-01 | BLOCKED | P13 | `actual_path_mapping.json`、真实工程固定 commit、写入白名单、内部 DTO版本和哈希 | 包内配置、格式说明、映射请求 |
| P07-BLK-02 | BLOCKED | P22 | 正式 ID注册表、stage/reward Schema、必要别名迁移 | 本地候选 catalog、引用静态结果 |
| P07-BLK-03 | BLOCKED | P08 | 固定版本的 Anki与关卡奖励边界 / PolicyRecord | 分域与 Undo不撤销stage候选语义 |
| P07-BLK-04 | BLOCKED | P01 | 本 S07配置版本的范围接收、前置阶段状态、权益裁决路由 | 严格两关候选，无新增章节/剧情 |
| P07-BLK-05 | BLOCKED | P05 | 固定 P06三阶段BOSS下的节奏/奖励预算、重复掉落预算回执 | 两关资源算术、停用的重复域 |
| P07-BLK-06 | BLOCKED | P06 | 普通样本从S03用于S07的接收记录及敌方版本冻结 | 原始敌人引用，无覆盖数值 |
| P07-BLK-07 | BLOCKED | P34 | 目标游戏引擎、OS、Anki版本及测试环境指纹 | 本次Linux/Python作者环境记录 |
| P07-BLK-08 | BLOCKED | P18 | 实际关卡实现固定commit、P14结果与P17/P21事务合同/运行证据 | 67条契约期望、IC-13 RFC |
| P07-VAL-09 | NOT_RUN | P32 | 实际执行逐条自动化/契约/故障注入结果 | 校验器、期望数据、作者原始日志 |
| P07-VAL-10 | NOT_RUN | P33 | 同一候选运行版本的人工退出/重启/领赏旅程 | 操作场景与预期 |
| P07-VAL-11 | NOT_RUN | P35 | 独立 SPEC / 运行证据门禁回执 | 逐件大小/哈希/来源/权限清单 |
| P07-BLK-12 | BLOCKED | P01 | 用户指定 EXT-INTEGRATOR及其接收授权 | 独立包与只读来源，不进行跨模块合并 |

缺依赖阻止正式启用，不阻止本岗交付可解析候选、图、规则与静态自检。关键项均明确缺失，不借临时 Mock豁免正式门禁。
