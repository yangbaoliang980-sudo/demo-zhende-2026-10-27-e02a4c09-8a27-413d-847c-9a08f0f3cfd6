import copy,unittest
from pathlib import Path
from p22_content.io import ContentError,read_json,json_bytes
from p22_content.schema import SchemaBank
from p22_content.migration import migrate_manifest,validate_id_map,compare_registry

ROOT=Path(__file__).resolve().parents[3]

class MigrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.bank=SchemaBank(ROOT)
    def setUp(self):
        self.manifest=read_json(ROOT,'tools/content_validation/fixtures/manifest_v1.synthetic.json')
        self.registry=[{'kind':'stage','scope':'','id':'TEST_STAGE_OLD','canonical_id':'TEST_STAGE_OLD','lifecycle':'TOMBSTONE'}, {'kind':'stage','scope':'','id':'TEST_STAGE_MIDDLE','canonical_id':'TEST_STAGE_OLD','lifecycle':'TOMBSTONE'}, {'kind':'stage','scope':'','id':'TEST_STAGE_NEW','canonical_id':'TEST_STAGE_OLD','lifecycle':'CANDIDATE'}]
        for i,r in enumerate(self.registry):r.update(owner='P22',source_path='synthetic/test-only.json',pointer=f'/{i}',source_sha256='0'*64,production_allowed=False)
        def row(a,b):return {'kind':'stage','scope':'','old_id':a,'new_id':b,'canonical_id':'TEST_STAGE_OLD','status':'APPROVED_TEST_ONLY','p13_receipt':'TEST_ONLY_P13','p21_receipt':'TEST_ONLY_P21','p01_receipt':'TEST_ONLY_P01'}
        self.rows=[row('TEST_STAGE_OLD','TEST_STAGE_MIDDLE'),row('TEST_STAGE_MIDDLE','TEST_STAGE_NEW')]
    def checked(self,profile='test'):return validate_id_map(self.registry,self.rows,self.bank,profile)
    def codes(self,profile='test'):return {e['code'] for e in self.checked(profile)['issues']}

    def test_explicit_metadata_defaults_only(self):
        before=copy.deepcopy(self.manifest);new,audit=migrate_manifest(self.manifest,self.bank)
        self.assertEqual(new['documents'],before['documents']);self.assertEqual(self.manifest,before)
        self.assertEqual(new['lifecycle'],'CANDIDATE');self.assertIs(new['production_allowed'],False);self.assertEqual(new['tags'],[])
        self.assertEqual(audit['id_rewrites'],0);self.assertEqual(audit['save_files_touched'],0)

    def test_migration_is_idempotent(self):
        new,_=migrate_manifest(self.manifest,self.bank);again,audit=migrate_manifest(new,self.bank)
        self.assertEqual(json_bytes(new),json_bytes(again));self.assertEqual(audit['changes'],[])

    def test_unknown_version_has_no_best_effort_fallback(self):
        self.manifest['schema_version']='P21-SAVE/1'
        with self.assertRaises(ContentError) as c:migrate_manifest(self.manifest,self.bank)
        self.assertEqual(c.exception.code,'E_MIGRATION_VERSION')

    def test_required_data_never_filled(self):
        del self.manifest['documents'][0]['sha256']
        with self.assertRaises(ContentError) as c:migrate_manifest(self.manifest,self.bank)
        self.assertEqual(c.exception.code,'E_MIGRATION_INPUT')

    def test_null_is_not_missing_default(self):
        new,_=migrate_manifest(self.manifest,self.bank);new['tags']=None
        with self.assertRaises(ContentError):migrate_manifest(new,self.bank)

    def test_default_annotation_does_not_mutate_validator_input(self):
        missing=copy.deepcopy(self.manifest);missing['schema_version']='P22-CONTENT-MANIFEST/0.2.0';original=copy.deepcopy(missing)
        errors=self.bank.errors('schema/content/content_manifest_v2.schema.json',missing)
        self.assertTrue(errors);self.assertEqual(missing,original);self.assertNotIn('tags',missing)

    def test_alias_chain_preserves_original_first_clear_identity(self):
        r=self.checked();self.assertEqual(r['status'],'PASS')
        for ident in ['TEST_STAGE_OLD','TEST_STAGE_MIDDLE','TEST_STAGE_NEW']:self.assertEqual(r['aliases']['stage||'+ident],'TEST_STAGE_OLD')
        self.assertFalse(r['production_applied']);self.assertEqual(r['save_files_touched'],0)

    def test_alias_cycle_rejected(self):
        self.rows[1]['new_id']='TEST_STAGE_OLD';self.assertIn('E_MIGRATION_CYCLE',self.codes());self.assertEqual(self.checked()['aliases'],{})

    def test_alias_self_reference_rejected(self):
        self.rows[0]['new_id']='TEST_STAGE_OLD';self.assertIn('E_MIGRATION_SELF',self.codes())

    def test_unknown_alias_target_rejected(self):
        self.rows[1]['new_id']='MISSING';self.assertIn('E_MIGRATION_UNKNOWN',self.codes())

    def test_cross_kind_alias_rejected(self):
        self.registry[2]['kind']='card';self.assertIn('E_MIGRATION_UNKNOWN',self.codes())

    def test_original_identity_requires_tombstone(self):
        self.registry[0]['lifecycle']='RELEASED';self.assertIn('E_MIGRATION_TOMBSTONE',self.codes())

    def test_canonical_identity_cannot_be_forged(self):
        self.rows[1]['canonical_id']='TEST_STAGE_MIDDLE';self.assertIn('E_MIGRATION_CANONICAL',self.codes())

    def test_proposal_does_not_become_live_alias(self):
        for r in self.rows:r['status']='PROPOSED'
        self.assertEqual(self.checked()['aliases'],{});self.assertIn('B_MIGRATION_PROPOSED',self.codes())

    def test_test_alias_is_not_production_alias(self):
        self.assertEqual(self.checked('candidate')['aliases'],{});self.assertIn('B_TEST_ALIAS',self.codes('candidate'))

    def test_external_approval_not_self_asserted(self):
        self.rows[0]['status']='APPROVED';self.rows[0]['p01_receipt']=''
        self.assertIn('E_MIGRATION_APPROVAL_MISSING',self.codes());self.assertIn('B_MIGRATION_APPROVAL_EXTERNAL',self.codes())

    def test_duplicate_migration_origin_rejected(self):
        self.rows.append(copy.deepcopy(self.rows[0]));self.assertIn('E_MIGRATION_DUPLICATE',self.codes())

    def test_issued_id_removal_rejected(self):
        r=compare_registry(self.registry,self.registry[1:]);self.assertEqual(r['status'],'FAIL');self.assertEqual(r['issues'][0]['code'],'E_ISSUED_ID_REMOVED')

    def test_tombstone_reuse_rejected(self):
        new=copy.deepcopy(self.registry);new[0]['lifecycle']='RELEASED';self.assertEqual(compare_registry(self.registry,new)['issues'][0]['code'],'E_ISSUED_ID_REUSED')

    def test_issued_canonical_change_rejected(self):
        new=copy.deepcopy(self.registry);new[0]['canonical_id']='TEST_STAGE_NEW';self.assertEqual(compare_registry(self.registry,new)['issues'][0]['code'],'E_ISSUED_CANONICAL_CHANGED')

    def test_empty_real_mapping_is_not_fabricated_history(self):
        self.assertEqual(validate_id_map([],[],self.bank)['aliases'],{});self.assertEqual(validate_id_map([],[],self.bank)['status'],'PASS')

    def test_duplicate_input_registry_rejected_even_with_empty_map(self):
        self.registry.append(copy.deepcopy(self.registry[0]))
        r=validate_id_map(self.registry,[],self.bank);self.assertEqual(r['status'],'FAIL');self.assertIn('E_DUPLICATE_ID',{x['code'] for x in r['issues']})

    def test_case_collision_input_registry_rejected(self):
        extra=copy.deepcopy(self.registry[0]);extra['id']=extra['id'].lower();self.registry.append(extra)
        self.assertIn('E_ID_CASE_COLLISION',self.codes())

    def test_invalid_input_registry_schema_rejected(self):
        del self.registry[0]['canonical_id']
        self.assertEqual(self.checked()['status'],'FAIL');self.assertEqual(self.checked()['aliases'],{})

    def test_duplicate_previous_registry_rejected(self):
        previous=self.registry+[copy.deepcopy(self.registry[0])]
        r=compare_registry(previous,self.registry);self.assertEqual(r['status'],'FAIL');self.assertEqual(r['issues'][0]['code'],'E_DUPLICATE_ID')
