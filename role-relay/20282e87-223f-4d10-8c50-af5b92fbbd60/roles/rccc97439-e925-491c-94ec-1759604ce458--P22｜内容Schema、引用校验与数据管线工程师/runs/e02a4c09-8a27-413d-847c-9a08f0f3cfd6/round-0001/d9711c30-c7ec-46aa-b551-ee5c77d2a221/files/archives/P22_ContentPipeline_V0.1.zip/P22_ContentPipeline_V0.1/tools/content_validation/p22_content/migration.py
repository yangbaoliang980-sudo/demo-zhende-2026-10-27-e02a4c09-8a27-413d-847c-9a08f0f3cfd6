import copy
from .io import ContentError,sha256,json_bytes,compact_hash

MIGRATION_COLUMNS=['kind','scope','old_id','new_id','canonical_id','status','p13_receipt','p21_receipt','p01_receipt']

def migrate_manifest(data,bank):
    """Only P22 index metadata. Never adds gameplay values or writes a save."""
    source=copy.deepcopy(data);version=source.get('schema_version') if isinstance(source,dict) else None
    if version not in ['P22-CONTENT-MANIFEST/0.1.0','P22-CONTENT-MANIFEST/0.2.0']:raise ContentError('E_MIGRATION_VERSION','No explicit migration path for this version')
    name='content_manifest_v1.schema.json' if version.endswith('/0.1.0') else 'content_manifest_v2.schema.json'
    errors=bank.errors('schema/content/'+name,source)
    if errors:raise ContentError('E_MIGRATION_INPUT',str(errors))
    result=copy.deepcopy(source);changes=[]
    if version.endswith('/0.1.0'):
        result['schema_version']='P22-CONTENT-MANIFEST/0.2.0'
        for key,value in [('lifecycle','CANDIDATE'),('production_allowed',False),('tags',[])]:result[key]=value;changes.append({'field':'/'+key,'operation':'ADD_EXPLICIT_METADATA_DEFAULT','value':value})
    errors=bank.errors('schema/content/content_manifest_v2.schema.json',result)
    if errors:raise ContentError('E_MIGRATION_OUTPUT',str(errors))
    if source['documents']!=result['documents']:raise ContentError('E_MIGRATION_IMMUTABILITY','Source document paths/hashes must remain unchanged')
    return result,{'migration_version':'P22-MANIFEST-MIGRATION/0.1.0','from':version,'to':result['schema_version'],'changes':changes,'source_canonical_sha256':compact_hash(source),'result_canonical_sha256':compact_hash(result),'id_rewrites':0,'source_documents_changed':0,'save_files_touched':0,'document_bytes_validation':'NOT_RUN_METADATA_ONLY_USE_LINT_FOR_DATA_BYTES','scope':'P22_SYNTHETIC_METADATA_VERSIONS_NOT_HISTORICAL_GAME_SAVE'}

def registry_identity_issues(registry):
    issues=[];seen=set();folded=set();global_ids={}
    for i,r in enumerate(registry):
        key=(r['kind'],r['scope'],r['id']);fold=(r['kind'],r['scope'].casefold(),r['id'].casefold())
        if key in seen:issues.append({'code':'E_DUPLICATE_ID','severity':'ERROR','pointer':f'/{i}/id','message':'Duplicate input registry identity'})
        elif fold in folded:issues.append({'code':'E_ID_CASE_COLLISION','severity':'ERROR','pointer':f'/{i}/id','message':'Case-insensitive input registry identity collision'})
        if not r['scope'] and r['id'] in global_ids and global_ids[r['id']]!=r['kind']:issues.append({'code':'E_ID_KIND_COLLISION','severity':'ERROR','pointer':f'/{i}/id','message':'Global ID reused for another kind'})
        seen.add(key);folded.add(fold)
        if not r['scope']:global_ids[r['id']]=r['kind']
    return issues

def validate_id_map(registry,rows,bank,profile='candidate'):
    issues=bank.errors('schema/content/id_registry.schema.json',registry)+bank.errors('schema/content/id_migration.schema.json',rows)
    if issues:return {'status':'FAIL','issues':[dict(e,severity='ERROR') for e in issues],'aliases':{}}
    issues=registry_identity_issues(registry)
    if issues:return {'status':'FAIL','issues':issues,'aliases':{}}
    defs={(r['kind'],r['scope'],r['id']):r for r in registry};edges={};active={};oldkeys=set()
    for i,r in enumerate(rows):
        key=(r['kind'],r['scope'],r['old_id']);target=(r['kind'],r['scope'],r['new_id']);ptr=f'/{i}'
        def err(code,msg,severity='ERROR'):issues.append({'code':code,'pointer':ptr,'message':msg,'severity':severity})
        if key in oldkeys:err('E_MIGRATION_DUPLICATE','More than one destination for the same original ID')
        oldkeys.add(key)
        if key==target:err('E_MIGRATION_SELF','Identity/self migration is not a rename')
        if key not in defs or target not in defs:err('E_MIGRATION_UNKNOWN','Both original and destination definitions must exist in the same kind/scope')
        else:
            if defs[key]['lifecycle'] not in ('DEPRECATED','TOMBSTONE'):err('E_MIGRATION_TOMBSTONE','Original identity must remain as deprecated/tombstone')
            if defs[key]['canonical_id']!=r['canonical_id'] or defs[target]['canonical_id']!=r['canonical_id']:
                err('E_MIGRATION_CANONICAL','Both registry records must preserve the same original canonical identity')
        edges[key]=target
        if r['status']=='PROPOSED':err('B_MIGRATION_PROPOSED','Proposal is not an active alias','BLOCKED')
        elif r['status']=='APPROVED_TEST_ONLY' and profile=='test':active[key]=r
        elif r['status']=='APPROVED_TEST_ONLY':err('B_TEST_ALIAS','Test-only mapping cannot enter a production/candidate registry','BLOCKED')
        elif r['status']=='APPROVED':
            if not all(r[k] for k in ['p13_receipt','p21_receipt','p01_receipt']):err('E_MIGRATION_APPROVAL_MISSING','Issued IDs require P13/P21/P01 acceptance references')
            err('B_MIGRATION_APPROVAL_EXTERNAL','This isolated tool does not authenticate external approval receipts','BLOCKED')
    aliases={}
    for start in sorted(edges):
        trail=[];cur=start
        while cur in edges:
            if cur in trail:
                issues.append({'code':'E_MIGRATION_CYCLE','severity':'ERROR','pointer':'','message':' -> '.join(k[2] for k in trail+[cur])});break
            trail.append(cur);cur=edges[cur]
        else:
            if start in active:
                chain=[active.get(key) for key in trail]
                if any(row is None for row in chain):issues.append({'code':'B_MIGRATION_CHAIN_NOT_ACTIVE','severity':'BLOCKED','pointer':'','message':'Every hop must be approved within the same test scope'});continue
                canonical={row['canonical_id'] for row in chain}
                if len(canonical)!=1 or (start[0],start[1],next(iter(canonical))) not in defs:
                    issues.append({'code':'E_MIGRATION_CANONICAL','severity':'ERROR','pointer':'','message':'Alias chain must preserve one registered historical canonical ID'});continue
                original=next(iter(canonical))
                # Canonical identity is an original tombstone, never the new display/content ID.
                if defs[(start[0],start[1],original)]['lifecycle'] not in ('TOMBSTONE','DEPRECATED'):
                    issues.append({'code':'E_MIGRATION_CANONICAL','severity':'ERROR','pointer':'','message':'Canonical origin must be retained as a tombstone'});continue
                for key in trail+[cur]:
                    label='|'.join(key)
                    if label in aliases and aliases[label]!=original:issues.append({'code':'E_MIGRATION_MERGE_CONFLICT','severity':'ERROR','pointer':'','message':'Two historical identities converge on one target'} )
                    aliases[label]=original
    if any(i.get('severity')=='ERROR' for i in issues):aliases={}
    return {'status':'FAIL' if any(i.get('severity')=='ERROR' for i in issues) else 'PASS','issues':issues,'aliases':dict(sorted(aliases.items())),'save_files_touched':0,'production_applied':False}

def compare_registry(previous,current):
    """Detect removal/reuse of issued IDs. Never approves or applies a change."""
    issues=registry_identity_issues(previous)+registry_identity_issues(current)
    if issues:return {'status':'FAIL','issues':issues,'applied':False}
    old={(r['kind'],r['scope'],r['id']):r for r in previous};new={(r['kind'],r['scope'],r['id']):r for r in current}
    for key,before in old.items():
        if before['lifecycle'] not in ('RELEASED','DEPRECATED','TOMBSTONE'):continue
        after=new.get(key)
        if after is None:issues.append({'code':'E_ISSUED_ID_REMOVED','id':key[2],'owner':'P13/P21/P01'})
        elif after['canonical_id']!=before['canonical_id']:issues.append({'code':'E_ISSUED_CANONICAL_CHANGED','id':key[2],'owner':'P13/P21/P01'})
        elif before['lifecycle']=='TOMBSTONE' and after['lifecycle']!='TOMBSTONE':issues.append({'code':'E_ISSUED_ID_REUSED','id':key[2],'owner':'P13/P21/P01'})
        elif before['lifecycle']=='RELEASED' and after['lifecycle']=='CANDIDATE':issues.append({'code':'E_ISSUED_ID_DOWNGRADE','id':key[2],'owner':'P13/P21/P01'})
    return {'status':'FAIL' if issues else 'PASS','issues':issues,'applied':False}
