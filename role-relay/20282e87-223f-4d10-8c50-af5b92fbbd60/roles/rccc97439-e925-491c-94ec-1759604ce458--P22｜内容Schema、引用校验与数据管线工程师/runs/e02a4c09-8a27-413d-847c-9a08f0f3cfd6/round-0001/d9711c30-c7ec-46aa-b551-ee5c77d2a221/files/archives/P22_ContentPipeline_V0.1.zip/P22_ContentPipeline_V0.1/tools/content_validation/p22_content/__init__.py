"""P22 content validation; never imports gameplay, Anki, or persistence code."""
VERSION = 'P22-CONTENT/0.1.0-isolated'
