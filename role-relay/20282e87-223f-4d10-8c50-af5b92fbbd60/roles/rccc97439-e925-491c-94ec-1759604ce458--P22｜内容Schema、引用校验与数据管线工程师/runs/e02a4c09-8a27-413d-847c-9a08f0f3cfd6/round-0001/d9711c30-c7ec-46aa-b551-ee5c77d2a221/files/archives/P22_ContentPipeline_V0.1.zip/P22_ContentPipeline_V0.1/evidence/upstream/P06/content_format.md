# 本地内容格式与下游读取说明

本地格式版本 `P06-ENEMY-0.1.0-proposal`。这是待审内容形状，不是P13运行时DTO，也不是P22正式Schema。全部 JSON/TSV 为 UTF-8；TSV 为制表符分隔、首行字段名、LF换行。TSV内JSON列由标准CSV引号规则转义，应用 `csv.DictReader(delimiter="\t")`，不要直接按引号或逗号切分。

## 1. 主配置字段

| 字段 / 对象 | 类型和范围 | 语义 |
| --- | --- | --- |
| `format_version` | string | 必须精确匹配本内容版本，不允许静默读旧格式 |
| `source_hashes` | source_id → 64位hex字符串 | 与 `source_input_receipt.tsv` 及实际源字节一致 |
| `authorization.actual_path_mapping` | 当前为null | 未收到P13映射，不应填成隔离目录来冒充授权 |
| `production_enabled` | false | 样本不得当正式游戏内容 |
| `enemy_id/skill_id/intent_id/phase_id` | `MOCK_P06_*` string | P06临时命名空间，P22尚未注册 |
| `max_hp` | 正整数，夹具≤21474836 | 使乘100比较留在本地定义的整数范围；正式范围交P13 |
| `base_amount_per_hit` / `hit_count` | 非负整数 | 当前动作每段基础伤害与段数；本版伤害动作一段，0伤行为为0段 |
| `future_release_base_amount` | 非负整数 | 仅蓄力预告的下一次重击值，不在当次执行 |
| `states[].state_id` | 本敌唯一string | 循环状态标识，不是BattleState的全局战斗phase |
| `next_state_id` | 本敌已声明的状态ID | 正常/临时守卫跳过后前进的循环位置；特殊覆盖态另见规则表 |
| `cooldown_on_success_slots` | 0或2 | HEAVY释放后阻塞的后续本敌槽数，不是秒数/帧数 |
| `charge_requirement` | 已枚举string或null | 开始蓄力或释放的守卫说明，由P16实现候选、P14验证提交 |
| `immunity` | 明确布尔/拒绝策略 | 未声明的免疫不存在；未知状态不得静默忽略 |
| `asset_registry_id` | 当前null | 不捏造P22/P30资产ID；请求用单独request_key关联 |

阶段JSON中的 `phases[].rank` 为0、1、2。阈值用百分比整数及等价分数双写，校验器检查二者一致。`once_key` 是语义模板，正式ID编码及拼接规范待P13批准，不能将模板字符串直接当现有数据库键。

`DEGRADED_BASIC` 是行为模式，不是新注册的phase_id。缺逻辑图时保留最后已提交phase_id、停用阶段处理；`DEGRADED_STRIKE` 是明确基础循环的特殊状态，由全局状态规则表定义。终局/死者状态同样由全局规则优先覆盖，不把“死者没有下一招”解释成配置缺失。

## 2. 意图字典

每个skill恰有一个intent。`current_base_amount_per_hit`、`current_hit_count`必须与skill一致；`future_base_amount_per_hit`只能表示未来。`preview_template_zh` 的 `{targets}` 和 `{reason}` 为语义占位，P19如何本地化由其已签UI合同决定；本包没有创建P22正式localization_key。

`icon_semantic`仅为类别建议，不是资源路径。缺图时仍应能显示文字。`valid_deviations` 列列出可以解释的预告/执行差异类型；实际差异必须有P14已提交的取消/跳过/结算原因。新增事件字段全部走RFC，不能由UI补写战斗事实。

## 3. 真值用例

`enemy_truth_cases.tsv` 包含以下核心列：

| 列 | 说明 |
| --- | --- |
| `case_id` | `P06-ET-001` 至 `P06-ET-089`，稳定用例ID |
| `input_json` | 固定输入投影：敌人状态、三名测试单位、HP/盾、阶段、蓄力、CD、预告、seed/RNG及图片存在性 |
| `stimulus_json` | 操作类型及已由外部规则给出的检查点数据；不是游戏命令DTO |
| `expected_json` | 待比较的语义投影，允许只断言与本用例有关的字段 |
| `seed` | 与input_json一致；除拒绝seed0的负例外为1..4294967295 |
| `source_anchors` | 源输入ID、P02规则/真值表锚点或RFC；含P06新设计项时不能冒充上游已批准 |
| `equivalence_pair` | seed无消耗/动画开关的期望等价组；实际引擎尚未运行 |
| `runtime_status` | 全部NOT_RUN；作者静态检查不会改变这一列 |

三名测试单位 `MOCK_P06_UNIT_H1/H2/H3` 的50HP是局部输入夹具，不替代P04角色配置，也不参与数值预算批准。`assets=APPROVED_FIXTURE_REFERENCE_ONLY_NO_IMAGE_DELIVERED` 是存在性条件，不是已收到或已审批的真实图像。

`DRAINED_CHECKPOINT` 用例直接提供结算后的HP、存活计数及反应计数，检验应出现哪些阶段提案/终局结果。它们没有实现伤害管线。`P14_ACCEPT_PHASE_PROPOSALS`检验拟议受理语义；`RESOLVE_FROZEN_SLOT`检验完整敌方槽语义；`PUBLISH_NEXT_INTENT/READ_COMMITTED_PREVIEW`是纯预告数据语义。检查点用例标有 `input_scope=INTERNAL_CHECKPOINT_PROJECTION`，其中P06-ET-045/058的“已提议未提交”不是允许对UI发布半提交BattleState。`other_enemies`明确列出“BOSS已死但别的敌人仍活着”时的其他实例，不以空名单配一个凭空存活计数。

`phase_after` 指该操作结束后的当前权威阶段；提案型用例仍保留旧phase；受理型用例才改变它。`phase_proposals`为本次新增提案，不含旧去重项。`expected_damage_projection`是P02伤害总量/抵盾/扣血的手工期望，不能当已运行的事件。

P32适配时须同时固定实现提交、内容四文件SHA、DTO版本、P02版本、随机算法、操作序列和观测日志。观测不得直接复制expected_json。未实现或无法映射的字段应标BLOCKED，不能选择忽略后宣布契约通过。

## 4. 读取示例（只读取文件）

```python
import csv, json
from pathlib import Path
root = Path(".")
spec = json.loads((root / "content/enemies/enemy_specs.json").read_text(encoding="utf-8"))
with (root / "content/enemies/enemy_truth_cases.tsv").open(encoding="utf-8", newline="") as f:
    cases = list(csv.DictReader(f, delimiter="\t"))
first_input = json.loads(cases[0]["input_json"])
first_expected = json.loads(cases[0]["expected_json"])
assert spec["production_enabled"] is False
assert cases[0]["runtime_status"] == "NOT_RUN"
```

示例只解析实体文件，不选择敌方动作、不推进阶段、不扣HP，也不代替P16实现。

## 5. 文件清单与修改

`delivery_manifest.sha256.tsv`精确记录每项文件的相对路径、大小、SHA-256、格式/版本、13份输入哈希、接收人与修改白名单。清单自身排除在清单内，由外层回执哈希固定。`verify_manifest.py`忽略Python自生成的缓存，其余未知文件会报错，防止交付包被静默追加配置。

源快照仅允许复核，不允许把P06修订写入源快照来掩盖接口变更。对正式ID、格式或预算作修订时升P06版本，保留旧清单、双方base SHA和ChangeRequest；P13完成路径/DTO映射、P22完成ID登记后再由被指定的整合者接入。
