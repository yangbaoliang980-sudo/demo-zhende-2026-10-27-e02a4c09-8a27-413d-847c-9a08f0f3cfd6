"""Strict, read-only source access and deterministic serialization."""
from __future__ import annotations
import csv, hashlib, io, json, os, re, shutil, tempfile
from pathlib import Path, PurePosixPath

MAX_FILE_BYTES = 16 * 1024 * 1024

class ContentError(Exception):
    def __init__(self, code, message, path='', pointer=''):
        super().__init__(message)
        self.code, self.message, self.path, self.pointer = code, message, path, pointer

def sha256(raw):
    return hashlib.sha256(raw).hexdigest()

def json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('utf-8')

def compact_hash(obj):
    return sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8'))

def pointer(parts):
    return '/' + '/'.join(str(x).replace('~','~0').replace('/','~1') for x in parts) if parts else ''

def safe_path(root, rel, must_exist=True):
    if not isinstance(rel,str) or not rel or '\\' in rel or ':' in rel or any(ord(c)<32 for c in rel):
        raise ContentError('E_PATH_UNSAFE','Relative POSIX path required',str(rel))
    p=PurePosixPath(rel)
    if p.is_absolute() or any(x in ('..','.') for x in rel.split('/')) or '' in rel.split('/'):
        raise ContentError('E_PATH_UNSAFE','Absolute, traversal and ambiguous paths are forbidden',rel)
    root=Path(root).resolve()
    candidate=root.joinpath(*p.parts)
    current=root
    for part in p.parts:
        current=current/part
        if current.is_symlink():raise ContentError('E_PATH_SYMLINK','Symlinks are not content inputs',rel)
    if not candidate.resolve(strict=False).is_relative_to(root):raise ContentError('E_PATH_ESCAPE','Path escapes input root',rel)
    if must_exist and not candidate.is_file():raise ContentError('E_FILE_MISSING','Required input file is absent',rel)
    return candidate

def read_bytes(root, rel):
    p=safe_path(root,rel)
    if p.stat().st_size>MAX_FILE_BYTES:raise ContentError('E_FILE_LIMIT','Input exceeds the 16 MiB per-file limit',rel)
    return p.read_bytes()

def parse_json(raw,path=''):
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ContentError('E_JSON_DUPLICATE_KEY','Duplicate JSON member: '+k,path)
            result[k]=v
        return result
    def nonfinite(v):raise ContentError('E_JSON_NONFINITE','Non-finite JSON value: '+v,path)
    try:return json.loads(raw.decode('utf-8'),object_pairs_hook=pairs,parse_constant=nonfinite)
    except ContentError:raise
    except (UnicodeDecodeError,json.JSONDecodeError,RecursionError,ValueError) as e:
        raise ContentError('E_JSON_PARSE',str(e),path) from e

def read_json(root,rel):return parse_json(read_bytes(root,rel),rel)

def parse_tsv(raw,columns,path=''):
    try:
        rows=list(csv.reader(io.StringIO(raw.decode('utf-8'),newline=''),delimiter='\t',strict=True))
    except (UnicodeDecodeError,csv.Error) as e:raise ContentError('E_TSV_PARSE',str(e),path) from e
    if not rows:raise ContentError('E_TSV_HEADER','Missing TSV header',path)
    header=rows[0]
    if len(header)!=len(set(header)):raise ContentError('E_TSV_DUPLICATE_HEADER','Duplicate TSV header',path)
    if set(header)!=set(columns):raise ContentError('E_TSV_HEADER','Unexpected/missing TSV columns; expected '+','.join(sorted(columns)),path)
    out=[]
    for idx,row in enumerate(rows[1:]):
        if len(row)!=len(header):raise ContentError('E_TSV_WIDTH',f'Line {idx+2}: expected {len(header)} fields, got {len(row)}',path,pointer([idx]))
        record={}
        for k,v in zip(header,row):
            kind=columns[k]
            if kind=='integer':
                if not re.fullmatch(r'-?(0|[1-9][0-9]*)',v):raise ContentError('E_TSV_INTEGER',f'Line {idx+2}: invalid integer {v!r}',path,pointer([idx,k]))
                v=int(v)
            elif kind=='boolean':
                if v not in ('true','false','True','False'):raise ContentError('E_TSV_BOOLEAN',f'Line {idx+2}: invalid boolean {v!r}',path,pointer([idx,k]))
                v=v.lower()=='true'
            record[k]=v
        out.append(record)
    return out

def tsv_bytes(rows,columns):
    s=io.StringIO(newline='');w=csv.DictWriter(s,fieldnames=columns,delimiter='\t',lineterminator='\n');w.writeheader()
    for row in rows:w.writerow({k:('true' if row.get(k) is True else 'false' if row.get(k) is False else row.get(k,'')) for k in columns})
    return s.getvalue().encode('utf-8')

def publish_new_directory(destination,files,protected_root=None):
    """Publish only to a new directory. No source or existing output is overwritten."""
    dst=Path(destination).absolute()
    if dst.exists() or dst.is_symlink():raise ContentError('E_OUTPUT_EXISTS','Output must not already exist',str(dst))
    if protected_root is not None and dst.resolve().is_relative_to(Path(protected_root).resolve()):
        raise ContentError('E_OUTPUT_IN_SOURCE','Output must be outside the read-only package',str(dst))
    parent=dst.parent
    if not parent.is_dir():raise ContentError('E_OUTPUT_PARENT','Output parent must exist',str(parent))
    if any(p.is_symlink() for p in [parent,*parent.parents]):raise ContentError('E_OUTPUT_SYMLINK','Output parent contains a symlink',str(parent))
    stage=Path(tempfile.mkdtemp(prefix='.p22-stage-',dir=parent))
    try:
        for rel,raw in sorted(files.items()):
            p=safe_path(stage,rel,must_exist=False);p.parent.mkdir(parents=True,exist_ok=True)
            with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        # mkdir reserves the destination; os.replace never targets an existing directory.
        dst.mkdir()
        for entry in sorted(stage.iterdir()):os.rename(entry,dst/entry.name)
        stage.rmdir()
        complete={'format':'P22-REPORT-COMPLETE/0.1.0','files':[{'path':rel,'size_bytes':len(raw),'sha256':sha256(raw)} for rel,raw in sorted(files.items())]}
        with (dst/'report_complete.json').open('xb') as f:
            f.write(json_bytes(complete));f.flush();os.fsync(f.fileno())
    except BaseException:
        shutil.rmtree(stage,ignore_errors=True)
        # A partial destination is retained for diagnosis and has no valid completion marker.
        raise

def verify_report_directory(root):
    manifest=read_json(root,'report_complete.json')
    if manifest.get('format')!='P22-REPORT-COMPLETE/0.1.0':raise ContentError('E_REPORT_FORMAT','Unknown completion marker')
    expected={r['path'] for r in manifest['files']}
    actual={p.relative_to(root).as_posix() for p in Path(root).rglob('*') if p.is_file()}-{'report_complete.json'}
    if len(expected)!=len(manifest['files']) or actual!=expected:raise ContentError('E_REPORT_FILES','Unexpected/missing report files')
    for r in manifest['files']:
        raw=read_bytes(root,r['path'])
        if sha256(raw)!=r['sha256'] or len(raw)!=r['size_bytes']:raise ContentError('E_REPORT_HASH','Report file changed',r['path'])
    return True
