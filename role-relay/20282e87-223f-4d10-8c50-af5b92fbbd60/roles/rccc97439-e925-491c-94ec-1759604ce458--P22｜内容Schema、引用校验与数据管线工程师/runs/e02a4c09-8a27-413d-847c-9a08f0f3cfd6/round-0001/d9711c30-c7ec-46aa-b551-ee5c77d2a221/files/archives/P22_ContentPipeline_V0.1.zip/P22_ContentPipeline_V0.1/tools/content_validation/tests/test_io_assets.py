import copy,json,os,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from p22_content.io import ContentError,parse_json,parse_tsv,read_bytes,safe_path,sha256,json_bytes,publish_new_directory,verify_report_directory
from p22_content.schema import SchemaBank
from p22_content.assets import check_assets

ROOT=Path(__file__).resolve().parents[3]

class IOTests(unittest.TestCase):
    def test_duplicate_json_keys_rejected(self):
        with self.assertRaises(ContentError) as c:parse_json(b'{"id":1,"id":2}')
        self.assertEqual(c.exception.code,'E_JSON_DUPLICATE_KEY')

    def test_nonfinite_json_rejected(self):
        for token in ['NaN','Infinity','-Infinity']:
            with self.subTest(token=token):
                with self.assertRaises(ContentError) as c:parse_json(('{"value":'+token+'}').encode())
                self.assertEqual(c.exception.code,'E_JSON_NONFINITE')

    def test_invalid_utf8_json_rejected(self):
        with self.assertRaises(ContentError) as c:parse_json(b'\xff')
        self.assertEqual(c.exception.code,'E_JSON_PARSE')

    def test_tsv_duplicate_header(self):
        with self.assertRaises(ContentError) as c:parse_tsv(b'id\tid\n1\t2\n',{'id':'string'})
        self.assertEqual(c.exception.code,'E_TSV_DUPLICATE_HEADER')

    def test_tsv_row_width_has_line_number(self):
        with self.assertRaises(ContentError) as c:parse_tsv(b'id\tcount\na\n',{'id':'string','count':'integer'})
        self.assertEqual(c.exception.code,'E_TSV_WIDTH');self.assertIn('Line 2',c.exception.message)

    def test_tsv_integer_not_silently_coerced(self):
        with self.assertRaises(ContentError) as c:parse_tsv(b'n\n1.0\n',{'n':'integer'})
        self.assertEqual(c.exception.code,'E_TSV_INTEGER')

    def test_tsv_boolean_not_truthy_string(self):
        with self.assertRaises(ContentError) as c:parse_tsv(b'enabled\nyes\n',{'enabled':'boolean'})
        self.assertEqual(c.exception.code,'E_TSV_BOOLEAN')

    def test_path_escape_absolute_drive_and_backslash_rejected(self):
        for path in ['../escape','/tmp/escape','C:/escape','assets\\x','a/../../x','a//x','a/./x']:
            with self.subTest(path=path):
                with self.assertRaises(ContentError):safe_path(ROOT,path)

    def test_symlink_input_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'real').write_bytes(b'x')
            try:(p/'link').symlink_to(p/'real')
            except (OSError,NotImplementedError):self.skipTest('OS does not permit symlink creation')
            with self.assertRaises(ContentError) as c:read_bytes(p,'link')
            self.assertEqual(c.exception.code,'E_PATH_SYMLINK')

    def test_oversize_input_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'data').write_bytes(b'12345')
            with patch('p22_content.io.MAX_FILE_BYTES',4):
                with self.assertRaises(ContentError) as c:read_bytes(p,'data')
            self.assertEqual(c.exception.code,'E_FILE_LIMIT')

    def test_new_output_complete_and_hash_verifiable(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'new';publish_new_directory(p,{'one.txt':b'one','nested/two.txt':b'two'},protected_root=ROOT)
            self.assertTrue(verify_report_directory(p))
            (p/'one.txt').write_bytes(b'changed')
            with self.assertRaises(ContentError) as c:verify_report_directory(p)
            self.assertEqual(c.exception.code,'E_REPORT_HASH')

    def test_existing_output_never_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';p.mkdir();(p/'sentinel').write_bytes(b'keep')
            with self.assertRaises(ContentError) as c:publish_new_directory(p,{'new.txt':b'new'},protected_root=ROOT)
            self.assertEqual(c.exception.code,'E_OUTPUT_EXISTS');self.assertEqual((p/'sentinel').read_bytes(),b'keep')

    def test_output_in_package_blocked(self):
        with self.assertRaises(ContentError) as c:publish_new_directory(ROOT/'forbidden_test_output',{'x':b'x'},protected_root=ROOT)
        self.assertEqual(c.exception.code,'E_OUTPUT_IN_SOURCE');self.assertFalse((ROOT/'forbidden_test_output').exists())

    def test_interrupted_output_has_no_completion_marker(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out';actual=os.rename;calls=[]
            def fail_second(src,dst):
                calls.append((src,dst))
                if len(calls)==2:raise OSError('TEST_ONLY_INTERRUPTED_REPORT_MOVE')
                return actual(src,dst)
            with patch('p22_content.io.os.rename',side_effect=fail_second):
                with self.assertRaises(OSError):publish_new_directory(p,{'a.txt':b'a','b.txt':b'b'},protected_root=ROOT)
            self.assertFalse((p/'report_complete.json').exists())

class AssetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.bank=SchemaBank(ROOT)
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.addCleanup(self.tmp.cleanup)
        for name,data in [('asset.bin',b'P22 TEST DATA'),('source.bin',b'P22 TEST SOURCE'),('license.txt',b'TEST ONLY NOT LEGAL APPROVAL'),('quality.txt',b'TEST ONLY NOT ART ACCEPTANCE')]: (self.root/name).write_bytes(data)
        r={'asset_id':'TEST_ASSET_A','asset_type':'TEST_DATA','status':'TEST_ONLY','path':'asset.bin','size_bytes':len((self.root/'asset.bin').read_bytes()),'sha256':sha256((self.root/'asset.bin').read_bytes()),'source_path':'source.bin','source_sha256':sha256((self.root/'source.bin').read_bytes()),'license_receipt_path':None,'license_receipt_sha256':None,'quality_receipt_path':None,'quality_receipt_sha256':None}
        self.catalog={'schema_version':'P22-ASSET-CATALOG/0.1.0','contract_owner':'P30','contract_status':'PROPOSAL','records':[r]}
    def check(self):return check_assets(self.root,self.catalog,self.bank)
    def codes(self):return {e['code'] for e in self.check()['issues']}

    def test_actual_bytes_and_source_hash_verified(self):
        r=self.check();self.assertEqual(r['status'],'PASS');self.assertEqual(r['verified_files'],2);self.assertEqual(r['production_gate'],'BLOCKED')

    def test_changed_asset_hash_rejected(self):
        (self.root/'asset.bin').write_bytes(b'altered');self.assertIn('E_ASSET_HASH',self.codes())

    def test_bad_size_rejected(self):
        self.catalog['records'][0]['size_bytes']+=1;self.assertIn('E_ASSET_SIZE',self.codes())

    def test_missing_actual_asset_file_rejected(self):
        (self.root/'asset.bin').unlink();self.assertIn('E_FILE_MISSING',self.codes())

    def test_resource_path_traversal_rejected(self):
        self.catalog['records'][0]['path']='../outside';self.assertIn('E_SCHEMA_PATTERN',self.codes())

    def test_asset_symlink_rejected(self):
        p=self.root/'asset.bin';p.unlink()
        try:p.symlink_to(self.root/'source.bin')
        except (OSError,NotImplementedError):self.skipTest('OS does not permit symlink creation')
        self.assertIn('E_PATH_SYMLINK',self.codes())

    def test_duplicate_asset_id_rejected(self):
        self.catalog['records'].append(copy.deepcopy(self.catalog['records'][0]));self.assertIn('E_DUPLICATE_ID',self.codes())

    def test_placeholder_cannot_be_formal_asset(self):
        self.catalog['records'][0]['status']='PLACEHOLDER';self.assertIn('B_ASSET_NOT_APPROVED',self.codes())
        self.assertEqual(self.check()['production_gate'],'BLOCKED')

    def test_approved_label_without_receipts_rejected(self):
        self.catalog['records'][0]['status']='APPROVED';self.assertEqual(self.check()['status'],'FAIL')

    def test_receipt_bytes_still_do_not_replace_external_gate(self):
        r=self.catalog['records'][0];r['status']='APPROVED'
        for name in ['license','quality']:
            r[name+'_receipt_path']=name+'.txt';r[name+'_receipt_sha256']=sha256((self.root/(name+'.txt')).read_bytes())
        result=self.check();self.assertEqual(result['status'],'PASS');self.assertEqual(result['production_gate'],'BLOCKED')
        self.assertEqual(result['license_review'],'NOT_RUN')

    def test_case_colliding_paths_rejected(self):
        r=copy.deepcopy(self.catalog['records'][0]);r.update(asset_id='TEST_ASSET_B',path='ASSET.bin');self.catalog['records'].append(r)
        self.assertIn('E_ASSET_CASE_COLLISION',self.codes())
