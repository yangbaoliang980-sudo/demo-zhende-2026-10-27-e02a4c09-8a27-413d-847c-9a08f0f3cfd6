# P06｜版本化RFC、阻塞与接收条件

本次任务 `P06-S03-ENEMY-001`；P06基线 `P06-ENEMY-0.1.0-proposal`。以下RFC随包交接，状态均为 `PROPOSED / PREPARED_NOT_ACKNOWLEDGED`。未声称相关owner已签收或批准。

V6核实的接口owner：**IC-06=P06，IC-07=P14，IC-12=P16**。P13仍拥有内部DTO；P22拥有内容ID/Schema；P21拥有物理存档事务。P05文档中的某些RFC编号用于其本地话题，不改变V6的正式接口owner。

## 1. 当前可交付范围与阻塞

| ID | 状态 | 唯一跟进owner | 缺少的具体证据 | 对本包的影响 / 可继续部分 |
| --- | --- | --- | --- | --- |
| P06-BLK-01 | BLOCKED | P13 | `actual_path_mapping.json`、`engineering_inventory.tsv`、`do_not_touch.txt`、真实项目固定提交、写入白名单；版本/SHA均未取得 | 不能覆盖真实工程；已交隔离文件及路径请求 |
| P06-BLK-02 | BLOCKED | P13 | `BattleState/EnemyIntent/PhaseProposal/LogicEvent`版本化DTO、Schema、整数/序号/去重合同及base SHA | 只能交本地内容与输入投影，不宣称可直接加载到现有引擎 |
| P06-BLK-03 | BLOCKED | P22 | `content_id_registry.tsv`、敌人/技能/意图/阶段ID批准与内容引用校验Schema版本/SHA | 全部MOCK命名；作者lint不替代P22全局注册校验 |
| P06-BLK-04 | BLOCKED | P07 | `stage_graph.json`、`stage_rewards.tsv`、`stage_retry_cases.json`及敌人放置/战斗节奏批准，固定提交/版本/SHA均缺 | 不能确定正式关卡难度/遭遇次数；已交各类型机制供关卡引用 |
| P06-BLK-05 | BLOCKED | P05 | 本P06模式的重新计算与预算批准回执；现有P05候选只有单次攻击合成敌人 | 24/55/125HP和8/12/18攻击仅沿用测试基准；循环表不等于难度验证 |
| P06-BLK-06 | BLOCKED | P01 | DEC-004范围签批、S03正式接入版本及后续S07启动回执 | 样本数不等于批准敌人数量；S07仅提前边界成果 |
| P06-BLK-07 | BLOCKED | P34 | 目标OS/硬件、游戏引擎运行入口及测试环境指纹 | 只有作者Python环境；目标真机/E2E均NOT_RUN |
| P06-BLK-08 | BLOCKED | P14 | IC-07本RFC的受理、固定实现提交与唯一写入证明 | P02提案与正式阶段提交之间的字段映射尚未批准 |
| P06-BLK-09 | BLOCKED | P16 | IC-12意图/阶段与表现接收回执、AI实现提交 | 89条用例是预期，不是AI运行结果 |
| P06-BLK-10 | BLOCKED | P27 | 敌人主卡面/阶段差分的实际源文件、导出、SHA及许可 | 已交5条资源请求；未制造或声称已有图片 |
| P06-BLK-11 | BLOCKED | P30 | 上述资源的正式manifest与缺图映射版本/SHA | 图像缺失退路有定义，实际导入未运行 |
| P06-VAL-01 | NOT_RUN | P32 | 对固定P16/P14实现的独立单元/契约/故障注入日志 | 作者内容lint与22条guardrail测试不得替代 |
| P06-VAL-02 | NOT_RUN | P35 | 独立SPEC/UNIT/CONTRACT/RUNTIME/E2E分类门禁 | P06不自签独立验收 |

P07与P06互有内容输入依赖，不据此等待全部岗位同步启动。本包提供明示候选，使P07能先引用类型并给出节奏回执；正式接入仍需双方固定版本。缺失不等于证明其他仓库没有相关文件；查询范围见证据记录。

## 2. P06-RFC-IC06-001 / v0.1：敌人内容

**Owner：P06；接收P16/P27/P22；内部DTO协作P13；预算协作P05/P07。**

源基线为 `source_input_receipt.tsv` 中P02、P05原字节，尤其P05参数表SHA `3adc64a511570385fcce3bc082bcbe0dda7d721425191d51c692b775fa715487`。目标真实内容Schema的base SHA为 `MISSING`；不能生成伪造旧版diff。申请 `P06-EnemyContent/0.1.0-proposal` 的字段、引用与校验约定，承载本包四个主文件；P22决定正式ID和Schema迁移，不允许直接去掉MOCK前缀上线。

新增模式为固定循环、锁定预告、HEAVY冷却、一次性阶段等待和图缺失降级。固定循环不消耗PRNG；seed与rng_state仍随上游只读传入。统计动作可复现但并不证明未来P16已正确实现。

受理条件：P22认可引用集合并提供批准版本；P05对高峰24/36与群攻6×最多3做预算复核；P07给遭遇节奏；P13给映射/DTO；P32独测；P35分层审查。

## 3. P06-RFC-IC07-001 / v0.1：预告与阶段提交

**Owner：P14；规则协作P02；DTO协作P13；候选产生P16；独测P32。**

P02源 `P02-BATTLE-0.1.0-draft`；对应源文件SHA见 `SRC-P02-RULE`。真实EnemyIntent/PhaseProposal的base SHA与版本均 `MISSING`，不覆盖已有实现。申请最小语义投影如下，名称仅为本地提案：

| 对象 | 请求承载的语义 | 权限 |
| --- | --- | --- |
| EnemyIntent候选 | enemy_id、skill_id、intent_id、稳定目标名单、基础量/段数、phase_epoch、content_version、intent_token、预告所针对的行动槽 | P16提供候选；P14校验并唯一提交 |
| 敌人行为状态 | 循环state_id、HEAVY槽数、蓄力标记、最后成功单体目标阵位、entry_wait_pending、degraded行为模式 | P16只读；P14写 |
| PhaseProposal | 图版本/哈希、根命令身份、旧阶段、新阶段、阈值边、检查点前后HP、按图排序、去重键 | P16提供内容候选；P02/P14检查终局及合法性 |
| 阶段受理 | 原子受理有序提案，当前阶段只在受理后改变；一批受理只提升一次epoch、一次等待，不赠行动 | P14唯一提交 |
| 跳过/取消记录 | 预告token、原因、原技能/目标、是否消费槽、是否清蓄力、CD更新 | P14记录；P19/P29只显示 |

先履行P02结算全序，后检查BOSS是否存活；反应未排空或终局时无阶段提案。多阈值跨越依P1→P2→P3顺序，不能只报最终P3。提案不是提交。阈值采样基于根事务/OWNER_ENTRY批次前与排空后HP；中间下穿后恢复不触发，此点需P02明示受理。

受理后取消旧蓄力与旧预告；下一敌人槽固定ENTRY_WAIT。无论阈值发生在玩家出牌、结束回合或敌入口DOT，都不插队执行未给玩家窗口的新招式。phase_epoch按一次原子受理批次加1；重复提案不能重置CD/循环/等待。已有提议未提交的检查点仅为内部过渡；若受理失败整事务回滚/故障，不能对UI发布半提交阶段并无限等待。

验证样例：P06-ET-043至060；致死反例049/050，反应全灭051/052/053。P02优先级不变，唯一HP/费用/阶段写入者仍P14。没有为本RFC添加奖励、存档或Anki事务。

## 4. P06-RFC-IC12-001 / v0.1：阶段与视觉

**Owner：P16；资源P27/P30；表现P19/P28/P29；DTO P13。**

受理技能预告、phase_epoch与asset request的对应关系；图片加载结果不参加逻辑选择。`phase_id`与`asset_id`必须分离。缺阶段图片时沿用同敌可用批准卡面，逻辑继续；没有可用图时使用明确诊断文字，不冒充正式资产。关闭/跳过动画不影响seed、事件排序、HP或冷却。

缺逻辑图才触发DEGRADED_BASIC模式，保留最后phase_id，先0伤提示后基准攻击，当前局不热恢复；基础配置也缺失则拒绝/故障。图像故障与逻辑图故障应有不同原因码。验证样例P06-ET-063至070、074/075。

## 5. 批准与冲突记录

本包文件SHA由交付清单固定。对方base SHA缺失时保持MISSING；收到固定版本后应记录 `change_request_id / old_p06_sha / other_owner_base_sha / proposed_new_sha / contract_version / owner_receipt / test_evidence`。冲突保留双方，不覆盖式合并。相同问题两轮无新证据升级P01。

P06独立可编辑白名单为本隔离包的 `design/enemies/**` 与 `content/enemies/**`；证据源文件禁止修改。真实工程修改列表为空。跨岗位源码整合等待用户指定的EXT-INTEGRATOR，P06没有代行或发布动作。
