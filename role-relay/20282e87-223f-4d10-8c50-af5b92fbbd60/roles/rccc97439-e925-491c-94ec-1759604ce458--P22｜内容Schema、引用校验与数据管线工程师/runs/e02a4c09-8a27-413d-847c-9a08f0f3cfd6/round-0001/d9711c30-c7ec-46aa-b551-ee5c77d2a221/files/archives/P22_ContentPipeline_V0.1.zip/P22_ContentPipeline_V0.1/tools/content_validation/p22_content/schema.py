from __future__ import annotations
from pathlib import Path
from .io import ContentError, read_json, sha256, read_bytes, pointer

class SchemaBank:
    def __init__(self,root):
        try:
            from jsonschema import Draft202012Validator
            from referencing import Registry,Resource
            from referencing.exceptions import NoSuchResource
        except ImportError as e:raise ContentError('B_DEPENDENCY','Install requirements.txt before schema validation') from e
        self.root=Path(root);self.cls=Draft202012Validator;self.schemas={};self.hashes={}
        def offline(uri):raise NoSuchResource(ref=uri)
        self.registry=Registry(retrieve=offline)
        for p in sorted((self.root/'schema/content').rglob('*.schema.json')):
            rel=p.relative_to(self.root).as_posix();s=read_json(self.root,rel)
            if s.get('$schema')!='https://json-schema.org/draft/2020-12/schema':raise ContentError('E_SCHEMA_DIALECT','Only the pinned Draft 2020-12 dialect is supported',rel)
            try:self.cls.check_schema(s)
            except Exception as e:raise ContentError('E_SCHEMA_DEFINITION',str(e),rel) from e
            sid=s.get('$id')
            if not sid or sid in [v['$id'] for v in self.schemas.values()]:raise ContentError('E_SCHEMA_ID','Missing or duplicate schema URI',rel)
            self.schemas[rel]=s;self.hashes[rel]=sha256(read_bytes(self.root,rel));self.registry=self.registry.with_resource(sid,Resource.from_contents(s))
        if not self.schemas:raise ContentError('E_SCHEMA_MISSING','No content schemas found')

    def errors(self,path,data):
        if path not in self.schemas:raise ContentError('E_SCHEMA_MISSING','Schema not in local content bank',path)
        try:
            result=[]
            for e in self.cls(self.schemas[path],registry=self.registry).iter_errors(data):
                ptr=pointer(list(e.absolute_path))
                if e.validator=='required':
                    for k in sorted(set(e.validator_value)-set(e.instance)):
                        result.append({'code':'E_SCHEMA_REQUIRED','pointer':ptr+'/'+k.replace('~','~0').replace('/','~1'),'message':f'Required field is missing: {k}'})
                else:result.append({'code':'E_SCHEMA_'+str(e.validator).upper(),'pointer':ptr,'message':e.message})
            return sorted(result,key=lambda x:(x['pointer'],x['code'],x['message']))
        except Exception as e:raise ContentError('E_SCHEMA_REF','Schema evaluation failed without remote retrieval: '+str(e),path) from e
