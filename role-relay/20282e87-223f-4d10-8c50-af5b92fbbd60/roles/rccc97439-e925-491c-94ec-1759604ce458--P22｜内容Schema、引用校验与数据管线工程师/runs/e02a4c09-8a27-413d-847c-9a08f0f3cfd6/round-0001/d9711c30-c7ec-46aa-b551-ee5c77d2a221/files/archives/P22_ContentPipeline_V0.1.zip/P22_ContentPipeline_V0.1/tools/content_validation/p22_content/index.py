from __future__ import annotations
import re
from .io import pointer

class Index:
    def __init__(self,documents,descriptors):
        self.data=documents;self.desc=descriptors;self.defs={};self.references=[];self.issues=[];self.edges=[];self.cycle_checks=[]
        self.folded={};self.global_ids={}

    def issue(self,code,key,ptr,message,owner=None,severity='ERROR',**detail):
        d=self.desc.get(key,{})
        row={'code':code,'severity':severity,'file':d.get('path',key),'pointer':ptr,'message':message,'owner':owner or d.get('owner','P22'),**detail}
        if d.get('format')=='tsv':
            try:row['line']=int(ptr.split('/')[1])+2
            except (ValueError,IndexError):pass
        self.issues.append(row)

    def block(self,code,key,ptr,message,owner=None):self.issue(code,key,ptr,message,owner,severity='BLOCKED')

    def define(self,key,ptr,kind,value,scope='',lifecycle='CANDIDATE'):
        if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,159}',value):
            self.issue('E_ID_FORMAT',key,ptr,'Invalid content identifier');return
        identity=(kind,scope,value);fold=(kind,scope.casefold(),value.casefold())
        if identity in self.defs:
            self.issue('E_DUPLICATE_ID',key,ptr,'Duplicate definition of '+value,first_definition=self.defs[identity]);return
        if fold in self.folded:
            self.issue('E_ID_CASE_COLLISION',key,ptr,'Case-insensitive identifier collision: '+value)
        if not scope and value in self.global_ids and self.global_ids[value]!=kind:
            self.issue('E_ID_KIND_COLLISION',key,ptr,'Global ID reused for another kind: '+value)
        d=self.desc[key]
        self.defs[identity]={'kind':kind,'scope':scope,'id':value,'canonical_id':value,'lifecycle':lifecycle,'owner':d['owner'],'source_path':d['path'],'pointer':ptr,'source_sha256':d['actual_sha256'],'production_allowed':False}
        self.folded[fold]=identity
        if not scope:self.global_ids[value]=kind

    def ref(self,key,ptr,kind,value,scope='',relation='REFERENCE'):
        if value is None:return
        d=self.desc[key]
        self.references.append({'file':d['path'],'pointer':ptr,'target_kind':kind,'target_scope':scope,'target_id':value,'relation':relation,'source_key':key})

    def equal(self,key,ptr,actual,expected,code='E_MIRROR_MISMATCH'):
        if actual!=expected:self.issue(code,key,ptr,'Derived view differs from authoritative source',expected=expected,actual=actual)

    def dag(self,name,edges,key,ptr):
        adjacency={}
        for a,b in edges:adjacency.setdefault(a,set()).add(b);adjacency.setdefault(b,set())
        color={};stack=[];cycles=[]
        def visit(n):
            color[n]=1;stack.append(n)
            for child in sorted(adjacency[n]):
                if color.get(child,0)==0:visit(child)
                elif color.get(child)==1:cycles.append(stack[stack.index(child):]+[child])
            stack.pop();color[n]=2
        try:
            for n in sorted(adjacency):
                if not color.get(n):visit(n)
        except RecursionError:
            self.issue('E_GRAPH_DEPTH',key,ptr,'Dependency graph exceeds traversal budget');return
        self.cycle_checks.append({'graph':name,'edge_count':len(edges),'cycles':cycles,'status':'FAIL' if cycles else 'PASS'})
        for cycle in cycles:self.issue('E_CYCLE',key,ptr,name+' cycle: '+' -> '.join(cycle),cycle=cycle)

    def finish(self):
        for r in self.references:
            target=self.defs.get((r['target_kind'],r['target_scope'],r['target_id']))
            if target is None:
                r['status']='UNRESOLVED'
                self.issue('E_DANGLING_REFERENCE',r['source_key'],r['pointer'],'No registered target: '+str(r['target_id']),target_kind=r['target_kind'],target_scope=r['target_scope'])
            else:r['status']='RESOLVED';r['target_file']=target['source_path'];r['target_pointer']=target['pointer']
            del r['source_key']
        return self
