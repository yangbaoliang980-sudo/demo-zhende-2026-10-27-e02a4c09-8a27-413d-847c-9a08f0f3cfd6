from collections import Counter
from .io import ContentError,read_bytes,sha256

def check_assets(root,catalog,bank,profile='candidate'):
    issues=[]
    for e in bank.errors('schema/content/asset_catalog.schema.json',catalog):issues.append({**e,'severity':'ERROR'})
    if issues:return {'status':'FAIL','issues':issues,'verified_files':0,'production_gate':'BLOCKED'}
    ids=set();paths={};verified=0
    for i,a in enumerate(catalog['records']):
        ptr=f'/records/{i}'
        if a['asset_id'] in ids:issues.append({'code':'E_DUPLICATE_ID','severity':'ERROR','pointer':ptr+'/asset_id','message':'Duplicate asset ID'})
        ids.add(a['asset_id'])
        folded=a['path'].casefold()
        if folded in paths and paths[folded]!=a['path']:issues.append({'code':'E_ASSET_CASE_COLLISION','severity':'ERROR','pointer':ptr+'/path','message':'Case-sensitive paths collide on target platforms'})
        paths[folded]=a['path']
        for field,hf in [('path','sha256'),('source_path','source_sha256'),('license_receipt_path','license_receipt_sha256'),('quality_receipt_path','quality_receipt_sha256')]:
            if a[field] is None:
                if a[hf] is not None:issues.append({'code':'E_ASSET_RECEIPT_PAIR','severity':'ERROR','pointer':ptr+'/'+field,'message':'Receipt path/hash must be paired'})
                continue
            try:
                b=read_bytes(root,a[field])
                if sha256(b)!=a[hf]:issues.append({'code':'E_ASSET_HASH','severity':'ERROR','pointer':ptr+'/'+field,'message':'Asset/source/evidence digest mismatch'})
                if field=='path' and len(b)!=a['size_bytes']:issues.append({'code':'E_ASSET_SIZE','severity':'ERROR','pointer':ptr+'/size_bytes','message':'Asset byte length mismatch'})
                verified+=1
            except ContentError as e:issues.append({'code':e.code,'severity':'ERROR','pointer':ptr+'/'+field,'message':e.message})
        if a['status']!='APPROVED':issues.append({'code':'B_ASSET_NOT_APPROVED','severity':'BLOCKED','pointer':ptr+'/status','message':'TEST_ONLY/PLACEHOLDER does not constitute formal art approval'})
    issues.append({'code':'B_ASSET_GATE_EXTERNAL','severity':'BLOCKED','pointer':'','message':'Byte/metadata validation does not authenticate P25/P37 acceptance or replace P30 import checks'})
    return {'status':'FAIL' if any(i['severity']=='ERROR' for i in issues) else 'PASS','issues':issues,'verified_files':verified,'production_gate':'BLOCKED','visual_validation':'NOT_RUN','license_review':'NOT_RUN'}
