import copy,json,tempfile,unittest
from pathlib import Path
from p22_content.io import ContentError,read_json,parse_json,parse_tsv,sha256
from p22_content.schema import SchemaBank
from p22_content.pipeline import load_dataset,validate,governance
from p22_content.references import collect
from p22_content.samples import run_samples

ROOT=Path(__file__).resolve().parents[3]

class ContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bank=SchemaBank(ROOT)
        cls.plan,cls.docs,cls.desc,cls.checks,cls.issues=load_dataset(ROOT,cls.bank)

    def codes(self,key,mutator,schema=False):
        docs=copy.deepcopy(self.docs);mutator(docs[key])
        errors=self.bank.errors(self.desc[key]['schema'],docs[key]) if schema else collect(docs,self.desc).issues
        return {e['code'] for e in errors},errors

    def test_received_18_documents_validate(self):
        self.assertEqual(len(self.checks),18);self.assertEqual(self.issues,[])
        self.assertTrue(all(c['schema_status']=='PASS' for c in self.checks))

    def test_full_cross_reference_graph(self):
        r=validate(ROOT);self.assertEqual(r['exit_code'],0);self.assertEqual(r['summary']['dangling_references'],0)
        self.assertEqual(r['summary']['duplicate_ids'],0);self.assertEqual(r['summary']['registered_definitions'],137)
        self.assertEqual(r['summary']['references_checked'],403)

    def test_missing_cost_points_to_field(self):
        codes,errors=self.codes('P03_card_catalog',lambda d:d['cards'][0].pop('cost'),True)
        self.assertIn('E_SCHEMA_REQUIRED',codes);self.assertTrue(any(e['pointer']=='/cards/0/cost' for e in errors))

    def test_boolean_is_not_integer_cost(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['cards'][0]['cost'].update(amount=True),True)
        self.assertIn('E_SCHEMA_TYPE',codes)

    def test_negative_cost_rejected(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['cards'][0]['cost'].update(amount=-1),True)
        self.assertIn('E_SCHEMA_MINIMUM',codes)

    def test_unknown_effect_code_rejected(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['effects'][0].update(effect_code='EXECUTE_SHELL'),True)
        self.assertIn('E_SCHEMA_ENUM',codes)

    def test_missing_status_configuration(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['effects'][3].pop('status_id'),True)
        self.assertIn('E_SCHEMA_REQUIRED',codes)

    def test_nonstatus_effect_cannot_define_phantom_status(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['effects'][0].update(status_id='TEST_PHANTOM_STATUS'),True)
        self.assertIn('E_SCHEMA_NOT',codes)

    def test_deferred_story_ids_are_rejected_until_schema_extension(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d['chapter'].update(story_event_ids=['UNREGISTERED_STORY']),True)
        self.assertIn('E_SCHEMA_MAXITEMS',codes)

    def test_unknown_content_version_rejected(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d.update(format_version='999'),True)
        self.assertIn('E_SCHEMA_CONST',codes)

    def test_unknown_gameplay_field_rejected(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['cards'][0].update(unreviewed_damage=999),True)
        self.assertIn('E_SCHEMA_ADDITIONALPROPERTIES',codes)

    def test_mock_flag_cannot_promote_content(self):
        codes,_=self.codes('P06_enemy_specs',lambda d:d.update(production_enabled=True),True)
        self.assertIn('E_SCHEMA_CONST',codes)

    def test_duplicate_definition_rejected(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['cards'].append(copy.deepcopy(d['cards'][0])))
        self.assertIn('E_DUPLICATE_ID',codes)

    def test_case_colliding_definition_rejected(self):
        def change(d):
            item=copy.deepcopy(d['cards'][0]);item['card_id']=item['card_id'].lower();d['cards'].append(item)
        codes,_=self.codes('P03_card_catalog',change);self.assertIn('E_ID_CASE_COLLISION',codes)

    def test_dangling_effect_reference(self):
        codes,errors=self.codes('P03_card_catalog',lambda d:d['cards'][0].update(effect_ids=['TEST_MISSING_EFFECT']))
        self.assertIn('E_DANGLING_REFERENCE',codes)
        self.assertTrue(any(e['pointer']=='/cards/0/effect_ids/0' for e in errors if e['code']=='E_DANGLING_REFERENCE'))

    def test_signature_character_skill_mismatch(self):
        codes,_=self.codes('P03_card_catalog',lambda d:d['cards'][4].update(owner_character_id='MOCK_P03_CHAR_B'))
        self.assertIn('E_SIGNATURE_BINDING',codes)

    def test_dictionary_mirror_cannot_drift(self):
        codes,errs=self.codes('P03_card_dictionary',lambda d:d[0].update(cost_energy_TEST_ONLY=9))
        self.assertIn('E_MIRROR_MISMATCH',codes);self.assertTrue(any(e.get('line')==2 for e in errs))

    def test_view_duplicate_is_not_a_new_definition(self):
        codes,_=self.codes('P03_character_card_pool',lambda d:d.append(copy.deepcopy(d[0])))
        self.assertIn('E_DUPLICATE_VIEW_ROW',codes)

    def test_p04_compatibility_is_not_alias(self):
        x=collect(self.docs,self.desc)
        self.assertIn(('character','','MOCK_P03_CHAR_A'),x.defs)
        self.assertIn(('character','','MOCK_P04_CHAR_001'),x.defs)
        self.assertEqual(x.defs[('character','','MOCK_P04_CHAR_001')]['canonical_id'],'MOCK_P04_CHAR_001')

    def test_character_signature_binding_mismatch(self):
        codes,_=self.codes('P04_character_skeleton',lambda d:d['characters'][0]['p03_fixture_compatibility'].update(signature_card_id='MOCK_P03_CARD_B_WALL'))
        self.assertIn('E_COMPATIBILITY_BINDING',codes)

    def test_no_resource_cost_with_none_sentinel(self):
        codes,_=self.codes('P04_progression_costs',lambda d:d[0].update(spend_amount=1))
        self.assertIn('E_RESOURCE_SENTINEL',codes)

    def test_missing_enemy_skill_reference(self):
        codes,_=self.codes('P06_enemy_specs',lambda d:d['enemies'][0]['states'][0].update(skill_id='TEST_MISSING_SKILL'))
        self.assertIn('E_DANGLING_REFERENCE',codes)

    def test_behavior_loop_is_legal(self):
        x=collect(self.docs,self.desc)
        self.assertFalse(any(e['code']=='E_CYCLE' for e in x.issues))
        self.assertTrue(any(r['relation']=='BEHAVIOR_CYCLE_ALLOWED' and r['target_id']=='N_STRIKE' for r in x.references))

    def test_behavior_state_is_scoped_to_enemy(self):
        codes,_=self.codes('P06_enemy_specs',lambda d:d['enemies'][0].update(initial_state_id='E_STRIKE'))
        self.assertIn('E_DANGLING_REFERENCE',codes)

    def test_behavior_transition_cannot_skip_phase_owner(self):
        codes,_=self.codes('P06_enemy_specs',lambda d:d['enemies'][2]['states'][0].update(next_state_id='MOCK_P06_PHASE_3:0'))
        self.assertIn('E_BEHAVIOR_PHASE_CROSS',codes)

    def test_phase_graph_cannot_bind_another_enemy(self):
        codes,_=self.codes('P06_boss_phase_graph',lambda d:d.update(enemy_id='MOCK_P06_ENEMY_001'))
        self.assertIn('E_BOSS_GRAPH_BINDING',codes)

    def test_phase_ranks_are_unique(self):
        codes,_=self.codes('P06_boss_phase_graph',lambda d:d['phases'][2].update(rank=1))
        self.assertIn('E_PHASE_RANK_DUPLICATE',codes)

    def test_stage_graph_requires_admitted_boss_enemy(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d['stages'][1]['enemy_refs'][0].update(enemy_id='MOCK_P06_ENEMY_001'))
        self.assertIn('E_STAGE_BOSS_BINDING',codes)

    def test_art_request_without_id_cannot_claim_hash(self):
        codes,_=self.codes('P06_asset_requests',lambda d:d[0].update(actual_asset_sha256='a'*64))
        self.assertIn('E_ASSET_REQUEST_BINDING',codes)

    def test_phase_cycle_and_regression(self):
        def change(d):
            e=copy.deepcopy(d['transitions'][0]);e.update(transition_id='TEST_REVERSE_PHASE',from_phase_id='MOCK_P06_PHASE_3',to_phase_id='MOCK_P06_PHASE_1');d['transitions'].append(e)
        codes,_=self.codes('P06_boss_phase_graph',change)
        self.assertIn('E_CYCLE',codes);self.assertIn('E_PHASE_REGRESSION',codes)

    def test_phase_threshold_mirror(self):
        codes,_=self.codes('P06_boss_phase_graph',lambda d:d['transitions'][0]['threshold_max_hp_fraction'].update(numerator=4))
        self.assertIn('E_THRESHOLD_MIRROR',codes)

    def test_stage_unlock_cycle(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d['stages'][0]['unlock_rule'].update(requires_stage_ids=['MOCK_P07_STAGE_002']))
        self.assertIn('E_CYCLE',codes)

    def test_stage_unlock_mirror(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d.update(unlock_edges=[]))
        self.assertIn('E_UNLOCK_MIRROR',codes)

    def test_stage_canonical_key_cannot_be_rewritten(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d['stages'][1].update(canonical_stage_id='MOCK_P07_STAGE_001'))
        self.assertIn('E_CANONICAL_CHANGE_UNAPPROVED',codes)

    def test_stage_enemy_source_pin(self):
        codes,_=self.codes('P07_stage_graph',lambda d:d['stages'][0]['enemy_refs'][0].update(source_sha256='0'*64))
        self.assertIn('E_SOURCE_BINDING',codes)

    def test_reward_duplicate_component(self):
        codes,_=self.codes('P07_stage_rewards',lambda d:d.append(copy.deepcopy(d[0])))
        self.assertIn('E_DUPLICATE_REWARD_COMPONENT',codes)

    def test_stage_reward_display_mirror(self):
        codes,_=self.codes('P07_stage_table',lambda d:d[0].update(first_tokens_shared=999))
        self.assertIn('E_MIRROR_MISMATCH',codes)

    def test_unknown_linguistic_alias_target(self):
        codes,_=self.codes('P09_pos_mapping_rules',lambda d:d['category_aliases'].update(noun='MISSING_CATEGORY'))
        self.assertIn('E_DANGLING_REFERENCE',codes)

    def test_linguistic_dictionary_mirror(self):
        codes,_=self.codes('P09_category_dictionary',lambda d:d['categories'][0].update(display_zh='测试差异'))
        self.assertIn('E_MIRROR_MISMATCH',codes)

    def test_release_registry_hash_pin(self):
        codes,_=self.codes('P09_mapping_release_registry',lambda d:d['releases'][0].update(sha256='0'*64))
        self.assertIn('E_RELEASE_HASH',codes)

    def test_release_path_traversal(self):
        codes,_=self.codes('P09_mapping_release_registry',lambda d:d['releases'][0].update(rules_path='../other.json'))
        self.assertIn('E_RELEASE_PATH',codes)

    def test_missing_art_is_blocked_not_approved(self):
        x=collect(self.docs,self.desc)
        self.assertEqual(len([e for e in x.issues if e['code']=='B_CHARACTER_ART_UNBOUND']),3)
        self.assertEqual(len([e for e in x.issues if e['code']=='B_ASSET_REQUEST_UNFULFILLED']),5)
        self.assertFalse(any(r['kind']=='asset' for r in x.defs.values()))

    def test_regression_heal_role_uint32_and_missing_asset_marker(self):
        for key in ['P04_character_skeleton','P06_enemy_specs','P06_asset_requests']:
            self.assertEqual(self.bank.errors(self.desc[key]['schema'],self.docs[key]),[])
        self.assertEqual(self.docs['P04_character_skeleton']['characters'][2]['role_code'],'HEAL')
        self.assertEqual(self.docs['P06_enemy_specs']['policies']['rng']['seed_max'],4294967295)
        self.assertEqual(self.docs['P06_asset_requests'][0]['actual_asset_sha256'],'NOT_RECEIVED')

    def test_reference_documents_are_not_content_targets(self):
        r=validate(ROOT)
        self.assertEqual(len([e for e in r['issues'] if e['code']=='B_REFERENCE_DOCUMENT_UNPINNED']),2)
        self.assertEqual(r['summary']['dangling_references'],0)

    def test_versioned_negative_files_reject_expected_defects(self):
        r=run_samples(ROOT);self.assertEqual(r['status'],'PASS');self.assertEqual(len(r['cases']),5)
        self.assertTrue(all(c['sample_data_status']=='REJECTED' for c in r['cases']))

    def test_v6_43_92_27_is_static_only(self):
        g=governance(ROOT);self.assertEqual(g['counts'],{'roles':43,'duties':92,'interfaces':27});self.assertEqual(g['status'],'PASS')
        self.assertEqual({r['职责ID'] for r in g['p22_duties']},{'053','082'})
        self.assertIn('NOT_IMPLEMENTATION',g['scope'])

    def test_save_schema_not_in_content_bank(self):
        self.assertFalse(any('/save/' in p for p in self.bank.schemas))
        self.assertNotIn('schema/save/P21_save_head.schema.json',self.bank.schemas)

    def test_remote_schema_reference_does_not_fetch(self):
        key='test-offline';self.bank.schemas[key]={'$ref':'https://invalid.example.test/never-fetch'}
        try:
            with self.assertRaises(ContentError) as caught:self.bank.errors(key,{})
            self.assertEqual(caught.exception.code,'E_SCHEMA_REF')
        finally:del self.bank.schemas[key]
