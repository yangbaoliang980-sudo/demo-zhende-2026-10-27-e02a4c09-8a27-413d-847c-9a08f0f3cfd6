# P04｜阻塞、职责转交与RFC提案

固定产品基线：P01-S00-V0.1；P03原卡源：`P03-CARDS-0.1.0-draft`；P04本地产物：`P04-SKELETON-0.1.0-draft`，全部隔离候选。关联需求 `REQ-005/027/033`，`DEC-004/009`。旧正式DTO base SHA 和旧正式角色Schema base SHA 均为 **MISSING**，不得伪造「已完成修改」的接口补丁。

| 跟踪ID | 状态 | 唯一owner | 缺失证据 / 解除条件 | 可独立交付 |
|---|---|---|---|---|
| P04-BLK-01 | BLOCKED | P13 | `actual_path_mapping.json`、`do_not_touch.txt`、本岗所有权、游戏内部Party/Character/Wallet DTO版本与引擎证据 | 角色候选字段与单独校验器 |
| P04-BLK-02 | BLOCKED | P22 | `content_id_registry.tsv`、正式角色/技能ID规则、Schema、跨文件引用lint及错误规则 | 隔离局部唯一性/存在性 |
| P04-BLK-03 | BLOCKED | P05 | 等级经验曲线、训练资源预算、技能升级费用/上限与角色基础数值审核 | 只在mock上自证算术闭合 |
| P04-BLK-04 | BLOCKED | P08 | 学习资源与非学习资源界限、奖额、撤销权益及零复习日政策 | 不将Anki事件接入本岗测试余额 |
| P04-BLK-05 | PENDING_USER_DECISION | P01 | DEC-004确认首版角色数量；DEC-009裁定装备/稀有/好感/星级最小范围 | 只提供3个结构fixture，不冻结数量 |
| P04-BLK-06 | NOT_RUN | P17 | 获取、上阵、XP成长、等级/技能、余额校验、命令幂等真实运行时代码 | P04交付判定表与测试基线 |
| P04-BLK-07 | NOT_RUN | P21 | 原子钱包与角色/队伍状态的物理事务、落盘、重新打开证据 | JSON内存往返，不称实际重启 |
| P04-BLK-08 | NOT_RUN | P32 | 独立内容/契约/单元/反例/持久化测试 | P04本岗校验日志 |
| P04-BLK-09 | NOT_RUN | P35 | P32后的独立审查与门禁回执 | 可提交证据文件供审 |
| P04-BLK-10 | NOT_RUN | P26/P25/P37 | 角色正式原画、编辑源文件、风格与素材合规审查 | 当前assets=null，无假占位图 |

## 待签 RFC（PROPOSED，不是已被接受的接口）

- **P04-RFC-IC03-001 → P22 / 抄送P03与P13**：建立 P04 三个候选角色与 P03 mock A/B/C 的版本化、可迁移正式 ID 对照；明确 `MOCK_P03_CHAR_D` 不应自动获得正式角色身份。要求角色/技能ID唯一性、卡牌归属引用的全域验证，并提供最终registry与schema哈希。
- **P04-RFC-IC09-001 → P13/P17 / 抄送P03/P05**：冻结只读 PartySnapshot、OwnedCharacterProgress、派生属性与 `DeckContribution` DTO。至少有三席有序ID、角色拥有状态、等级/XP/技能rank、局部catalog版本；P03内容不得由P17在计算中私改。
- **P04-RFC-IC10-001 → P17/P21 / 抄送P05/P08**：确认 `WalletDelta` 与角色提升/技能提升在**同一原子提交**，余额先校验后写入，命令去重（同ID同指纹无副作用、不同指纹拒绝）、失败回滚、真实重新载入后的验证字段；明确本仓库的P04不是实际Wallet写权限owner。
- **P04-RFC-PRD-001 → P01**：收录 `DEC-004/009` 未签决定，不以本包角色三个、技能上限5/3、训练代币价格、示意角色名字作为最终MVP冻结值。

## 冲突和恢复

若P03/P22的某一正式ID或签名卡冲突：保留 P03 card_catalog 原 SHA、P04 本次贡献表 SHA、双方接口版本/旧base SHA；出具 ChangeRequest，不覆盖P03及P22文件。若P17报告无钱包余额但P05预算仍未签，维持 BLOCKED 不能以mock余额说明实际经济可用；若测试失败，回对应唯一owner（P04字段→P04，P03归属→P03，P17运行时→P17，P21持久事务→P21）。同一故障连续两轮无新证据→P01；跨模块源码整合仅用户明确委派的 EXT-INTEGRATOR。
