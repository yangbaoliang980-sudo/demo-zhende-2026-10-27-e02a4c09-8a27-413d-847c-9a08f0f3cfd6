"""Reproducible P11 author verification commands."""
