"""P17's in-memory P21 boundary model. NOT a P21 implementation.

No disk, no database and no durable receipts. A single lock models one atomic
snapshot boundary. 'foreign_revision' is only a synthetic P11/P18 side effect.
"""
from threading import RLock
from character_party_runtime import FrozenMessage,DomainError,validate_state,restore_state
from character_party_runtime.common import require


class InjectedFailure(RuntimeError): pass
class SimulatedCommitUnknown(RuntimeError): pass


class AtomicMemoryModel:
    origin='P17_TEST_MEMORY_MODEL_NOT_P21'
    durable=False

    def __init__(self,planner,snapshot):
        validate_state(snapshot,planner.catalog)
        self.planner=planner;self._snapshot=snapshot;self._lock=RLock()
        self.foreign_revision=0;self.receipts=[]

    def snapshot(self):
        with self._lock:return self._snapshot

    def submit(self,candidate,*,fail_at=None,synthetic_counterpart=False):
        with self._lock:
            if fail_at=='before_validation':raise InjectedFailure(fail_at)
            result=self.planner.validate_for_commit(candidate,self._snapshot)
            if result.status=='DUPLICATE_NO_OP':return {'status':'DUPLICATE_NO_OP','durable':False,'origin':self.origin}
            c=candidate.value
            counterpart=c['required_counterpart_owner']
            require(counterpart is None or synthetic_counterpart,'E_COUNTERPART_COMMIT_CONTRACT_UNBOUND')
            # Every object is staged privately. None is visible until publish.
            staged=FrozenMessage.from_value(c['after_state'])
            foreign=self.foreign_revision+(1 if counterpart else 0)
            if fail_at=='after_wallet_prepared':raise InjectedFailure(fail_at)
            receipt={'status':'COMMITTED_SIMULATION','request_id':c['request']['request_id'],
                     'request_sha256':c['request_sha256'],'candidate_sha256':candidate.sha256,
                     'revision':staged.value['revision'],'state_sha256':staged.sha256,
                     'durable':False,'origin':self.origin}
            if fail_at=='before_publish':raise InjectedFailure(fail_at)
            self._snapshot=staged;self.foreign_revision=foreign;self.receipts.append(receipt)
            if fail_at=='after_publish_unknown':raise SimulatedCommitUnknown(fail_at)
            return receipt.copy()

    def lookup(self,request_id):
        with self._lock:
            r=next((x for x in self.receipts if x['request_id']==request_id),None)
            return {'status':'COMMITTED_SIMULATION' if r else 'ABSENT_SIMULATION',
                    'receipt':None if r is None else r.copy(),'durable':False,'origin':self.origin}

    def reload(self):
        with self._lock:
            old=self._snapshot;d=old.value
            new=restore_state(old.raw,self.planner.catalog,expected_sha256=old.sha256,
                              expected_store_instance=d['store_instance'],expected_continuity_ref=d['continuity_ref'])
            self._snapshot=new
            return new

