import unittest
from character_party_runtime import MetaPlanner,load_catalog,empty_state,command,FrozenMessage
from .authority import FixtureAuthority,CHARS,TOKEN
from .atomic_memory_model import AtomicMemoryModel


class MetaCase(unittest.TestCase):
    def setUp(self):
        self.catalog=load_catalog();self.authority=FixtureAuthority()
        self.planner=MetaPlanner(self.catalog,self.authority)
        self.model=AtomicMemoryModel(self.planner,empty_state(self.catalog));self.seq=0

    def request(self,kind,payload,snapshot=None):
        self.seq+=1
        return command(snapshot or self.model.snapshot(),'fixture:request-'+str(self.seq),kind,payload)

    def apply(self,kind,payload):
        request=self.request(kind,payload);before=self.model.snapshot()
        result=self.planner.plan(request,before)
        self.assertEqual(result.status,'CANDIDATE',result.value())
        self.assertEqual(self.model.snapshot(),before)
        self.model.submit(result.candidate,synthetic_counterpart=True)
        return request,result.candidate

    def reject(self,kind,payload,reason,status='REJECTED'):
        before=self.model.snapshot();foreign=self.model.foreign_revision
        result=self.planner.plan(self.request(kind,payload),before)
        self.assertEqual((result.status,result.reason),(status,reason),result.value())
        self.assertIsNone(result.candidate);self.assertEqual(self.model.snapshot(),before)
        self.assertEqual(self.model.foreign_revision,foreign)
        return result

    def grant(self,ref='fixture:grant',**kw):
        self.authority.grant(ref,**kw)
        return self.apply('APPLY_GRANT',{'grant_ref':ref})

    def seed(self,amount=100,xp=70):
        return self.grant('fixture:seed',amount=amount,characters=CHARS,
                          xp=[{'character_id':x,'amount':xp} for x in CHARS] if xp else [])

    def upgrade(self,cid=CHARS[0],level=2):
        for rank in range(1,level):
            self.apply('LEVEL_UP',{'character_id':cid,'from_rank':rank,'to_rank':rank+1})

    def balance(self):
        rows=self.planner.wallet_snapshot(self.model.snapshot()).value['balances']
        return next((r['available'] for r in rows if r['resource_id']==TOKEN),0)

