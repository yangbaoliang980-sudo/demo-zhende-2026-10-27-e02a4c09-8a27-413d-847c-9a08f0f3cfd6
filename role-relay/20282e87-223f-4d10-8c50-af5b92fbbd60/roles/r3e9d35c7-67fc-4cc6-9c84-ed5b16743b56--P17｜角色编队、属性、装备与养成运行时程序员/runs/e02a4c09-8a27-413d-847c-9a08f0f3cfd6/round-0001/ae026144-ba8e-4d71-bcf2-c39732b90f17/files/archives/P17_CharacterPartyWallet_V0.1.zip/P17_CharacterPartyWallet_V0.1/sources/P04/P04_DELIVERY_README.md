# P04｜角色数据、三人编队与养成系统策划｜隔离交付

**任务** `TASK-P04-S02-LOCAL-001` · **版本** `P04-SKELETON-0.1.0-draft` · **阶段** S02，附带S06数据条件说明。

**真实产物，不是游戏运行或正式集成。** 本包给出三角色静态内容、编队合法性、XP/等级/技能rank/候选消费、P03卡组贡献桥接、完整生命周期JSON样例与可执行的自检脚本。三名角色为**测试结构**，不是P01批准的最终初始角色数量；角色名字、数值、费用均非产品正式决策。

## 启动与验证

在解压的本包根目录执行（Python 3.10+标准库）：

```bash
python content/characters/validate_character_content.py
```

预期 stdout 包含 `P04_LOCAL_STATIC_VALIDATION: PASS`，完整执行环境、退出码、反例结果在 `P04_static_validation.log`。该验证不写真实游戏/Anki/P17钱包/P21存档，也没有代替P32独立测试或P35审查。

## 四个强制实体文件

- `content/characters/character_skeleton.json`：三个建议原型、字段、角色定位、属性和确定性成长公式；P03原mock槽映射与未批扩展标志。
- `design/characters/party_constraints.md`：三席位、唯一性、拥有校验、失败码与验证次序，明确角色与技能/卡组接口边界。
- `content/characters/progression_costs.tsv`：角色获取、LV1→5与技能rank1→3的逐行候选来源/去向/门槛/消费，共21行，测试用经济参数未获P05批准。
- `content/characters/character_deck_contribution.tsv`：4种共同卡+3个角色专属贡献的精确P03引用，合计9个构筑实例，不修改P03原卡catalog。

其余 `character_field_dictionary.tsv`、`character_lifecycle_fixtures.json`、`character_cases.tsv`、`validate_character_content.py` 为独立可验证辅助工件，`design/characters/progression_semantics.md` 与 `interface_rfc_and_blockers.md` 管理契约边界。

## 只读上游证据

`evidence/readonly_p03/` 内原样存放 P03 的 `card_catalog.json`、`character_card_pool.tsv` 和 `deck_build_fixtures.json`，与用户上传ZIP中的字节完全一致。**仅作为不可编辑的离线验证基准，不允许把其覆盖到工程P03目录。**

## P03 兼容要点

P03的 `MOCK_P03_CHAR_A/B/C/D` 全部是测试槽。P04新增 `MOCK_P04_CHAR_001/002/003` 三个自己的候选ID，分别通过本岗贡献表临时映射至 A/B/C，D未映射。P03 common 模板 `STRIKE×2+BARRIER×2+RECOVER×1+EMBER×1` 不受角色成长影响；选入的三个角色各贡献1张P03 signature，共9张实例。P03已经生成的24个4P3队伍仍保持原样，P04仅在其中的6个三人排列上做兼容验证。D非新角色，禁止自动获取或默认进入队伍。

## 权责、阻塞与回执

P04允许提供字段/内容候选，不批准P05预算，不注册P22正式ID，不写P13 DTO、P17运行状态、P21真实存档、P26立绘。`design/characters/**`、`content/characters/**` 为**规划的独占路径**，未经P13 `actual_path_mapping.json` 和授权不可覆盖真实工程。根目录交接/日志/清单是包级元数据；只读上游不是本岗可编辑范围。`source_input_receipt.tsv` 记录输入原始sha，`downstream_handoff.tsv` 记录接收人及待签状态；P32/P35/真实S06重启均未执行。
