import csv,itertools,json
from character_party_runtime import (MetaPlanner,load_catalog,empty_state,FrozenMessage,
    Catalog,DomainError,restore_state,command)
from character_party_runtime._upstream import PACKAGE_ROOT
from runtime.meta.characters.rules import derived
from runtime.meta.party.projection import validate_party
from tests.support.base import MetaCase
from tests.support.authority import CHARS,TOKEN
from tests.support.atomic_memory_model import AtomicMemoryModel


class CharacterTests(MetaCase):
    def test_p04_original_lifecycle(self):
        f=json.loads((PACKAGE_ROOT/'sources/P04/content/characters/character_lifecycle_fixtures.json').read_text())
        for c in f['commands']:
            a=c['action']
            if a in ('ACQUIRE','GRANT_TOKEN','GRANT_XP'):
                args=({'characters':[c['target']]} if a=='ACQUIRE' else
                      {'amount':c['delta']} if a=='GRANT_TOKEN' else
                      {'xp':[{'character_id':c['target'],'amount':c['delta']}]})
                self.authority.grant(c['event_identity'],**args)
                kind,payload='APPLY_GRANT',{'grant_ref':c['event_identity']}
            elif a=='SET_PARTY':kind,payload='SET_PARTY',{'ordered_character_ids':c['ordered_ids']}
            elif a=='UPGRADE_LEVEL':
                kind,payload='LEVEL_UP',{'character_id':c['target'],'from_rank':c['from_level'],'to_rank':c['to_level']}
            else:
                self.assertEqual(a,'SERIALIZE_JSON_ROUNDTRIP_ASSERT');self.model.reload();continue
            req=command(self.model.snapshot(),c['command_id'],kind,payload)
            result=self.planner.plan(req,self.model.snapshot());self.assertEqual(result.status,'CANDIDATE',result.reason)
            self.model.submit(result.candidate,synthetic_counterpart=True)
        actual=self.model.snapshot().value;expected=f['expected_after_mutations_before_serialization']
        projection={'owned_character_ids':[c['character_id'] for c in actual['characters']],
            'party_ordered_ids':actual['party_slots'],'character_progress':{c['character_id']:{
                k:c[k] for k in ('level','xp_total','skill_rank')} for c in actual['characters']},
            'wallet':{TOKEN:self.balance()},'revision':actual['revision']}
        self.assertEqual(projection,expected)
        self.assertEqual({c:derived(actual,self.catalog,c) for c in CHARS},f['derived_stats_after'])

    def test_all_p05_growth_rows(self):
        self.seed(amount=1000)
        path=PACKAGE_ROOT/'sources/P05/content/balance/character_growth_projection.tsv'
        rows=list(csv.DictReader(path.open(encoding='utf-8'),delimiter='\t'))
        self.assertEqual(len(rows),15)
        for row in rows:
            cid=row['character_id'];level=int(row['level'])
            if level>1:self.apply('LEVEL_UP',{'character_id':cid,'from_rank':level-1,'to_rank':level})
            stats=derived(self.model.snapshot().value,self.catalog,cid)
            self.assertEqual(stats,{k:int(row[k]) for k in ('max_hp','attack','defense','support')})

    def test_acquire_unknown_character(self):
        self.authority.grant('fixture:unknown',characters=['UNKNOWN'])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:unknown'},'E_CHARACTER_NOT_FOUND')

    def test_duplicate_acquisition_same_entitlement(self):
        self.grant(characters=[CHARS[0]])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:grant'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')

    def test_duplicate_character_different_entitlement_no_bonus(self):
        self.grant(characters=[CHARS[0]])
        self.authority.grant('fixture:other',characters=[CHARS[0]],amount=100)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:other'},'E_CHARACTER_ALREADY_OWNED')
        self.assertEqual(self.balance(),0)

    def test_xp_for_unowned_rejects_entire_grant(self):
        self.authority.grant('fixture:xp',amount=10,xp=[{'character_id':CHARS[0],'amount':1}])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:xp'},'E_CHARACTER_NOT_OWNED')

    def test_level_insufficient_xp(self):
        self.seed(xp=9)
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_XP_INSUFFICIENT')

    def test_level_insufficient_materials(self):
        self.seed(amount=3)
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_WALLET_INSUFFICIENT')

    def test_level_jump_rejected(self):
        self.seed()
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':3},'E_LEVEL_STEP_INVALID')

    def test_level_cap(self):
        self.seed();self.upgrade(level=5)
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':5,'to_rank':6},'E_LEVEL_CAP')

    def test_level_old_from_rank(self):
        self.seed();self.upgrade()
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_CHARACTER_RANK_CONFLICT')

    def test_xp_is_not_spent_or_auto_leveled(self):
        self.seed();c=self.model.snapshot().value['characters'][0]
        self.assertEqual((c['level'],c['xp_total']),(1,70));self.upgrade(level=3)
        self.assertEqual(self.model.snapshot().value['characters'][0]['xp_total'],70)
        self.assertEqual(self.balance(),90)

    def test_skill_character_level_gate(self):
        self.seed();self.upgrade(level=2)
        self.reject('SKILL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_SKILL_LEVEL_GATED')

    def test_skill_growth_and_no_card_scaling(self):
        self.seed();self.upgrade(level=5)
        self.apply('SKILL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        self.apply('SKILL_UP',{'character_id':CHARS[0],'from_rank':2,'to_rank':3})
        self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        m=self.planner.party_export(self.model.snapshot()).value['members'][0]
        self.assertEqual(m['skill_rank'],3);self.assertEqual(self.balance(),40)
        self.assertEqual(m['card_scaling'],'NONE_PENDING_P03_P05_P13_P14_CONTRACT')

    def test_skill_insufficient_materials(self):
        self.seed(amount=59);self.upgrade(level=5)
        self.apply('SKILL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        self.assertEqual(self.balance(),19)
        self.reject('SKILL_UP',{'character_id':CHARS[0],'from_rank':2,'to_rank':3},'E_WALLET_INSUFFICIENT')

    def test_skill_jump(self):
        self.seed();self.upgrade(level=5)
        self.reject('SKILL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':3},'E_SKILL_STEP_INVALID')

    def test_skill_cap(self):
        self.seed();self.upgrade(level=5)
        for a,b in [(1,2),(2,3)]:self.apply('SKILL_UP',{'character_id':CHARS[0],'from_rank':a,'to_rank':b})
        self.reject('SKILL_UP',{'character_id':CHARS[0],'from_rank':3,'to_rank':4},'E_SKILL_CAP')

    def test_unowned_upgrade(self):
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_CHARACTER_NOT_OWNED')

    def test_bool_rank_rejected(self):
        self.seed();self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':True,'to_rank':2},'E_INTEGER')

    def test_readonly_snapshot(self):
        self.seed();original=self.model.snapshot();copy=original.value
        copy['characters'][0]['level']=5;copy['wallet']['lots'][0]['available']=999
        self.assertEqual(original,self.model.snapshot());self.assertEqual(self.balance(),100)

    def test_public_attribute_api_on_character_without_party(self):
        self.seed();self.upgrade(level=3)
        msg=self.planner.character_attributes(self.model.snapshot(),CHARS[0])
        self.assertEqual(msg.value['stats'],{'max_hp':120,'attack':25,'defense':7,'support':5})
        copy=msg.value;copy['stats']['attack']=999
        self.assertEqual(msg.value['stats']['attack'],25)


class PartyTests(MetaCase):
    def test_all_six_ordered_permutations(self):
        self.seed()
        for ids in itertools.permutations(CHARS):
            self.apply('SET_PARTY',{'ordered_character_ids':list(ids)})
            export=self.planner.party_snapshot(self.model.snapshot()).value
            self.assertEqual([m['character_id'] for m in export['members']],list(ids))
            self.assertEqual([m['slot'] for m in export['members']],[0,1,2])

    def test_too_few(self):
        self.seed();self.reject('SET_PARTY',{'ordered_character_ids':CHARS[:2]},'E_PARTY_SIZE')

    def test_too_many(self):
        self.seed();self.reject('SET_PARTY',{'ordered_character_ids':CHARS+[CHARS[0]]},'E_PARTY_SIZE')

    def test_duplicate_id(self):
        self.seed();self.reject('SET_PARTY',{'ordered_character_ids':[CHARS[0],CHARS[0],CHARS[2]]},'E_PARTY_DUPLICATE')

    def test_unknown_id(self):
        self.seed();self.reject('SET_PARTY',{'ordered_character_ids':[CHARS[0],CHARS[1],'UNKNOWN']},'E_CHARACTER_NOT_FOUND')

    def test_unowned_id(self):
        self.grant(characters=CHARS[:2]);self.reject('SET_PARTY',{'ordered_character_ids':CHARS},'E_CHARACTER_NOT_OWNED')

    def test_id_type_priority(self):
        self.reject('SET_PARTY',{'ordered_character_ids':[CHARS[0],{},CHARS[2]]},'E_CHARACTER_ID_TYPE')

    def test_payload_type(self):
        self.reject('SET_PARTY',{'ordered_character_ids':'ABC'},'E_PARTY_PAYLOAD_TYPE')

    def test_missing_content_before_ownership(self):
        with self.assertRaisesRegex(DomainError,'E_CHARACTER_NOT_FOUND'):
            validate_party([CHARS[0],CHARS[1],'UNKNOWN'],set(),self.catalog)

    def test_role_diversity_not_required(self):
        data=self.catalog.value
        for c in data['characters']:c['role']='ATTACK'
        alternate=Catalog(FrozenMessage.from_value(data))
        self.assertEqual(validate_party(CHARS,set(CHARS),alternate),CHARS)

    def test_empty_party_cannot_export_for_battle(self):
        with self.assertRaisesRegex(DomainError,'E_CHARACTER_ID_TYPE'):
            self.planner.party_snapshot(self.model.snapshot())

    def test_projection_preserves_lossless_sidecar(self):
        self.seed();self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        full=self.planner.party_export(self.model.snapshot());wire=self.planner.party_snapshot(self.model.snapshot())
        self.assertEqual(full.value['members'][2]['stats']['support'],17)
        self.assertNotIn('support',wire.value['members'][2])
        self.assertEqual([m['p03_link']['character_id'] for m in full.value['members']],
                         ['MOCK_P03_CHAR_A','MOCK_P03_CHAR_B','MOCK_P03_CHAR_C'])
        copy=full.value;copy['members'][0]['stats']['attack']=999
        self.assertEqual(full.value['members'][0]['stats']['attack'],17)

    def test_party_change_does_not_spend_or_scale_cards(self):
        self.seed();before=self.model.snapshot().value['wallet']
        self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        self.assertEqual(before,self.model.snapshot().value['wallet'])


class EquipmentTests(MetaCase):
    def enable_fixture(self):
        self.catalog=load_catalog(equipment_test_fixture=True)
        self.planner=MetaPlanner(self.catalog,self.authority)
        self.model=AtomicMemoryModel(self.planner,empty_state(self.catalog));self.seed()
        self.grant('fixture:gear',equipment=[{'instance_id':'fixture:blade-1','definition_id':'TEST_P17_BLADE'},
             {'instance_id':'fixture:charm-1','definition_id':'TEST_P17_CHARM'},
             {'instance_id':'fixture:heal-1','definition_id':'TEST_P17_HEAL_CHARM'}])

    def test_default_feature_closed(self):
        self.seed();self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[{'slot':'weapon','instance_id':'fixture:x'}]},'E_FEATURE_DISABLED')

    def test_duplicate_checked_before_disabled_flag(self):
        self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[
            {'slot':'weapon','instance_id':'fixture:x'},{'slot':'charm','instance_id':'fixture:x'}]},'E_EQUIPMENT_DUPLICATE')

    def test_equip_unequip_and_derived_recalculate(self):
        self.enable_fixture();before=derived(self.model.snapshot().value,self.catalog,CHARS[0])
        self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[{'slot':'weapon','instance_id':'fixture:blade-1'}]})
        after=derived(self.model.snapshot().value,self.catalog,CHARS[0]);self.assertEqual(after['attack'],before['attack']+3)
        self.model.reload();self.assertEqual(derived(self.model.snapshot().value,self.catalog,CHARS[0]),after)
        self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[]})
        self.assertEqual(derived(self.model.snapshot().value,self.catalog,CHARS[0]),before)

    def test_instance_cannot_equip_twice_across_characters(self):
        self.enable_fixture()
        self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[{'slot':'weapon','instance_id':'fixture:blade-1'}]})
        self.reject('SET_EQUIPMENT',{'character_id':CHARS[1],'items':[{'slot':'weapon','instance_id':'fixture:blade-1'}]},'E_EQUIPMENT_IN_USE')

    def test_wrong_slot(self):
        self.enable_fixture();self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],
            'items':[{'slot':'charm','instance_id':'fixture:blade-1'}]},'E_EQUIPMENT_SLOT')

    def test_level_gate(self):
        self.enable_fixture();self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],
            'items':[{'slot':'charm','instance_id':'fixture:charm-1'}]},'E_EQUIPMENT_LEVEL_GATED')

    def test_role_gate(self):
        self.enable_fixture();self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],
            'items':[{'slot':'charm','instance_id':'fixture:heal-1'}]},'E_EQUIPMENT_ROLE')

    def test_unowned_instance(self):
        self.enable_fixture();self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],
            'items':[{'slot':'weapon','instance_id':'fixture:missing'}]},'E_EQUIPMENT_NOT_OWNED')

    def test_valid_two_slots_and_atomic_replacement(self):
        self.enable_fixture();self.upgrade()
        self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[
            {'slot':'weapon','instance_id':'fixture:blade-1'},{'slot':'charm','instance_id':'fixture:charm-1'}]})
        self.assertEqual(derived(self.model.snapshot().value,self.catalog,CHARS[0]),
                         {'max_hp':113,'attack':24,'defense':8,'support':8})
        self.reject('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[
            {'slot':'weapon','instance_id':'fixture:blade-1'},{'slot':'charm','instance_id':'fixture:missing'}]},'E_EQUIPMENT_NOT_OWNED')

    def test_equipment_grant_is_disabled_by_default(self):
        self.authority.grant('fixture:gear',equipment=[{'instance_id':'fixture:x','definition_id':'TEST_P17_BLADE'}])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:gear'},'E_FEATURE_DISABLED')

    def test_duplicate_equipment_grant_rejected(self):
        self.enable_fixture();self.authority.grant('fixture:again',amount=99,
            equipment=[{'instance_id':'fixture:blade-1','definition_id':'TEST_P17_BLADE'}])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:again'},'E_EQUIPMENT_ALREADY_OWNED')
