# P04｜验收分层与回归矩阵（作者自检不替代独立验收）

| 验收对象 | 状态 | 证据 / 后续负责人 |
|---|---|---|
| 上传包外层23项的大小/SHA-256 | PASS_INGEST_ONLY | 逐字节核验原始 relay manifest，输入 ZIP 未修改 |
| P01/P02/P03 ZIP CRC 与包内manifest | PASS_INGEST_ONLY | P01 15/15、P02 14/14、P03 16/16 SHA-256 匹配，保留原ZIP为上游来源 |
| 本岗角色条目字段、局部ID唯一、成长整数公式 | P04_SELF_STATIC_PASS | 本包 `content/characters/validate_character_content.py`、日志 |
| 三人编队6排列与P03 24原fixture交集 | P04_SELF_STATIC_PASS | 6个A/B/C有序构筑与P03原样fixture的卡牌序列逐项相符 |
| 资源来源/消费去向、训练代币余额及重复事件反例 | P04_SELF_FIXTURE_PASS | 测试输入15，扣除4+4+6剩1；不使用真实钱包 |
| 获取→上阵→升级→序列化往返 | P04_SELF_MEMORY_ROUNDTRIP_PASS | 内存JSON对象encode/decode结果一致；非真实游戏重启 |
| P22正式内容ID/Schema | BLOCKED | P22出具 registry、linter和schema签署版本后才能尝试正式校验 |
| P13真实工程路径/DTO/真实目标机 | BLOCKED | P13出具 actual_path_mapping、DTO 和授权；P34提供目标机指纹 |
| P05经济批准、P08学习政策 | BLOCKED | 参数为未批准fixture，不能作为正式游戏奖额 |
| P17运行时角色解锁/钱包/成长单元测试 | NOT_RUN | P17应提交真实独立模块、日志；本岗不得代写 |
| P21物理存档、真实退出重新启动 | NOT_RUN | P17/P21执行并留进程/磁盘证据 |
| P03/P13/P15/P14端到端出牌与血条结算 | NOT_RUN | 未调用游戏引擎或真实 BattleState |
| P32独立单元/契约/负向测试 | NOT_RUN | 本地作者自检不可冒称P32 |
| P33人工界面/玩法体验 | NOT_RUN | 无可运行界面可测 |
| P25/P26/P37正式美术及合规审查 | NOT_RUN | 本包未包含任何角色立绘，`art.asset_id=null` |
| P35独立审查门禁 | NOT_RUN | 未取得任何签署回执 |
| Anki四键、Undo、真实资源奖励、真实E2E | NOT_RUN | 无Anki联动、无正式游戏集成 |

允许的最强结论：**P04隔离内容/静态数据测试已按本岗脚本执行通过，正式工程交付及独立门禁仍阻塞。** 下游接收 `PREPARED_NOT_ACKNOWLEDGED`，不把本文件当P32/P35签收记录。
