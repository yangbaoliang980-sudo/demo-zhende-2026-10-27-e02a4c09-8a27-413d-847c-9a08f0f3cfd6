# P04 作者自检阶段实际失败与修复记录

在增加 CASE-PARTY-027 `[C,A,B]` 回归断言之后，第一次执行 `python content/characters/validate_character_content.py` **实际返回退出码1**，日志标准错误为：

```text
P04_LOCAL_STATIC_VALIDATION: FAIL ValidationError: ordered permutation [C,A,B] works: expected='OK' got='E_CHARACTER_ID_TYPE'
```

调查发现**不是角色内容或编队规则错误**：验证脚本同一函数使用了变量 `c` 先作角色ID（第三个角色），后又在 `for c in m['characters']` 中被覆盖为一个角色定义字典，导致测试输入 `[c,a,b]` 中混入了非字符串。变更了测试脚本该单行，将该位置替换为显式 `char_ids[2]`，P04原始角色内容、P03上游原件、钱包/存档运行代码均未改动。

本记录保留原始失败作为修复轨迹，之后成功结果只以随包 `P04_static_validation.log` 中**实际重新执行**的原始输出与退出码为准。这只是P04作者自检，不代表P32独立复测。
