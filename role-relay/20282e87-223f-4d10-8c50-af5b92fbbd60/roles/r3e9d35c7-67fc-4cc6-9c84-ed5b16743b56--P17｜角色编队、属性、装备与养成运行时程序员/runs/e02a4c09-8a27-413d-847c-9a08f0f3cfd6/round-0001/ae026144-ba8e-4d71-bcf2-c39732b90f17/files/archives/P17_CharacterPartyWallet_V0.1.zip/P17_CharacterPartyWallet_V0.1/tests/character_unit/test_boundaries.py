import subprocess,sys
from character_party_runtime import (MetaPlanner,Catalog,FrozenMessage,empty_state,DomainError,command)
from character_party_runtime._upstream import PACKAGE_ROOT
from tests.support.base import MetaCase
from tests.support.authority import CHARS


class BoundaryTests(MetaCase):
    def test_direct_wallet_module_import_in_new_process(self):
        r=subprocess.run([sys.executable,'-B','-c','from runtime.meta.wallet.rules import balances; print(balances({"lots":[]}))'],
                         cwd=PACKAGE_ROOT,capture_output=True)
        self.assertEqual(r.returncode,0,r.stderr.decode())

    def test_full_length_valid_profile_id(self):
        profile='P'*128;s=empty_state(self.catalog,profile_id=profile)
        self.authority.grant('fixture:long-profile',amount=1,profile=profile)
        r=self.planner.plan(command(s,'fixture:long-request','APPLY_GRANT',{'grant_ref':'fixture:long-profile'}),s)
        self.assertEqual(r.status,'CANDIDATE',r.reason)

    def test_malformed_entitlement_key_rejected_without_typeerror(self):
        self.seed();d=self.model.snapshot().value;d['entitlements'][0]['key']=[]
        invalid=FrozenMessage.from_value(d)
        r=self.planner.plan(command(invalid,'fixture:bad-key','SET_PARTY',{'ordered_character_ids':CHARS}),invalid)
        self.assertEqual(r.status,'REJECTED')

    def test_missing_catalog_character_id_rejected_as_domain_error(self):
        d=self.catalog.value;del d['characters'][0]['character_id']
        with self.assertRaises(DomainError):Catalog(FrozenMessage.from_value(d))

    def test_bad_resource_shape_rejected_without_typeerror(self):
        g=self.authority.grant('fixture:bad',amount=1).value;g['resources']=[[]]
        self.authority.grants['fixture:bad']=FrozenMessage.from_value(g)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:bad'},'E_SHAPE')

    def test_no_hardcoded_total_roster_limit(self):
        d=self.catalog.value;c=dict(d['characters'][0]);c['character_id']='TEST_FOURTH_CHARACTER'
        c['p03_character_id']='TEST_FOURTH_P03';c['signature_card_id']='TEST_FOURTH_CARD'
        d['characters'].append(c)
        d['costs'] += [{**r,'character_id':c['character_id']} for r in d['costs'] if r['character_id']==CHARS[0]]
        catalog=Catalog(FrozenMessage.from_value(d));planner=MetaPlanner(catalog,self.authority);s=empty_state(catalog)
        self.authority.grant('fixture:four',characters=CHARS+[c['character_id']],amount=4,
                             xp=[{'character_id':c['character_id'],'amount':10}])
        r=planner.plan(command(s,'fixture:acquire-four','APPLY_GRANT',{'grant_ref':'fixture:four'}),s)
        self.assertEqual(r.status,'CANDIDATE',r.reason)
        s=FrozenMessage.from_value(r.candidate.value['after_state'])
        r=planner.plan(command(s,'fixture:four-party','SET_PARTY',{'ordered_character_ids':[c['character_id'],CHARS[0],CHARS[1]]}),s)
        self.assertEqual(r.status,'CANDIDATE',r.reason)

    def test_level_caller_cannot_override_cost(self):
        self.seed();self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2,'cost':0},'E_SHAPE')

    def test_command_unknown_fields_are_rejected(self):
        r=self.request('SET_PARTY',{'ordered_character_ids':CHARS}).value;r['production_authorized']=True
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(r),self.model.snapshot()).reason,'E_SHAPE')

