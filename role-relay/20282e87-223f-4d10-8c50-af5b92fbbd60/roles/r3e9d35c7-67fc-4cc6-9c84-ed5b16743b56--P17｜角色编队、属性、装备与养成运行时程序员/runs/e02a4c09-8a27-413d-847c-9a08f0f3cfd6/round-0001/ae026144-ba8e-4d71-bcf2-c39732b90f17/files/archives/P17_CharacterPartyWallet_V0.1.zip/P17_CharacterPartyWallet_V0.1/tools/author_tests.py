from pathlib import Path
import sys,unittest,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))

class RecordedResult(unittest.TextTestResult):
    def __init__(self,*args,**kw):super().__init__(*args,**kw);self.records=[]
    def addSuccess(self,test):super().addSuccess(test);self.records.append({'test_id':test.id(),'status':'PASS'})
    def addFailure(self,test,err):super().addFailure(test,err);self.records.append({'test_id':test.id(),'status':'FAIL'})
    def addError(self,test,err):super().addError(test,err);self.records.append({'test_id':test.id(),'status':'ERROR'})
    def addSkip(self,test,reason):super().addSkip(test,reason);self.records.append({'test_id':test.id(),'status':'NOT_RUN','reason':reason})

def main():
    suite=unittest.defaultTestLoader.discover(str(ROOT/'tests/character_unit'),pattern='test_*.py',top_level_dir=str(ROOT))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromName('wallet_concurrency_tests'))
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    print(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
                      'skipped':len(result.skipped),'status':'PASS' if result.wasSuccessful() else 'FAIL',
                      'scope':'P17_AUTHOR_TESTS_ONLY','tests':result.records}))
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())
