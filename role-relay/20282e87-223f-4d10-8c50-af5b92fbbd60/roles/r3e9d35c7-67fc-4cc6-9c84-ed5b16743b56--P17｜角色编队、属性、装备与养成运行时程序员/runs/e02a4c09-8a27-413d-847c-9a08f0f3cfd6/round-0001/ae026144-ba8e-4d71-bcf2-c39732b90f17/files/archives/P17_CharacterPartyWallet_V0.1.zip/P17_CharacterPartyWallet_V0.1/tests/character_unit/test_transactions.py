import json,subprocess,sys
from character_party_runtime import (FrozenMessage,DomainError,MetaPlanner,UnboundP21,
    command,atomic_proposal,restore_state,validate_state)
from character_party_runtime.common import ContractError,canonical,fingerprint
from character_party_runtime._upstream import PACKAGE_ROOT
from tests.support.base import MetaCase
from tests.support.authority import CHARS
from tests.support.atomic_memory_model import InjectedFailure,SimulatedCommitUnknown
from yltt_framework.contracts import validate


class TransactionTests(MetaCase):
    def test_duplicate_command_no_second_debit(self):
        self.seed();request,candidate=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        before=self.model.snapshot();r=self.planner.plan(request,before)
        self.assertEqual(r.status,'DUPLICATE_NO_OP')
        self.assertEqual(self.model.submit(candidate)['status'],'DUPLICATE_NO_OP')
        self.assertEqual(self.model.snapshot(),before);self.assertEqual(self.balance(),96)

    def test_same_id_changed_payload_collision(self):
        self.seed();r,_=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        changed=r.value;changed['payload']['character_id']=CHARS[1]
        result=self.planner.plan(FrozenMessage.from_value(changed),self.model.snapshot())
        self.assertEqual(result.reason,'E_COMMAND_ID_COLLISION')

    def test_same_id_changed_revision_is_collision_not_retry(self):
        self.seed();r,_=self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        d=r.value;d['expected_revision']+=1
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(d),self.model.snapshot()).reason,'E_COMMAND_ID_COLLISION')

    def test_stale_distinct_request(self):
        self.seed();old=self.model.snapshot()
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},old)
        self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        self.assertEqual(self.planner.plan(request,self.model.snapshot()).reason,'E_REVISION_CONFLICT')

    def test_wallet_revision_fence(self):
        self.seed();r=self.request('SET_PARTY',{'ordered_character_ids':CHARS}).value;r['expected_wallet_revision']=0
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(r),self.model.snapshot()).reason,'E_WALLET_REVISION_CONFLICT')

    def test_store_instance_fence(self):
        self.seed();r=self.request('SET_PARTY',{'ordered_character_ids':CHARS}).value;r['store_instance']='fixture:other-store'
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(r),self.model.snapshot()).reason,'E_STORE_INSTANCE')

    def test_continuity_fence(self):
        self.seed();r=self.request('SET_PARTY',{'ordered_character_ids':CHARS}).value;r['continuity_ref']='fixture:old-continuity'
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(r),self.model.snapshot()).reason,'E_CONTINUITY_FENCE')

    def test_content_fence(self):
        self.seed();r=self.request('SET_PARTY',{'ordered_character_ids':CHARS}).value;r['content_sha256']='0'*64
        self.assertEqual(self.planner.plan(FrozenMessage.from_value(r),self.model.snapshot()).reason,'E_CONTENT_CONFLICT')

    def test_faults_before_publish_change_nothing(self):
        self.seed();request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        result=self.planner.plan(request,self.model.snapshot());before=self.model.snapshot();count=len(self.model.receipts)
        for stage in ('before_validation','after_wallet_prepared','before_publish'):
            with self.assertRaises(InjectedFailure):self.model.submit(result.candidate,fail_at=stage)
            self.assertEqual(self.model.snapshot(),before);self.assertEqual(len(self.model.receipts),count)
        self.model.submit(result.candidate);self.assertEqual(self.balance(),96)

    def test_composite_mock_rollback_preserves_foreign_domain(self):
        self.authority.grant('fixture:joint',amount=12,characters=CHARS)
        result=self.planner.plan(self.request('APPLY_GRANT',{'grant_ref':'fixture:joint'}),self.model.snapshot())
        before=self.model.snapshot();foreign=self.model.foreign_revision
        with self.assertRaises(InjectedFailure):
            self.model.submit(result.candidate,synthetic_counterpart=True,fail_at='before_publish')
        self.assertEqual(self.model.snapshot(),before);self.assertEqual(self.model.foreign_revision,foreign)
        self.model.submit(result.candidate,synthetic_counterpart=True)
        self.assertEqual(self.model.foreign_revision,foreign+1)
        self.assertEqual(self.balance(),12);self.assertEqual(len(self.model.snapshot().value['characters']),3)

    def test_unknown_outcome_lookup_and_same_request_retry(self):
        self.seed();req=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        result=self.planner.plan(req,self.model.snapshot())
        with self.assertRaises(SimulatedCommitUnknown):self.model.submit(result.candidate,fail_at='after_publish_unknown')
        lookup=self.model.lookup(req.value['request_id'])
        self.assertEqual(lookup['status'],'COMMITTED_SIMULATION');self.assertFalse(lookup['durable'])
        self.assertEqual(self.model.submit(result.candidate)['status'],'DUPLICATE_NO_OP');self.assertEqual(self.balance(),96)

    def test_tampered_candidate_recomputed_and_rejected(self):
        self.seed();r=self.planner.plan(self.request('SET_PARTY',{'ordered_character_ids':CHARS}),self.model.snapshot())
        d=r.candidate.value;d['after_state']['characters'][0]['level']=5
        d['after_sha256']=fingerprint(d['after_state'])
        with self.assertRaisesRegex(DomainError,'E_CANDIDATE_RECOMPUTE_MISMATCH'):
            self.model.submit(FrozenMessage.from_value(d))

    def test_evidence_change_between_plan_and_commit_rejected(self):
        self.authority.grant('fixture:grant',amount=5)
        r=self.planner.plan(self.request('APPLY_GRANT',{'grant_ref':'fixture:grant'}),self.model.snapshot())
        self.authority.grant('fixture:grant',amount=9)
        with self.assertRaisesRegex(DomainError,'E_CANDIDATE_RECOMPUTE_MISMATCH'):
            self.model.submit(r.candidate,synthetic_counterpart=True)
        self.assertEqual(self.balance(),0)

    def test_authority_removed_between_plan_commit_blocks(self):
        self.authority.grant('fixture:grant',amount=5)
        r=self.planner.plan(self.request('APPLY_GRANT',{'grant_ref':'fixture:grant'}),self.model.snapshot())
        self.authority.grants.clear()
        with self.assertRaisesRegex(DomainError,'E_GRANT_EVIDENCE_UNBOUND'):
            self.model.submit(r.candidate,synthetic_counterpart=True)

    def test_real_p21_unbound_does_not_debit(self):
        self.seed();r=self.planner.plan(self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2}),self.model.snapshot())
        before=self.model.snapshot()
        with self.assertRaisesRegex(DomainError,'E_P21_NOT_BOUND'):
            UnboundP21().submit(r.candidate)
        self.assertEqual(self.model.snapshot(),before);self.assertEqual(self.balance(),100)

    def test_production_constructor_closed(self):
        with self.assertRaisesRegex(DomainError,'E_PRODUCTION_BOOTSTRAP_BLOCKED'):
            MetaPlanner(self.catalog,self.authority,mode='production')

    def test_original_p13_atomic_character_projection(self):
        self.seed();r=self.planner.plan(self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2}),self.model.snapshot())
        projection=atomic_proposal(r.candidate)
        self.assertEqual(validate(projection.value,'AtomicCommitProposal'),projection)
        self.assertEqual(projection.value['domain_candidate_sha256'],r.candidate.sha256)

    def test_cross_domain_atomic_projection_blocks_without_owner_contract(self):
        self.authority.grant('fixture:study',kind='STUDY',amount=5)
        r=self.planner.plan(self.request('APPLY_GRANT',{'grant_ref':'fixture:study'}),self.model.snapshot())
        with self.assertRaisesRegex(DomainError,'E_COUNTERPART_COMMIT_CONTRACT_UNBOUND'):atomic_proposal(r.candidate)
        with self.assertRaisesRegex(DomainError,'E_COUNTERPART_COMMIT_CONTRACT_UNBOUND'):self.model.submit(r.candidate)

    def test_p13_rejects_unsupported_support_field(self):
        self.seed();self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        d=self.planner.party_snapshot(self.model.snapshot()).value;d['members'][0]['support']=3
        with self.assertRaisesRegex(ContractError,'SCHEMA_EXTRA_FIELD'):validate(d,'PartySnapshot')

    def test_p13_rejects_unattributed_wallet_change(self):
        self.seed();r=self.planner.plan(self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2}),self.model.snapshot())
        d=r.candidate.value['wallet_delta'];d['allocations']=[]
        with self.assertRaisesRegex(ContractError,'WALLET_ATTRIBUTION_MISMATCH'):validate(d,'WalletDeltaCandidate')

    def test_rehydrate_preserves_consumed_request_and_values(self):
        self.seed();request,_=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        before=self.model.snapshot();after=self.model.reload();self.assertEqual(before.raw,after.raw)
        self.assertEqual(self.planner.plan(request,after).status,'DUPLICATE_NO_OP')

    def test_reload_rejects_corruption(self):
        self.seed();s=self.model.snapshot();d=s.value;d['wallet']['lots'][0]['available']+=1
        with self.assertRaisesRegex(DomainError,'E_RELOAD_HASH'):
            restore_state(canonical(d),self.catalog,expected_sha256=s.sha256,
                          expected_store_instance=s.value['store_instance'],expected_continuity_ref=s.value['continuity_ref'])

    def test_reload_rejects_rehashed_broken_accounting(self):
        self.seed();d=self.model.snapshot().value;d['wallet']['lots'][0]['available']+=1
        with self.assertRaisesRegex(DomainError,'E_LOT_CONSERVATION'):validate_state(FrozenMessage.from_value(d),self.catalog)

    def test_reload_old_continuity_rejected(self):
        self.seed();s=self.model.snapshot()
        with self.assertRaisesRegex(DomainError,'E_CONTINUITY_FENCE'):
            restore_state(s.raw,self.catalog,expected_sha256=s.sha256,
                          expected_store_instance=s.value['store_instance'],expected_continuity_ref='fixture:new-epoch')

    def test_json_duplicate_keys_and_floats_rejected(self):
        for raw in (b'{"x":1,"x":2}',b'{"x":1.0}',b'{"x":NaN}',b'{"x":1e0}'):
            with self.assertRaises(ContractError):FrozenMessage(raw)

    def test_separate_python_process_rehydrate(self):
        self.seed();self.upgrade(level=3);self.apply('SET_PARTY',{'ordered_character_ids':CHARS})
        snap=self.model.snapshot();code='''import sys,json
from character_party_runtime import FrozenMessage,load_catalog,restore_state,MetaPlanner
s=FrozenMessage(sys.stdin.buffer.read());d=s.value
r=restore_state(s.raw,load_catalog(),expected_sha256=sys.argv[1],expected_store_instance=d['store_instance'],expected_continuity_ref=d['continuity_ref'])
print(json.dumps({'sha256':r.sha256,'party':MetaPlanner(load_catalog()).party_export(r).value}))
'''
        run=subprocess.run([sys.executable,'-B','-c',code,snap.sha256],input=snap.raw,cwd=PACKAGE_ROOT,capture_output=True)
        self.assertEqual(run.returncode,0,run.stderr.decode())
        data=json.loads(run.stdout);self.assertEqual(data['sha256'],snap.sha256)
        self.assertEqual(data['party'],self.planner.party_export(snap).value)

