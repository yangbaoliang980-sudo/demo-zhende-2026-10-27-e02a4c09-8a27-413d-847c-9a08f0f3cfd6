from pathlib import Path
import os,subprocess,sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
hashes=[]
for seed in ('1','17','8675309'):
    env=os.environ.copy();env['PYTHONHASHSEED']=seed;env['PYTHONDONTWRITEBYTECODE']='1'
    code='from examples.lifecycle_demo import run_demo; from character_party_runtime.common import fingerprint; print(fingerprint(run_demo()))'
    run=subprocess.run([sys.executable,'-B','-c',code],cwd=ROOT,env=env,capture_output=True)
    assert run.returncode==0,run.stderr.decode()
    hashes.append({'pythonhashseed':seed,'execution_sha256':run.stdout.decode().strip()})
assert len({r['execution_sha256'] for r in hashes})==1,'CROSS_PROCESS_NONDETERMINISM'
print(json.dumps({'status':'PASS','scope':'THREE_ISOLATED_PYTHON_PROCESSES','results':hashes}))
