"""Execute the unchanged P13 validator; report the unbound P11/P21 boundary."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from character_party_runtime import FrozenMessage,DomainError,atomic_proposal
from yltt_framework.contracts import validate

schema=json.loads((ROOT/'sources/P13/contracts/internal/internal_dto.schema.json').read_text())
projection=json.loads((ROOT/'wallet_delta_contract.json').read_text())
for name,shape in projection['$defs'].items():assert shape==schema['$defs'][name],name
demo=json.loads((ROOT/'examples/lifecycle_execution.json').read_text())
counts={};blocked=[]
def check(value):
    name=value['dto_type'];validate(value,name);counts[name]=counts.get(name,0)+1
check(demo['p13_party_snapshot']);check(demo['p13_wallet_snapshot'])
for step in demo['steps']:
    if 'candidate' not in step:continue
    check(step['candidate']['wallet_delta'])
    if step['p13_atomic_projection'] is not None:check(step['p13_atomic_projection'])
    else:
        try:atomic_proposal(FrozenMessage.from_value(step['candidate']))
        except DomainError as e:
            assert e.code=='E_COUNTERPART_COMMIT_CONTRACT_UNBOUND'
            blocked.append(step['request']['request_id'])
        else:raise AssertionError('unbound composite incorrectly projected')
sys.path.insert(0,str(ROOT/'sources/P11'))
from ledger_runtime.types import RewardIntent,WalletDelta
assert 'source_after' in WalletDelta.__dataclass_fields__
assert 'source_after' not in projection['$defs']['WalletDeltaCandidate']['properties']
print(json.dumps({'status':'PASS','scope':'P13_ORIGINAL_STRUCTURAL_CONTRACT_AND_REJECTION_CHECKS',
    'validated_dto_counts':counts,'total_validated':sum(counts.values()),
    'unbound_composite_requests_rejected':blocked,
    'p11_legacy_fields':{'RewardIntent':list(RewardIntent.__dataclass_fields__),
                         'WalletDelta':list(WalletDelta.__dataclass_fields__)},
    'p11_runtime_adapter':'BLOCKED_SOURCE_AFTER_LOSSLESS_MAPPING_NOT_ACCEPTED',
    'p21_real_atomic_commit':'BLOCKED_NOT_RECEIVED'}))
