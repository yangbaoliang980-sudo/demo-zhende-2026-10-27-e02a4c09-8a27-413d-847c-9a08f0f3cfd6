import random
from character_party_runtime import MetaPlanner,FrozenMessage,command,DomainError
from character_party_runtime.common import MAX_INTEGER,fingerprint
from tests.support.base import MetaCase
from tests.support.authority import TOKEN,CHARS,POLICY_SHA


class WalletTests(MetaCase):
    def test_missing_grant_port_fails_closed(self):
        closed=MetaPlanner(self.catalog)
        result=closed.plan(self.request('APPLY_GRANT',{'grant_ref':'fixture:missing'}),self.model.snapshot())
        self.assertEqual((result.status,result.reason),('BLOCKED','E_GRANT_EVIDENCE_UNBOUND'))

    def test_payload_cannot_self_declare_trusted_reward(self):
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:x','trusted':True,'amount':1000},'E_SHAPE')

    def test_learning_reward_from_resolved_p11_fixture(self):
        self.grant('fixture:study',kind='STUDY',amount=10)
        self.assertEqual(self.balance(),10)
        source=self.model.snapshot().value['wallet']['lots'][0]['source']
        self.assertEqual(source['source_kind'],'STUDY')

    def test_learning_issuer_mismatch(self):
        msg=self.authority.grant('fixture:study',kind='STUDY',amount=10).value;msg['issuer']='P18'
        self.authority.grants['fixture:study']=FrozenMessage.from_value(msg)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:study'},'E_GRANT_ISSUER')

    def test_grant_profile_mismatch(self):
        self.authority.grant('fixture:foreign',amount=10,profile='fixture:other')
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:foreign'},'E_BENEFICIARY_MISMATCH')

    def test_first_clear_cannot_regrant_with_new_delivery_reference(self):
        self.grant('fixture:clear-one',kind='STAGE_FIRST_CLEAR',amount=5)
        self.authority.grant('fixture:clear-two',kind='STAGE_FIRST_CLEAR',amount=5)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:clear-two'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')
        self.assertEqual(self.balance(),5)

    def test_first_clear_identity_rejects_battle_id(self):
        self.authority.grant('fixture:badclear',kind='STAGE_FIRST_CLEAR',amount=5,
            identity={'campaign_id':'fixture:campaign','stage_id':'fixture:stage','battle_id':'fixture:newbattle'})
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:badclear'},'E_SHAPE')

    def test_repeat_battle_receipt_cannot_be_claimed_twice(self):
        ident={'campaign_id':'fixture:campaign','stage_id':'fixture:stage','battle_id':'fixture:battle'}
        self.grant('fixture:repeat-one',amount=5,identity=ident)
        self.authority.grant('fixture:repeat-two',amount=5,identity=ident)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:repeat-two'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')

    def test_new_repeat_battle_can_credit_separately(self):
        self.grant('fixture:battle-one',amount=5);self.grant('fixture:battle-two',amount=5)
        self.assertEqual(self.balance(),10)

    def test_same_entitlement_different_amount_collides(self):
        self.grant('fixture:clear-one',kind='STAGE_FIRST_CLEAR',amount=5)
        self.authority.grant('fixture:clear-two',kind='STAGE_FIRST_CLEAR',amount=6)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:clear-two'},'E_ENTITLEMENT_COLLISION')

    def test_policy_change_does_not_reset_entitlement(self):
        self.grant('fixture:clear-one',kind='STAGE_FIRST_CLEAR',amount=5)
        self.authority.grant('fixture:clear-two',kind='STAGE_FIRST_CLEAR',amount=5,policy_sha=fingerprint('another-policy'))
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:clear-two'},'E_ENTITLEMENT_COLLISION')

    def test_source_domains_are_separate(self):
        self.grant('fixture:first',kind='STAGE_FIRST_CLEAR',amount=5)
        self.grant('fixture:repeat',amount=3);self.grant('fixture:study',kind='STUDY',amount=2)
        self.assertEqual(self.balance(),10)
        self.assertEqual({l['source']['source_kind'] for l in self.model.snapshot().value['wallet']['lots']},
                         {'STUDY','STAGE_FIRST_CLEAR','STAGE_REPEAT'})

    def test_negative_credit_rejected(self):
        self.authority.grant('fixture:negative',resources=[{'resource_id':TOKEN,'amount':-1}])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:negative'},'E_INTEGER')

    def test_boolean_credit_rejected(self):
        self.authority.grant('fixture:bool',resources=[{'resource_id':TOKEN,'amount':True}])
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:bool'},'E_INTEGER')

    def test_duplicate_resource_credit_rejected(self):
        self.authority.grant('fixture:duplicate',resources=[{'resource_id':TOKEN,'amount':1}]*2)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:duplicate'},'E_RESOURCE_DUPLICATE')

    def test_aggregate_credit_overflow_is_atomic(self):
        self.grant('fixture:max',amount=MAX_INTEGER)
        self.authority.grant('fixture:overflow',amount=1)
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:overflow'},'E_INTEGER_OVERFLOW')

    def test_reserve_capture_once(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',7)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.assertEqual(self.balance(),3)
        self.assertEqual(self.planner.wallet_snapshot(self.model.snapshot()).value['balances'][0]['reserved'],7)
        self.apply('CAPTURE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.assertEqual(self.balance(),3)
        self.reject('CAPTURE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')

    def test_release_restores_exact_source(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',7)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.apply('RELEASE',{'reservation_id':'fixture:r'});self.assertEqual(self.balance(),10)
        self.reject('RELEASE',{'reservation_id':'fixture:r'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')

    def test_release_captured_rejected(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',7)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.apply('CAPTURE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.reject('RELEASE',{'reservation_id':'fixture:r'},'E_RESERVATION_NOT_ACTIVE')

    def test_capture_released_rejected(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',7)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.apply('RELEASE',{'reservation_id':'fixture:r'})
        self.reject('CAPTURE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'},'E_RESERVATION_NOT_ACTIVE')

    def test_reservation_cannot_change_purpose(self):
        self.grant(amount=10);self.authority.quote('fixture:a',7);self.authority.quote('fixture:b',7)
        self.apply('RESERVE',{'quote_ref':'fixture:a','reservation_id':'fixture:r'})
        self.reject('CAPTURE',{'quote_ref':'fixture:b','reservation_id':'fixture:r'},'E_RESERVATION_BINDING')

    def test_reserved_materials_cannot_fund_upgrade(self):
        self.seed(amount=5);self.authority.quote('fixture:cost',2)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.reject('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},'E_WALLET_INSUFFICIENT')

    def test_duplicate_reservation_id(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',2)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.reject('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'},'E_RESERVATION_ID_REUSED')

    def test_one_purpose_cannot_hold_two_reservations(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',2)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r1'})
        self.reject('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r2'},'E_PURPOSE_ALREADY_RESERVED')

    def test_direct_spend_cannot_bypass_reservation(self):
        self.grant(amount=10);self.authority.quote('fixture:cost',2)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r1'})
        self.reject('SPEND',{'quote_ref':'fixture:cost'},'E_PURPOSE_ALREADY_RESERVED')

    def test_spend_consumption_key_once_across_references(self):
        self.grant(amount=10);self.authority.quote('fixture:a',2,purpose='fixture:one-entry')
        self.authority.quote('fixture:b',2,purpose='fixture:one-entry')
        self.apply('SPEND',{'quote_ref':'fixture:a'})
        self.reject('SPEND',{'quote_ref':'fixture:b'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')
        self.assertEqual(self.balance(),8)

    def test_spend_same_identity_changed_cost_rejected(self):
        self.grant(amount=10);self.authority.quote('fixture:a',2,purpose='fixture:one-entry')
        self.authority.quote('fixture:b',3,purpose='fixture:one-entry');self.apply('SPEND',{'quote_ref':'fixture:a'})
        self.reject('SPEND',{'quote_ref':'fixture:b'},'E_CONSUMPTION_COLLISION')

    def test_multi_resource_insufficiency_keeps_every_resource(self):
        self.grant(resources=[{'resource_id':TOKEN,'amount':10},{'resource_id':'TEST_GEM','amount':1}])
        self.authority.quote('fixture:two',resources=[{'resource_id':TOKEN,'amount':5},{'resource_id':'TEST_GEM','amount':2}])
        self.reject('SPEND',{'quote_ref':'fixture:two'},'E_WALLET_INSUFFICIENT')

    def test_deterministic_oldest_source_first(self):
        self.grant('fixture:older',amount=3);self.grant('fixture:newer',amount=5)
        self.authority.quote('fixture:spend',5);self.apply('SPEND',{'quote_ref':'fixture:spend'})
        lots=sorted(self.model.snapshot().value['wallet']['lots'],key=lambda x:x['created_revision'])
        self.assertEqual([(x['available'],x['spent']) for x in lots],[(0,3),(3,2)])

    def test_full_unspent_study_revoke(self):
        self.grant('fixture:study',kind='STUDY',amount=10);self.authority.reversal('fixture:undo','fixture:study')
        self.apply('REVOKE_STUDY',{'reversal_ref':'fixture:undo'});self.assertEqual(self.balance(),0)
        self.reject('REVOKE_STUDY',{'reversal_ref':'fixture:undo'},'DUPLICATE_ENTITLEMENT_NO_OP','DUPLICATE_NO_OP')

    def test_spent_study_revoke_blocks_without_debt(self):
        self.grant('fixture:study',kind='STUDY',amount=10);self.authority.quote('fixture:spend',4)
        self.apply('SPEND',{'quote_ref':'fixture:spend'});self.authority.reversal('fixture:undo','fixture:study')
        self.reject('REVOKE_STUDY',{'reversal_ref':'fixture:undo'},'E_RECONCILIATION_REQUIRED','BLOCKED')
        self.assertEqual(self.balance(),6)

    def test_reserved_study_revoke_blocks_until_release(self):
        self.grant('fixture:study',kind='STUDY',amount=10);self.authority.quote('fixture:cost',4)
        self.apply('RESERVE',{'quote_ref':'fixture:cost','reservation_id':'fixture:r'})
        self.authority.reversal('fixture:undo','fixture:study')
        self.reject('REVOKE_STUDY',{'reversal_ref':'fixture:undo'},'E_RECONCILIATION_REQUIRED','BLOCKED')
        self.apply('RELEASE',{'reservation_id':'fixture:r'});self.apply('REVOKE_STUDY',{'reversal_ref':'fixture:undo'})
        self.assertEqual(self.balance(),0)

    def test_revoke_never_uses_another_source_to_pay_shortfall(self):
        self.grant('fixture:study',kind='STUDY',amount=5);self.authority.quote('fixture:spend',5)
        self.apply('SPEND',{'quote_ref':'fixture:spend'});self.grant('fixture:stage',amount=50)
        self.authority.reversal('fixture:undo','fixture:study')
        self.reject('REVOKE_STUDY',{'reversal_ref':'fixture:undo'},'E_RECONCILIATION_REQUIRED','BLOCKED')
        self.assertEqual(self.balance(),50)

    def test_unapproved_restore_cannot_recredit_revoked_family(self):
        self.grant('fixture:study',kind='STUDY',amount=5);self.authority.reversal('fixture:undo','fixture:study')
        self.apply('REVOKE_STUDY',{'reversal_ref':'fixture:undo'})
        self.reject('APPLY_GRANT',{'grant_ref':'fixture:study'},'E_REVOKED_ENTITLEMENT_REGRANT_BLOCKED')

    def test_reversal_policy_must_match_original(self):
        self.grant('fixture:study',kind='STUDY',amount=5);r=self.authority.reversal('fixture:undo','fixture:study').value
        r['policy_sha256']=fingerprint('changed-policy');self.authority.reversals['fixture:undo']=FrozenMessage.from_value(r)
        self.reject('REVOKE_STUDY',{'reversal_ref':'fixture:undo'},'E_HISTORICAL_POLICY_MISMATCH')

    def test_fixed_seed_sequence_conserves_every_source(self):
        rng=random.Random(1701);self.grant(amount=80)
        for index in range(45):
            amount=rng.randrange(1,8);ref='fixture:random-'+str(index)
            if rng.randrange(3)==0:self.grant(ref,amount=amount)
            else:
                self.authority.quote(ref,amount)
                if amount>self.balance():self.reject('SPEND',{'quote_ref':ref},'E_WALLET_INSUFFICIENT')
                else:self.apply('SPEND',{'quote_ref':ref})
            for lot in self.model.snapshot().value['wallet']['lots']:
                self.assertEqual(lot['quantity'],sum(lot[k] for k in ('available','reserved','spent','revoked')))
                self.assertGreaterEqual(lot['available'],0)
        self.model.reload()
