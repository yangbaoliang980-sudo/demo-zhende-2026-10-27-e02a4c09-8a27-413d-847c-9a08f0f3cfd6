"""Test-only P11/P18 input registries; these do not establish real eligibility."""
from character_party_runtime.common import FrozenMessage,GRANT_VERSION,QUOTE_VERSION,fingerprint

TOKEN='MOCK_P04_TRAINING_TOKEN'
CHARS=['MOCK_P04_CHAR_001','MOCK_P04_CHAR_002','MOCK_P04_CHAR_003']
POLICY_SHA=fingerprint('P17_SYNTHETIC_TEST_POLICY_NOT_USER_APPROVAL')


class FixtureAuthority:
    def __init__(self):
        self.grants={};self.quotes={};self.reversals={}

    def resolve_grant(self,ref):return self.grants.get(ref)
    def resolve_quote(self,ref):return self.quotes.get(ref)
    def resolve_reversal(self,ref):return self.reversals.get(ref)

    def grant(self,ref,*,amount=0,resources=None,characters=None,xp=None,equipment=None,
              kind='STAGE_REPEAT',identity=None,profile='fixture:player',policy_sha=POLICY_SHA):
        if identity is None:
            identity=({'source_id':'fixture:anki','collection_lineage':'fixture:lineage','family_id':ref}
                      if kind=='STUDY' else {'campaign_id':'fixture:campaign','stage_id':'fixture:stage',
                      **({'battle_id':ref} if kind=='STAGE_REPEAT' else {})})
        rows=resources if resources is not None else ([{'resource_id':TOKEN,'amount':amount}] if amount else [])
        g={'schema_version':GRANT_VERSION,'grant_ref':ref,'issuer':'P11' if kind=='STUDY' else 'P18',
           'profile_id':profile,'source_kind':kind,'identity':identity,'eligibility_ref':'fixture:not-real-proof',
           'policy_version':'fixture:policy-v1','policy_sha256':policy_sha,'resources':rows,
           'characters':characters or [],'xp':xp or [],'equipment':equipment or []}
        msg=FrozenMessage.from_value(g);self.grants[ref]=msg;return msg

    def quote(self,ref,amount=1,*,resources=None,purpose=None,profile='fixture:player'):
        q={'schema_version':QUOTE_VERSION,'quote_ref':ref,'issuer':'P18','profile_id':profile,
           'purpose_key':purpose or ref,'eligibility_ref':'fixture:not-real-proof',
           'policy_version':'fixture:cost-v1','policy_sha256':POLICY_SHA,
           'resources':resources if resources is not None else [{'resource_id':TOKEN,'amount':amount}]}
        msg=FrozenMessage.from_value(q);self.quotes[ref]=msg;return msg

    def reversal(self,ref,grant_ref):
        g=self.grants[grant_ref].value
        r={'schema_version':'P17-REVERSAL-INPUT/0.1.0-proposal','reversal_ref':ref,'issuer':'P11',
           'profile_id':g['profile_id'],'identity':g['identity'],
           'policy_sha256':g['policy_sha256'],'eligibility_ref':'fixture:not-real-proof'}
        msg=FrozenMessage.from_value(r);self.reversals[ref]=msg;return msg

