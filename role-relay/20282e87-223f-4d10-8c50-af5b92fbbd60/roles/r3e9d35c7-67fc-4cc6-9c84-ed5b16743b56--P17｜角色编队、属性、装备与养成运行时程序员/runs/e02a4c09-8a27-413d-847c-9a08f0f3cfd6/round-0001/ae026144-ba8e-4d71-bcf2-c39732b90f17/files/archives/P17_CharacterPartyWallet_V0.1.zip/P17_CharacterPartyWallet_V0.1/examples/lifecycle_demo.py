"""Execute the original P04 input and preserve every real planner output."""
import json
from character_party_runtime import MetaPlanner,load_catalog,empty_state,command,atomic_proposal
from character_party_runtime._upstream import PACKAGE_ROOT
from tests.support.authority import FixtureAuthority,TOKEN
from tests.support.atomic_memory_model import AtomicMemoryModel


def run_demo():
    catalog=load_catalog();authority=FixtureAuthority();planner=MetaPlanner(catalog,authority)
    model=AtomicMemoryModel(planner,empty_state(catalog));trace=[]
    f=json.loads((PACKAGE_ROOT/'sources/P04/content/characters/character_lifecycle_fixtures.json').read_text())
    for entry in f['commands']:
        action=entry['action'];evidence=None
        if action in ('ACQUIRE','GRANT_TOKEN','GRANT_XP'):
            kwargs=({'characters':[entry['target']]} if action=='ACQUIRE' else
                    {'amount':entry['delta']} if action=='GRANT_TOKEN' else
                    {'xp':[{'character_id':entry['target'],'amount':entry['delta']}]})
            evidence=authority.grant(entry['event_identity'],**kwargs)
            kind,payload='APPLY_GRANT',{'grant_ref':entry['event_identity']}
        elif action=='SET_PARTY':kind,payload='SET_PARTY',{'ordered_character_ids':entry['ordered_ids']}
        elif action=='UPGRADE_LEVEL':
            kind,payload='LEVEL_UP',{'character_id':entry['target'],'from_rank':entry['from_level'],'to_rank':entry['to_level']}
        else:
            assert action=='SERIALIZE_JSON_ROUNDTRIP_ASSERT';before=model.snapshot();after=model.reload()
            assert before.raw==after.raw
            trace.append({'source_command':entry,'reload_sha256':after.sha256,'method':'IN_MEMORY_BYTES_ROUNDTRIP'})
            continue
        before=model.snapshot();request=command(before,entry['command_id'],kind,payload)
        outcome=planner.plan(request,before);assert outcome.status=='CANDIDATE',outcome.reason
        candidate=outcome.candidate
        receipt=model.submit(candidate,synthetic_counterpart=True)
        trace.append({'source_command':entry,'request':request.value,'request_sha256':request.sha256,
            'evidence':None if evidence is None else evidence.value,
            'candidate':candidate.value,'candidate_sha256':candidate.sha256,
            'p13_atomic_projection':atomic_proposal(candidate).value if candidate.value['required_counterpart_owner'] is None else None,
            'model_receipt':receipt})
    final=model.snapshot();state=final.value;full=planner.party_export(final);wire=planner.party_snapshot(final)
    projection={'owned_character_ids':[c['character_id'] for c in state['characters']],
        'party_ordered_ids':state['party_slots'],
        'character_progress':{c['character_id']:{k:c[k] for k in ('level','xp_total','skill_rank')} for c in state['characters']},
        'wallet':{r['resource_id']:r['available'] for r in planner.wallet_snapshot(final).value['balances']},'revision':state['revision']}
    assert projection==f['expected_after_mutations_before_serialization']
    assert {m['character_id']:m['stats'] for m in full.value['members']}==f['derived_stats_after']
    # Exact same command is retried after reload, with original expected_revision.
    last=trace[-2];retry=planner.plan(command_from_value(last['request']),final)
    assert retry.status=='DUPLICATE_NO_OP';assert model.snapshot().raw==final.raw
    return {'scope':'P17_ISOLATED_EXECUTION_WITH_SYNTHETIC_P11_P18_AND_IN_MEMORY_P21_MODEL',
        'production_commit':'BLOCKED','durable':False,'catalog_sha256':catalog.sha256,
        'steps':trace,'final_state':state,'final_state_sha256':final.sha256,
        'party_export':full.value,'p13_party_snapshot':wire.value,'p13_wallet_snapshot':planner.wallet_snapshot(final).value,
        'p04_projection':projection,'source_expectations_match':True,
        'retry_status':retry.status,'summary':{'committed_simulation_transactions':len(model.receipts),
            'available_training_tokens':projection['wallet'][TOKEN],
            'character_levels':[c['level'] for c in state['characters']],
            'wallet_revision':state['wallet_revision'],'meta_revision':state['revision']}}


def command_from_value(value):
    from character_party_runtime import FrozenMessage
    return FrozenMessage.from_value(value)


if __name__=='__main__':
    print(json.dumps(run_demo(),ensure_ascii=False,indent=2))
