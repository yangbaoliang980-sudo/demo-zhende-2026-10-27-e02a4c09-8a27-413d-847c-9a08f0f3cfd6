"""Explicitly synthetic example workflows; no production composition root."""
