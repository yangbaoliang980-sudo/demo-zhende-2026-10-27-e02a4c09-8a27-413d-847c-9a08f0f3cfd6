"""Isolated author verification."""
