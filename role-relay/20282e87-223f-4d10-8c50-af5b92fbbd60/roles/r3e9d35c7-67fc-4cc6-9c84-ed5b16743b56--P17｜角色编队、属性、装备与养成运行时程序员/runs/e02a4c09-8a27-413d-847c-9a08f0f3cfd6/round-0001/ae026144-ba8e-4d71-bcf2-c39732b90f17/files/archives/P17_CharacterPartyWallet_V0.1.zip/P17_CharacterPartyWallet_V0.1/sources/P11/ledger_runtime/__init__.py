"""P11 business implementation; all integration ports remain proposals.

No Anki, wallet storage, IPC, or game save adapter is included here.
"""
from .service import StudyLedger
from .types import LedgerStatus

__version__ = '0.1.0-isolated'
__all__ = ['StudyLedger', 'LedgerStatus']
