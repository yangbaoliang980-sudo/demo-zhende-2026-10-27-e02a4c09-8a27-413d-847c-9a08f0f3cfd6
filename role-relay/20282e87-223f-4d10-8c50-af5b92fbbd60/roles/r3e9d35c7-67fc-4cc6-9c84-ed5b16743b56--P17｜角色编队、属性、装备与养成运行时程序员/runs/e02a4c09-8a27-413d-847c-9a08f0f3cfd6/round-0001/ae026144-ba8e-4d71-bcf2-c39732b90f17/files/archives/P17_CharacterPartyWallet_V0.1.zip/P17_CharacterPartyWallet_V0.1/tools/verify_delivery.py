"""Read-only byte verification. The manifest itself is bound by the outer receipt."""
from pathlib import Path,PurePosixPath
import sys,json,csv,hashlib
ROOT=Path(__file__).resolve().parents[1]

def h(path):return hashlib.sha256(path.read_bytes()).hexdigest()

rows=list(csv.DictReader((ROOT/'delivery_manifest.sha256.tsv').open(encoding='utf-8'),delimiter='\t'))
paths=[]
for row in rows:
    rel=PurePosixPath(row['relative_path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    p=ROOT.joinpath(*rel.parts);assert p.is_file() and not p.is_symlink(),str(rel)
    assert p.stat().st_size==int(row['size_bytes']) and h(p)==row['sha256'],str(rel)
    paths.append(str(rel))
assert len(paths)==len(set(paths)),'DUPLICATE_MANIFEST_PATH'
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==set(paths)|{'delivery_manifest.sha256.tsv'},'UNLISTED_OR_MISSING_PACKAGE_FILE'
source=json.loads((ROOT/'source_input_receipt.json').read_text())
for row in source['upstream_files']+[source['v6_roles']]:
    p=ROOT/row['package_relative_path']
    assert p.stat().st_size==row['size_bytes'] and h(p)==row['sha256'],str(p)
binding=json.loads((ROOT/'evidence/final_executed_source_binding.json').read_text())
for row in binding['files']:
    assert h(ROOT/row['relative_path'])==row['sha256'],row['relative_path']
print(json.dumps({'status':'PASS','manifest_entries':len(rows),
    'package_file_count':len(actual),'upstream_originals_verified':len(source['upstream_files'])+1,
    'executed_source_bindings':len(binding['files']),'scope':'LOCAL_BYTES_NOT_P35_ACCEPTANCE'}))
