"""P17 author tests; not P32 independent acceptance."""
