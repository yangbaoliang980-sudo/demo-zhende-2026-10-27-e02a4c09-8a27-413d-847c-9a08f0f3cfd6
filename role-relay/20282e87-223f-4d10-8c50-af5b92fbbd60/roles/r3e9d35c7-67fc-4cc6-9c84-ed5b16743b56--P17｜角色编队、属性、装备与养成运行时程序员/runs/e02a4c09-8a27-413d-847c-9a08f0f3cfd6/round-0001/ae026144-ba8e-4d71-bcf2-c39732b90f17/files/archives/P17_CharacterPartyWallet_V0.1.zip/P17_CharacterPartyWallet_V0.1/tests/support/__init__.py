"""Explicitly synthetic collaborators. Never production providers."""
