"""Capture an actual subprocess run and the exact source bytes it executed."""
from pathlib import Path
import sys,json,hashlib,subprocess,datetime,zipfile,os
ROOT=Path(__file__).resolve().parents[1]

def main():
    if len(sys.argv)<3:raise SystemExit('record_run.py RUN_NAME COMMAND ...')
    name=sys.argv[1]
    if not name.replace('_','').isalnum():raise SystemExit('invalid run name')
    dest=ROOT/'evidence/runs'/name;dest.mkdir(parents=True,exist_ok=False)
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or any(x in p.relative_to(ROOT).parts for x in ('evidence','__pycache__')):continue
        if p.suffix not in ('.py','.json','.tsv'):continue
        b=p.read_bytes();files.append({'path':p.relative_to(ROOT).as_posix(),'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    (dest/'source_hashes.json').write_text(json.dumps(files,indent=2)+'\n')
    with zipfile.ZipFile(dest/'executed_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
        for e in files:z.write(ROOT/e['path'],e['path'])
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    cmd=sys.argv[2:]
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    run=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True)
    (dest/'stdout.log').write_bytes(run.stdout);(dest/'stderr.log').write_bytes(run.stderr)
    receipt={'command':cmd,'cwd':str(ROOT),'started_utc':started,
        'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':run.returncode,
        'stdout_sha256':hashlib.sha256(run.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(run.stderr).hexdigest(),
        'python_version':sys.version,'evidence_scope':'P17_AUTHOR_EXECUTION_NOT_INDEPENDENT_ACCEPTANCE'}
    (dest/'run_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'run':name,'exit_code':run.returncode,'stdout':run.stdout.decode(errors='replace')[-2000:],
                      'stderr_tail':run.stderr.decode(errors='replace')[-4500:]},ensure_ascii=False))
    return run.returncode

if __name__=='__main__':raise SystemExit(main())

