from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from examples.lifecycle_demo import run_demo
from character_party_runtime.common import canonical,fingerprint

actual=run_demo();expected=json.loads((ROOT/'examples/lifecycle_execution.json').read_text())
assert canonical(actual)==canonical(expected),'DEMO_REPLAY_MISMATCH'
print(json.dumps({'status':'PASS','scope':'P17_AUTHOR_REPLAY','execution_sha256':fingerprint(actual),'summary':actual['summary']}))
