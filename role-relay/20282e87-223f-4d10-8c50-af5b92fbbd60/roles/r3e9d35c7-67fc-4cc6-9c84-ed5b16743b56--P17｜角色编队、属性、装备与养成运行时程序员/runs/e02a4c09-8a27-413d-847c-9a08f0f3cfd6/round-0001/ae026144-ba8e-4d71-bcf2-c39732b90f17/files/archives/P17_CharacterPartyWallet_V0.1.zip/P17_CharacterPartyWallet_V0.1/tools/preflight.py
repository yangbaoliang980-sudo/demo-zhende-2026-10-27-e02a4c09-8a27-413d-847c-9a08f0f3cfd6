from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parents[1]
mapping=json.loads((ROOT/'sources/P13/architecture/actual_path_mapping.json').read_text())
paths=[x for x in mapping['mappings'] if x['owner']=='P17']
blockers=json.loads((ROOT/'blockers.json').read_text())['items']
print(json.dumps({'status':'BLOCKED','production_bootstrap_implemented':False,
    'p17_mappings':[{k:p.get(k) for k in ('design_path','actual_production_path','write_allowed')} for p in paths],
    'blocking_items':[{'id':b['id'],'owner':b['owner'],'condition':b['missing']} for b in blockers],
    'target_engine_run':'NOT_RUN','windows_run':'NOT_RUN','anki_e2e':'NOT_RUN',
    'independent_acceptance':'NOT_RUN'},ensure_ascii=False,indent=2))
raise SystemExit(3)
