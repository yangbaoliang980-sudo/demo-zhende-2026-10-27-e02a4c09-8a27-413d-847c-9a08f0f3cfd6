#!/usr/bin/env python3
"""Controlled corruption checks in a disposable COPY; never writes to the supplied root."""
import argparse,csv,datetime,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from PIL import Image

def writej(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root):ap.error('output must be new and outside root')
    out.mkdir(parents=True);copy=out/'disposable_fixture';shutil.copytree(root,copy);records=[]
    def case(name,path,mutate,expected):
        p=copy/path;old=p.read_bytes();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        try:
            mutate(p);log=out/name
            cmd=[sys.executable,'-B',str(copy/'validation/validate_p25.py'),'--root',str(copy),'--output',str(log)]
            r=subprocess.run(cmd,capture_output=True,text=True);data=json.loads((log/'validation_results.json').read_text());failed=[x['id'] for x in data['checks'] if x['status']=='FAIL']
            ok=r.returncode==2 and expected in failed
            (log/'stdout.txt').write_text(r.stdout);(log/'stderr.txt').write_text(r.stderr)
            records.append({'id':name,'status':'PASS' if ok else 'FAIL','expectation':'validator rejects corruption; not an art-quality PASS','mutation_path':path,'base_sha256':hashlib.sha256(old).hexdigest(),'mutated_sha256':sha(p) if p.exists() else None,'expected_failed_check':expected,'actual_failed_checks':failed,'actual_exit_code':r.returncode,'command':cmd,'started_utc':start})
        finally:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(old)
    case('N01_tampered_bible','art_direction/style_bible.md',lambda p:p.write_bytes(p.read_bytes()+b'\nCORRUPTED\n'),'P25-V02_DELIVERY_INTEGRITY')
    png='asset_visual_reviews/evidence/upstream/P24/art/ui/exports/1x/placeholder_ui_button_primary_default@1x.png'
    case('N02_missing_export',png,lambda p:p.unlink(),'P25-V06_PNG_DIMENSION_ALPHA')
    def escape(p):
        x=json.loads(p.read_text());x['files'][0]['relative_path']='../outside_scope.txt';writej(p,x)
    case('N03_path_escape','delivery_manifest.json',escape,'P25-V02_DELIVERY_INTEGRITY')
    def badcrop(p):
        x=json.loads(p.read_text());x['profiles'][0]['mandatory_subject_rect_px']=[2000,123,1844,2765];writej(p,x)
    case('N04_outside_crop','art_direction/crop_profiles.json',badcrop,'P25-V09_CROP_BOUNDS')
    def rgb(p):
        with Image.open(p) as im:c=im.convert('RGB')
        c.save(p,format='PNG')
    case('N05_lost_alpha',png,rgb,'P25-V06_PNG_DIMENSION_ALPHA')
    def promote(p):
        x=json.loads(p.read_text());x['assets'][0]['production_allowed']=True;x['assets'][0]['lifecycle']='PRODUCTION';writej(p,x)
    case('N06_placeholder_promoted','asset_visual_reviews/evidence/upstream/P24/ui_visual_export_manifest.json',promote,'P25-V08_NO_PLACEHOLDER_PROMOTION')
    def fakepass(p):
        with p.open(newline='') as f:rr=list(csv.DictReader(f,delimiter='\t'))
        rr[0]['p25_review_status']='PASS'
        with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rr[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rr)
    case('N07_fabricated_sample_pass','art_direction/sample_acceptance.tsv',fakepass,'P25-V10_SAMPLE_EVIDENCE_TRUTH')
    def blank(p):Image.new('RGB',(1600,1770),(32,37,53)).save(p)
    case('N08_blank_contact_sheet','asset_visual_reviews/boards/P25_P24_Contact_01.png',blank,'P25-V12_VISIBLE_CONTACT_CELLS')
    # A named candidate referencing the real empty ORA must be rejected, regardless of claimed identity.
    sub=json.loads((copy/'art_direction/sample_submission_template.json').read_text());source=copy/'art_direction/templates/character_source_template.ora'
    sub.update(lifecycle='CANDIDATE',sample_id='test.candidate',character_id='test.character');sub['source'].update(path=str(source.relative_to(copy)),sha256=sha(source),size_bytes=source.stat().st_size,format='ORA')
    submission=out/'blank_template_as_candidate.json';writej(submission,sub);log=out/'N09_empty_template_as_character'
    cmd=[sys.executable,'-B',str(copy/'validation/inspect_sample.py'),'--root',str(copy),'--submission',str(submission),'--base',str(copy),'--output',str(log)]
    r=subprocess.run(cmd,capture_output=True,text=True);data=json.loads((log/'sample_inspection_results.json').read_text());failed=[x['id'] for x in data['checks'] if x['status']=='FAIL'];ok=r.returncode==2 and 'SOURCE_NOT_EMPTY_TEMPLATE' in failed
    (log/'stdout.txt').write_text(r.stdout);(log/'stderr.txt').write_text(r.stderr)
    records.append({'id':'N09_empty_template_as_character','status':'PASS' if ok else 'FAIL','expectation':'reject empty ORA as a real character','expected_failed_check':'SOURCE_NOT_EMPTY_TEMPLATE','actual_failed_checks':failed,'actual_exit_code':r.returncode,'command':cmd,'submission_sha256':sha(submission)})
    result={'layer':'P25_AUTHOR_NEGATIVE_VALIDATION','status':'PASS' if all(r['status']=='PASS' for r in records) else 'FAIL','tool_sha256':sha(Path(__file__)),'records':records,'passed':sum(r['status']=='PASS' for r in records),'failed':sum(r['status']=='FAIL' for r in records),'fixture_copy_retained_outside_package':str(copy),'game_runtime_executed':False}
    writej(out/'negative_results.json',result);print(json.dumps({k:result[k] for k in ('status','passed','failed')}));sys.exit(0 if result['status']=='PASS' else 2)
if __name__=='__main__':main()
