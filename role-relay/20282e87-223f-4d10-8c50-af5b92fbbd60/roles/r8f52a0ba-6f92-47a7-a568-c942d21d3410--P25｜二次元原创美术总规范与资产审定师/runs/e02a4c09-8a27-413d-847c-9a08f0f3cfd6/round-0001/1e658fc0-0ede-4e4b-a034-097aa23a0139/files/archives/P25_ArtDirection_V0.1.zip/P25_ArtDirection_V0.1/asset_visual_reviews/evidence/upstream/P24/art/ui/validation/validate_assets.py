"""P24 static artifact validation only. No engine, game, GitHub, or Anki calls."""
import argparse,copy,csv,datetime,hashlib,json,re,shutil,sys,tempfile
from pathlib import Path,PurePosixPath
import xml.etree.ElementTree as ET
from PIL import Image

ROOT=Path(__file__).resolve().parents[3]
NS='{http://www.w3.org/2000/svg}'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def path_in(root,rel):
    if not isinstance(rel,str) or not rel or '\\' in rel or ':' in rel:raise ValueError('PATH_OUTSIDE')
    q=PurePosixPath(rel)
    if q.is_absolute() or '..' in q.parts:raise ValueError('PATH_OUTSIDE')
    p=root/rel
    if not p.resolve().is_relative_to(root.resolve()) or any((root/Path(*q.parts[:i])).is_symlink() for i in range(1,len(q.parts)+1)):raise ValueError('PATH_OUTSIDE')
    return p
def ratio(fg,bg):
    def lum(c):
        a=[int(c[i:i+2],16)/255 for i in [1,3,5]]
        return sum(v*k for v,k in zip([x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in a],[.2126,.7152,.0722]))
    a,b=sorted([lum(fg),lum(bg)]);return (b+.05)/(a+.05)

def validate(root):
    errors=[];checks=[];counts={};group='initial'
    def err(code,item,details=''):errors.append({'check':group,'code':code,'item':str(item),'details':str(details),'repair_owner':'P24'})
    def ck(name,fn):
        nonlocal group
        group=name;before=len(errors)
        try:detail=fn()
        except Exception as e:err(str(e) if str(e)=='PATH_OUTSIDE' else 'VALIDATION_EXCEPTION',name,repr(e));detail=None
        checks.append({'id':name,'status':'PASS' if len(errors)==before else 'FAIL','detail':detail})
    cat=load(root/'art/ui/asset_catalog.json');assets=cat['assets'];byid={a['asset_id']:a for a in assets}
    def identity():
        ids=[a['asset_id'] for a in assets]
        if len(ids)!=len(set(ids)) or len(ids)!=len(set(x.casefold() for x in ids)):err('ID_DUP','asset_catalog')
        for a in assets:
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:/-]{0,159}',a['asset_id']):err('ID_SYNTAX',a['asset_id'])
        if len(assets)!=cat['asset_count']:err('COUNT_MISMATCH','asset_count')
        counts['assets']=len(assets);return len(assets)
    ck('V01_IDENTITY',identity)
    def lifecycle():
        for a in assets:
            if a.get('lifecycle')!='PLACEHOLDER' or a.get('production_allowed') is not False:err('PRODUCTION_FORBIDDEN',a['asset_id'])
            if not Path(a['source_relative_path']).name.startswith('placeholder_'):err('PLACEHOLDER_FILENAME',a['asset_id'])
        return 'All assets explicitly placeholder; no production promotion'
    ck('V02_PLACEHOLDER_GUARD',lifecycle)
    def svg_sources():
        seen=[]
        for a in assets:
            try:p=path_in(root,a['source_relative_path'])
            except ValueError:err('PATH_OUTSIDE',a['asset_id']);continue
            seen.append(a['source_relative_path'])
            if not p.is_file():err('MISSING_SOURCE',a['asset_id']);continue
            rt=ET.parse(p).getroot()
            if [float(rt.get('width')),float(rt.get('height'))]!=a['logical_size']:err('SVG_SIZE',a['asset_id'])
            meta=json.loads(rt.find(NS+'metadata').text)
            for key in ['asset_id','logical_size','nine_slice_ltrb_1x','safe_rect_1x','reserved_rects_1x','production_allowed']:
                if meta.get(key)!=a.get(key):err('SOURCE_METADATA_MISMATCH',a['asset_id'],key)
            for e in rt.iter():
                if e.tag.split('}')[-1] in ['script','foreignObject','text','image','animate','set']:err('SVG_NOT_PURE_COMPONENT',a['asset_id'],e.tag)
                for k,v in e.attrib.items():
                    if k.lower().startswith('on') or ('href' in k and not v.startswith('#')):err('SVG_ACTIVE_OR_EXTERNAL',a['asset_id'],k)
        if len(seen)!=len(set(seen)):err('SOURCE_PATH_DUP','catalog')
        return len(seen)
    ck('V03_EDITABLE_SVG',svg_sources)
    def pngs():
        num=0;paths=[]
        for a in assets:
            if sorted(e['density'] for e in a['exports'])!=[1,2]:err('DENSITY_VARIANTS',a['asset_id'])
            for e in a['exports']:
                num+=1
                try:p=path_in(root,e['relative_path'])
                except ValueError:err('PATH_OUTSIDE',a['asset_id']);continue
                paths.append(e['relative_path'])
                try:
                    with Image.open(p) as im:
                        im.load()
                        if im.format!='PNG' or im.mode!='RGBA':err('ALPHA_RGBA',p,'expected PNG RGBA')
                        if list(im.size)!=[v*e['density'] for v in a['logical_size']]:err('PNG_SIZE',p)
                        if im.mode=='RGBA':
                            lo,hi=im.getchannel('A').getextrema()
                            if lo==255 or hi==0:err('ALPHA_RANGE',p,[lo,hi])
                except Exception as ex:err('PNG_DECODE',p,ex)
        if len(paths)!=len(set(paths)):err('EXPORT_PATH_DUP','catalog')
        counts['component_pngs']=num;return num
    ck('V04_PNG_DIMENSION_ALPHA',pngs)
    def states():
        wanted={'default','hover','pressed','disabled','selected','error'}
        families=['button.primary','button.secondary','button.navigation','frame.hand','frame.enemy','cost.badge']
        for family in families:
            found={a['state'] for a in assets if a['family']==family}
            if not wanted<=found:err('STATES_INCOMPLETE',family,sorted(wanted-found))
        for family in ['focus.button','focus.hand','focus.enemy','focus.navigation']:
            if not any(a['family']==family and a['state']=='active' for a in assets):err('FOCUS_MISSING',family)
        matrix=list(csv.DictReader((root/'ui_asset_state_matrix.tsv').open(),delimiter='\t'));pairs=[(x['family'],x['visual_state']) for x in matrix]
        if len(pairs)!=len(set(pairs)):err('MATRIX_DUP','matrix')
        for row in matrix:
            if row['coverage'] in ['ASSET','COMPOSITE_OVERLAY'] and row['asset_id'] not in byid:err('MATRIX_DANGLING',row['asset_id'])
            if row['coverage']=='NOT_APPLICABLE' and not row['reason']:err('MATRIX_NO_REASON',row['family'])
        represented={x['asset_id'] for x in matrix if x['coverage']=='ASSET'}
        if represented!=set(byid):err('MATRIX_ASSET_COVERAGE','matrix')
        counts['matrix_rows']=len(matrix);return {'required_six_state_families':len(families),'matrix_rows':len(matrix)}
    ck('V05_STATE_COVERAGE',states)
    def geometry():
        for a in assets:
            w,hh=a['logical_size'];br=a['nine_slice_ltrb_1x']
            if br and (len(br)!=4 or min(br)<0 or br[0]+br[2]>w or br[1]+br[3]>hh):err('NINE_SLICE_RANGE',a['asset_id'])
            for rc in ([a['safe_rect_1x']] if a['safe_rect_1x'] else [])+a.get('reserved_rects_1x',[]):
                x,y,rw,rh=rc
                if x<0 or y<0 or rw<=0 or rh<=0 or x+rw>w or y+rh>hh:err('SAFE_RECT_RANGE',a['asset_id'],rc)
            if a['trim_allowed'] or a['rotate_atlas_allowed']:err('TRIM_ROTATE_NOT_ACCEPTED',a['asset_id'])
        return 'slice border / safe rect / reserved rect / no trim'
    ck('V06_GEOMETRY_METADATA',geometry)
    def source_receipts():
        rows=load(root/'source_input_receipt.json')['files']
        for x in rows:
            p=path_in(root,x['local_copy'])
            if not p.is_file() or p.stat().st_size!=x['size_bytes'] or sha(p)!=x['sha256']:err('INPUT_HASH_MISMATCH',x['source_id'])
        known={x['source_id']:x['sha256'] for x in rows}
        for a in assets:
            for x in a['source_input_hashes']:
                if known.get(x['source_id'])!=x['sha256']:err('SOURCE_REF_MISMATCH',a['asset_id'],x['source_id'])
        counts['source_receipts']=len(rows);return len(rows)
    ck('V07_FIXED_INPUT_HASHES',source_receipts)
    def bindings():
        doc=load(root/'art/ui/spec/p23_asset_binding_candidates.json');up=load(root/'art/ui/evidence/upstream/P23_STATES/ui_state_map.json')
        expected={(x['widget_id'],x['anchor_id']):x for x in up['widgets']}
        got={(x['widget_id'],x['anchor_id']):x for x in doc['bindings']}
        if got.keys()!=expected.keys():err('ANCHOR_ID_CHANGED','bindings')
        for k,x in got.items():
            if k not in expected:continue
            if x['upstream_states']!=expected[k]['states'] or x['source_field']!=expected[k].get('source_field') or x['changes_command_semantics']:err('BINDING_SEMANTICS_CHANGED',k)
            for fam in x['candidate_families']:
                if not any(a['family']==fam for a in assets):err('BINDING_FAMILY_MISSING',k,fam)
        if doc['source_ui_state_map_sha256']!=sha(root/'art/ui/evidence/upstream/P23_STATES/ui_state_map.json'):err('BINDING_SOURCE_HASH','bindings')
        return len(got)
    ck('V08_UPSTREAM_ANCHOR_BINDINGS',bindings)
    def sample_geometry():
        n=0
        for mapfile in (root/'art/ui/evidence/layout').glob('*_mapping.json'):
            m=load(mapfile);p=root/m['base_file'];src=ET.parse(p).getroot();dest=root/'art/ui/source/boards'/mapfile.name.replace('_mapping.json','.svg');view=ET.parse(dest).getroot()
            def controls(rt):
                return [(e.get('data-anchor-id'),*[float(e.get(k)) for k in ['x','y','width','height']]) for e in rt.iter() if e.get('data-control')=='true']
            if controls(src)!=controls(view):err('CONTROL_GEOMETRY_CHANGED',dest)
            def texts(rt):return [''.join(e.itertext()) for e in rt.iter(NS+'text') if 48<=float(e.get('y',0))<768]
            if texts(view)!=m['original_ui_strings']:err('UI_TEXT_CHANGED',dest)
            if m['source_sha256']!=sha(p) or m['interaction_changes']:err('LAYOUT_BASE_CHANGED',dest)
            n+=1
        return n
    ck('V09_SAMPLE_LAYOUT_TEXT',sample_geometry)
    def previews():
        num=0;items=load(root/'art/ui/preview_catalog.json')['items']
        for p in items:
            ET.parse(path_in(root,p['svg_relative_path']))
            for a in p['source_asset_ids']:
                if a not in byid:err('PREVIEW_ASSET_MISSING',p['preview_id'],a)
            for e in p['exports']:
                im=Image.open(path_in(root,e['relative_path']));im.load();wanted=[round(v*e['scale']) for v in p['board_size']]
                if list(im.size)!=wanted:err('PREVIEW_SIZE',e['relative_path'])
                num+=1
        counts['preview_boards']=len(items);counts['preview_pngs']=num;return {'boards':len(items),'pngs':num}
    ck('V10_PREVIEW_FILES',previews)
    def contrast():
        rows=load(root/'art/ui/spec/contrast_cases.json')['cases']
        for x in rows:
            if x['minimum'] not in [3,4.5] or ratio(x['fg'],x['bg'])<x['minimum']:err('CONTRAST_BELOW_TARGET',x['id'])
        counts['contrast_pairs']=len(rows);return len(rows)
    ck('V11_CONTRAST',contrast)
    def recorded_visual():
        q=load(root/'art/ui/evidence/visual_qa/visual_qa_results.json')
        if q['status']!='PASS' or q['missing_glyphs']:err('VISUAL_QA_NOT_PASS','visual_qa')
        for b in q['boards']:
            p=root/'art/ui/source/boards'/(b['preview_id']+'.svg')
            if sha(p)!=b['source_sha256']:err('VISUAL_QA_STALE',b['preview_id'])
        return {'text_nodes':q['text_node_count'],'nine_slice_cases':len(q['nine_slice_cases']),'scope':'recorded author QA, not independent runtime'}
    ck('V12_AUTHOR_VISUAL_EVIDENCE',recorded_visual)
    def render_evidence():
        n=0
        for typ in ['render_assets','render_boards']:
            doc=load(root/f'art/ui/evidence/{typ}/render_results.json')
            if doc['status']!='PASS' or doc['runtime_game_executed']:err('RENDER_EVIDENCE_INVALID',typ)
            for x in doc['cases']:
                p=path_in(root,x['relative_path'])
                if sha(p)!=x['sha256']:err('RENDER_EVIDENCE_STALE',x['relative_path'])
                if 'asset_id' in x:
                    a=byid.get(x['asset_id'])
                    if a and sha(path_in(root,a['source_relative_path']))!=x['source_sha256']:err('SOURCE_RENDER_STALE',x['asset_id'])
                n+=1
        return n
    ck('V13_RENDER_PROVENANCE',render_evidence)
    def export_manifest():
        doc=load(root/'ui_visual_export_manifest.json');entries=doc['assets']
        if {a['asset_id'] for a in entries}!=set(byid):err('EXPORT_MANIFEST_COVERAGE','export_manifest')
        for a in entries:
            if a['runtime_path'] is not None or a['import_version'] is not None or a['production_allowed']:err('PRODUCTION_FORBIDDEN',a['asset_id'])
            for f in [a['source']]+a['exports']:
                p=path_in(root,f['relative_path'])
                if not p.is_file() or p.stat().st_size!=f['size_bytes'] or sha(p)!=f['sha256']:err('HASH_MISMATCH',f['relative_path'])
        return len(entries)
    ck('V14_EXPORT_MANIFEST',export_manifest)
    def delivery_manifest():
        doc=load(root/'delivery_manifest.json');entries=doc['files'];paths=[x['relative_path'] for x in entries]
        actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name!='delivery_manifest.json'}
        if len(paths)!=len(set(paths)) or set(paths)!=actual:err('DELIVERY_FILE_SET','manifest',{'missing':sorted(actual-set(paths)),'extra':sorted(set(paths)-actual)})
        for f in entries:
            p=path_in(root,f['relative_path'])
            if not p.is_file() or p.stat().st_size!=f['size_bytes'] or sha(p)!=f['sha256']:err('HASH_MISMATCH',f['relative_path'])
            for key in ['format','version','owner','source_input_hashes','receivers','modification_allowlist']:
                if key not in f:err('MANIFEST_FIELD_MISSING',f['relative_path'],key)
        counts['manifest_files']=len(entries);return len(entries)
    ck('V15_DELIVERY_INTEGRITY',delivery_manifest)
    def ownership():
        allowed={'README.md','P24_delivery_report.md','source_input_receipt.json','actual_path_request.json','ui_asset_state_matrix.tsv','ui_visual_export_manifest.json','delivery_manifest.json','verification_status.json','blocker_register.json','interface_rfcs.json'}
        for p in root.rglob('*'):
            if not p.is_file():continue
            rel=str(p.relative_to(root))
            if not rel.startswith('art/ui/') and rel not in allowed:err('OWNERSHIP_SCOPE',rel)
        mapping=load(root/'actual_path_request.json')
        if mapping['production_write_authorized'] or mapping['actual_production_paths'] is not None:err('PRODUCTION_FORBIDDEN','path_request')
        proposal=load(root/'art/ui/spec/p30_import_proposal.json')
        if proposal['accepted'] or proposal['runtime_paths'] is not None:err('PRODUCTION_FORBIDDEN','import_proposal')
        return 'isolated P24 files; original snapshots read-only'
    ck('V16_OWNERSHIP_GATE',ownership)
    def html():
        t=(root/'art/ui/P24_preview_index.html').read_text()
        if re.search(r'<script|\bon\w+\s*=|https?://',t,re.I):err('HTML_NOT_OFFLINE_STATIC','index')
        for ref in re.findall(r'(?:href|src)="([^"]+)"',t):
            if ref.startswith('#'):continue
            p=(root/'art/ui'/ref).resolve()
            if not p.is_relative_to(root.resolve()) or not p.is_file():err('PREVIEW_LINK_MISSING',ref)
        return 'offline static image index'
    ck('V17_OFFLINE_INDEX',html)
    def evidence_boundaries():
        levels={x['layer']:x['status'] for x in load(root/'verification_status.json')['levels']}
        for k in ['P25_STYLE_REVIEW','P37_LICENSE_REVIEW','P30_ENGINE_IMPORT','GAME_UNIT_TESTS','GAME_RUNTIME_CONTRACT_TESTS','TARGET_OS_DPI_INPUT','ANKI_E2E','P32_INDEPENDENT_TEST','P35_ENGINEERING_RELEASE']:
            if levels.get(k)!='NOT_RUN':err('UNSUPPORTED_PASS',k)
        if levels.get('PRODUCTION_INTEGRATION_PREFLIGHT')!='BLOCKED':err('UNSUPPORTED_PASS','production_preflight')
        return 'author and independent / runtime evidence separated'
    ck('V18_EVIDENCE_BOUNDARIES',evidence_boundaries)
    return {'layer':'AUTHOR_STATIC_ASSET_VALIDATION','status':'PASS' if not errors else 'FAIL','checks':checks,'counts':counts,'errors':errors,'game_runtime_executed':False}

def negatives(root):
    cases=[('duplicate_id','ID_DUP'),('rgb_png','ALPHA_RGBA'),('wrong_size','PNG_SIZE'),('missing_state','STATES_INCOMPLETE'),('path_escape','PATH_OUTSIDE'),('promote_placeholder','PRODUCTION_FORBIDDEN'),('bad_slice','NINE_SLICE_RANGE'),('tampered_bytes','HASH_MISMATCH'),('low_contrast','CONTRAST_BELOW_TARGET')]
    results=[]
    for name,code in cases:
        with tempfile.TemporaryDirectory(prefix='p24-negative-') as td:
            test=Path(td)/'package';shutil.copytree(root,test)
            cp=test/'art/ui/asset_catalog.json';c=load(cp);a=c['assets'][0]
            if name=='duplicate_id':c['assets'][1]['asset_id']=a['asset_id']
            elif name=='missing_state':c['assets']=[x for x in c['assets'] if not (x['family']=='frame.hand' and x['state']=='error')]
            elif name=='path_escape':a['source_relative_path']='../outside.svg'
            elif name=='promote_placeholder':a['production_allowed']=True
            elif name=='bad_slice':a['nine_slice_ltrb_1x']=[999,18,24,18]
            elif name in ['rgb_png','wrong_size','tampered_bytes']:
                p=test/a['exports'][0]['relative_path']
                if name=='tampered_bytes':p.write_bytes(p.read_bytes()+b'INTENTIONAL_NEGATIVE_TEST')
                else:
                    im=Image.open(p)
                    im=(im.convert('RGB') if name=='rgb_png' else im.crop((0,0,im.width-1,im.height)))
                    im.save(p)
            elif name=='low_contrast':
                p=test/'art/ui/spec/contrast_cases.json';d=load(p);d['cases'][0]['fg']=d['cases'][0]['bg'];p.write_text(json.dumps(d))
            cp.write_text(json.dumps(c))
            result=validate(test);codes=sorted(set(e['code'] for e in result['errors']))
            results.append({'case':name,'expected_error':code,'observed_errors':codes,'status':'EXPECTED_REJECTION' if result['status']=='FAIL' and code in codes else 'FAIL'})
    return {'layer':'AUTHOR_NEGATIVE_STATIC_VALIDATOR_TESTS','cases':results,'status':'PASS' if all(x['status']=='EXPECTED_REJECTION' for x in results) else 'FAIL'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--output',type=Path,required=True);p.add_argument('--preflight',action='store_true');p.add_argument('--negative-tests',action='store_true');a=p.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root):p.error('Output must be new and outside the package')
    out.mkdir(parents=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        res=validate(root);code=0 if res['status']=='PASS' else 2
        (out/'validation_results.json').write_text(json.dumps(res,ensure_ascii=False,indent=2)+'\n')
        if a.negative_tests:
            neg=negatives(root);(out/'negative_results.json').write_text(json.dumps(neg,ensure_ascii=False,indent=2)+'\n')
            if neg['status']!='PASS':code=2
        if a.preflight:
            blockers=load(root/'blocker_register.json')['blockers'];gate={'status':'BLOCKED','static_status':res['status'],'production_allowed':False,'open_conditions':blockers}
            (out/'production_preflight.json').write_text(json.dumps(gate,ensure_ascii=False,indent=2)+'\n')
            if code==0:code=3
        print(json.dumps({'status':'BLOCKED' if code==3 else ('PASS' if code==0 else 'FAIL'),'static_checks':len(res['checks']),'passed_checks':sum(x['status']=='PASS' for x in res['checks']),'counts':res['counts'],'errors':res['errors'][:12]},ensure_ascii=False))
    except Exception as e:
        code=2;(out/'fatal_error.json').write_text(json.dumps({'status':'FAIL','error':repr(e)},ensure_ascii=False)+'\n');print(repr(e))
    (out/'execution_record.json').write_text(json.dumps({'layer':'P24_AUTHOR_STATIC_ONLY','argv':sys.argv,'cwd':str(Path.cwd()),'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'exit_code':code,'validator_sha256':sha(Path(__file__))},ensure_ascii=False,indent=2)+'\n')
    return code
if __name__=='__main__':raise SystemExit(main())
