# P25 复验工具说明

## 检查范围与退出码

`validate_p25.py` 检查交付文件、输入和 P24 快照的字节、105 项审查覆盖、210 个 PNG、透明孔、8 个裁切配置、42 项样本状态、7 对规范/联系表图、105 个非空切图格、349 个已测文字边界、ORA 容器、权限与审查层级。它不会调用游戏、Anki 或绘图软件，也不会代签审美和许可。

- `0`：所选静态技术检查 PASS。
- `2`：实际检查失败。结果 JSON 列出失败编号与原始错误。
- `3`：正式门禁或送审输入 BLOCKED；不能作为成功导入。

`--preflight` 仍会先检查全部文件；损坏优先返回 FAIL/2，未损坏但缺正式前提返回 BLOCKED/3。

每次输出目录须全新且在输入包外。禁止复验时修补原快照；修复应由文件 owner 形成新版本。

## 新角色送审格式

复制 `art_direction/sample_submission_template.json` 到 P26 的隔离样本目录，填入实际文件。`lifecycle` 由模板改为 `CANDIDATE`；不可先设为 PRODUCTION。所有路径相对 `--base`，拒绝绝对路径、`..` 与符号链接逃逸。

`source` 记录 `path`、`sha256`、`size_bytes`、`format`、`application`、`application_version`。`editable_open_evidence` 与 `layers_manifest` 各使用 `{ "path": "...", "size_bytes": 实数, "sha256": "真实64位值" }`，并提供软件实际打开、切层和局部修改后的图片/记录。检查器只绑定证据字节，不会验证记录内容真实性或把它当作亲自运行。

`p04_brief` 与 `input_refs` 的各项同样使用文件引用对象，并附上 `version`。源、角色 ID 和需求由对应 owner 给定；本文不分配正式 ID。

`exports` 每项至少包含：

| 字段 | 含义 |
| --- | --- |
| `variant` | `stand_export`、`avatar`、`portrait_review`、`characters_w14_crop`、`party_w08_crop` 之一 |
| `path` / `size_bytes` / `sha256` | 真实导出文件的相对路径与字节证据 |
| `source_sha256` | 绑定当前原生源文件的实际哈希 |
| `intended_color_space` | 本基准为 `sRGB` |
| `embedded_profile` | 实际的 sRGB/ICC 描述；没有则为 null，不能声称已嵌入 |
| `crop_rect` / `scale` / `pivot` | 母版到该变体的裁切、等比缩放、锚点，并注明坐标基准 |

`inspect_sample.py` 实际检查路径、文件大小与哈希、PNG 解码/尺寸/alpha、源到导出绑定、空白模板冒充、输入引用是否存在。对 ORA 额外检查非指南绘画层是否存在；这仍不能证明脸部、手部、遮挡或“真正可编辑”的质量。PSD/KRA/CLIP 不由此工具解析其绘画语义。

```bash
python -B /path/to/P25_ArtDirection_V0.1/validation/inspect_sample.py \
  --submission /path/to/P26_sample/submission.json \
  --base /path/to/P26_sample --output /path/to/P26_precheck_new
```

完整技术送审记录可能返回 PASS/0，但输出始终保留 `formal_gate=BLOCKED_NOT_AUTHORIZED_BY_THIS_TOOL`。P25 审美、P37 权利、P30 导入、P35 审查仍需各自独立回执。未授予该工具合并或发布权限。

## 有针对性的负向检查

`run_negative_checks.py` 使用副本复现：文件篡改、丢失导出、路径逃逸、裁切越界、丢失 alpha、占位图晋级、未审样本填 PASS、联系表图片空白、空 ORA 冒充角色。每项保留期望失败编号、实际退出码、完整验证结果和 stdout/stderr。负向检查的 PASS 表示“按预期拒绝”，不是损坏素材合格。

首次生成联系表时曾出现 Inkscape 返回 0 但图片未显示的问题。已修正本岗生成器并保存失败证据；`P25-V12_VISIBLE_CONTACT_CELLS` 与对应负向用例正是针对该实际缺陷增加，避免只检查进程退出码。

## 本轮规范图的字体复验

需 Node 和 fontTools，直接复用P24随包的本地解码器，不要求Python Brotli扩展：

```bash
python -B validation/inspect_spec_fonts.py --output ../P25_font_check
```

输出记录实际转换字体哈希及7张规范/联系表SVG中409个可见码点的覆盖。字体转换仅用于临时渲染，不改变原字体，不代签许可。
