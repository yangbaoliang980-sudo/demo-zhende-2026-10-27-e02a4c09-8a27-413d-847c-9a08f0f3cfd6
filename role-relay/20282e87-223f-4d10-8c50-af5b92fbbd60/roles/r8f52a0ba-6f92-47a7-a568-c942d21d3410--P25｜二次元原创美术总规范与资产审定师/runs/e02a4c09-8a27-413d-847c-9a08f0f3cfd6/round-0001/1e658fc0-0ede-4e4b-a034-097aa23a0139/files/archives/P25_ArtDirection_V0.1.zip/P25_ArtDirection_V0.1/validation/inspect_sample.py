#!/usr/bin/env python3
"""Inspect a future P26 submission without approving aesthetics, permissions or production.
Exit 0 means only the recorded technical submission checks passed; 2 invalid evidence;
3 missing evidence/TEMPLATE_NOT_ART. This tool never opens the formal or batch gate.
"""
import argparse, datetime, hashlib, io, json, sys, zipfile
from pathlib import Path
import xml.etree.ElementTree as ET
from PIL import Image
from validate_p25 import safe, readj, sha, require


def inspect(root, submission, base):
    obj=readj(submission);checks=[]
    def add(ident,status,detail):checks.append({'id':ident,'status':status,'detail':detail})
    template=obj.get('lifecycle')=='TEMPLATE_NOT_ART'
    add('SAMPLE_LIFECYCLE','BLOCKED' if template else ('PASS' if obj.get('lifecycle')=='CANDIDATE' else 'FAIL'),obj.get('lifecycle'))
    for k in ('sample_id','character_id'):
        add(k.upper(),'PASS' if isinstance(obj.get(k),str) and obj[k].strip() else 'BLOCKED',obj.get(k))
    add('NO_AUTOMATED_PROMOTION','PASS' if obj.get('production_allowed') is False and obj.get('mass_production_allowed') is False else 'FAIL','Production flags must remain false in an unaudited candidate.')
    add('STYLE_VERSION','PASS' if obj.get('style_version')=='P25-ART-BIBLE/0.1.0' else 'FAIL',obj.get('style_version'))
    def bound_file(ident,record):
        if not isinstance(record,dict) or not record.get('path'):
            add(ident,'BLOCKED','No actual file reference');return None
        try:
            p=safe(base,record['path']);require(p.is_file(),'file missing')
            require(p.stat().st_size==record.get('size_bytes'),'size mismatch')
            require(sha(p)==record.get('sha256'),'SHA-256 mismatch')
            add(ident,'PASS',{'path':record['path'],'size_bytes':p.stat().st_size,'sha256':sha(p)});return p
        except Exception as e:add(ident,'FAIL',str(e));return None
    src=obj.get('source') or {};source=bound_file('SOURCE_BYTES',src)
    if source:
        try:
            require(source.suffix.lower() in {'.ora','.kra','.psd','.clip'},'source must use an agreed editable native format')
            # Exact template rejection works even if somebody strips its metadata or renames it.
            require(sha(source)!=sha(root/'art_direction/templates/character_source_template.ora'),'blank P25 ORA is not character art')
            if source.suffix.lower()=='.ora':
                with zipfile.ZipFile(source) as z:
                    require(z.read('mimetype')==b'image/openraster','invalid ORA mimetype')
                    if 'p25_template_metadata.json' in z.namelist():
                        m=json.loads(z.read('p25_template_metadata.json'));require(m.get('lifecycle')!='TEMPLATE_NOT_ART','template metadata forbids sample use')
                    st=ET.fromstring(z.read('stack.xml'));painted=0
                    for layer in st.findall('.//layer'):
                        name=layer.get('name','').lower()
                        if any(x in name for x in ('guide','sketch','background','参考','草稿','安全线')):continue
                        mem=layer.get('src');require(mem and '..' not in mem.split('/') and not mem.startswith('/'),'invalid ORA layer reference')
                        with Image.open(io.BytesIO(z.read(mem))) as im:
                            if im.convert('RGBA').getchannel('A').getextrema()[1]>0:painted+=1
                    require(painted>=2,'no demonstrated multi-layer painted content')
            add('SOURCE_NOT_EMPTY_TEMPLATE','PASS','Byte/template and basic format checks only; semantic editability still requires opening in the stated application.')
        except Exception as e:add('SOURCE_NOT_EMPTY_TEMPLATE','FAIL',str(e))
    for k in ('application','application_version'):
        add('SOURCE_'+k.upper(),'PASS' if src.get(k) else 'BLOCKED',src.get(k))
    bound_file('EDITABLE_OPEN_EVIDENCE',src.get('editable_open_evidence'))
    bound_file('LAYERS_MANIFEST',src.get('layers_manifest'))
    profiles={x['id']:x for x in readj(root/'art_direction/crop_profiles.json')['profiles']}
    required=['stand_export','avatar','portrait_review','characters_w14_crop','party_w08_crop']
    exports=obj.get('exports') or [];seen=set()
    for i,e in enumerate(exports):
        name=e.get('variant');ident='EXPORT_'+str(name or i)
        if name in seen:add(ident,'FAIL','Duplicate variant');continue
        seen.add(name);p=bound_file(ident+'_BYTES',e)
        if not p:continue
        try:
            require(name in profiles,'unknown crop variant');expected=profiles[name]['canvas_px'];b=p.read_bytes()
            with Image.open(p) as im:
                im.load();require(im.format=='PNG' and im.mode=='RGBA','must be a real RGBA PNG')
                require(list(im.size)==expected,'pixel dimensions differ from profile')
                require(b[24]==8 and b[25]==6,'must be PNG RGBA8')
                lo,hi=im.getchannel('A').getextrema();require(hi>0,'export is fully transparent')
                if name=='stand_export':require(lo==0,'stand export requires transparent background')
            require(e.get('source_sha256')==src.get('sha256') and src.get('sha256'),'source-to-export SHA binding missing/different')
            require(e.get('intended_color_space')=='sRGB','record intended color space')
            add(ident+'_PIXELS','PASS',{'dimensions':expected,'scope':'decoded pixels; facial quality is not evaluated'})
        except Exception as ex:add(ident+'_PIXELS','FAIL',str(ex))
    for name in required:
        if name not in seen:add('REQUIRED_'+name,'BLOCKED','Actual export missing')
    # Check references, not their legal validity or owner signatures.
    bound_file('P04_BRIEF',obj.get('p04_brief'))
    refs=obj.get('input_refs') or {}
    for name in ('p01_scope','p23_safe_area','p13_actual_path_mapping','p37_permission_receipt'):
        bound_file('INPUT_'+name,refs.get(name))
    env=obj.get('target_environment') or {}
    add('TARGET_ENVIRONMENT','PASS' if all(env.get(k) for k in ('engine','engine_version','os','os_version','logical_resolution','dpi_scale')) else 'BLOCKED','Engine/OS/version/resolution/DPI must be recorded; this does not execute a target-device test.')
    counts={s:sum(c['status']==s for c in checks) for s in ('PASS','FAIL','BLOCKED')}
    status='FAIL' if counts['FAIL'] else ('BLOCKED' if counts['BLOCKED'] else 'PASS')
    return {'tool_version':'P25-SAMPLE-INSPECTOR/0.1.0','layer':'SUBMISSION_TECHNICAL_PRECHECK_ONLY','submission_sha256':sha(submission),'status':status,'checks':checks,'counts':counts,'formal_gate':'BLOCKED_NOT_AUTHORIZED_BY_THIS_TOOL','aesthetic_review':'NOT_RUN','native_editor_open_by_tool':'NOT_RUN','permission_review':'NOT_RUN','game_runtime_executed':False,'mass_production_allowed':False}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--submission',type=Path,required=True);ap.add_argument('--base',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    root=a.root.resolve();base=a.base.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root) or out.is_relative_to(base):ap.error('output must be new and outside package and submission base')
    try:result=inspect(root,a.submission.resolve(),base)
    except Exception as e:result={'status':'FAIL','error':str(e),'formal_gate':'BLOCKED_NOT_AUTHORIZED_BY_THIS_TOOL','mass_production_allowed':False}
    result['executed_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();result['tool_sha256']=sha(Path(__file__))
    code={'PASS':0,'FAIL':2,'BLOCKED':3}[result['status']];result['exit_code']=code
    out.mkdir(parents=True);(out/'sample_inspection_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'exit_code':code,'output':str(out)},ensure_ascii=False));sys.exit(code)
if __name__=='__main__':main()
