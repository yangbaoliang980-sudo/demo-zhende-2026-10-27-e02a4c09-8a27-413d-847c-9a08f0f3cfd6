"""Decode original WOFF2 to temporary SFNT for author rendering; originals are never edited."""
import argparse, json, os, shutil, subprocess, types, hashlib
from pathlib import Path
from fontTools.ttLib import TTFont, woff2

def prepare(src, dst):
    dst.mkdir(parents=True, exist_ok=True)
    if not woff2.haveBrotli:
        def decode(data):
            r = subprocess.run([os.environ.get('P24_NODE', 'node'), '-e',
                "const z=require('node:zlib');let a=[];process.stdin.on('data',x=>a.push(x));process.stdin.on('end',()=>process.stdout.write(z.brotliDecompressSync(Buffer.concat(a),{maxOutputLength:67108864})))"],
                input=data, capture_output=True, check=True)
            return r.stdout
        woff2.brotli = types.SimpleNamespace(decompress=decode)
        woff2.haveBrotli = True
        decoder = 'Node built-in zlib.brotliDecompressSync (local; no network)'
    else:
        decoder = 'fontTools installed Brotli binding'
    records=[]
    for p in sorted(src.iterdir()):
        if p.suffix not in ('.woff2', '.ttf'): continue
        f=TTFont(p, recalcTimestamp=False)
        dest=dst/(p.stem+'.ttf');f.flavor=None;f.save(dest)
        records.append({'source':p.name,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
          'sfnt':dest.name,'sfnt_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
          'families':sorted({n.toUnicode() for n in f['name'].names if n.nameID==1}),
          'font_version':sorted({n.toUnicode() for n in f['name'].names if n.nameID==5}),
          'cmap_count':len(f.getBestCmap())})
    conf=dst/'fonts.conf'
    conf.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>'+str(dst.resolve())+'</dir><cachedir>'+str((dst/'cache').resolve())+'</cachedir></fontconfig>')
    (dst/'conversion.json').write_text(json.dumps({'decoder':decoder,'fonts':records},ensure_ascii=False,indent=2)+'\n')
    return conf

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('source',type=Path);a.add_argument('output',type=Path);n=a.parse_args()
    print(prepare(n.source,n.output))
