"""Author visual QA: actual Inkscape text bounds, cmap, color pairs and sliced image corners."""
import argparse,csv,datetime,hashlib,json,os,subprocess
from pathlib import Path
import xml.etree.ElementTree as ET
from fontTools.ttLib import TTFont
from PIL import Image,ImageOps
from create_boards import nine
from build_p24 import dump,h,C

def luminance(s):
    v=[int(s[i:i+2],16)/255 for i in (1,3,5)]
    v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in v]
    return sum(a*b for a,b in zip(v,[.2126,.7152,.0722]))
def ratio(fg,bg):
    a,b=sorted([luminance(fg),luminance(bg)]);return (b+.05)/(a+.05)

def run(root,out,fontdir):
    if out.exists() or out.resolve().is_relative_to(root.resolve()):raise ValueError('Use a new output directory outside package')
    out.mkdir(parents=True);env=os.environ.copy();env['FONTCONFIG_FILE']=str((fontdir/'fonts.conf').resolve());env['XDG_CONFIG_HOME']=str((out/'runtime_config').resolve());env['XDG_CACHE_HOME']=str((out/'runtime_cache').resolve())
    fontlist=[];cmaps={}
    for p in sorted(fontdir.glob('*.ttf')):
        ft=TTFont(p);names=sorted({x.toUnicode() for x in ft['name'].names if x.nameID==1});cmaps[p.name]=set(ft.getBestCmap())
        fontlist.append({'file':p.name,'sha256':h(p),'families':names,'weight_class':ft['OS/2'].usWeightClass,'glyph_count':len(ft.getBestCmap())})
    locs={'zh-Hans':['noto-sans-sc-chinese-simplified-400-normal.ttf','noto-sans-jp-japanese-400-normal.ttf','DejaVuSans.ttf'],
          'ja':['noto-sans-jp-japanese-400-normal.ttf','noto-sans-sc-chinese-simplified-400-normal.ttf','DejaVuSans.ttf']}
    previews=json.loads((root/'art/ui/preview_catalog.json').read_text())['items'];boards=[];missing=[];fallbacks=[];count=0
    version=subprocess.run(['inkscape','--version'],capture_output=True,text=True).stdout.strip()
    for item in previews:
        src=root/item['svg_relative_path'];cmd=['inkscape',str(src.resolve()),'--query-all'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
        proc=subprocess.run(cmd,capture_output=True,text=True,env=env)
        (out/(item['preview_id']+'.stdout.log')).write_text(proc.stdout);(out/(item['preview_id']+'.stderr.log')).write_text(proc.stderr)
        boxes={}
        for line in proc.stdout.splitlines():
            a=line.rsplit(',',4)
            if len(a)==5:
                try:boxes[a[0]]=list(map(float,a[1:]))
                except ValueError:pass
        rt=ET.parse(src).getroot();w,hh=item['board_size'];rows=[];fail=[]
        for e in rt.iter('{http://www.w3.org/2000/svg}text'):
            count+=1;t=''.join(e.itertext());id=e.get('id');box=boxes.get(id);ok=bool(box) and box[0]>=-.1 and box[1]>=-.1 and box[0]+box[2]<=w+.1 and box[1]+box[3]<=hh+.1
            rows.append({'id':id,'text':t,'bbox':box,'inside_board':ok,'font_size':float(e.get('font-size','0'))})
            if not ok:fail.append(id)
            for ch in set(t):
                if ch.isspace():continue
                order=locs.get(e.get('lang'),locs['zh-Hans']);hit=next((name for name in order if ord(ch) in cmaps[name]),None)
                if hit is None:missing.append({'preview':item['preview_id'],'text_id':id,'codepoint':f'U+{ord(ch):04X}','character':ch})
                elif hit!=order[0]:fallbacks.append({'preview':item['preview_id'],'text_id':id,'character':ch,'font':hit})
        overlaps=[]
        for i,a in enumerate(rows):
            if not a['bbox']:continue
            ax,ay,aw,ah=a['bbox']
            for b in rows[i+1:]:
                if not b['bbox']:continue
                bx,by,bw,bh=b['bbox'];ix=min(ax+aw,bx+bw)-max(ax,bx);iy=min(ay+ah,by+bh)-max(ay,by)
                if ix>2 and iy>2:overlaps.append({'a':a['id'],'b':b['id'],'intersection':[ix,iy]})
        boards.append({'preview_id':item['preview_id'],'source_sha256':h(src),'argv':cmd,'start_utc':start,'exit_code':proc.returncode,
          'text_count':len(rows),'out_of_board':fail,'text_overlaps':overlaps,'texts':rows,'status':'PASS' if proc.returncode==0 and not fail and not overlaps else 'FAIL'})
    # All essential text pairings over the actually used opaque surfaces.
    pairs=[]
    for bg in ['canvas','surface','raised','disabled']:
        for fg in ['text','muted']:pairs.append((f'{fg}_on_{bg}',C[fg],C[bg],4.5))
    for bg in ['primary','hover','pressed','gold']:pairs.append((f'button_ink_on_{bg}',C['ink'],C[bg],4.5))
    for bg in ['#181D2B','#302B43','#3C2837','#392F27']:
        for fg in [C['text'],C['muted']]:pairs.append((f'text_{fg}_on_{bg}',fg,bg,4.5))
    pairs += [('disabled_label',C['disabled_text'],C['disabled'],4.5),('warning_label',C['warning'],'#392F27',4.5)]
    for fg in ['focus','gold','line']:
        for bg in ['canvas','surface','raised','disabled']:pairs.append((f'{fg}_edge_on_{bg}',C[fg],C[bg],3))
    pairs += [('hp_fill_track',C['health'],C['track'],3),('hp_low_track',C['danger'],C['track'],3),('shield_track',C['focus'],C['track'],3)]
    contrast=[{'id':i,'fg':fg,'bg':bg,'minimum':m,'ratio':ratio(fg,bg),'status':'PASS' if ratio(fg,bg)>=m else 'FAIL'} for i,fg,bg,m in pairs]
    # Slice metadata and real exported pixels, including the smallest proposed dimensions.
    slices=[];cat=json.loads((root/'art/ui/asset_catalog.json').read_text())
    for a in cat['assets']:
        br=a['nine_slice_ltrb_1x']
        if not br:continue
        src=Image.open(root/a['exports'][0]['relative_path']).convert('RGBA');sw,sh=src.size;l,t,rr,b=br
        for tw,th in [a['minimum_display_size'],[sw+137,sh+24]]:
            im=nine(src,(tw,th),br);same=[]
            for sbox,dbox in [((0,0,l,t),(0,0,l,t)),((sw-rr,0,sw,t),(tw-rr,0,tw,t)),((0,sh-b,l,sh),(0,th-b,l,th)),((sw-rr,sh-b,sw,sh),(tw-rr,th-b,tw,th))]:same.append(src.crop(sbox).tobytes()==im.crop(dbox).tobytes())
            slices.append({'asset_id':a['asset_id'],'target_size':[tw,th],'corners_unchanged':same,'status':'PASS' if all(same) else 'FAIL'})
    # PNG dimensions at independent density renders; this is not an OS DPI test.
    density=[]
    for item in previews:
        for e in item['exports']:
            p=root/e['relative_path'];im=Image.open(p);wanted=tuple(round(v*e['scale']) for v in item['board_size'])
            density.append({'path':e['relative_path'],'scale':e['scale'],'actual_size':list(im.size),'expected_size':list(wanted),'status':'PASS' if im.size==wanted else 'FAIL'})
    im=Image.open(root/'art/ui/exports/previews/P24_Battle_Target_1280.png');ImageOps.grayscale(im).convert('RGBA').save(out/'P24_Battle_Grayscale.png')
    res={'layer':'AUTHOR_STATIC_VISUAL_QA','game_runtime_executed':False,'inkscape':version,'fonts':fontlist,
         'text_node_count':count,'boards':boards,'missing_glyphs':missing,'fallback_glyphs':fallbacks,'contrast_pairs':contrast,'nine_slice_cases':slices,'density_cases':density,
         'not_proven':['Target engine import','Target OS DPI','Dynamic line shaping and reflow','Player usability','Independent P25/P32/P35/P37 approval']}
    res['status']='PASS' if not missing and all(x['status']=='PASS' for x in boards+contrast+slices+density) else 'FAIL'
    dump(out/'visual_qa_results.json',res)
    dump(out/'contrast_cases.json',{'version':'P24-CONTRAST-CASES/0.1.0','cases':contrast})
    print(json.dumps({'status':res['status'],'boards':len(boards),'text_nodes':count,'missing_glyphs':len(missing),'contrast_pairs':len(contrast),'nine_slice_cases':len(slices),'density_cases':len(density),'failing_boards':[x['preview_id'] for x in boards if x['status']!='PASS']},ensure_ascii=False))
    return 0 if res['status']=='PASS' else 2

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--fonts',type=Path,required=True);a=p.parse_args();raise SystemExit(run(a.root,a.output,a.fonts))
