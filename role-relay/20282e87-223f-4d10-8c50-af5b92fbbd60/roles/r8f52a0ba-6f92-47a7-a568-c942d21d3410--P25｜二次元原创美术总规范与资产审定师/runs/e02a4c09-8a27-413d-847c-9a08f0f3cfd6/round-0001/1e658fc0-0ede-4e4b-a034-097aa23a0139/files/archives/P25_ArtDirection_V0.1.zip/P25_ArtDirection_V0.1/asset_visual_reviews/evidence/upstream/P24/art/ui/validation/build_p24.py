"""P24 isolated visual asset authoring. No game code, commands, or Anki access."""
from pathlib import Path
import argparse, base64, csv, hashlib, io, json, math, re, shutil
from html import escape
import xml.etree.ElementTree as ET
from PIL import Image

VERSION='P24-UI-VISUAL/0.1.0-placeholder'
TASK='P24-S03-UI-ASSET-001'
C={'canvas':'#121520','surface':'#202535','raised':'#2B3045','ink':'#19192B',
   'text':'#F5F1E9','muted':'#C0C9DA','line':'#8D9AB5','gold':'#E6BF7D',
   'primary':'#D8BCF4','hover':'#EBD5FF','pressed':'#BDA1DE','disabled':'#353C50',
   'disabled_text':'#C7CFDE','focus':'#97E2F6','health':'#9ADDB7','danger':'#FFB9C2',
   'track':'#101420','warning':'#F3CD8D'}
STATES=['default','hover','pressed','disabled','selected','error']
STATE_ZH={'default':'默认','hover':'悬停','pressed':'按下','disabled':'禁用','selected':'选中','error':'错误','unknown':'未知','pending':'待核对','low':'低生命','empty':'空值','active':'焦点','shield':'护盾'}

def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n')
def rect(x,y,w,hh,fill='none',stroke='none',sw=1,r=0,extra=''):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{hh}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'
def path(d,stroke,sw=2,fill='none',extra=''):return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round" {extra}/>'
def circ(x,y,r,fill='none',stroke='none',sw=1):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>'
def svg(w,hh,body,title,metadata=None):
    meta=escape(json.dumps(metadata or {'owner':'P24','lifecycle':'PLACEHOLDER','production_allowed':False},ensure_ascii=False))
    return f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="{w}" height="{hh}" viewBox="0 0 {w} {hh}" version="1.1"><title>{escape(title)}</title><metadata>{meta}</metadata>{body}</svg>\n'
def group(name,body):return f'<g id="{name}">{body}</g>'

def icon_body(kind,color):
    p=lambda d,sw=2,fill='none':path(d,color,sw,fill)
    shapes={
      'attack':p('M10 22 L23 9 L24 5 L20 6 L7 19 Z')+p('M7 17 L15 25 M10 22 L5 27'),
      'shield':p('M16 4 L26 8 L25 19 Q23 25 16 28 Q9 25 7 19 L6 8 Z')+p('M16 9 L16 22 M11 15 L21 15'),
      'heal':p('M12 5 L20 5 L20 12 L27 12 L27 20 L20 20 L20 27 L12 27 L12 20 L5 20 L5 12 L12 12 Z'),
      'buff':p('M16 4 L24 13 L20 13 L20 23 L12 23 L12 13 L8 13 Z')+p('M7 28 L25 28'),
      'energy':p('M18 3 L7 18 L14 18 L12 29 L25 13 L18 13 Z'),
      'draw':rect(7,9,18,18,'none',color,2,2)+p('M10 5 L23 5 M16 12 L16 22 M12 18 L16 22 L20 18'),
      'discard':rect(5,4,17,20,'none',color,2,2)+p('M10 9 L17 9 M19 26 L27 26 M23 22 L27 26 L23 30'),
      'remove':rect(7,4,18,24,'none',color,2,2)+p('M11 11 L21 21 M21 11 L11 21'),
      'intent':p('M4 16 Q16 2 28 16 Q16 30 4 16 Z')+circ(16,16,5,'none',color,2),
      'unknown':p('M10 10 Q10 4 17 4 Q24 4 24 10 Q24 14 17 17 L17 21')+circ(17,27,1.5,color),
      'locked':rect(6,13,20,15,'none',color,2,3)+p('M10 13 L10 9 Q10 3 16 3 Q22 3 22 9 L22 13 M16 19 L16 23'),
      'check':circ(16,16,12,'none',color,2)+p('M9 16 L14 21 L23 11',2.5),
      'warning':p('M16 4 L29 27 L3 27 Z')+p('M16 12 L16 18',2.5)+circ(16,23,1.2,color),
      'error':p('M10 4 L22 4 L28 10 L28 22 L22 28 L10 28 L4 22 L4 10 Z')+p('M11 11 L21 21 M21 11 L11 21',2.5),
      'pending':p('M8 4 L24 4 M8 28 L24 28 M10 4 L10 10 L22 22 L22 28 M22 4 L22 10 L10 22 L10 28')+p('M12 8 L20 8 M12 24 L20 24'),
      'connected':p('M13 20 L9 24 Q4 27 3 21 Q3 19 5 17 L10 12 Q14 9 18 13 M19 12 L23 8 Q28 5 29 11 Q29 13 27 15 L22 20 Q18 23 14 19 M11 21 L21 11'),
      'disconnected':p('M10 20 L7 23 Q3 25 3 20 L6 16 M22 12 L25 9 Q29 7 29 12 L26 16 M11 9 L9 5 M21 23 L23 27 M5 5 L27 27'),
      'details':circ(16,16,12,'none',color,2)+p('M16 14 L16 23')+circ(16,9,1.2,color),
      'target':circ(16,16,9,'none',color,2)+circ(16,16,3,'none',color,2)+p('M16 2 L16 8 M16 24 L16 30 M2 16 L8 16 M24 16 L30 16'),
      'turn':p('M7 12 Q9 4 18 5 Q27 6 27 16 Q27 26 17 27 M7 12 L5 5 M7 12 L14 11 M7 22 L16 22 M12 18 L16 22 L12 26'),
      'book':p('M16 9 Q10 4 3 6 L3 25 Q10 23 16 28 Q22 23 29 25 L29 6 Q22 4 16 9 Z M16 9 L16 28 M7 11 L12 13 M20 13 L25 11 M7 17 L12 19 M20 19 L25 17'),
      'grammar':p('M10 5 L5 5 L5 27 L10 27 M22 5 L27 5 L27 27 L22 27 M12 11 L20 11 M12 16 L20 16 M12 21 L18 21'),
      'sentence':p('M5 5 L27 5 L27 23 L18 23 L12 29 L12 23 L5 23 Z M10 10 L22 10 M10 15 L22 15 M10 19 L17 19'),
      'currency':circ(16,16,12,'none',color,2)+p('M16 8 L23 16 L16 24 L9 16 Z')}
    return group('glyph',shapes[kind])

def component(family,state,w,hh):
    col=C['line'];fill=C['surface'];extra=''
    if state=='hover':fill=C['raised'];col=C['primary']
    if state=='pressed':fill='#181D2B';col=C['primary']
    if state=='selected':fill='#302B43';col=C['gold']
    if state=='disabled':fill=C['disabled'];extra='stroke-dasharray="5 4"'
    if state=='error':fill='#3C2837';col=C['danger']
    if state=='pending':fill='#392F27';col=C['warning']
    if state=='unknown':fill=C['track'];extra='stroke-dasharray="3 3"'
    if family.startswith('icon.'):
        return icon_body(family.split('.')[1],C['disabled_text'] if state=='disabled' else C['text'])
    if family.startswith('button.'):
        if family=='button.primary' and state not in ['disabled','error']:
            fill={'default':C['primary'],'hover':C['hover'],'pressed':C['pressed'],'selected':C['gold']}[state]
            col=fill
        b=rect(5,5,w-10,hh-10,fill,col,1.5,7,extra)
        if state!='disabled':b+=path(f'M17 9 H{w-17}',C['ink'] if family=='button.primary' else col,1,extra='opacity="0.24"')
        if state=='pressed':b+=path(f'M18 {hh-9} H{w-18}',C['ink'] if family=='button.primary' else col,2)
        if state=='selected':b+=path(f'M{w-23} 13 l3 3 l5 -6',C['ink'] if family=='button.primary' else C['gold'],1.8)
        if state=='error':b+=path(f'M{w-18} 10 l5 8 h-10 Z',C['danger'],1)
        if state=='disabled':b+=path(f'M{w-20} 11 l8 8',C['disabled_text'],1.5)
        return group('surface',b)
    if family=='card.back':
        b=rect(2,2,w-4,hh-4,fill,col,1.5,10,extra)+rect(10,10,w-20,hh-20,'none',C['gold'] if state=='default' else col,1,6)
        b+=path(f'M{w/2} 27 L{w-39} {hh/2} L{w/2} {hh-27} L39 {hh/2} Z',col,1)
        b+=circ(w/2,hh/2,39,'none',col,1)
        b+=f'<g transform="translate({w/2-25} {hh/2-25}) scale(1.5625)">{icon_body("book",C["gold"] if state=="default" else C["muted"])}</g>'
        return group('card-back',b)
    if family=='card.art_window':
        return group('transparent-window',rect(2,2,w-4,hh-4,'none',col,2,7,extra)+path(f'M10 5 H22 M{w-22} 5 H{w-10} M10 {hh-5} H22 M{w-22} {hh-5} H{w-10}',col,1))
    if family.startswith('frame.') or family=='panel.surface':
        b=rect(2,2,w-4,hh-4,fill,col,1.5,10,extra)
        if family!='panel.surface':
            decor=C['gold'] if state in ['default','selected'] else col
            b+=path(f'M12 7 H28 M7 12 V26 M{w-28} 7 H{w-12} M{w-7} 12 V26 M12 {hh-7} H28 M{w-28} {hh-7} H{w-12}',decor,1)
        if state=='selected':b+=path(f'M{w-27} {hh-15} l5 5 l8 -10',C['gold'],2.5)+rect(6,6,w-12,hh-12,'none',C['gold'],1,6)
        if state=='error':b+=path(f'M{w-16} {hh-25} l7 12 h-14 Z',C['danger'],1.5)
        if state=='disabled':b+=path(f'M{w-24} {hh-25} l12 12',C['disabled_text'],2)
        return group('frame',b)
    if family=='bar.hp_track':
        b=rect(.75,.75,w-1.5,hh-1.5,C['track'],col,1.5,4,extra)
        if state=='unknown':
            for x in range(8,w-7,12):b+=path(f'M{x} 3 l-4 6',C['line'],1)
        return group('track',b)
    if family in ['bar.hp_fill','bar.shield_fill']:
        color=C['health'] if family=='bar.hp_fill' else C['focus']
        if state=='low':color=C['danger']
        if state=='disabled':color=C['disabled_text']
        return group('fill',rect(0,0,w,hh,color,r=2))
    if family=='cost.badge':
        fill=C['primary'] if state in ['default','hover','pressed','selected'] else fill
        if state=='hover':fill=C['hover']
        if state=='pressed':fill=C['pressed']
        if state=='selected':fill=C['gold']
        b=path(f'M{w/2} 2 L{w-3} 11 V{hh-11} L{w/2} {hh-2} L3 {hh-11} V11 Z',col,1.5,fill,extra)
        return group('cost-base',b)
    if family.startswith('focus.'):
        return group('independent-focus',rect(1.5,1.5,w-3,hh-3,'none',C['focus'],3,10))
    raise ValueError(family)

def base_metadata(family,state,w,hh):
    nine=None; safe=[4,4,w-8,hh-8];beh='none';minsize=[w,hh]
    if family.startswith('button.'):
        nine=[24,18,24,18];safe=[24,12,w-48,hh-24];beh='nine_slice';minsize=[96,44]
    if family.startswith('frame.') or family=='panel.surface':
        nine=[32,28,32,28];safe=[14,14,w-28,hh-28];beh='nine_slice';minsize=[96,64]
    if family.startswith('focus.'):
        nine=[12,12,12,12];safe=None;beh='nine_slice';minsize=[44,44]
    if family.startswith('bar.'):
        safe=None;beh='clip_horizontal' if 'fill' in family else 'nine_slice';minsize=[12,hh]
        if 'track' in family:nine=[6,4,6,4]
    if family=='card.art_window':safe=[8,8,w-16,hh-16]
    if family=='cost.badge':safe=[10,8,20,24]
    if family=='card.back':safe=[16,16,w-32,hh-32]
    reserved=[]
    if family.startswith('frame.') and state in ['selected','disabled','error']:reserved=[[w-32,hh-32,26,26]]
    if family.startswith('button.') and state in ['selected','disabled','error']:reserved=[[w-28,8,18,16]]
    return {'logical_size':[w,hh],'stretch_mode':beh,'nine_slice_ltrb_1x':nine,'safe_rect_1x':safe,'reserved_rects_1x':reserved,
       'minimum_display_size':minsize,'transparent_canvas':True,'text_baked':False,
       'pivot_normalized':[0.5,0.5],'trim_allowed':False,'rotate_atlas_allowed':False,
       'alpha':'straight / unassociated RGBA8','color_space':'sRGB','engine_import':'NOT_RUN'}

def intake(root,p23,work):
    records=[]
    selected={
      'P23_W01':'design/ux/wireframes/W01_Battle_Ready.svg','P23_W02':'design/ux/wireframes/W02_Battle_Target.svg',
      'P23_W03':'design/ux/wireframes/W03_Battle_Unknown.svg','P23_W10':'design/ux/wireframes/W10_Learning_Quarantine.svg',
      'P23_W16':'design/ux/wireframes/W16_Typography.svg','P23_W17':'design/ux/wireframes/W17_Battle_Large_Text.svg',
      'P23_STATES':'design/ux/ui_state_map.json','P23_ANCHORS':'design/ux/ux_anchor_contract.json',
      'P23_TOKENS':'design/accessibility/accessibility_tokens.json','P23_TYPOGRAPHY':'design/accessibility/typography_accessibility_spec.md',
      'P23_FONT_PROVENANCE':'design/accessibility/font_provenance.json',
      'P23_STRINGS':'design/accessibility/typography_test_strings.json',
      'P23_INTERACTION':'design/ux/interaction_spec.md',
      'P01_REQUIREMENTS':'design/ux/evidence/upstream/P01/SRC-P01-REQ/requirements_traceability.tsv',
      'P01_SCOPE':'design/ux/evidence/upstream/P01/SRC-P01-SCOPE/prd_scope_v0.md',
      'P13_PATH':'design/ux/evidence/upstream/P13/SRC-P13-PATH/actual_path_mapping.json',
      'P13_ENV':'design/ux/evidence/upstream/P13/SRC-P13-ENV/target_environment_requirements.json',
      'P22_ID':'design/ux/evidence/upstream/P22/SRC-P22-ID-POLICY/id_policy.json',
      'P22_SCHEMA':'design/ux/evidence/upstream/P22/SRC-P22-SPEC/content_schema_spec.md',
      'P22_REGISTRY':'design/ux/evidence/upstream/P22/SRC-P22-REGISTRY/content_id_registry.tsv',
      'V6_INTERFACES':'design/ux/evidence/upstream/V6/SRC-V6-IC/第六轮_27项接口契约冻结修订V6.0.json',
      'V6_ROLES':'design/ux/evidence/upstream/V6/SRC-V6-ROLES/第六轮_全部岗位职责_可复制版V6.0.txt',
      'P19_STYLE':'design/ux/evidence/upstream/P19/SRC-P19-CSS/battle.css',
      'P20_STYLE':'design/ux/evidence/upstream/P20/SRC-P20-CSS/styles.css'}
    for sid,r in selected.items():
        src=p23/r;dest=root/'art/ui/evidence/upstream'/sid/src.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
        records.append({'source_id':sid,'original_member':'P23_UX_Accessibility_V0.1/'+r,'local_copy':str(dest.relative_to(root)),
          'size_bytes':src.stat().st_size,'sha256':h(src),'container_sha256':'6ac0dd8506586f1310addcb5a94c4bae23fb776ab18072b3d93f261dab005b4d',
          'read_status':'READ','source_commit':'bc9aec3a300e1a39aafb3303754a00b8004bbde5','unchanged_copy':True})
    fonts=root/'art/ui/source/fonts';fonts.mkdir(parents=True)
    for src in sorted((p23/'design/accessibility/fonts').iterdir()):
        shutil.copyfile(src,fonts/src.name)
        records.append({'source_id':'FONT_'+src.stem,'local_copy':str((fonts/src.name).relative_to(root)),'size_bytes':src.stat().st_size,'sha256':h(src),'unchanged_copy':True,'read_status':'DECODED_OR_LICENSE_READ'})
    for name in ['github_tree_evidence.json','outer_verification.json','upstream_verified.json','p22_resource_manifest.json']:
        dest=root/'art/ui/evidence/intake'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/name,dest)
    dump(root/'source_input_receipt.json',{'schema_version':'P24-SOURCE-INPUTS/0.1.0','task_id':TASK,
      'files':records,'scope_note':'Read-only input snapshots; sources retain their original owners. Git tree matches are separately recorded.',
      'missing':[{'owner':'P25','artifact':'fixed Art Bible / palette / approved crop guide'},
       {'owner':'P30','artifact':'accepted IC-22 import schema / settings / engine version'},
       {'owner':'P13','artifact':'actual_path_mapping with P24 entries and write authorization'},
       {'owner':'P22','artifact':'accepted P24 resource IDs and export naming contract'}]})
    return records

def create_assets(root,records):
    comps=[]
    defs=[('button.primary',180,48,STATES),('button.secondary',180,48,STATES),('button.navigation',200,48,STATES),
      ('frame.hand',236,174,STATES),('frame.enemy',350,196,STATES),('card.back',236,174,['default','disabled']),
      ('card.art_window',78,92,['default','selected','disabled']),('panel.surface',240,100,['default','selected','error','pending']),
      ('bar.hp_track',310,12,['default','empty','unknown']),('bar.hp_fill',304,6,['default','low','disabled']),
      ('bar.shield_fill',304,6,['default']),('cost.badge',40,40,STATES+['unknown']),
      ('focus.button',180,48,['active']),('focus.hand',246,184,['active']),('focus.enemy',360,206,['active']),('focus.navigation',200,48,['active'])]
    icons=['attack','shield','heal','buff','energy','draw','discard','remove','intent','unknown','locked','check','warning','error','pending','connected','disconnected','details','target','turn','book','grammar','sentence','currency']
    defs += [('icon.'+i,32,32,['default','disabled']) for i in icons]
    sources=[{'source_id':r['source_id'],'sha256':r['sha256']} for r in records if r['source_id'] in ['P23_W01','P23_W02','P23_W10','P23_TOKENS','P23_STATES','P22_ID','V6_INTERFACES','V6_ROLES','P20_STYLE']]
    for family,w,hh,states in defs:
        for state in states:
            aid='p24.ui.'+family+'.'+state
            stem='placeholder_ui_'+family.replace('.','_')+'_'+state
            rel='art/ui/source/components/'+stem+'.svg'
            meta=base_metadata(family,state,w,hh)
            obj={'asset_id':aid,'family':family,'state':state,'lifecycle':'PLACEHOLDER','production_allowed':False,
                 'source_relative_path':rel,'exports':[{'density':d,'relative_path':f'art/ui/exports/{d}x/{stem}@{d}x.png'} for d in [1,2]],
                 'owner':'P24','receivers':['P19','P20','P28','P30','P35'],'source_input_hashes':sources,**meta}
            if family=='card.art_window':obj['transparent_art_aperture_1x']=[8,8,62,76]
            if family=='bar.hp_track':obj['fill_rect_1x']=[3,3,304,6]
            obj['label_color']=C['ink'] if family in ['button.primary','cost.badge'] and state not in ['disabled','error','unknown'] else C['text']
            out=root/rel;out.parent.mkdir(parents=True,exist_ok=True)
            out.write_text(svg(w,hh,component(family,state,w,hh),f'PLACEHOLDER | {aid}',obj))
            comps.append(obj)
    dump(root/'art/ui/asset_catalog.json',{'schema_version':'P24-ASSET-CATALOG/0.1.0','version':VERSION,'task_id':TASK,'asset_count':len(comps),'assets':comps,'source_input_hashes':sources})
    matrix=[]
    for family,w,hh,states in defs:
        for st in dict.fromkeys(STATES+['focus','pending','unknown','empty','low']+states):
            found=next((x for x in comps if x['family']==family and x['state']==st),None)
            focus_family={'button.primary':'focus.button','button.secondary':'focus.button','button.navigation':'focus.navigation','frame.hand':'focus.hand','frame.enemy':'focus.enemy'}.get(family)
            focus_asset=next((x for x in comps if x['family']==focus_family),None) if st=='focus' else None
            if found:coverage='ASSET';reference=found['asset_id'];reason='Actual source and both density exports.'
            elif focus_asset:coverage='COMPOSITE_OVERLAY';reference=focus_asset['asset_id'];reason='Independent focus overlay; selection and disabled reason remain visible.'
            else:coverage='NOT_APPLICABLE';reference='';reason='Noninteractive graphic or state outside this visual family; do not infer a business transition.'
            matrix.append({'family':family,'visual_state':st,'coverage':coverage,'asset_id':reference,'reason':reason,'lifecycle':'PLACEHOLDER','runtime_binding':'NOT_RUN','owner':'P24'})
    with (root/'ui_asset_state_matrix.tsv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=list(matrix[0]),delimiter='\t');wr.writeheader();wr.writerows(matrix)
    dump(root/'art/ui/spec/visual_tokens.json',{'version':VERSION,'palette':C,'type':{'heading':28,'section':22,'critical':20,'body':18,'support':16,'no_autoshrink':True},'focus':{'color':C['focus'],'stroke':3,'separate_from_selection':True},'selection':{'color':C['gold'],'shape':'double border + corner check + textual label by P19/P20'},'board_reference':[1280,856],'ui_rect':[0,48,1280,720],'status':'PLACEHOLDER_PENDING_P25'})
    return comps

def main():
    a=argparse.ArgumentParser();a.add_argument('--output',type=Path,required=True);a.add_argument('--p23',type=Path,required=True);a.add_argument('--work',type=Path,required=True);n=a.parse_args()
    if n.output.exists():raise SystemExit('Refuse existing output. Use a new isolated directory.')
    n.output.mkdir(parents=True)
    r=intake(n.output,n.p23,n.work);c=create_assets(n.output,r)
    print(json.dumps({'status':'AUTHOR_SOURCES_GENERATED','assets':len(c),'svg_sources':len(c),'planned_png_exports':2*len(c)},ensure_ascii=False))

if __name__=='__main__':main()
