from pathlib import Path
import json,hashlib,mimetypes,sys,xml.etree.ElementTree as ET
from PIL import Image
from build_p24 import h,dump,VERSION,TASK

root=Path(sys.argv[1]);cat=json.loads((root/'art/ui/asset_catalog.json').read_text())
inputs=json.loads((root/'source_input_receipt.json').read_text());core=[{'source_id':x['source_id'],'sha256':x['sha256']} for x in inputs['files'] if x['source_id'] in ['V6_ROLES','V6_INTERFACES','P23_W02','P23_W10','P23_STATES','P23_TOKENS','P13_PATH','P22_ID','P20_STYLE']]
parent_sha={};export_entries=[]
def basic(rel):
 p=root/rel;fmt=mimetypes.guess_type(rel)[0] or 'application/octet-stream';d={'relative_path':rel,'size_bytes':p.stat().st_size,'sha256':h(p),'format':fmt,'format_version':p.suffix.lstrip('.') or 'plain'}
 if p.suffix=='.svg':
  rt=ET.parse(p).getroot();d['dimensions']=[float(rt.get('width')),float(rt.get('height'))];d['format_version']='SVG 1.1 editable vector'
 if p.suffix=='.png':
  im=Image.open(p);im.load();d['dimensions']=list(im.size);d['format_version']='PNG RGBA8' if im.mode=='RGBA' else 'PNG '+im.mode
 return d
for a in cat['assets']:
 s=basic(a['source_relative_path']);exports=[]
 for e in a['exports']:
  f=basic(e['relative_path']);im=Image.open(root/e['relative_path']);al=im.getchannel('A');hist=al.histogram();f.update({'density':e['density'],'source_sha256':s['sha256'],
   'alpha':{'association':'straight','min':al.getextrema()[0],'max':al.getextrema()[1],'zero_pixels':hist[0],'partial_pixels':sum(hist[1:255]),'opaque_pixels':hist[255]},
   'nine_slice_ltrb_physical_px':([v*e['density'] for v in a['nine_slice_ltrb_1x']] if a['nine_slice_ltrb_1x'] else None)})
  exports.append(f);parent_sha[e['relative_path']]={'source_id':a['asset_id'],'sha256':s['sha256']}
 export_entries.append({'asset_id':a['asset_id'],'family':a['family'],'state':a['state'],'lifecycle':'PLACEHOLDER','production_allowed':False,'owner':'P24','content_ref':None,
   'runtime_path':None,'import_version':None,'source':s,'exports':exports,'logical_size':a['logical_size'],'safe_rect_1x':a['safe_rect_1x'],'reserved_rects_1x':a['reserved_rects_1x'],
   'nine_slice_ltrb_1x':a['nine_slice_ltrb_1x'],'stretch_mode':a['stretch_mode'],'source_input_hashes':a['source_input_hashes'],'receivers':a['receivers'],
   'modification_allowlist':[{'role':'P24','paths':[a['source_relative_path']]+[x['relative_path'] for x in a['exports']],'scope':'isolated package only; no production authority'}]})
dump(root/'ui_visual_export_manifest.json',{'schema_version':'P24-UI-VISUAL-EXPORT/0.1.0','task_id':TASK,'version':VERSION,'related_contract':'IC-22 / V6.0 specification only',
 'actual_import_contract_version':None,'status':'PLACEHOLDER_AWAITING_P22_P25_P30_P37','asset_count':len(export_entries),'source_count':len(export_entries),'png_export_count':sum(len(x['exports']) for x in export_entries),'assets':export_entries})
for b in json.loads((root/'art/ui/preview_catalog.json').read_text())['items']:
 for e in b['exports']:parent_sha[e['relative_path']]={'source_id':b['preview_id'],'sha256':h(root/b['svg_relative_path'])}
records=[]
for p in sorted(root.rglob('*')):
 if not p.is_file() or p==root/'delivery_manifest.json':continue
 rel=str(p.relative_to(root));x=basic(rel);owner='P24';allow=[{'role':'P24','package_relative_path':rel,'scope':'new isolated P24 deliverable only; no production overwrite'}]
 if rel.startswith('art/ui/evidence/upstream/'):
  owner=rel.split('/')[4].split('_')[0];allow=[]
 if rel.startswith('art/ui/source/fonts/'):
  owner='UPSTREAM_FONT_OR_LICENSE';allow=[]
 sources=core+([parent_sha[rel]] if rel in parent_sha else [])
 x.update({'version':VERSION,'owner':owner,'artifact_role':'READ_ONLY_ORIGINAL_INPUT' if not allow else 'P24_ISOLATED_VISUAL_DELIVERY',
   'source_input_hashes':sources,'receivers':['P19','P20','P25','P28','P30','P32','P35','P37'],'modification_allowlist':allow,'actual_production_path':None,'production_write_allowed':False})
 records.append(x)
dump(root/'delivery_manifest.json',{'schema_version':'P24-DELIVERY-MANIFEST/0.1.0','task_id':TASK,'version':VERSION,'listed_file_count':len(records),'total_package_file_count':len(records)+1,
 'self_exclusion':'Only this manifest is excluded; package-external receipt binds its exact size/SHA-256 and the archive.','files':records})
print(json.dumps({'manifest_files':len(records),'total_files':len(records)+1,'assets':len(export_entries),'png_exports':sum(len(x['exports']) for x in export_entries)},ensure_ascii=False))
