"""Static artwork review boards, using the actual exported component PNGs."""
from pathlib import Path
import argparse,base64,copy,io,json,xml.etree.ElementTree as ET
from html import escape
from PIL import Image
from build_p24 import C,STATES,STATE_ZH,svg,rect,path,circ,dump,h
NS='http://www.w3.org/2000/svg'
ET.register_namespace('',NS)

def nine(im,size,border):
    tw,th=size;sw,sh=im.size
    if (sw,sh)==(tw,th):return im.copy()
    if not border:return im.resize(size,Image.Resampling.LANCZOS)
    l,t,r,b=border
    if tw<l+r or th<t+b:raise ValueError('Below nine-slice minimum')
    out=Image.new('RGBA',(tw,th))
    sx=[0,l,sw-r,sw];sy=[0,t,sh-b,sh];dx=[0,l,tw-r,tw];dy=[0,t,th-b,th]
    for yi in range(3):
        for xi in range(3):
            piece=im.crop((sx[xi],sy[yi],sx[xi+1],sy[yi+1]))
            want=(dx[xi+1]-dx[xi],dy[yi+1]-dy[yi])
            if 0 in want:continue
            piece=piece.resize(want,Image.Resampling.BILINEAR)
            out.alpha_composite(piece,(dx[xi],dy[yi]))
    return out

class Boards:
    def __init__(self,root):
        self.root=root;cat=json.loads((root/'art/ui/asset_catalog.json').read_text());self.assets={a['asset_id']:a for a in cat['assets']};self.items=[];self.uses=[]
    def data(self,family,state,size=None):
        aid='p24.ui.'+family+'.'+state;a=self.assets[aid];im=Image.open(self.root/a['exports'][0]['relative_path']).convert('RGBA')
        if size and size!=im.size:
            if a['stretch_mode']=='clip_horizontal' and size[1]==im.height and size[0]<=im.width:
                im=im.crop((0,0,size[0],size[1]))
            else:im=nine(im,size,a['nine_slice_ltrb_1x'])
        buf=io.BytesIO();im.save(buf,format='PNG');return 'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode(),aid
    def asset(self,family,state,x,y,w=None,hh=None):
        a=self.assets['p24.ui.'+family+'.'+state];w=w or a['logical_size'][0];hh=hh or a['logical_size'][1]
        data,aid=self.data(family,state,(int(w),int(hh)));self.uses.append(aid)
        return f'<image x="{x}" y="{y}" width="{w}" height="{hh}" href="{data}" data-asset-id="{aid}"/>'
    def txt(self,x,y,t,size=18,color=None,lang='zh-Hans',anchor='start'):
        font='Noto Sans JP Thin' if lang=='ja' else 'Noto Sans SC Thin'
        return f'<text x="{x}" y="{y}" font-family="{font},DejaVu Sans" font-size="{size}" font-weight="400" fill="{color or C["text"]}" lang="{lang}" text-anchor="{anchor}">{escape(t)}</text>'
    def title(self,w,hh,num,title,sub):
        return rect(0,0,w,hh,C['canvas'])+self.txt(40,39,'KOTODAMA BRIGADE   /   P24  ·  S03',16,C['gold'])+self.txt(40,89,title,32)+self.txt(40,122,sub,18,C['muted'])+self.txt(w-40,40,'PLACEHOLDER · 待 P25 / P30 / P37 复核',16,C['primary'],anchor='end')+self.txt(w-40,hh-26,num,16,C['muted'],anchor='end')
    def save(self,id,title,w,hh,body,scales=[1],base=None):
        rel='art/ui/source/boards/'+id+'.svg';out=self.root/rel;out.parent.mkdir(parents=True,exist_ok=True)
        if base is None:body=svg(w,hh,body,title,{'kind':'STATIC_VISUAL_SAMPLE','lifecycle':'PLACEHOLDER','game_execution':False})
        root=ET.fromstring(body)
        defs=ET.Element('{'+NS+'}defs');style=ET.SubElement(defs,'{'+NS+'}style')
        style.text='@font-face{font-family:"Noto Sans SC Thin";src:url("../fonts/noto-sans-sc-chinese-simplified-400-normal.woff2") format("woff2");font-weight:400}@font-face{font-family:"Noto Sans JP Thin";src:url("../fonts/noto-sans-jp-japanese-400-normal.woff2") format("woff2");font-weight:400}@font-face{font-family:"DejaVu Sans";src:url("../fonts/DejaVuSans.ttf") format("truetype");font-weight:400}'
        root.insert(0,defs)
        for i,e in enumerate(root.iter('{'+NS+'}text')):e.set('id',f'p24_text_{i:04d}')
        out.write_text(ET.tostring(root,encoding='unicode')+'\n')
        exports=[{'scale':sc,'relative_path':'art/ui/exports/previews/'+id+('' if sc==1 else '_'+str(int(sc*100)))+'.png'} for sc in scales]
        self.items.append({'preview_id':id,'title':title,'svg_relative_path':rel,'exports':exports,'board_size':[w,hh],
          'kind':'STATIC_DESIGN_NOT_RUNTIME','lifecycle':'PLACEHOLDER','source_asset_ids':sorted(set(self.uses)),'base_wireframe':base})
        self.uses=[]

    def states(self):
        w,hh=1600,1200;b=self.title(w,hh,'01 / 07','组件状态 · 同一套视觉语言','六种基础状态；冰蓝色焦点层独立叠加。所有标签均由界面层显示，切图本身不含文字。')
        for j,s in enumerate(STATES):b+=self.txt(335+220*j,178,STATE_ZH[s],20,anchor='middle')
        rows=[('button.primary','主要按钮',220,48),('button.secondary','次要按钮',312,48),('button.navigation','导航按钮',404,48),('frame.hand','手牌卡框',508,148),('frame.enemy','敌方卡框',716,112)]
        for family,label,y,ht in rows:
            b+=self.txt(40,y+27,label,20)+self.txt(40,y+53,family,16,C['muted'])
            for j,s in enumerate(STATES):
                ww=200 if family.startswith('frame') else (200 if 'navigation' in family else 180);x=235+220*j
                if family.startswith('frame'):
                    a=self.assets['p24.ui.'+family+'.'+s];data,aid=self.data(family,s)
                    b+=f'<image x="{x}" y="{y}" width="{ww}" height="{ht}" href="{data}" data-asset-id="{aid}"/>';self.uses.append(aid)
                    b+=self.txt(x+14,y+35,'视觉占位',18)
                    b+=self.txt(x+14,y+67,'PLACEHOLDER',16,C['muted'])
                else:
                    b+=self.asset(family,s,x,y,ww,ht)
                    col=self.assets['p24.ui.'+family+'.'+s]['label_color'];b+=self.txt(x+ww/2,y+31,'继续 / 確認',18,col,anchor='middle')
        b+=path('M40 871 H1560',C['line'],1)
        b+=self.txt(40,917,'焦点不是选中；禁用也保留可读原因',24)
        for j,(st,lab) in enumerate([('default','可操作 + 焦点'),('selected','已选中 + 焦点'),('disabled','禁用 + 原因详情可达')]):
            x=40+j*490;b+=self.asset('button.secondary',st,x,956,240,56)+self.asset('focus.button','active',x,956,240,56)+self.txt(x+120,991,'查看详情',18,anchor='middle')+self.txt(x,1044,lab,18,C['muted'])
        b+=self.txt(40,1128,'金色双框 + 勾号 = 已选中    /    冰蓝连续外框 = 当前输入焦点    /    虚线 + 斜杠 = 禁用',20)
        self.save('P24_Component_States','组件状态图',w,hh,b)

    def icons(self):
        labels={'attack':'攻击','shield':'护盾','heal':'治疗','buff':'增益','energy':'费用','draw':'抽牌堆','discard':'弃牌堆','remove':'移除区','intent':'行动意图','unknown':'未知','locked':'不可操作','check':'已确认','warning':'需要注意','error':'操作错误','pending':'待核对','connected':'连接可用','disconnected':'未连接','details':'详情','target':'目标','turn':'回合','book':'学习记录','grammar':'语法','sentence':'整句','currency':'资源'}
        w,hh=1440,1040;b=self.title(w,hh,'02 / 07','图标与费用 · 形状也能传达含义','24 个原创几何图标；32px / 64px 透明导出。图标必须配文字，不独自证明奖励到账。')
        for i,(k,label) in enumerate(labels.items()):
            x=40+(i%6)*228;y=164+(i//6)*172
            b+=rect(x,y,212,156,C['surface'],r=10)
            b+=self.asset('icon.'+k,'default',x+28,y+20,48,48)+self.asset('icon.'+k,'disabled',x+136,y+31,32,32)
            b+=self.txt(x+18,y+105,label,20)+self.txt(x+18,y+134,k,16,C['muted'])
        b+=self.txt(40,908,'费用徽章',22)
        for i,s in enumerate(STATES+['unknown']):
            x=230+i*160;b+=self.asset('cost.badge',s,x,866);col=self.assets['p24.ui.cost.badge.'+s]['label_color'];b+=self.txt(x+20,894,'?' if s=='unknown' else '2',24,col,anchor='middle');b+=self.txt(x+20,940,STATE_ZH[s],18,anchor='middle')
        b+=self.txt(40,995,'连接图标、记录状态和钱包证明分别展示；pending / unknown 不替换成成功勾号。',18,C['muted'])
        self.save('P24_Icons_Cost','图标与费用',w,hh,b)

    def reskin(self,sid,outid,title):
        src=next((self.root/'art/ui/evidence/upstream'/sid).glob('*.svg'));rt=ET.fromstring(src.read_text());text_parent_colors={}
        for defs in list(rt.findall('{'+NS+'}defs')):rt.remove(defs)
        original_texts=[];replaced=[]
        for i,e in enumerate(list(rt)):
            tag=e.tag.split('}')[-1]
            if tag=='rect':
                x=float(e.get('x','0'));y=float(e.get('y','0'));w=float(e.get('width','0'));hh=float(e.get('height','0'));anchor=e.get('data-anchor-id','');reg=e.get('data-region','');origfill=e.get('fill')
                fam=st=None
                if x==0 and y==0 and w==1280 and hh==856:e.set('fill',C['canvas']);continue
                if x==0 and y==0 and hh==48:e.set('fill',C['surface']);continue
                if reg=='focus_indicator':fam='focus.button';st='active'
                elif reg=='selection_indicator':e.set('stroke',C['gold']);e.set('stroke-width','2');continue
                elif anchor.startswith('ux.battle.hand.'):
                    fam='frame.hand';st='disabled' if 'stroke-dasharray' in e.attrib else ('selected' if e.get('stroke-width')=='2' else 'default')
                elif anchor.startswith('ux.battle.enemy.'):fam='frame.enemy';st='selected' if sid=='P23_W02' else 'default'
                elif hh==92 and w==78:fam='card.art_window';st='default'
                elif hh==12 and w==310:fam='bar.hp_track';st='default'
                elif hh==12 and 0<w<310:
                    # Source wireframe's fixture ratio only; never used by runtime.
                    length=round((w/310)*304);data,aid=self.data('bar.hp_fill','default',(length,6));e.tag='{'+NS+'}image';e.attrib={'x':str(x+3),'y':str(y+3),'width':str(length),'height':'6','href':data,'data-asset-id':aid};self.uses.append(aid);continue
                elif e.get('data-control')=='true':
                    if anchor.startswith('ux.nav.'):
                        fam='button.navigation';st='selected' if origfill=='#1b2635' else 'default'
                    else:
                        fam='button.primary' if origfill=='#1b2635' else 'button.secondary'
                        st='disabled' if 'stroke-dasharray' in e.attrib else 'default'
                        if origfill=='#1b2635':text_parent_colors[(x,y,w,hh)]=C['ink']
                elif w>=90 and hh>=36:
                    fam='panel.surface';st='pending' if sid=='P23_W10' and y<260 and w>500 else 'default'
                if fam:
                    a=self.assets['p24.ui.'+fam+'.'+st]
                    if a['nine_slice_ltrb_1x'] and (w<sum(a['nine_slice_ltrb_1x'][::2]) or hh<sum(a['nine_slice_ltrb_1x'][1::2])):
                        e.set('fill',C['surface']);e.set('stroke',C['line']);continue
                    data,aid=self.data(fam,st,(round(w),round(hh)));attrs={'x':str(x),'y':str(y),'width':str(w),'height':str(hh),'href':data,'data-asset-id':aid}
                    for k,v in e.attrib.items():
                        if k.startswith('data-'):attrs[k]=v
                    e.tag='{'+NS+'}image';e.attrib=attrs;self.uses.append(aid);replaced.append({'anchor':anchor,'asset_id':aid,'source_rect':[x,y,w,hh]})
                else:
                    if e.get('fill')!='none':e.set('fill',C['surface'])
                    if e.get('stroke')!='none':e.set('stroke',C['line'])
            elif tag=='text':
                y=float(e.get('y','0'));x=float(e.get('x','0'));size=float(e.get('font-size','18'))
                if 48<=y<768:original_texts.append(e.text)
                if y<48:
                    e.text='P24 / '+title if x<900 else 'PLACEHOLDER · 静态资产样例'
                if y>=768:
                    e.text=('基于 P23 最终线框的视觉换肤；名称与数值为设计夹具；目标引擎与实际 DPI 未测试。' if y<805 else 'P14 保持业务权威；P19/P20 负责文字与输入；P24 只提供视觉资产。')
                e.set('fill',C['text'] if e.get('fill')!='#445266' else C['muted'])
                for (px,py,pw,ph),color in text_parent_colors.items():
                    if px<=x<px+pw and py<=y<py+ph:e.set('fill',color)
                e.set('font-family','Noto Sans JP Thin,DejaVu Sans' if e.get('lang')=='ja' else 'Noto Sans SC Thin,Noto Sans JP Thin,DejaVu Sans')
                e.set('font-weight','400');e.attrib.pop('dominant-baseline',None);e.set('y',str(round(y+size*.88,2)))
            elif tag=='line':e.set('stroke',C['line'])
        dump(self.root/'art/ui/evidence/layout'/f'{outid}_mapping.json',{'source_sha256':h(src),'base_file':str(src.relative_to(self.root)),'original_ui_strings':original_texts,'replaced_shapes':replaced,'interaction_changes':False,'ui_rect':[0,48,1280,720]})
        self.save(outid,title,1280,856,ET.tostring(rt,encoding='unicode'),base={'source_id':sid,'sha256':h(src),'ui_geometry':'PRESERVED','new_runtime_code':False})

    def geometry(self):
        w,hh=1440,1000;b=self.title(w,hh,'05 / 07','安全区与层次 · 为文字和立绘留位置','手牌框 236×174；敌方信息框 350×196；立绘窗口 78×92。红/青辅助线只出现在规范图。')
        b+=self.txt(40,190,'手牌框 · 逻辑 1×',22)+self.asset('frame.hand','selected',40,218)
        b+=rect(54,232,208,146,'none',C['focus'],1,extra='stroke-dasharray="4 3"')
        b+=self.txt(56,264,'标题区',20)+self.txt(56,306,'规则文字独立显示',18)+self.txt(56,350,'归属 / 不可用原因',16,C['muted'])
        b+=self.txt(330,190,'敌方信息框 · 逻辑 1×',22)+self.asset('frame.enemy','default',330,218)
        b+=self.asset('card.art_window','default',350,234)
        b+=rect(358,242,62,76,'none',C['focus'],1,extra='stroke-dasharray="4 3"')
        b+=self.txt(442,265,'立绘由 P27 提供',20)+self.txt(442,300,'生命 12 / 18',20)+self.txt(442,334,'护盾 0',20)
        b+=self.asset('bar.hp_track','default',350,367)+self.asset('bar.hp_fill','default',353,370,203,6)
        b+=self.txt(350,402,'外框不侵入标题、生命和意图。',18,C['muted'])
        b+=self.txt(760,190,'卡背 · 不承载未知牌面内容',22)+self.asset('card.back','default',760,218)+self.asset('card.back','disabled',1052,218)
        b+=self.txt(40,475,'血条是切图层；生命数值来自权威视图',24)
        for i,(ratio,label,fill) in enumerate([(1,'生命 18 / 18','default'),(2/3,'生命 12 / 18','default'),(.2,'生命 4 / 20（视觉夹具）','low'),(0,'生命 0 / 18 · 已倒下','default')]):
            x=40+i*345;y=514;b+=self.txt(x,y,label,18)+self.asset('bar.hp_track','empty' if ratio==0 else 'default',x,y+20)
            if ratio:
                # Drawing a static test fixture, not a game data binding.
                b+=self.asset('bar.hp_fill',fill,x+3,y+23,round(304*ratio),6)
        b+=self.txt(40,619,'未知状态',20)+self.asset('bar.hp_track','unknown',40,640)+self.txt(40,688,'生命未知；不显示假的填充百分比。',18,C['muted'])
        b+=self.txt(414,619,'护盾独立显示',20)+self.asset('bar.shield_fill','default',414,643)+self.txt(414,688,'护盾 3；不会把护盾并入生命最大值。',18,C['muted'])
        b+=rect(40,742,1360,174,C['surface'],r=12)
        for i,t in enumerate(['文本安全区：手牌内缩 14px；费用 40px 徽章中心只放当前值，不烘焙数字。',
                               '立绘安全区：窗口透明孔为 (8,8,62,76)；仅占位测量，最终人脸/发型裁切等待 P25。',
                               '外发切图：保持透明画布、原点和 pivot；不自动裁边、不旋转；Atlas 外扩由 P30 实测。',
                               '低生命颜色仅供表现层使用；P24 不定义生命阈值，不生成战斗计算或状态变化。']):b+=self.txt(62,779+i*34,t,18,C['muted'])
        self.save('P24_Geometry_SafeAreas','安全区与层次',w,hh,b)

    def typography(self):
        w,hh=1280,856;b=self.title(w,hh,'06 / 07','中日混排与字号 · 独立文字层','正文 18px；关键状态 20px。此图另有 125% / 150% / 200% 静态像素密度导出。')
        blocks=[(40,'中文 · 关键状态','攻击前排　基础 12 × 2 次','目标：锋刃位 A','生命 128 / 160　护盾 +8','zh-Hans'),
                (660,'日本語 · 重要情報','前列を攻撃　基礎値 12 × 2 回','対象：前衛 A','HP 128 / 160　シールド +8','ja')]
        for x,head,line1,line2,line3,lang in blocks:
            b+=rect(x,163,580,220,C['surface'],C['line'],1,10)+self.txt(x+24,203,head,22,lang=lang)
            for i,t in enumerate([line1,line2,line3]):b+=self.txt(x+24,249+i*47,t,20,lang=lang)
        b+=rect(40,409,1200,150,C['surface'],C['line'],1,10)
        b+=self.txt(64,448,'长名称与括号读音（原 UTF-8 保持不变）',22)
        b+=self.txt(64,491,'星のあいだに置き忘れた観測記録と三度目の夜明',20,lang='ja')
        b+=self.txt(64,532,'語彙（ごい） ／ 取り消す（とりけす）　「確認しました」',18,lang='ja')
        b+=rect(40,587,1200,166,'#392F27',C['warning'],1,10)
        b+=self.txt(64,629,'待核对 · 已隔离',20,C['warning'])+self.txt(64,666,'该记录尚未计入可用奖励。连接可用不代表奖励已经到账。',18)
        b+=self.txt(64,705,'缺字候选：[缺字 U+20BB7]　[缺字 U+F0000]；原字符仅留在原始测试夹具。',18,C['muted'])
        b+=self.txt(40,806,'本图验证静态导出与字形覆盖；真实引擎塑形、200% 重排、键盘和屏幕阅读器测试均为 NOT_RUN。',16,C['muted'])
        self.save('P24_Typography_Scale','中日混排与字号',w,hh,b,[1,1.25,1.5,2])

    def alpha(self):
        w,hh=1440,1040;b=self.title(w,hh,'07 / 07','透明通道与九宫格 · 保持边角不变','同一 PNG 在深色、浅色和棋盘背景下检查；所有组件导出为 RGBA8，保留未关联 alpha。')
        for j,bg in enumerate([C['canvas'],'#F4F0E8','checker']):
            x=40+j*460;y=170;b+=rect(x,y,440,245,bg if bg!='checker' else '#bfc1c9',r=10)
            if bg=='checker':
                for yy in range(0,240,20):
                    for xx in range(0,440,20):
                        if (xx//20+yy//20)%2==0:b+=rect(x+xx,y+yy,20,20,'#e5e6eb')
            b+=self.asset('card.art_window','default',x+26,y+30)+self.asset('icon.attack','default',x+140,y+60,64,64)+self.asset('cost.badge','selected',x+240,y+63,64,64)
            b+=self.asset('button.primary','default',x+20,y+159,400,56)+self.txt(x+220,y+194,'确认出牌',20,C['ink'],anchor='middle')
            b+=self.txt(x+20,y+231,['深色基底','浅色仅用于 alpha 检查','棋盘格仅用于 alpha 检查'][j],16,C['muted'] if j==0 else C['ink'])
        b+=self.txt(40,477,'九宫格 1×：left / top / right / bottom = 24 / 18 / 24 / 18',22)
        for i,(ww,ht) in enumerate([(180,48),(320,48),(640,72)]):
            y=516+i*119;b+=self.asset('button.secondary','selected',40,y,ww,ht)+self.asset('focus.button','active',40,y,ww,ht)+self.txt(40+ww/2,y+ht/2+7,'确认 / 確認',18,anchor='middle')
            b+=self.txt(ww+76,y+ht/2+7,f'{ww} × {ht} · 边角像素不缩放',18,C['muted'])
        b+=self.txt(40,944,'2× 边界乘 2；零生命不绘制 fill；未知生命用独立图纹和文字。文字永远不参与九宫格。',20)
        self.save('P24_Alpha_NineSlice','透明与九宫格',w,hh,b)

    def run(self):
        self.states();self.icons();self.reskin('P23_W02','P24_Battle_Target_1280','战斗 · 目标确认');self.reskin('P23_W10','P24_Learning_Quarantine_1280','学习 · 待核对');self.geometry();self.typography();self.alpha()
        dump(self.root/'art/ui/preview_catalog.json',{'version':'P24-PREVIEW-INDEX/0.1.0','game_ui_implemented':False,'items':self.items})

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('root',type=Path);n=a.parse_args();Boards(n.root).run();print('7 editable static boards generated; 10 PNG previews scheduled.')
