#!/usr/bin/env python3
"""Build a candidate inventory outside the package. Installing it creates a new package version.
The top-level manifest excludes itself; its bytes must be bound by an external receipt.
"""
import argparse, hashlib, json, mimetypes
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root):ap.error('output must be a new file outside root')
    source=json.loads((root/'source_input_receipt.json').read_text());by_path={s['package_relative_path']:s for s in source['sources']};by_id={s['source_id']:s for s in source['sources']}
    base=[{'source_id':i,'sha256':by_id[i]['sha256']} for i in ['V6_ROLES','P01_REQ','P23_ANCHOR','P24_STYLE']]
    files=[]
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p==root/'delivery_manifest.json':continue
        rel=p.relative_to(root).as_posix();h=sha(p);up=rel.startswith('asset_visual_reviews/evidence/upstream/');upload='/uploaded_previews/' in rel
        owner='P25';deps=list(base);kind='P25_ISOLATED_ART_DIRECTION_OR_REVIEW';version='P25-ART-BIBLE/0.1.0';receivers=['P24','P26','P27','P28','P30','P35']
        if up or upload:
            kind='IMMUTABLE_UPSTREAM_EVIDENCE_COPY';owner='P24' if '/upstream/P24/' in rel else 'UPSTREAM_ORIGINAL_OWNER';version='original bytes; source_input_receipt or nested original manifest'
            deps=[{'source_id':'ORIGINAL_INPUT_BYTES','sha256':h}];receivers=['P25','P35','P37']
            if rel in by_path:
                sid=by_path[rel]['source_id'];deps=[{'source_id':sid,'sha256':by_path[rel]['sha256']}];owner=sid.split('_')[0] if sid.startswith('P') else 'V6_ORIGINAL_SOURCE'
            elif upload:owner=p.name.split('_')[0]
        elif p.suffix=='.png' and p.with_suffix('.svg').is_file():
            deps.append({'source_id':'P25_EDITABLE_VECTOR_SOURCE','sha256':sha(p.with_suffix('.svg'))})
        elif p.suffix in ['.svg','.ora']:
            deps.append({'source_id':'P25_VISUAL_GENERATOR','sha256':sha(root/'validation/build_review_visuals.py')})
        ext=p.suffix.lower();fmt={'.md':'text/markdown','.tsv':'text/tab-separated-values','.json':'application/json','.svg':'image/svg+xml','.ora':'image/openraster','.woff2':'font/woff2','.ttf':'font/ttf','.py':'text/x-python'}.get(ext,mimetypes.guess_type(str(p))[0] or 'application/octet-stream')
        format_version={'.png':'PNG (actual IHDR recorded in asset or render evidence)','.svg':'SVG 1.1','.ora':'OpenRaster 0.0.3 container; TEMPLATE_NOT_ART','.py':'Python 3.12 tested','.md':'UTF-8 Markdown','.tsv':'UTF-8 TSV','.json':'UTF-8 JSON'}.get(ext,ext.lstrip('.') or 'unversioned original bytes')
        files.append({'relative_path':rel,'size_bytes':p.stat().st_size,'sha256':h,'format':fmt,'format_version':format_version,'version':version,'owner':owner,'artifact_role':kind,'source_input_hashes':deps,'receivers':receivers,'modification_allowlist':[] if up or upload else [{'role':'P25','package_relative_path':rel,'scope':'isolated P25 revision only; preserve prior base hash'}],'actual_production_path':None,'production_write_allowed':False})
    m={'schema_version':'P25-DELIVERY-MANIFEST/0.1.0','task_id':'P25-PRE-S03-ART-001','version':'P25-ART-BIBLE/0.1.0','listed_file_count':len(files),'total_package_file_count':len(files)+1,'self_exclusion':'Only this top-level delivery_manifest.json is excluded; external receipt binds it and the final ZIP. All nested upstream manifests are included.','files':files}
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({'files':len(files),'output':str(out)},ensure_ascii=False))
if __name__=='__main__':main()
