/** P24 author-only SVG/PNG exporter. Never loads game or remote code. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
const args=process.argv.slice(2);
const val=k=>{let i=args.indexOf(k);if(i<0||!args[i+1])throw new Error('Missing '+k);return args[i+1]};
const root=path.resolve(val('--root')),output=path.resolve(val('--output')),fonts=path.resolve(val('--fonts'));
if(fs.existsSync(output))throw new Error('Refuse existing output');
if(output===root||output.startsWith(root+path.sep))throw new Error('Output must be outside package');
process.env.FONTCONFIG_FILE=fonts;
const require=createRequire(import.meta.url);
const sharp=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES?path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'sharp'):'sharp');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const mode=val('--mode');
const catalog=JSON.parse(fs.readFileSync(path.join(root,mode==='assets'?'art/ui/asset_catalog.json':'art/ui/preview_catalog.json'),'utf8'));
fs.mkdirSync(output,{recursive:true});
const report={layer:'AUTHOR_STATIC_VISUAL_RENDER',mode,engine:sharp.versions,argv:process.argv.slice(2),started_utc:new Date().toISOString(),runtime_game_executed:false,cases:[],errors:[]};
try{
 if(mode==='assets'){
  for(const item of catalog.assets){
   const src=fs.readFileSync(path.join(root,item.source_relative_path));
   for(const e of item.exports){
    const dest=path.join(output,e.relative_path);fs.mkdirSync(path.dirname(dest),{recursive:true});
    const png=await sharp(src,{density:72*e.density}).ensureAlpha().toColorspace('srgb').png({compressionLevel:9,adaptiveFiltering:false,palette:false}).toBuffer();
    fs.writeFileSync(dest,png);const m=await sharp(png).metadata();
    report.cases.push({asset_id:item.asset_id,density:e.density,source_sha256:sha(src),relative_path:e.relative_path,sha256:sha(png),size_bytes:png.length,width:m.width,height:m.height,channels:m.channels,has_alpha:m.hasAlpha,status:'PASS'});
   }
  }
 }else if(mode==='boards'){
  for(const item of catalog.items){
   const src=fs.readFileSync(path.join(root,item.svg_relative_path));
   for(const e of item.exports){
    const dest=path.join(output,e.relative_path);fs.mkdirSync(path.dirname(dest),{recursive:true});
    const png=await sharp(src,{density:72*e.scale}).ensureAlpha().toColorspace('srgb').png({compressionLevel:9,adaptiveFiltering:false,palette:false}).toBuffer();
    fs.writeFileSync(dest,png);const m=await sharp(png).metadata();
    report.cases.push({preview_id:item.preview_id,scale:e.scale,source_sha256:sha(src),relative_path:e.relative_path,sha256:sha(png),size_bytes:png.length,width:m.width,height:m.height,status:'PASS'});
   }
  }
 }else throw new Error('Unknown mode '+mode);
}catch(e){report.errors.push(String(e.stack||e));process.exitCode=2}
report.ended_utc=new Date().toISOString();
report.status=report.errors.length?'FAIL':'PASS';
fs.writeFileSync(path.join(output,'render_results.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,mode,cases:report.cases.length,errors:report.errors}));
