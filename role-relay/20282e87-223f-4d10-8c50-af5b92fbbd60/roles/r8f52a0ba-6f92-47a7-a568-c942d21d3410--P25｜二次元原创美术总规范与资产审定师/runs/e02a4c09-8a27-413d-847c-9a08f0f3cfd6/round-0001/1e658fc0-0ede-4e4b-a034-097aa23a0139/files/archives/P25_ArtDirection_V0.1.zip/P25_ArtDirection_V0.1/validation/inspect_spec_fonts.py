#!/usr/bin/env python3
"""Check the actual specification text against locally decoded font cmap tables.
Uses the already supplied P24 Node Brotli helper; never downloads or installs fonts.
"""
import argparse,datetime,hashlib,json,subprocess,sys
from pathlib import Path
import xml.etree.ElementTree as ET
from fontTools.ttLib import TTFont

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root):ap.error('output must be new and outside root')
    out.mkdir(parents=True);p24=root/'asset_visual_reviews/evidence/upstream/P24';fonts=out/'temporary_fonts'
    cmd=[sys.executable,'-B',str(p24/'art/ui/validation/prepare_fonts.py'),str(p24/'art/ui/source/fonts'),str(fonts)]
    result=subprocess.run(cmd,capture_output=True,text=True);(out/'decoder_stdout.txt').write_text(result.stdout);(out/'decoder_stderr.txt').write_text(result.stderr)
    if result.returncode:raise RuntimeError('Local font decoder failed; see raw logs')
    conversion=json.loads((fonts/'conversion.json').read_text());coverage=set()
    for e in conversion['fonts']:
        p=fonts/e['sfnt'];assert sha(p)==e['sfnt_sha256'];f=TTFont(p);coverage.update((f.getBestCmap() or {}).keys())
    files=[];chars=set()
    paths=list((root/'art_direction/boards').glob('*.svg'))+list((root/'asset_visual_reviews/boards').glob('*.svg'))+[root/'art_direction/templates/portrait_crop_guide.svg']
    for p in paths:
        rt=ET.parse(p).getroot();text=''.join(''.join(e.itertext()) for e in rt.iter('{http://www.w3.org/2000/svg}text'));chars.update(ord(c) for c in text if not c.isspace());files.append({'path':str(p.relative_to(root)),'sha256':sha(p)})
    missing=sorted(chars-coverage);data={'layer':'P25_SPECIFICATION_FONT_COVERAGE','status':'FAIL' if missing else 'PASS','executed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool_sha256':sha(Path(__file__)),'files':files,'font_conversion':conversion,'unique_visible_codepoints':len(chars),'missing_codepoints':[{'codepoint':f'U+{c:04X}','character':chr(c)} for c in missing],'limitation':'cmap coverage only; not shaping, native-editor/engine import, display-device or permission approval','exit_code':2 if missing else 0}
    (out/'font_coverage.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':data['status'],'characters':len(chars),'missing':len(missing)},ensure_ascii=False));sys.exit(data['exit_code'])
if __name__=='__main__':main()
