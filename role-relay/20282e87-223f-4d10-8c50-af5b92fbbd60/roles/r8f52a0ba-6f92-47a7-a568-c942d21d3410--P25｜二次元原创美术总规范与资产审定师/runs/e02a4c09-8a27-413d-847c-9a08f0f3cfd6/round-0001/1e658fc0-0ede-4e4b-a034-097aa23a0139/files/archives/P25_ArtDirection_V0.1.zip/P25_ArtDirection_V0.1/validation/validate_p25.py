#!/usr/bin/env python3
"""Read-only integrity and static-art checks. Does not approve game, rights or artwork.
Exit: 0 static PASS, 2 FAIL, 3 formal preflight BLOCKED. Output must be new/outside root.
"""
import argparse, csv, datetime, hashlib, io, json, platform, sys, zipfile
from pathlib import Path, PurePosixPath
from html.parser import HTMLParser
from urllib.parse import unquote, urlsplit
import xml.etree.ElementTree as ET
from PIL import Image

VERSION = 'P25-VALIDATOR/0.1.0'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def readj(path): return json.loads(path.read_text(encoding='utf-8'))
def require(condition, message):
    if not condition: raise ValueError(message)
def safe(root, relative):
    require(isinstance(relative,str) and relative and '\\' not in relative,'invalid relative path')
    p=PurePosixPath(relative)
    require(not p.is_absolute() and '..' not in p.parts,'path escape rejected: '+relative)
    result=(root/relative).resolve()
    require(result.is_relative_to(root.resolve()),'resolved path escape rejected: '+relative)
    require(not (root/relative).is_symlink(),'symlink rejected: '+relative)
    return result

def matching(root, record, key='relative_path'):
    p=safe(root,record[key]);require(p.is_file(),'missing file: '+record[key])
    require(p.stat().st_size==record['size_bytes'],'size mismatch: '+record[key])
    require(sha(p)==record['sha256'],'hash mismatch: '+record[key]);return p

def rows(path):
    with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))

class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k in ('src','href') and v:self.links.append(v)

def validate(root):
    checks=[]
    def run(ident,fn):
        try: detail=fn();checks.append({'id':ident,'status':'PASS','detail':detail})
        except Exception as exc:checks.append({'id':ident,'status':'FAIL','error':str(exc)})
    p24=root/'asset_visual_reviews/evidence/upstream/P24'
    def essential():
        names=['README.md','P25_delivery_report.md','P25_review_index.html','source_input_receipt.json','actual_path_request.json','interface_rfcs.json','blocker_register.json','verification_status.json','art_direction/style_bible.md','art_direction/character_brief_template.md','art_direction/layer_export_spec.md','art_direction/sample_acceptance.tsv','art_direction/sample_submission_template.json','asset_visual_reviews/P24_review.md','asset_visual_reviews/P24_asset_reviews.tsv','asset_visual_reviews/issue_register.tsv','asset_visual_reviews/formal_asset_register.json','asset_visual_reviews/sample_gate.json','validation/inspect_sample.py']
        for n in names:require(safe(root,n).is_file(),'missing required artifact: '+n)
        return {'required_files':len(names)}
    run('P25-V01_REQUIRED_ARTIFACTS',essential)
    def manifest():
        m=readj(root/'delivery_manifest.json');seen=set()
        for e in m['files']:
            require(e['relative_path'] not in seen,'duplicate manifest path');seen.add(e['relative_path']);matching(root,e)
            for k in ['format','format_version','version','owner','source_input_hashes','receivers','modification_allowlist']:
                require(k in e,'missing provenance field: '+k)
            require(e.get('production_write_allowed') is False,'production writing authorized by local manifest')
            require(len(e['source_input_hashes'])>0,'missing source input hash')
            for s in e['source_input_hashes']:require(len(s['sha256'])==64,'invalid source hash')
        # Only the top-level manifest is excluded, not upstream manifests with the same basename.
        actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=root/'delivery_manifest.json'}
        require(actual==seen,'manifest file-set mismatch: '+repr(sorted(actual^seen)[:12]))
        require(m['listed_file_count']==len(seen),'manifest declared count differs')
        return {'listed_files':len(seen),'excluded':'delivery_manifest.json'}
    run('P25-V02_DELIVERY_INTEGRITY',manifest)
    def inputs():
        ss=readj(root/'source_input_receipt.json')['sources'];ids=set()
        for e in ss:
            require(e['source_id'] not in ids,'duplicate source id');ids.add(e['source_id']);matching(root,e,'package_relative_path')
        require(len(ss)==23,'expected 23 direct pinned inputs')
        return {'direct_inputs':len(ss)}
    run('P25-V03_INPUT_RECEIPTS',inputs)
    def snapshot():
        m=readj(p24/'delivery_manifest.json')
        for e in m['files']:matching(p24,e)
        n=sum(p.is_file() for p in p24.rglob('*'));require(n==436,'P24 snapshot file count changed')
        return {'files':n,'hash_verified_entries':len(m['files'])}
    run('P25-V04_P24_IMMUTABLE_SNAPSHOT',snapshot)
    def review():
        a=readj(p24/'ui_visual_export_manifest.json')['assets'];rr=rows(root/'asset_visual_reviews/P24_asset_reviews.tsv')
        require(len(rr)==105 and len({x['asset_id'] for x in rr})==105,'review rows missing/duplicated')
        require({x['asset_id'] for x in a}=={x['asset_id'] for x in rr},'review ID coverage differs')
        byid={x['asset_id']:x for x in rr}
        for x in a:
            r=byid[x['asset_id']];matching(p24,x['source'])
            require(r['source_sha256']==x['source']['sha256'],'review source hash differs')
            require(r['png_1x_sha256']==x['exports'][0]['sha256'] and r['png_2x_sha256']==x['exports'][1]['sha256'],'review export hash differs')
            require(r['reviewer']=='P25' and r['repair_owner']=='P24','role authority differs')
            require(r['formal_asset_status']=='BLOCKED','placeholder promoted in review')
            require(safe(root,r['visual_evidence']).is_file(),'missing visual evidence')
        return {'review_rows':len(rr)}
    run('P25-V05_REVIEW_COVERAGE',review)
    def pngs():
        n=0
        for a in readj(p24/'ui_visual_export_manifest.json')['assets']:
            for e in a['exports']:
                p=safe(p24,e['relative_path']);b=p.read_bytes()
                with Image.open(p) as im:
                    im.load();require(im.format=='PNG' and im.mode=='RGBA','PNG must be RGBA: '+str(p))
                    require(list(im.size)==e['dimensions'],'incorrect PNG dimensions')
                    require(b[24]==8 and b[25]==6,'PNG IHDR must be 8-bit truecolor+alpha')
                n+=1
        require(n==210,'PNG count differs');return {'rgba8_pngs':n}
    run('P25-V06_PNG_DIMENSION_ALPHA',pngs)
    def apertures():
        count=0
        for a in readj(p24/'ui_visual_export_manifest.json')['assets']:
            if a['family']!='card.art_window':continue
            for e in a['exports']:
                d=e['density']
                with Image.open(safe(p24,e['relative_path'])) as im:
                    aa=im.getchannel('A').crop((8*d,8*d,70*d,84*d));require(aa.getextrema()==(0,0),'portrait aperture alpha is nonzero')
                count+=1
        require(count==6,'expected six transparent apertures');return count
    run('P25-V07_TRANSPARENT_WINDOWS',apertures)
    def promotion():
        for a in readj(p24/'ui_visual_export_manifest.json')['assets']:
            require(a['lifecycle']=='PLACEHOLDER' and a['production_allowed'] is False,'P24 placeholder promoted')
        f=readj(root/'asset_visual_reviews/formal_asset_register.json');g=readj(root/'asset_visual_reviews/sample_gate.json')
        require(f['formal_asset_count']==0 and f['assets']==[],'formal assets invented')
        require(g['sample_received'] is False and g['mass_production_allowed'] is False and g['production_allowed'] is False,'missing sample gate opened')
        return '105 placeholders remain placeholders; formal assets=0; one-sample and batch gates closed'
    run('P25-V08_NO_PLACEHOLDER_PROMOTION',promotion)
    def crops():
        x=readj(root/'art_direction/crop_profiles.json');ids=set()
        for p in x['profiles']:
            require(p['id'] not in ids,'duplicate profile');ids.add(p['id']);w,h=p['canvas_px']
            require(w>0 and h>0 and int(w)==w and int(h)==h,'invalid canvas')
            require(p['production_allowed'] is False,'crop contract self-approved')
            for key,value in p.items():
                if key.endswith('_rect_px'):
                    xx,yy,ww,hh=value;require(xx>=0 and yy>=0 and ww>0 and hh>0 and xx+ww<=w and yy+hh<=h,'out-of-bounds rectangle '+p['id']+'/'+key)
                if key.endswith('_rect_normalized'):
                    xx,yy,ww,hh=value;require(xx>=0 and yy>=0 and ww>0 and hh>0 and xx+ww<=1 and yy+hh<=1,'invalid normalized rectangle')
            if 'logical_slot_px' in p:require([v*p['density'] for v in p['logical_slot_px']]==p['canvas_px'],'density/slot mismatch')
        require(len(ids)==8,'profile count differs');require(x['hand_frame']['art_slot'] is None,'unapproved hand art slot')
        require(x['actual_ui_rect_px']==[0,48,1280,720],'P23 coordinate base drift')
        return {'bounded_profiles':len(ids),'hand_art_slot':'UNAPPROVED'}
    run('P25-V09_CROP_BOUNDS',crops)
    def sample_truth():
        rr=rows(root/'art_direction/sample_acceptance.tsv');require(len(rr)==42,'expected 42 criteria')
        require(len({x['criterion_id'] for x in rr})==42,'duplicate criterion')
        for r in rr:
            require(r['sample_id']=='NOT_RECEIVED','unexpected actual sample ID in this frozen release')
            require(r['author_selfcheck']=='NOT_RUN' and r['p25_review_status'] in ['NOT_RUN','BLOCKED'],'unperformed sample test claimed PASS')
        return {'criteria':42,'actual_character_review':'NOT_RUN'}
    run('P25-V10_SAMPLE_EVIDENCE_TRUTH',sample_truth)
    def renders():
        r=readj(root/'asset_visual_reviews/evidence/render_results.json');require(len(r['records'])==7,'expected seven SVG/PNG pairs')
        for e in r['records']:
            p=safe(root,e['source_path']);q=safe(root,e['png_path']);require(sha(p)==e['source_sha256'] and sha(q)==e['png_sha256'],'render source/output hash differs')
            rt=ET.parse(p).getroot();md=rt.find('{http://www.w3.org/2000/svg}metadata');require(md is not None and json.loads(md.text)['production_allowed'] is False,'specification graphic lacks status')
            with Image.open(q) as im:require(list(im.size)==e['dimensions'],'render dimensions differ')
            require(e['exit_code']==0,'recorded renderer failed')
        return {'pairs':7,'scope':'specification diagrams and contact sheets, not game runtime'}
    run('P25-V11_RENDER_PROVENANCE',renders)
    def contacts():
        records=[]
        for page in range(3):
            with Image.open(root/f'asset_visual_reviews/boards/P25_P24_Contact_{page+1:02d}.png') as raw:im=raw.convert('RGB')
            for i in range(35):
                x=40+i%5*312;y=168+i//5*210
                reg=im.crop((x+12,y+12,x+286,y+144));different=sum(c!=(32,37,53) for c in reg.getdata())
                require(different>0,'empty contact-sheet cell '+str(page*35+i+1));records.append(different)
        return {'nonempty_cells':len(records),'minimum_visible_pixels':min(records)}
    run('P25-V12_VISIBLE_CONTACT_CELLS',contacts)
    def textbounds():
        rr=readj(root/'asset_visual_reviews/evidence/text_bounds.json');require(len(rr)==349,'expected 349 measured text nodes')
        for r in rr:
            rt=ET.parse(safe(root,r['svg'])).getroot();w,h=float(rt.get('width')),float(rt.get('height'));x,y,bw,bh=r['bbox']
            require(x>=-0.1 and y>=-0.1 and x+bw<=w+0.1 and y+bh<=h+0.1,'text outside canvas')
        return {'recorded_inkscape_measurements':len(rr),'out_of_bounds':0,'limitation':'bounding rectangles do not prove every pair of text nodes is non-overlapping'}
    run('P25-V13_TEXT_BOUNDS',textbounds)
    def ora():
        p=root/'art_direction/templates/character_source_template.ora'
        with zipfile.ZipFile(p) as z:
            require(z.testzip() is None,'ORA CRC error');infos=z.infolist();require(infos[0].filename=='mimetype' and infos[0].compress_type==zipfile.ZIP_STORED,'ORA first uncompressed mimetype missing')
            require(z.read('mimetype')==b'image/openraster','ORA mimetype invalid');rt=ET.fromstring(z.read('stack.xml'))
            require((int(rt.get('w')),int(rt.get('h')))==(2048,3072),'ORA dimensions differ');ll=rt.findall('.//layer');require(len(ll)==10,'ORA layer count differs')
            empty=0;guide=0
            for layer in ll:
                member=layer.get('src');require('..' not in PurePosixPath(member).parts and not member.startswith('/'),'ORA path escape')
                with Image.open(io.BytesIO(z.read(member))) as im:
                    require(im.mode=='RGBA' and im.size==(2048,3072),'ORA layer dimensions/alpha differ');aa=im.getchannel('A').getextrema()
                    if layer.get('name')=='EMPTY_DRAWING_LAYER':require(aa==(0,0),'blank template painting layer not empty');empty+=1
                    else:require(layer.get('name')=='GUIDE_NOT_ART' and aa[1]>0,'guide mislabeled');guide+=1
            require((empty,guide)==(9,1),'ORA semantic count differs')
            meta=json.loads(z.read('p25_template_metadata.json'));require(meta['lifecycle']=='TEMPLATE_NOT_ART' and meta['production_allowed'] is False,'template promoted as art')
            with Image.open(io.BytesIO(z.read('Thumbnails/thumbnail.png'))) as im:require(max(im.size)<=256,'ORA thumbnail too large')
        return {'groups':10,'empty_drawing_layers':9,'guide_layers':1,'native_gui_open':'NOT_RUN'}
    run('P25-V14_ORA_TEMPLATE_STRUCTURE',ora)
    def authority():
        p=readj(root/'actual_path_request.json')
        require(p.get('production_write_authorized') is False and p.get('not_an_actual_path_mapping') is True,'missing denied path gate')
        source=readj(root/'source_input_receipt.json');sp=next(s for s in source['sources'] if s['source_id']=='P13_PATH');orig=readj(safe(root,sp['package_relative_path']))
        require(orig['production_write_authorized'] is False,'P13 production authorization unexpectedly changed')
        f=readj(root/'interface_rfcs.json');text=json.dumps(f,ensure_ascii=False)
        require('PREPARED_NOT_SUBMITTED' in text,'RFC transmission status absent')
        return 'P13 production_write_authorized=false; local RFC files are not submissions'
    run('P25-V15_AUTHORITY_BOUNDARY',authority)
    def measured():
        x=readj(root/'asset_visual_reviews/evidence/p25_asset_measurements.json')
        require(x['svg_count']==105 and x['png_count']==210,'measurement count differs')
        hp=x['hp_fixture_check'];require(hp['observed_fill_pixels']==203 and hp['expected_rounded_fill']==round(304*12/18),'HP observation inconsistent')
        require(all(c.get('status')=='PASS' for c in x['contrast_checks']),'contrast measurement failed')
        require(len(x['contrast_checks'])==37,'contrast pair count differs')
        n=0
        for a in readj(p24/'ui_visual_export_manifest.json')['assets']:
            for e in a['exports']:
                with Image.open(safe(p24,e['relative_path'])) as im:require('srgb' not in im.info and 'icc_profile' not in im.info,'color metadata observation changed')
                n+=1
        return {'recorded_contrast_pairs':37,'actual_pngs_without_srgb_or_icc':n,'hp_pixels':203}
    run('P25-V16_MEASUREMENT_EVIDENCE',measured)
    def attached():
        x=readj(root/'asset_visual_reviews/evidence/attached_image_verification.json');require(len(x['records'])==12,'missing attached preview')
        matches=0
        for r in x['records']:
            p=matching(root,r,'package_relative_path')
            with Image.open(p) as im:im.load()
            if r['result']=='PASS':matches+=1
            else:require(r.get('disposition')=='UPLOADED_PREVIEW_READ_NOT_USED_AS_GEOMETRY_BASELINE','unbound preview misrepresented')
        require(matches==11,'uploaded preview match count differs');return {'read_and_hashed':12,'exact_p23_member_matches':11,'separate_byte_version':1}
    run('P25-V17_ATTACHMENT_PROVENANCE',attached)
    def html():
        p=Links();p.feed((root/'P25_review_index.html').read_text(encoding='utf-8'));count=0
        for link in p.links:
            u=urlsplit(link)
            require(not u.scheme and not u.netloc,'offline index contains external resource/link')
            if u.path:require(safe(root,unquote(u.path)).is_file(),'broken index link '+link);count+=1
        return {'local_links':count}
    run('P25-V18_OFFLINE_REVIEW_INDEX',html)
    def boundaries():
        x=readj(root/'verification_status.json');d={e['layer']:e for e in x['layers']}
        for k in ['GAME_UNIT','GAME_CONTRACT','TARGET_DEVICE','ANKI_E2E','P32_INDEPENDENT_TEST','P35_INDEPENDENT_REVIEW','P37_PERMISSION_REVIEW','P30_ENGINE_IMPORT','CHARACTER_NATIVE_EDITOR_OPEN']:
            require(d[k]['status']=='NOT_RUN','unperformed validation marked as completed: '+k)
        require(d['FORMAL_ART_GATE']['status']=='BLOCKED','formal art gate opened')
        return {'unperformed_layers_separated':9,'formal_art_gate':'BLOCKED'}
    run('P25-V19_VALIDATION_LAYER_BOUNDARIES',boundaries)
    return checks

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--preflight',action='store_true');a=ap.parse_args()
    root=a.root.resolve();out=a.output.resolve()
    if not root.is_dir() or out.exists() or out.is_relative_to(root):ap.error('root must exist; output must be new and outside root')
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();checks=validate(root);failed=[x for x in checks if x['status']=='FAIL']
    status='FAIL' if failed else ('BLOCKED' if a.preflight else 'PASS');code=2 if failed else (3 if a.preflight else 0)
    gates=readj(root/'asset_visual_reviews/sample_gate.json') if (root/'asset_visual_reviews/sample_gate.json').is_file() else None
    result={'validator_version':VERSION,'validator_sha256':sha(Path(__file__)),'layer':'P25_AUTHOR_STATIC_VALIDATION','status':status,'mode':'formal_preflight' if a.preflight else 'static','started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python_version':platform.python_version(),'checks':checks,'passed':len(checks)-len(failed),'failed':len(failed),'formal_gate':gates if a.preflight else 'NOT_EVALUATED_BY_STATIC_PASS','game_runtime_executed':False,'exit_code':code}
    out.mkdir(parents=True);(out/'validation_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':status,'passed':result['passed'],'failed':len(failed),'exit_code':code,'output':str(out)},ensure_ascii=False));sys.exit(code)
if __name__=='__main__':main()
