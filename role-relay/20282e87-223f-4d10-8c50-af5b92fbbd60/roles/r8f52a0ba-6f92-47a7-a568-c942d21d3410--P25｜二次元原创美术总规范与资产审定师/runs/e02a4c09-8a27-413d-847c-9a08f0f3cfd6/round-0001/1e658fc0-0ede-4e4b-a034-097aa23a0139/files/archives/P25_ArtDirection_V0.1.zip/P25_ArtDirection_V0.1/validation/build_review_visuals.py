"""Build exact P25 specification diagrams and contact sheets, not character artwork.
All writes go to a new directory outside the package. No network or game calls.
"""
from pathlib import Path
import argparse, base64, datetime, hashlib, io, json, os, shutil, subprocess
import xml.etree.ElementTree as ET
import zipfile
from html import escape
from PIL import Image, ImageDraw, PngImagePlugin

NS='http://www.w3.org/2000/svg'
SC='Noto Sans SC Thin'
C={'bg':'#121520','surface':'#202535','raised':'#2B3045','text':'#F5F1E9','muted':'#C0C9DA','gold':'#E6BF7D','cyan':'#97E2F6','violet':'#D8BCF4','line':'#8D9AB5','green':'#9ADDB7','red':'#FFB9C2'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def txt(x,y,s,size=20,color=None,anchor='start'):
    return f'<text x="{x}" y="{y}" font-family="{SC},DejaVu Sans" font-size="{size}" fill="{color or C["text"]}" text-anchor="{anchor}">{escape(str(s))}</text>'
def rect(x,y,w,h,fill=None,stroke=None,sw=1,r=0,dash=None):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill or "none"}" stroke="{stroke or "none"}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def line(x1,y1,x2,y2,col=None,sw=1,dash=None):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{col or C["line"]}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>'
def ell(cx,cy,rx,ry,fill=None,stroke=None,sw=1):
    return f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{fill or "none"}" stroke="{stroke or C["line"]}" stroke-width="{sw}"/>'
def path(d,stroke=None,sw=2,fill=None):
    return f'<path d="{d}" stroke="{stroke or C["line"]}" stroke-width="{sw}" fill="{fill or "none"}" stroke-linecap="round" stroke-linejoin="round"/>'
def pic(p,x,y,w,h):
    return f'<image x="{x}" y="{y}" width="{w}" height="{h}" xlink:href="data:image/png;base64,{base64.b64encode(p.read_bytes()).decode()}"/>'
def header(w,h,title,subtitle,status='规范图 · 不是人物/敌人成稿'):
    return rect(0,0,w,h,C['bg'])+txt(44,40,'KOTODAMA BRIGADE / P25',17,C['gold'])+txt(w-44,40,'P25-ART-BIBLE / 0.1.0',17,C['muted'],'end')+txt(44,94,title,36)+txt(44,132,subtitle,20,C['muted'])+rect(44,h-62,w-88,1,C['line'])+txt(44,h-26,status,17,C['gold'])

def write_svg(out,relative,w,h,body,kind):
    p=out/relative;p.parent.mkdir(parents=True,exist_ok=True)
    s=f'<svg xmlns="{NS}" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w}" height="{h}" viewBox="0 0 {w} {h}" version="1.1"><title>P25 {kind}</title><metadata>{escape(json.dumps({"kind":kind,"production_allowed":False,"style_version":"P25-ART-BIBLE/0.1.0"}))}</metadata>{body}</svg>'
    rt=ET.fromstring(s)
    for i,e in enumerate(rt.iter('{'+NS+'}text')):e.set('id',f'p25_text_{i:04d}')
    ET.register_namespace('',NS);ET.register_namespace('xlink','http://www.w3.org/1999/xlink');p.write_text(ET.tostring(rt,encoding='unicode')+'\n')
    return p

def style_board(root,out):
    w,h=1600,1120;b=header(w,h,'美术基准 · 人物清楚，界面克制','二维清线 / 两段主阴影 / 有色轮廓 / 低纹理材质 / 先一人审定')
    tokens=json.loads((root/'art_direction/palette.json').read_text())['tokens']
    selected=[tokens[i] for i in [0,1,3,5,7,8,13,14,15,16,17,20]]
    for i,t in enumerate(selected):
        x=44+(i%6)*252;y=174+(i//6)*144
        b+=rect(x,y,232,66,t['hex'],C['line'],1,8)+txt(x,y+96,t['label_zh'],20)+txt(x,y+124,t['hex'],17,C['muted'])
    b+=txt(44,502,'线条层级（以 2048 × 3072 母版为参考）',25)
    for i,(label,sw) in enumerate([('外轮廓 6–10 px',8),('内部结构 3–5 px',4),('脸部细线 2–3 px',2.5)]):
        x=44+i*500;b+=rect(x,528,474,124,C['surface'],None,r=12)+path(f'M {x+24} 578 C {x+92} 530 {x+170} 623 {x+240} 568',C['violet'],sw)+txt(x+24,627,label,21)
    b+=txt(44,700,'同一光源，不同材质',25)
    for i,(label,base,shadow,highlight) in enumerate([('软布：大面哑光','#71608E','#51445F','#9B87B5'),('旧纸：平整弱纹理','#F3EBE0','#C5B1B0','#FFF9F1'),('哑金：局部窄高光','#C6A56C','#826544','#F3DDB6')]):
        x=44+i*500;b+=rect(x,728,474,232,C['surface'],None,r=12)+rect(x+26,751,164,132,base,None,r=10)
        b+=path(f'M {x+108} 751 L {x+190} 751 L {x+190} 883 L {x+146} 883 Z','none',0,shadow)
        if i==2:b+=path(f'M {x+58} 766 L {x+110} 766',highlight,7)
        elif i==0:b+=path(f'M {x+47} 774 Q {x+80} 792 {x+116} 773',highlight,5)
        else:b+=line(x+46,774,x+102,774,highlight,3)
        b+=txt(x+216,780,['主光：左上','同一结构','亮部少量'][i],21)+txt(x+216,816,['阴影有转折','纹理后退','不涂满白边'][i],20,C['muted'])+txt(x+26,931,label,21)
    b+=txt(44,1012,'身份色由 P04/P26 确认；本图色块不代表已批准的人设，也不代表正式素材放行。',20,C['muted'])
    return write_svg(out,'art_direction/boards/P25_Style_Reference.svg',w,h,b,'SPECIFICATION_BOARD')

def proportion_board(root,out):
    w,h=1600,1240;b=header(w,h,'比例与裁切 · 用量尺沟通，用样本定稿','下图只有几何构成线；没有绘制角色，不计入正式样本数量')
    b+=rect(44,174,458,944,C['surface'],None,r=14)+txt(70,216,'正面中立姿势 · 6.25 头高',23)
    cx=251;top=270;u=118
    for i in range(7):
        y=top+i*u;b+=line(78,y,462,y,C['line'],1,'6 6')+txt(84,y-9,f'{i} H',16,C['muted'])
    b+=ell(cx,top+u/2,53,u/2,None,C['cyan'],3)
    b+=path(f'M {cx-30} {top+u} L {cx-30} {top+1.28*u} M {cx+30} {top+u} L {cx+30} {top+1.28*u}',C['cyan'],3)
    b+=path(f'M 172 {top+1.32*u} L 330 {top+1.32*u} L 310 {top+3.2*u} L 192 {top+3.2*u} Z',C['cyan'],3)
    b+=path(f'M 172 {top+1.32*u} L 140 {top+2.28*u} L 159 {top+3.25*u} M 330 {top+1.32*u} L 362 {top+2.28*u} L 343 {top+3.25*u}',C['cyan'],3)
    b+=path(f'M 207 {top+3.2*u} L 202 {top+4.75*u} L 191 {top+6.1*u} L 169 {top+6.25*u} L 216 {top+6.25*u} M 295 {top+3.2*u} L 300 {top+4.75*u} L 311 {top+6.1*u} L 333 {top+6.25*u} L 286 {top+6.25*u}',C['cyan'],3)
    b+=line(251,258,251,1034,C['gold'],1,'4 8')+txt(70,1087,'不含发饰；透视姿势另交结构说明。',18,C['muted'])
    b+=rect(528,174,1028,418,C['surface'],None,r=14)+txt(554,216,'脸部构成 · 只作正面定位参考',25)
    fx,fy=734,397;b+=ell(fx,fy,108,140,None,C['cyan'],3)+line(fx,251,fx,550,C['line'],1,'5 5')
    for v,lab,col in [(0.54,'眼线 0.50–0.57 H',C['violet']),(0.72,'鼻尖 0.68–0.75 H',C['muted']),(0.82,'嘴线 0.78–0.85 H',C['gold'])]:
        y=257+280*v;b+=line(612,y,862,y,col,2)+txt(888,y+6,lab,21,col)
    b+=txt(888,278,'先定头部朝向，再放五官。',22)+txt(888,318,'眼神、颈根、头肩连接为硬项。',21,C['muted'])
    b+=rect(528,616,1028,502,C['surface'],None,r=14)+txt(554,660,'既有 UI 窗口：分别裁切，不拉伸母版',25)
    b+=rect(554,702,156,184,None,C['gold'],2)+rect(570,718,124,152,None,C['cyan'],2)+rect(578,726,108,136,None,C['violet'],2,'0','4 4')
    b+=txt(742,735,'P24 敌方窗 78 × 92（此处画成 2×）',21)+txt(742,774,'透明孔 62 × 76；关键特征内缩 4 px。',20,C['muted'])+txt(742,812,'全身、长角、武器不保证能同时展示。',20,C['muted'])
    b+=rect(554,928,288,118,None,C['cyan'],2)+txt(868,960,'P23 编队：288 × 118',21)+txt(868,998,'P23 档案：288 × 180',21)+txt(868,1036,'优先脸部和主识别轮廓；专用横向裁切。',20,C['muted'])
    b+=txt(44,1160,'3:4 半身审查图不是 236 × 174 手牌插画位；新窗口须经 P23 的 IC-21 受理。',20,C['muted'])
    return write_svg(out,'art_direction/boards/P25_Proportion_Crop.svg',w,h,b,'CONSTRUCTION_GUIDE_NOT_CHARACTER_ART')

def layer_board(root,out):
    w,h=1600,1100;b=header(w,h,'可编辑源与透明导出 · 证明能修改','层名和文件扩展名只是线索；实际切层、局部修改与重导出才是证据')
    groups=[('90_background','审查底色 · 透明导出时隐藏'),('80_light_fx','反光 / 特效 · 关闭后人物完整'),('70_hands_props','手与道具 · 连接和遮挡可检查'),('60_front_hair','前发 / 主色 / 阴影 / 高光'),('50_face','眉 / 眼 / 嘴 · 表情局部可编辑'),('40_outfit','服装底色与阴影'),('30_body_skin','身体与肤色'),('20_back_hair','后发'),('10_sketch','结构草稿 · 可隐藏'),('00_guides','安全线 · 不得烘焙进成品')]
    b+=txt(44,192,'建议层树',25)
    for i,(name,note) in enumerate(groups):
        y=218+i*64;b+=rect(44,y,728,54,C['surface'],C['line'],0.6,6)+rect(60,y+15,18,18,None,C['gold'],1)+txt(94,y+34,name,18,C['violet'])+txt(314,y+34,note,18)
    b+=txt(820,192,'导出审查：同一透明图，三种底色',25)
    for i,(label,bg) in enumerate([('深底',C['bg']),('浅底','#F5F1E9'),('棋盘','#ADB3BF')]):
        x=820+i*240;b+=rect(x,220,214,205,bg,C['line'],1,6)
        if i==2:
            for yy in range(7):
                for xx in range(7):
                    if (xx+yy)%2==0:b+=rect(x+xx*30,220+yy*28,30,28,'#DDE1E9')
        b+=ell(x+107,312,65,65,'#71608E',C['violet'],3)+path(f'M {x+73} 343 L {x+125} 272 L {x+145} 342',C['gold'],5)
        b+=txt(x,459,label,20)
    b+=txt(820,514,'上方是几何测试形；不是角色素材。',20,C['muted'])
    lines=[('RGBA8 / 无损 PNG','记录真实像素、alpha、色彩元数据'),('同画布 / 同原点 / 同锚点','不自动 trim，不在图集中随意旋转'),('源 → 导出哈希绑定','改源后重导出，并刷新每个 variant'),('可编辑性必须实际打开验证','空白 ORA 模板不能通过人物样本门禁'),('P25 / P37 / P30 / P35 分别签收','审美、权利、导入、流程不能互相代签')]
    for i,(a,c) in enumerate(lines):
        y=563+i*85;b+=txt(820,y,a,22,C['gold'])+txt(820,y+32,c,19,C['muted'])
    b+=txt(44,929,'分层不是骨骼拆件：无需新增 Spine、3D 或逐帧动作成本。',23)
    b+=txt(44,973,'P25 只提供规范模板与审查证据；画师的真实绘画仍由原岗位交付。',20,C['muted'])
    return write_svg(out,'art_direction/boards/P25_Layer_Alpha.svg',w,h,b,'LAYER_AND_ALPHA_GUIDE')

def contacts(root,out):
    up=root/'asset_visual_reviews/evidence/upstream/P24';assets=json.loads((up/'ui_visual_export_manifest.json').read_text())['assets'];paths=[]
    for page in range(3):
        sub=assets[page*35:(page+1)*35];w,h=1600,1770;b=header(w,h,f'P24 实物审查索引 · {page+1} / 3','35 个原导出切图 / 每格标明 asset_id 与状态 / 不改源像素','P25 缩略审查证据 · 原资产仍是 PLACEHOLDER')
        for i,a in enumerate(sub):
            x=40+(i%5)*312;y=168+(i//5)*210
            b+=rect(x,y,298,198,C['surface'],C['line'],0.6,8)
            im=up/a['exports'][0]['relative_path'];iw,ih=a['logical_size'];scale=min(1,274/iw,132/ih)
            if iw<=40 and ih<=40:scale=1
            dw,dh=iw*scale,ih*scale
            b+=pic(im,x+(298-dw)/2,y+12+(132-dh)/2,dw,dh)
            b+=txt(x+12,y+164,f'{page*35+i+1:03d}  '+a['family'],16,C['text'])+txt(x+12,y+188,a['state']+f'  |  {int(iw)}×{int(ih)}',15,C['muted'])
        paths.append(write_svg(out,f'asset_visual_reviews/boards/P25_P24_Contact_{page+1:02d}.svg',w,h,b,'READ_ONLY_ASSET_CONTACT_SHEET'))
    return paths

def crop_template(out):
    w,h=2048,3072;b=rect(0,0,w,h,None,C['line'],2)+rect(102,123,1844,2765,None,C['cyan'],5,dash='18 14')
    b+=line(w/2,64,w/2,h-64,C['gold'],3,'12 20')
    for i in range(7):
        y=200+i*420;b+=line(150,y,1898,y,C['line'],2,'10 18')+txt(158,y-18,f'{i} H',27,C['muted'])
    b+=txt(130,82,'P25 / GUIDE ONLY / TEMPLATE_NOT_ART',36,C['gold'])+txt(130,2990,'2048 × 3072 / Hide guides before export',32,C['gold'])
    return write_svg(out,'art_direction/templates/portrait_crop_guide.svg',w,h,b,'TEMPLATE_NOT_ART')

def ora_template(out):
    w,h=2048,3072;guide=Image.new('RGBA',(w,h));d=ImageDraw.Draw(guide)
    d.rectangle((102,123,1946,2888),outline=(151,226,246,200),width=5);d.line((1024,50,1024,3022),fill=(230,191,125,170),width=3)
    for i in range(7):d.line((150,200+i*420,1898,200+i*420),fill=(141,154,181,150),width=2)
    empty=Image.new('RGBA',(w,h));metadata=PngImagePlugin.PngInfo();metadata.add(b'sRGB',b'\x00')
    def png(im):
        b=io.BytesIO();im.save(b,format='PNG',pnginfo=metadata);return b.getvalue()
    root=ET.Element('image',{'version':'0.0.3','w':str(w),'h':str(h),'name':'P25 TEMPLATE_NOT_ART — empty drawing layers'})
    stack=ET.SubElement(root,'stack')
    names=['90_background','80_light_fx','70_hands_props','60_front_hair','50_face','40_outfit','30_body_skin','20_back_hair','10_sketch','00_guides']
    entries=[]
    for i,name in enumerate(names):
        group=ET.SubElement(stack,'stack',{'name':name,'opacity':'1.0','visibility':'visible' if name=='00_guides' else 'hidden','composite-op':'svg:src-over','isolation':'isolate'})
        src=f'data/layer{i:02d}.png';ET.SubElement(group,'layer',{'name':'GUIDE_NOT_ART' if name=='00_guides' else 'EMPTY_DRAWING_LAYER','src':src,'x':'0','y':'0','opacity':'1.0','visibility':'visible','composite-op':'svg:src-over'})
        entries.append((src,png(guide if name=='00_guides' else empty)))
    p=out/'art_direction/templates/character_source_template.ora';p.parent.mkdir(parents=True,exist_ok=True)
    thumbnail=guide.copy();thumbnail.thumbnail((256,256))
    with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('mimetype',b'image/openraster',compress_type=zipfile.ZIP_STORED)
        z.writestr('stack.xml',ET.tostring(root,encoding='utf-8',xml_declaration=True))
        for name,data in entries:z.writestr(name,data)
        z.writestr('mergedimage.png',png(guide));z.writestr('Thumbnails/thumbnail.png',png(thumbnail))
        z.writestr('p25_template_metadata.json',json.dumps({'lifecycle':'TEMPLATE_NOT_ART','production_allowed':False,'character_id':None,'style_version':'P25-ART-BIBLE/0.1.0','actual_painted_character_layers':0,'guide_layers':1,'empty_layers':9,'gui_open_test':'NOT_RUN'},ensure_ascii=False))
    return p

def main():
    pa=argparse.ArgumentParser();pa.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);pa.add_argument('--output',type=Path,required=True);a=pa.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out.is_relative_to(root):pa.error('output must be new and outside the package')
    out.mkdir(parents=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p24=root/'asset_visual_reviews/evidence/upstream/P24'
    subprocess.run([sys_executable(),'-B',str(p24/'art/ui/validation/prepare_fonts.py'),str(p24/'art/ui/source/fonts'),str(out/'_runtime_fonts')],check=True,capture_output=True)
    env=os.environ.copy();env['FONTCONFIG_FILE']=str(out/'_runtime_fonts/fonts.conf')
    paths=[style_board(root,out),proportion_board(root,out),layer_board(root,out),*contacts(root,out),crop_template(out)]
    ora=ora_template(out);records=[];layout=[]
    for p in paths:
        png=p.with_suffix('.png');r=subprocess.run(['inkscape',str(p),'--export-type=png','--export-filename='+str(png)],env=env,capture_output=True,text=True)
        if r.returncode:raise RuntimeError(r.stderr)
        q=subprocess.run(['inkscape',str(p),'--query-all'],env=env,capture_output=True,text=True,check=True)
        rt=ET.parse(p).getroot();ww,hh=float(rt.get('width')),float(rt.get('height'))
        for raw in q.stdout.splitlines():
            parts=raw.split(',')
            if len(parts)==5 and parts[0].startswith('p25_text_'):
                x,y,w,h=map(float,parts[1:]);layout.append({'svg':str(p.relative_to(out)),'text_id':parts[0],'bbox':[x,y,w,h],'inside_canvas':x>=-0.1 and y>=-0.1 and x+w<=ww+0.1 and y+h<=hh+0.1})
        im=Image.open(png)
        records.append({'source_path':str(p.relative_to(out)),'source_sha256':sha(p),'png_path':str(png.relative_to(out)),'png_sha256':sha(png),'dimensions':list(im.size),'renderer':'Inkscape','exit_code':r.returncode,'stderr':r.stderr.strip()})
    contact_visibility=[]
    for page in range(3):
        im=Image.open(out/f'asset_visual_reviews/boards/P25_P24_Contact_{page+1:02d}.png').convert('RGB')
        for i in range(35):
            x=40+(i%5)*312;y=168+(i//5)*210
            region=im.crop((x+12,y+12,x+286,y+144))
            different=sum(c!=(32,37,53) for c in region.getdata())
            contact_visibility.append({'asset_index':page*35+i+1,'visible_pixels_different_from_panel':different,'status':'PASS' if different>0 else 'FAIL'})
    info={'layer':'P25_DOCUMENT_VISUAL_RENDER','start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':records,'ora_template':{'path':str(ora.relative_to(out)),'sha256':sha(ora),'status':'STRUCTURE_GENERATED_GUI_OPEN_NOT_RUN'},'layout_text_nodes':len(layout),'layout_out_of_bounds':[x for x in layout if not x['inside_canvas']],'contact_visibility':contact_visibility,'game_runtime_executed':False}
    (out/'render_results.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n');(out/'text_bounds.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'svg_png_pairs':len(records),'out_of_bounds':len(info['layout_out_of_bounds']),'visible_contact_cells':sum(x['status']=='PASS' for x in contact_visibility),'output':str(out)},ensure_ascii=False))
def sys_executable():
    import sys
    return sys.executable
if __name__=='__main__':main()
