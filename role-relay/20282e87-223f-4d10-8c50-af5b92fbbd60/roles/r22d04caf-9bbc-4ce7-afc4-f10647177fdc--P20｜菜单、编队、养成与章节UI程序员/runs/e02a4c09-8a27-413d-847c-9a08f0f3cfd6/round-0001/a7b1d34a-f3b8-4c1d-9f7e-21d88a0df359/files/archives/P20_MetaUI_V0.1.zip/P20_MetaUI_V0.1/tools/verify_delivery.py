"""Verify every delivered file without writing files or importing game code."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1]
def main():
    path=ROOT/'delivery_manifest.json'
    if not path.exists():print('BLOCKED: final manifest not yet generated');return 3
    data=json.loads(path.read_text());expected={x['relative_path']:x for x in data['files']};failures=[]
    for name,row in expected.items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file():failures.append({'path':name,'error':'MISSING_OR_OUTSIDE'});continue
        b=p.read_bytes()
        if len(b)!=row['size_bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:failures.append({'path':name,'error':'BYTES_MISMATCH'})
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    extras=sorted(actual-set(expected)-{'delivery_manifest.json'})
    failures.extend({'path':x,'error':'UNLISTED_FILE'} for x in extras)
    print(json.dumps({'status':'FAIL' if failures else 'PASS','verified_files':len(expected),'manifest_self_binding':'EXTERNAL_DELIVERY_RECEIPT','failures':failures},ensure_ascii=False,indent=2))
    return 1 if failures else 0
if __name__=='__main__':raise SystemExit(main())
