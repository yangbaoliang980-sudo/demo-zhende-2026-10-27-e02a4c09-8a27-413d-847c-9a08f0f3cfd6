"""Author-only snapshot generation. Explicit output path; never edits upstream."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tests/meta_ui_unit/support'))
from fixture_host import Host,make_intent,NORMAL
def generate(out):
    out.mkdir(parents=True,exist_ok=True);records={}
    def save(name,host):
        value=host.view();(out/(name+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');records[name]={'mode':value['mode'],'query_state':value['learning']['query']['state'] if value['learning']['query'] else None}
    for name in ['demo','empty','equipment','unbound']:
        h=Host(True,name);save(name,h)
        if name=='demo':
            h.submit(make_intent(h.view(),'LEVEL_UP',{'character_id':h.view()['characters'][0]['character_id'],'from_rank':1,'to_rank':2},'p20.fixture.upgrade'))
            save('upgrade_committed',h)
        h.close()
    h=Host(True)
    for state in ['DISCONNECTED','CONNECTED','APPLIED','QUARANTINED','PENDING_RECONCILIATION','REJECTED','REVERTED','REDELIVERY','RECONCILING']:
        h.learning_scenario(state);save('learning_'+state.lower(),h)
    h.learning_scenario('DISCONNECTED')
    h.submit(make_intent(h.view(),'ENTER_STAGE',{'stage_id':NORMAL},'p20.fixture.enter'));save('active_battle',h)
    h.inject_result();save('settlement_pending',h)
    h.submit(make_intent(h.view(),'CLAIM_STAGE_REWARD',{'battle_id':h.last_result.value['battle_id']},'p20.fixture.claim'));save('settlement_committed',h)
    h.revoke_first();save('stage_review',h)
    h.close();print(json.dumps({'scope':'NATIVE_PLANNERS_WITH_TEST_PORTS','generated':records},ensure_ascii=False,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);a=p.parse_args();generate(a.out)
