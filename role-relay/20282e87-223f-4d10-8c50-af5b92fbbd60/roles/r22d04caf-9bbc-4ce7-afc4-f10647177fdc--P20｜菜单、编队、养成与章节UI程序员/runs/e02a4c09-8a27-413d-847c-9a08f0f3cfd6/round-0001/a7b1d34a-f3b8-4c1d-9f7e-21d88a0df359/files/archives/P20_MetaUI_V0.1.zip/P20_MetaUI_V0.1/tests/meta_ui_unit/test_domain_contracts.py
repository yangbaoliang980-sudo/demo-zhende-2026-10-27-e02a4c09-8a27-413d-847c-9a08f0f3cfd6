from pathlib import Path
import copy,hashlib,json,sys,unittest
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).resolve().parent/'support'))
from fixture_host import (Host,make_intent,CHARS,NORMAL,BOSS,MetaPlanner,progress_view,validate_dto,canonical,fingerprint,StageError,TOKEN)

class DomainContractTests(unittest.TestCase):
    def setUp(self):self.h=Host(True);self.addCleanup(self.h.close);self.seq=0
    def request(self,kind,payload,view=None,rid=None):
        self.seq+=1;return make_intent(view or self.h.view(),kind,payload,rid or 'test.'+str(self.seq))
    def apply(self,kind,payload):return self.h.submit(self.request(kind,payload))
    def balance(self):return self.h.meta_planner.wallet_snapshot(self.h.model.meta).value['balances'][0]['available']
    def enter(self,sid=NORMAL):return self.apply('ENTER_STAGE',{'stage_id':sid})
    def settle(self,outcome='WIN'):
        self.h.inject_result(outcome);return self.apply('CLAIM_STAGE_REWARD',{'battle_id':self.h.last_result.value['battle_id']})

    def test_default_is_unbound_without_fake_balance(self):
        h=Host();self.addCleanup(h.close);v=h.view();self.assertEqual(v['mode'],'UNBOUND');self.assertIsNone(v['wallet']);self.assertEqual(v['characters'],[]);self.assertFalse(v['capabilities']['write_allowed'])
    def test_unbound_command_cannot_grant(self):
        h=Host();self.addCleanup(h.close);r=h.submit(make_intent(h.view(),'SET_PARTY',{'ordered_character_ids':CHARS}));self.assertEqual(r['status'],'BLOCKED');self.assertIsNone(h.model)
    def test_upstream_original_bytes(self):
        records=json.loads((ROOT/'sources/original_bytes.json').read_text())
        self.assertGreater(len(records),0)
        for record in records:
            with self.subTest(path=record['package_path']):
                data=(ROOT/record['package_path']).read_bytes();self.assertEqual(len(data),record['size_bytes']);self.assertEqual(hashlib.sha256(data).hexdigest(),record['sha256'])
    def test_p13_read_dtos_stay_exact(self):
        v=self.h.view();validate_dto(v['save'],'SaveStatusView');validate_dto(v['wallet'],'WalletSnapshot');self.assertEqual(v['wallet'],self.h.meta_planner.wallet_snapshot(self.h.model.meta).value)
    def test_character_attributes_match_original_owner(self):
        for c in self.h.view()['characters']:
            original=self.h.meta_planner.character_attributes(self.h.model.meta,c['character_id']).value
            self.assertEqual(c['stats'],original['stats']);self.assertEqual(c['source_revision'],original['revision'])
    def test_progress_extended_view_not_lossy_p13_projection(self):
        self.assertEqual(self.h.view()['stage_progress'],progress_view(self.h.model.stage,self.h.catalog).value)
    def test_queries_do_not_change_domain_state(self):
        before=(self.h.model.stage.raw,self.h.model.meta.raw,len(self.h.model.receipts))
        for _ in range(5):self.h.view()
        self.assertEqual(before,(self.h.model.stage.raw,self.h.model.meta.raw,len(self.h.model.receipts)))
    def test_upgrade_uses_p17_amount_once(self):
        self.assertEqual(self.balance(),15);r=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        self.assertEqual(r['status'],'COMMITTED_SIMULATION');self.assertEqual(self.balance(),11);self.assertFalse(r['durable']);self.assertEqual(r['view']['characters'][0]['level'],2)
    def test_same_id_duplicate_has_one_debit(self):
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});a=self.h.submit(request);before=self.h.model.meta.raw;b=self.h.submit(request)
        self.assertEqual(a['status'],b['status']);self.assertEqual(before,self.h.model.meta.raw);self.assertEqual(len(self.h.trace),1)
    def test_duplicate_after_response_loss_queries_without_resubmit(self):
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.h.fail_next='after_publish_unknown'
        with self.assertRaises(ConnectionError):self.h.submit(request)
        before=self.h.model.meta.raw;r=self.h.lookup(request);self.assertEqual(r['status'],'COMMITTED_SIMULATION');self.assertEqual(self.balance(),11);self.assertEqual(before,self.h.model.meta.raw);self.assertEqual(len(self.h.trace),1)
    def test_unknown_before_submission_stays_unknown(self):
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.h.fail_next='before_publish_unknown'
        with self.assertRaises(ConnectionError):self.h.submit(request)
        self.assertEqual(self.h.lookup(request)['status'],'UNKNOWN');self.assertEqual(self.balance(),15)
    def test_same_id_modified_payload_is_collision(self):
        r=self.request('SET_PARTY',{'ordered_character_ids':CHARS});self.h.submit(r);before=self.h.model.meta.raw;r['payload']['ordered_character_ids']=list(reversed(CHARS))
        self.assertEqual(self.h.submit(r)['reason'],'E_COMMAND_ID_COLLISION');self.assertEqual(before,self.h.model.meta.raw)
    def test_stale_revision_request_rejected(self):
        old=self.h.view();self.apply('SET_PARTY',{'ordered_character_ids':list(reversed(CHARS))});r=self.h.submit(self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},old));self.assertEqual(r['reason'],'E_VIEW_STALE');self.assertEqual(self.balance(),15)
    def test_new_id_cannot_repeat_same_upgrade(self):
        self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});r=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.assertEqual(r['status'],'REJECTED');self.assertEqual(self.balance(),11)
    def test_parallel_duplicate_upgrade_exactly_once(self):
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2})
        with ThreadPoolExecutor(max_workers=8) as pool:r=list(pool.map(lambda _:self.h.submit(request),range(16)))
        self.assertTrue(all(x['status']=='COMMITTED_SIMULATION' for x in r));self.assertEqual(self.balance(),11);self.assertEqual(len(self.h.trace),1)
    def test_parallel_different_ids_old_snapshot_no_double_debit(self):
        view=self.h.view();requests=[self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2},view) for _ in range(8)]
        with ThreadPoolExecutor(max_workers=8) as pool:r=list(pool.map(self.h.submit,requests))
        self.assertEqual(sum(x['status']=='COMMITTED_SIMULATION' for x in r),1);self.assertEqual(self.balance(),11)
    def test_party_order_is_preserved(self):
        order=[CHARS[2],CHARS[0],CHARS[1]];r=self.apply('SET_PARTY',{'ordered_character_ids':order});self.assertEqual(r['view']['party']['slots'],order)
    def test_party_duplicate_does_not_commit(self):
        before=self.h.model.meta.raw;r=self.apply('SET_PARTY',{'ordered_character_ids':[CHARS[0]]*3});self.assertEqual(r['status'],'REJECTED');self.assertEqual(before,self.h.model.meta.raw)
    def test_party_missing_member_does_not_commit(self):
        before=self.h.model.meta.raw;r=self.apply('SET_PARTY',{'ordered_character_ids':CHARS[:2]});self.assertEqual(r['status'],'REJECTED');self.assertEqual(before,self.h.model.meta.raw)
    def test_empty_data_cannot_enter_or_equip(self):
        self.h.reset('empty');v=self.h.view();self.assertEqual(v['characters'],[]);self.assertFalse(v['party']['valid']);self.assertFalse(v['stage_details'][0]['action_enabled']);self.assertEqual(self.enter()['status'],'REJECTED')
    def test_default_equipment_closed(self):
        r=self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[]});self.assertEqual(r['reason'],'E_FEATURE_DISABLED')
    def test_test_equipment_changes_only_via_p17(self):
        self.h.reset('equipment');v=self.h.view();old=v['characters'][0]['stats']['attack'];r=self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[{'slot':'weapon','instance_id':'fixture.blade.1'}]});self.assertEqual(r['status'],'COMMITTED_SIMULATION');self.assertEqual(r['view']['characters'][0]['stats']['attack'],old+3)
        r=self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[]});self.assertEqual(r['view']['characters'][0]['stats']['attack'],old)
    def test_equipment_instance_cannot_be_used_twice(self):
        self.h.reset('equipment');self.apply('SET_EQUIPMENT',{'character_id':CHARS[0],'items':[{'slot':'weapon','instance_id':'fixture.blade.1'}]});before=self.h.model.meta.raw
        r=self.apply('SET_EQUIPMENT',{'character_id':CHARS[1],'items':[{'slot':'weapon','instance_id':'fixture.blade.1'}]});self.assertEqual(r['reason'],'E_EQUIPMENT_IN_USE');self.assertEqual(before,self.h.model.meta.raw)
    def test_locked_stage_cannot_enter(self):
        before=self.h.model.stage.raw;r=self.enter(BOSS);self.assertEqual(r['reason'],'E_LOCKED_STAGE');self.assertEqual(before,self.h.model.stage.raw)
    def test_entry_preserves_party_and_no_entry_debit(self):
        order=list(reversed(CHARS));self.apply('SET_PARTY',{'ordered_character_ids':order});r=self.enter();self.assertEqual(r['status'],'COMMITTED_SIMULATION');self.assertEqual(self.balance(),15)
        admission=self.h.model.stage.value['attempts'][0]['admission'];self.assertEqual([x['character_id'] for x in admission['party_snapshot']['members']],order)
    def test_active_battle_blocks_new_entry_and_meta_mutation(self):
        self.enter();before=self.h.model.meta.raw;r=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.assertEqual(r['reason'],'E_MUTATION_BLOCKED_ACTIVE_BATTLE');self.assertEqual(before,self.h.model.meta.raw);self.assertEqual(self.enter()['status'],'REJECTED')
    def test_view_navigation_cannot_claim_reward(self):
        self.enter();self.h.inject_result();before=(self.h.model.meta.raw,self.h.model.stage.raw)
        for _ in range(4):self.h.view()
        self.assertEqual(before,(self.h.model.meta.raw,self.h.model.stage.raw));self.assertEqual(self.balance(),15)
    def test_first_clear_only_service_commit_unlocks(self):
        self.enter();self.h.inject_result();self.assertFalse(self.h.view()['stage_progress']['stages'][1]['unlocked']);r=self.apply('CLAIM_STAGE_REWARD',{'battle_id':self.h.last_result.value['battle_id']});self.assertEqual(r['reason'],'FIRST_CLEAR');self.assertEqual(self.balance(),18);self.assertTrue(r['view']['stage_progress']['stages'][1]['unlocked'])
    def test_duplicate_claim_new_id_no_extra_reward(self):
        self.enter();self.settle();before=self.h.model.meta.raw;r=self.apply('CLAIM_STAGE_REWARD',{'battle_id':self.h.last_result.value['battle_id']});self.assertEqual(r['status'],'DUPLICATE_NO_OP');self.assertEqual(before,self.h.model.meta.raw);self.assertEqual(self.balance(),18)
    def test_second_battle_same_stage_no_first_clear_repeat(self):
        self.enter();self.settle();self.enter();r=self.settle();self.assertEqual(r['reason'],'REPEAT_DISABLED');self.assertEqual(self.balance(),18);self.assertEqual(len(self.h.model.stage.value['first_clears']),1)
    def test_loss_closes_attempt_without_reward(self):
        self.enter();r=self.settle('LOSS');self.assertEqual(r['reason'],'NO_CLEAR');self.assertEqual(self.balance(),15);self.assertFalse(r['view']['stage_progress']['stages'][1]['unlocked']);self.assertIsNone(r['view']['stage_progress']['active_battle_id'])
    def test_review_keeps_consumed_first_clear_and_hides_reward(self):
        self.enter();self.settle();before=self.h.model.meta.raw;self.h.revoke_first();v=self.h.view();self.assertEqual(v['stage_progress']['stages'][0]['status'],'REVIEW_REQUIRED');self.assertTrue(v['stage_progress']['stages'][0]['first_clear_consumed']);self.assertEqual(v['settlement']['reward_status'],'QUARANTINED');self.assertEqual(before,self.h.model.meta.raw)
    def test_revoked_prerequisite_quarantines_inflight_boss(self):
        self.enter();self.settle();self.enter(BOSS);self.h.revoke_first();before=self.h.model.meta.raw;r=self.settle();self.assertIn('QUARANTINE',r['reason']);self.assertEqual(before,self.h.model.meta.raw);self.assertEqual(r['view']['settlement']['reward_status'],'QUARANTINED')
    def test_forged_reward_amount_and_result_rejected_at_boundary(self):
        r=self.request('CLAIM_STAGE_REWARD',{'battle_id':'fake','amount':999})
        with self.assertRaises(StageError):self.h.submit(r)
        with self.assertRaises(StageError):self.h.submit(self.request('APPLY_GRANT',{'grant_ref':'fake'}))
        self.assertEqual(self.balance(),15)
    def test_save_migration_failure_blocks_consumption_and_navigation_is_read_only(self):
        self.h.control({'action':'save','state':'RECOVERY_REQUIRED'});before=self.h.model.meta.raw
        r=self.apply('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.assertEqual(r['status'],'BLOCKED');self.assertEqual(self.h.view()['save']['state'],'RECOVERY_REQUIRED');self.assertEqual(before,self.h.model.meta.raw)
    def test_restart_identity_fences_old_command_and_lookup(self):
        request=self.request('LEVEL_UP',{'character_id':CHARS[0],'from_rank':1,'to_rank':2});self.h.fail_next='after_publish_unknown'
        with self.assertRaises(ConnectionError):self.h.submit(request)
        self.h.reset();self.assertEqual(self.h.lookup(request)['status'],'UNKNOWN');self.assertEqual(self.h.submit(request)['reason'],'E_VIEW_STALE')
    def test_p11_query_states_are_from_original_ledger_and_cannot_credit_meta_wallet(self):
        before=self.h.model.meta.raw
        for state,expected in [('APPLIED','APPLIED'),('QUARANTINED','QUARANTINED'),('PENDING_RECONCILIATION','PENDING_RECONCILIATION'),('REJECTED','REJECTED'),('REVERTED','REVERTED'),('REDELIVERY','PENDING_RECONCILIATION'),('RECONCILING','PENDING_RECONCILIATION')]:
            with self.subTest(state=state):
                self.h.learning_scenario(state);v=self.h.view();self.assertEqual(v['learning']['query']['state'],expected);self.assertEqual(before,self.h.model.meta.raw)
                if v['learning']['query']['receipt']:self.assertEqual(v['learning']['query']['receipt']['origin'],'P21_SIMULATOR')
    def test_learning_read_only_query_does_not_rerun_award(self):
        self.h.learning_scenario('APPLIED');s=self.h.ledger_service;before=s.store.snapshot();calls=(s.wallet.calls,s.policy.calls)
        for _ in range(5):self.h.view()
        self.assertEqual(before,s.store.snapshot());self.assertEqual(calls,(s.wallet.calls,s.policy.calls))

if __name__=='__main__':unittest.main(verbosity=2)
