@echo off
cd /d "%~dp0"
python -B run_ui.py
pause
