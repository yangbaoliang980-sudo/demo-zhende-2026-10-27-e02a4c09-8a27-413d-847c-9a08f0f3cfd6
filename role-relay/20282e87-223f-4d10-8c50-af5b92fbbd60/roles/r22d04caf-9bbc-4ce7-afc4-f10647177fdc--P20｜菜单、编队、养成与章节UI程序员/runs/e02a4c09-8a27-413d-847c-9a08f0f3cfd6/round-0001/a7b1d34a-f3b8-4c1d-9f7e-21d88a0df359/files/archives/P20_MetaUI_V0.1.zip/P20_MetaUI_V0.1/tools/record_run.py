"""Capture actual author execution, raw output, exit code and executed P20 bytes."""
import argparse,datetime,hashlib,json,subprocess,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(label,command,evidence=None):
    out=(evidence or ROOT/'evidence/runs')/label
    if out.exists():raise SystemExit('Refusing to overwrite an existing evidence run: '+str(out))
    out.mkdir(parents=True);sources=[]
    with zipfile.ZipFile(out/'executed_p20_sources.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(ROOT.rglob('*')):
            if not p.is_file() or p.parts[len(ROOT.parts)] in {'sources','evidence'}:continue
            if p.suffix not in {'.py','.mjs','.css','.html','.cmd'} and not (p.suffix=='.json' and p.parts[len(ROOT.parts)] in {'tests','ui'}):continue
            rel=str(p.relative_to(ROOT));data=p.read_bytes();archive.writestr(rel,data);sources.append({'path':rel,'size_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
    result=subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (out/'stdout.log').write_bytes(result.stdout);(out/'stderr.log').write_bytes(result.stderr)
    record={'schema_version':'P20-EXECUTION/0.1.0','layer':'AUTHOR_ONLY','command':command,'working_directory':str(ROOT),
        'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-clock,3),
        'exit_code':result.returncode,'sources':sources,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
    (out/'run_receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(result.stdout.decode('utf-8',errors='replace'));print(result.stderr.decode('utf-8',errors='replace'))
    print(json.dumps({'label':label,'exit_code':result.returncode,'evidence':str(out)},ensure_ascii=False))
    return result.returncode
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--evidence',type=Path);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
    cmd=a.command[1:] if a.command[:1]==['--'] else a.command
    if not cmd:p.error('command required')
    raise SystemExit(run(a.label,cmd,a.evidence))
