# P20 第三方文件与原件声明

本岗 HTML/CSS/JavaScript、测试、工具和文档为本次 P20 新写文件。P11/P13/P17/P18/P19/P01/P04/P05/P06/P07/V6 来源文件是用户转交材料的原字节复制；每一份都在 `sources/original_bytes.json` 登记。其许可不能由 P20 重新授予。

## 字体

复用 P19 已交付的 `@fontsource/noto-sans-sc` 5.3.1 简体中文 400 字重 WOFF2。字体文件、`LICENSE`、原 `package.json` 字节均未修改，移动到本岗 `ui/meta/assets/fonts/` 下引用。

字体 SHA-256：`95e3633b6a98f764ba3adfb54504a0cd4799328c009adf9081d6c1850f9c4c78`。原许可为 SIL Open Font License 1.1，随包提供。本次作者仅核对随包许可和原字节，P37 独立合规受理仍为 `NOT_RUN`。

## 浏览器测试依赖

实际使用 Node 24.22.1、Playwright 1.62.1、`@sparticuz/chromium` 153.0.0 提供的 Chromium 153.0.8010.0。包内保存下载锁文件和实际版本/二进制摘要；不分发浏览器二进制、node_modules 或 Python/Node 运行时。

最初下载受执行沙箱 EPERM 限制，随后通过工具的自动审批执行临时目录安装；未修改网络策略或关闭 TLS。默认受限执行下 Chromium 启动也被 OS 操作限制，随后使用已允许的执行权限运行只访问 127.0.0.1 的测试。环境问题与 UI 源码缺陷分别记录。

没有新增外部角色美术，没有把占位图形当正式角色立绘，也没有申请用户资产的公开授权。
