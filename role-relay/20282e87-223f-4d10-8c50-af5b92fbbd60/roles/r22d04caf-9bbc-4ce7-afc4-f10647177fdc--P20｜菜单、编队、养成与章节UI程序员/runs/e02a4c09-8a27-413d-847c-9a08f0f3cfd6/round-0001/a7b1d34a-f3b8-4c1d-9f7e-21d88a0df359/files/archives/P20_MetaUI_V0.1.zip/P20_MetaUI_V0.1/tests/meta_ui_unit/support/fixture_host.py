"""P20 author-only composition fixture. Never install as a production adapter.

Only unchanged P17/P18 planners decide domain mutations. This memory publisher
is an explicitly volatile P21 stand-in. P11 uses its own unchanged SQLite test
model in an isolated temporary directory; it is never connected to P17 money.
"""
from __future__ import annotations
import copy, importlib.util, json, sys, tempfile, threading, uuid
from dataclasses import asdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[3]
P18=ROOT/'sources/P18'; P11=ROOT/'sources/P11'
for path in (P18, P18/'upstream/P17', P11):
    if str(path) not in sys.path: sys.path.append(str(path))

def _support(name,path):
    if name in sys.modules: return sys.modules[name]
    spec=importlib.util.spec_from_file_location(name,path/'__init__.py',submodule_search_locations=[str(path)])
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

_support('p18_original_support',P18/'tests/support')
_support('p11_original_support',P11/'tests/support')
from stage_runtime import StagePlanner, load_catalog as stage_catalog, empty_state as stage_empty, command as stage_command, progress_view
from stage_runtime.common import FrozenMessage, fingerprint, canonical, need, StageError, get_row
from character_party_runtime import MetaPlanner, load_catalog as meta_catalog, empty_state as meta_empty, command as meta_command
from character_party_runtime.common import DomainError
from p18_original_support.authority import FixtureAuthority
from p18_original_support.memory_model import AtomicMemoryModel
from p18_original_support.p17_port import P17ContractPort, SingleGrant, CHARS, TOKEN
from ledger_runtime import StudyLedger
from ledger_runtime.types import canonical as ledger_canonical
from p11_original_support.simulated_ports import FixtureEvidence, FixturePolicy, FixtureWallet, event, control
from p11_original_support.sqlite_atomic_model import SQLiteAtomicModel
from yltt_framework.contracts import validate as validate_dto

VIEW='P20-META-VIEW/0.1.0-proposal'; INTENT='P20-META-INTENT/0.1.0-proposal'
NORMAL='MOCK_P07_STAGE_001'; BOSS='MOCK_P07_STAGE_002'
SAVE_STATES={'READY','READ_ONLY','MIGRATING','RECOVERY_REQUIRED','UNAVAILABLE'}
COMMAND_PAYLOADS={'SET_PARTY':{'ordered_character_ids'},'LEVEL_UP':{'character_id','from_rank','to_rank'},'SET_EQUIPMENT':{'character_id','items'},'ENTER_STAGE':{'stage_id'},'CLAIM_STAGE_REWARD':{'battle_id'}}

class FixturePublisher(AtomicMemoryModel):
    """Adds a P17-only author-fixture transaction boundary; no arithmetic."""
    def submit_meta(self,planner,candidate):
        with self.lock:
            checked=planner.validate_for_commit(candidate,self.meta)
            if checked.status=='DUPLICATE_NO_OP': return {'status':'DUPLICATE_NO_OP','durable':False}
            c=candidate.value
            need(c['required_counterpart_owner'] is None,'E_TEST_META_COUNTERPART')
            stage,_,receipts=self._record
            after=FrozenMessage.from_value(c['after_state'])
            receipt=FrozenMessage.from_value({'status':'COMMITTED_SIMULATION','durable':False,
                'request_id':c['request']['request_id'],'request_sha256':c['request_sha256'],
                'meta_sha256':after.sha256,'revision':after.value['revision'],'origin':'P20_AUTHOR_MEMORY_PUBLISHER_NOT_P21'})
            self._record=(stage,after,receipts+(receipt,))
            return receipt.value

class FixtureWalletPort(P17ContractPort):
    def __init__(self,equipment=False): self.catalog=meta_catalog(equipment_test_fixture=equipment)

class Host:
    def __init__(self,fixture=False,scenario='demo'):
        self.lock=threading.RLock();self.fixture=fixture;self.temp=None;self.reset(scenario)

    def close(self):
        if self.temp: self.temp.cleanup();self.temp=None

    def reset(self,scenario='demo'):
        with self.lock:
            if scenario not in {'demo','empty','equipment','unbound'}: raise ValueError('UNKNOWN_SCENARIO')
            self.close();self.session='fixture.session.'+uuid.uuid4().hex;self.sequence=0
            self.scope='fixture:player';self.store='fixture.store.'+uuid.uuid4().hex;self.continuity='fixture.continuity'
            self.fail_next=None;self.offline=False;self.lookup_unknown=False;self.intents={};self.responses={};self.trace=[]
            self.last_result=None;self.last_receipt=None;self.last_decision='NOT_SETTLED';self.save_state='READY';self.save_reason='ISOLATED_MEMORY_ONLY'
            self.learning={'connection':'DISCONNECTED','pending_count':0,'query':None}
            self.ledger_service=None;self.ledger_inbox=None
            self.scenario=scenario
            if not self.fixture or scenario=='unbound':
                self.model=None;self.save_state='UNAVAILABLE';self.save_reason='P21_PORT_UNBOUND';return
            self.wallet=FixtureWalletPort(scenario=='equipment');self.meta_planner=MetaPlanner(self.wallet.catalog)
            self.catalog=stage_catalog();self.authority=FixtureAuthority();self.stage_planner=StagePlanner(self.catalog,self.authority)
            meta=meta_empty(self.wallet.catalog,profile_id=self.scope,store_instance=self.store,continuity_ref=self.continuity)
            stage=stage_empty(self.catalog,player_save_scope_id=self.scope,store_instance=self.store,continuity_ref=self.continuity)
            if scenario!='empty':
                # Replay only the original P04 acquisition/token/XP/party prefix.
                # Deliberately stop before its upgrade commands so UI can perform them.
                original=json.loads((P18/'upstream/P17/sources/P04/content/characters/character_lifecycle_fixtures.json').read_text())
                for row in original['commands']:
                    action=row['action']
                    if action not in {'ACQUIRE','GRANT_TOKEN','GRANT_XP','SET_PARTY'}: continue
                    if action=='SET_PARTY':
                        plan=MetaPlanner(self.wallet.catalog).plan(meta_command(meta,row['command_id'],'SET_PARTY',{'ordered_character_ids':row['ordered_ids']}),meta)
                    else:
                        ref=row['event_identity'];grant=self._grant(ref,
                            characters=[row['target']] if action=='ACQUIRE' else [],
                            resources=[{'resource_id':TOKEN,'amount':row['delta']}] if action=='GRANT_TOKEN' else [],
                            xp=[{'character_id':row['target'],'amount':row['delta']}] if action=='GRANT_XP' else [])
                        plan=self.wallet._planner(grant).plan(meta_command(meta,row['command_id'],'APPLY_GRANT',{'grant_ref':ref}),meta)
                    need(plan.status=='CANDIDATE',plan.reason)
                    meta=FrozenMessage.from_value(plan.candidate.value['after_state'])
                if scenario=='equipment':
                    grant=self._grant('fixture.equipment',equipment=[{'instance_id':'fixture.blade.1','definition_id':'TEST_P17_BLADE'},{'instance_id':'fixture.charm.1','definition_id':'TEST_P17_CHARM'}])
                    plan=self.wallet._planner(grant).plan(meta_command(meta,'fixture.equipment.acquire','APPLY_GRANT',{'grant_ref':'fixture.equipment'}),meta)
                    need(plan.status=='CANDIDATE',plan.reason);meta=FrozenMessage.from_value(plan.candidate.value['after_state'])
            self.model=FixturePublisher(self.stage_planner,stage,meta,self.wallet)
            p04=json.loads((P18/'upstream/P17/sources/P04/content/characters/character_skeleton.json').read_text())
            self.characters_metadata={x['character_id']:x for x in p04['characters']}
            p07=json.loads((P18/'upstream/P07/content/stages/stage_graph.json').read_text())
            self.stages_metadata={x['stage_id']:x for x in p07['stages']}

    def _grant(self,ref,*,characters=(),resources=(),xp=(),equipment=()):
        return FrozenMessage.from_value({'schema_version':'P17-GRANT-INPUT/0.1.0-proposal','grant_ref':ref,
            'issuer':'P18','profile_id':self.scope,'source_kind':'STAGE_REPEAT',
            'identity':{'campaign_id':'fixture.bootstrap','stage_id':'fixture.not-a-player-stage','battle_id':ref},
            'eligibility_ref':'fixture.TEST_ONLY','policy_version':'fixture.P04-prefix',
            'policy_sha256':fingerprint('P20_TEST_BOOTSTRAP_NOT_GAME_GRANT'),'resources':list(resources),
            'characters':list(characters),'xp':list(xp),'equipment':list(equipment)})

    def _identity(self):return {'profile_id':self.scope,'store_instance':self.store,'continuity_ref':self.continuity,'session_id':self.session}

    def _binding(self):
        return {'identity':self._identity(),'revisions':{'meta':self.model.meta.value['revision'],'wallet':self.model.meta.value['wallet_revision'],'stage':self.model.stage.value['revision']},
            'source_hashes':{'meta':self.model.meta.sha256,'stage':self.model.stage.sha256,'content':fingerprint([self.wallet.catalog.sha256,self.catalog.sha256])}}

    def _level(self,state,row):
        cid=row['character_id'];rank=row['level'];costs=[];xp=0;to=rank;available=False;reason='E_LEVEL_CAP'
        try:
            config=self.wallet.catalog.cost(cid,'LEVEL',rank);costs=config['resources'];xp=config['requires_xp_total'];to=config['to_rank']
            result=self.meta_planner.plan(meta_command(state,'p20.preview.level','LEVEL_UP',{'character_id':cid,'from_rank':rank,'to_rank':to}),state)
            available=result.status=='CANDIDATE';reason='READY' if available else result.reason
        except DomainError: pass
        if self.model.stage.value['active_battle_id']:
            available=False;reason='E_MUTATION_BLOCKED_ACTIVE_BATTLE'
        return {'available':available,'reason':reason,'from_rank':rank,'to_rank':to,'requires_xp_total':xp,'costs':costs}

    def _equipment(self,state,row):
        result=[]
        for instance in state.value['equipment_instances']:
            definition=self.wallet.catalog.equipment(instance['definition_id']);item={'slot':definition['slot'],'instance_id':instance['instance_id']}
            proposed=self.meta_planner.plan(meta_command(state,'p20.preview.equipment','SET_EQUIPMENT',{'character_id':row['character_id'],'items':[item]}),state)
            result.append({**item,'name':instance['definition_id'],'available':proposed.status=='CANDIDATE','reason':proposed.reason})
        return result

    def _stage_action(self,sid):
        # Read-only preview uses a disposable registry; it never grants admission.
        try:
            authority=FixtureAuthority();authority.bind_store(self.model.stage)
            ref=authority.issue_entry(self.catalog,self.model.stage,self.model.meta,self.wallet,sid,'fixture.preview.battle')
            planner=StagePlanner(self.catalog,authority)
            request=stage_command(self.model.stage,self.catalog,'fixture.preview.enter','ENTER',{'stage_id':sid,'battle_id':'fixture.preview.battle','entry_ref':ref,'seed':1})
            result=planner.plan(request,self.model.stage)
            return result.status=='CANDIDATE', 'READY' if result.status=='CANDIDATE' else result.reason
        except (DomainError,StageError) as exc:return False,exc.code

    def view(self):
        with self.lock:
            if self.offline: raise ConnectionError('INJECTED_VIEW_DISCONNECTED')
            self.sequence+=1
            save={'contract_version':'YLTT-INTERNAL/0.1.0-isolated','dto_type':'SaveStatusView','store_instance':self.store,
                'state':self.save_state,'save_format_version':'P20_FIXTURE_MEMORY_ONLY','high_watermark':0,'reason_code':self.save_reason}
            if not self.model:
                save.update(store_instance=None,save_format_version=None,high_watermark=None)
                return {'schema_version':VIEW,'mode':'UNBOUND','sequence':self.sequence,'identity':self._identity(),
                    'revisions':{'meta':0,'wallet':0,'stage':0},'source_hashes':{k:'0'*64 for k in ('meta','stage','content')},
                    'save':validate_dto(save,'SaveStatusView').value,'capabilities':{'write_allowed':False,'equipment_enabled':False},
                    'wallet':None,'characters':[],'party':{'slots':[None,None,None],'valid':False},'stage_progress':None,'stage_details':[],
                    'settlement':None,'learning':copy.deepcopy(self.learning)}
            meta=self.model.meta;state=meta.value;stage=self.model.stage;progress=progress_view(stage,self.catalog).value
            save['high_watermark']=len(self.model.receipts)
            chars=[]
            for row in state['characters']:
                attr=self.meta_planner.character_attributes(meta,row['character_id']).value
                definition=self.characters_metadata[row['character_id']]
                chars.append({**row,'display_name':definition['display_name'],'role':definition['role_code'],
                    'stats':attr['stats'],'source_revision':attr['revision'],'source_sha256':meta.sha256,
                    'level_action':self._level(meta,row),'equipment_options':self._equipment(meta,row)})
            party_valid=True
            try:self.meta_planner.party_snapshot(meta)
            except DomainError:party_valid=False
            details=[]
            for row in progress['stages']:
                sid=row['stage_id'];definition=self.stages_metadata[sid];config=self.catalog.stage(sid)
                available,reason=self._stage_action(sid)
                details.append({'stage_id':sid,'name':definition['display_name'],'subtitle':'BOSS / 测试关卡' if definition['tier']=='BOSS' else 'NORMAL / 测试关卡',
                    'action_enabled':available,'reason':reason,'reward_preview':[{'label':'训练代币','amount':config['first']['tokens']},{'label':'每位角色经验','amount':config['first']['xp_each']}]})
            settlement=None
            if self.last_result:
                result=self.last_result.value;sid=result['stage_id']
                terminal=self.stage_planner.lookup_terminal(stage,result['battle_id'])
                status=get_row(progress['stages'],'stage_id',sid)['status']
                held=status in {'REVIEW_REQUIRED','PENDING_RECONCILIATION'}
                settlement={'battle_id':result['battle_id'],'stage_id':sid,'outcome':result['outcome'],
                    'result_id':result['result_id'],'terminal_revision':result['terminal_revision'],
                    'decision':self.last_decision,'claimable':terminal is None and not held,
                    'receipt':copy.deepcopy(self.last_receipt),'origin':'SYNTHETIC_BATTLE_RESULT_NOT_P14',
                    'reward_status':'QUARANTINED' if held else 'SIMULATED' if self.last_receipt else 'PREVIEW'}
            learning=copy.deepcopy(self.learning)
            if self.ledger_service and self.ledger_inbox:learning['query']=asdict(self.ledger_service.query(self.ledger_inbox))
            return {'schema_version':VIEW,'mode':'FIXTURE','sequence':self.sequence,**self._binding(),
                'save':validate_dto(save,'SaveStatusView').value,'capabilities':{'write_allowed':True,'equipment_enabled':self.wallet.catalog.value['equipment_enabled']},
                'wallet':self.meta_planner.wallet_snapshot(meta).value,'characters':chars,'party':{'slots':state['party_slots'],'valid':party_valid},
                'stage_progress':progress,'stage_details':details,'settlement':settlement,'learning':learning}

    def _check_intent(self,intent):
        need(type(intent) is dict and set(intent)=={'schema_version','request_id','binding','kind','payload'},'E_INTENT_SHAPE')
        need(intent['schema_version']==INTENT,'E_INTENT_VERSION')
        from stage_runtime.common import ident
        ident(intent['request_id']);need(intent['kind'] in COMMAND_PAYLOADS,'E_UI_COMMAND_KIND')
        need(type(intent['payload']) is dict and set(intent['payload'])==COMMAND_PAYLOADS[intent['kind']],'E_UI_PAYLOAD')
        canonical(intent) # P13 limit and unsafe number validation.

    def _reply(self,intent,status,reason,receipt=None):
        return {'request_id':intent['request_id'],'request_sha256':fingerprint(intent),'status':status,'reason':reason,
            'durable':False,'receipt':receipt,'view':self.view()}

    def submit(self,intent):
        with self.lock:
            self._check_intent(intent)
            rid=intent['request_id'];digest=fingerprint(intent)
            if rid in self.intents:
                if self.intents[rid]!=digest:return self._reply(intent,'REJECTED','E_COMMAND_ID_COLLISION')
                stored=self.responses.get(rid)
                if stored:return {**copy.deepcopy(stored),'view':self.view()}
                return self._reply(intent,'UNKNOWN','E_ORIGINAL_OPERATION_UNKNOWN')
            if not self.fixture or not self.model:return self._reply(intent,'BLOCKED','E_UNBOUND')
            if self.save_state!='READY':return self._reply(intent,'BLOCKED','E_SAVE_UNAVAILABLE')
            if intent['binding']!=self._binding():return self._reply(intent,'REJECTED','E_VIEW_STALE')
            if self.offline:raise ConnectionError('INJECTED_OFFLINE')
            self.intents[rid]=digest
            fault=self.fail_next;self.fail_next=None
            if fault=='before_publish_unknown':raise ConnectionError('INJECTED_BEFORE_SUBMIT_UNKNOWN')
            kind=intent['kind'];payload=intent['payload'];receipt=None;request=None;candidate=None
            before={'meta':self.model.meta.sha256,'stage':self.model.stage.sha256}
            try:
                if kind in {'SET_PARTY','LEVEL_UP','SET_EQUIPMENT'}:
                    need(not self.model.stage.value['active_battle_id'],'E_MUTATION_BLOCKED_ACTIVE_BATTLE')
                    request=meta_command(self.model.meta,rid,kind,payload)
                    result=self.meta_planner.plan(request,self.model.meta)
                    if result.status=='CANDIDATE':
                        candidate=result.candidate;receipt=self.model.submit_meta(self.meta_planner,candidate)
                else:
                    if kind=='ENTER_STAGE':
                        battle='p20.battle.'+fingerprint(rid)[:24]
                        ref=self.authority.issue_entry(self.catalog,self.model.stage,self.model.meta,self.wallet,payload['stage_id'],battle)
                        native={'stage_id':payload['stage_id'],'battle_id':battle,'entry_ref':ref,'seed':1};native_kind='ENTER'
                    else:
                        need(self.last_result is not None and self.last_result.value['battle_id']==payload['battle_id'],'E_RESULT_REFERENCE_UNBOUND')
                        native={'result':self.last_result.value};native_kind='SETTLE'
                    request=stage_command(self.model.stage,self.catalog,rid,native_kind,native)
                    result=self.stage_planner.plan(request,self.model.stage)
                    if result.status=='CANDIDATE':
                        candidate=result.candidate;bundle=self.model.prepare(candidate);receipt=self.model.submit(bundle)
                        if kind=='CLAIM_STAGE_REWARD':self.last_receipt=receipt;self.last_decision=candidate.value['decision']
                        else:self.last_result=None;self.last_receipt=None;self.last_decision='NOT_SETTLED'
                status=receipt['status'] if receipt else result.status
                need(status in {'COMMITTED_SIMULATION','DUPLICATE_NO_OP','REJECTED','BLOCKED'},'E_UNEXPECTED_PLAN_STATUS')
                response=self._reply(intent,status,result.reason,receipt)
            except (DomainError,StageError) as exc:response=self._reply(intent,'REJECTED',exc.code)
            self.responses[rid]=copy.deepcopy(response)
            self.trace.append({'intent':copy.deepcopy(intent),'intent_sha256':digest,'native_request':None if request is None else request.value,
                'candidate_sha256':None if candidate is None else candidate.sha256,'before':before,
                'after':{'meta':self.model.meta.sha256,'stage':self.model.stage.sha256},'receipt':receipt,'status':response['status']})
            if fault=='after_publish_unknown':raise ConnectionError('INJECTED_COMMITTED_RESPONSE_LOST')
            return response

    def lookup(self,intent):
        with self.lock:
            self._check_intent(intent);rid=intent['request_id'];digest=fingerprint(intent)
            if self.lookup_unknown or intent['binding']['identity']!=self._identity():return self._reply(intent,'UNKNOWN','E_AUTHORITATIVE_LOOKUP_UNAVAILABLE')
            if self.intents.get(rid)!=digest:return self._reply(intent,'UNKNOWN','E_ORIGINAL_REQUEST_NOT_FOUND_OR_MISMATCH')
            stored=self.responses.get(rid)
            if not stored:return self._reply(intent,'UNKNOWN','E_ORIGINAL_OPERATION_UNKNOWN')
            return {**copy.deepcopy(stored),'view':self.view()}

    def inject_result(self,outcome='WIN'):
        with self.lock:
            need(self.fixture and self.model is not None,'E_NOT_FIXTURE')
            battle=self.model.stage.value['active_battle_id'];need(battle is not None,'E_NO_ACTIVE_BATTLE')
            need(outcome in {'WIN','LOSS','DRAW'},'E_FIXTURE_OUTCOME')
            self.last_result=self.authority.issue_battle(self.model.stage,self.catalog,battle,outcome=outcome)
            self.last_receipt=None;self.last_decision='NOT_SETTLED'
            return self.last_result.value

    def revoke_first(self):
        with self.lock:
            fc=self.model.stage.value['first_clears'];need(bool(fc),'E_NO_FIRST_CLEAR')
            bid=fc[0]['battle_id'];terminal=self.stage_planner.lookup_terminal(self.model.stage,bid)
            result=FrozenMessage.from_value(terminal.value['result'])
            ref=self.authority.issue_control(self.model.stage,bid,result,ref='fixture.P20.revoke')
            req=stage_command(self.model.stage,self.catalog,'fixture.P20.revoke.'+str(self.model.stage.value['revision']),'REVOKE',{'control_ref':ref})
            candidate=self.stage_planner.plan(req,self.model.stage);need(candidate.status=='CANDIDATE',candidate.reason)
            return self.model.submit(self.model.prepare(candidate.candidate))

    def learning_scenario(self,state):
        with self.lock:
            need(self.fixture,'E_NOT_FIXTURE')
            if state not in {'DISCONNECTED','CONNECTED','APPLIED','QUARANTINED','PENDING_RECONCILIATION','REJECTED','REVERTED','REDELIVERY','RECONCILING'}:raise ValueError('UNKNOWN_LEARNING_SCENARIO')
            self.close();self.ledger_service=None;self.ledger_inbox=None
            self.learning={'connection':'DISCONNECTED' if state=='DISCONNECTED' else 'CONNECTED','pending_count':0,'query':None}
            if state in {'DISCONNECTED','CONNECTED'}:return self.learning
            self.temp=tempfile.TemporaryDirectory(prefix='p20-p11-test-');folder=Path(self.temp.name)
            (folder/'.P11_SIMULATION_ONLY').write_text('AUTHOR TEST ONLY\n')
            store=SQLiteAtomicModel(folder/'study.p11-sim.sqlite');evidence=FixtureEvidence();policy=FixturePolicy();wallet=FixtureWallet()
            service=StudyLedger(store,wallet,evidence,policy);review=event()
            if state=='QUARANTINED':evidence.blocked.add(review['event_id'])
            if state=='PENDING_RECONCILIATION':wallet.forced_hold='P20_TEST_RECONCILIATION_HOLD'
            if state=='REJECTED':outcome=service.handle(b'{not a valid learning event}')
            elif state=='REDELIVERY':
                outcome=service.receive(ledger_canonical(review));self.learning.update(connection='REDELIVERY',pending_count=2)
            else:outcome=service.handle(ledger_canonical(review))
            if state=='REVERTED':
                service.handle(ledger_canonical(control('UNDO','undo-1','review-1',1)));outcome=service.query(outcome.inbox_id)
            if state=='RECONCILING':
                store.lookup_unavailable=True;self.learning['connection']='RECONCILING'
            self.ledger_service=service;self.ledger_inbox=outcome.inbox_id
            self.learning['query']=asdict(service.query(outcome.inbox_id))
            return copy.deepcopy(self.learning)

    def control(self,action):
        with self.lock:
            need(self.fixture,'E_NOT_FIXTURE');kind=action.get('action')
            if kind=='reset':self.reset(action.get('scenario','demo'))
            elif kind=='result':self.inject_result(action.get('outcome','WIN'))
            elif kind=='learning':self.learning_scenario(action['state'])
            elif kind=='save':
                need(action.get('state') in SAVE_STATES,'E_SAVE_STATE');self.save_state=action['state'];self.save_reason='TEST_MIGRATION_FAILED' if self.save_state=='RECOVERY_REQUIRED' else 'TEST_SAVE_STATE'
            elif kind=='fault':
                need(action.get('value') in {'after_publish_unknown','before_publish_unknown',None},'E_FAULT_NAME');self.fail_next=action['value']
            elif kind=='offline':self.offline=action.get('value') is True
            elif kind=='lookup_unknown':self.lookup_unknown=action.get('value') is True
            elif kind=='revoke_first':self.revoke_first()
            else:raise ValueError('UNKNOWN_FIXTURE_CONTROL')
            return {'status':'TEST_CONTROL_APPLIED','durable':False}

def make_intent(view,kind,payload,request_id='p20.test.request'):
    return {'schema_version':INTENT,'request_id':request_id,'binding':{k:copy.deepcopy(view[k]) for k in ('identity','revisions','source_hashes')},'kind':kind,'payload':payload}
