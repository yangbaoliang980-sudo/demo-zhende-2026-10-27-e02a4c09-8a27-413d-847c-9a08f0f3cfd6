import {MetaController} from './controller.mjs';
import {HttpMetaPort} from './port.mjs';
import {render} from './renderer.mjs';
import {ROUTES} from './model.mjs';
const root=document.getElementById('app');const feedback=document.getElementById('feedback');
let storage;try{storage=window.localStorage;}catch{storage={getItem(){throw Error('E_STORAGE_UNAVAILABLE');},setItem(){throw Error('E_STORAGE_UNAVAILABLE');},removeItem(){throw Error('E_STORAGE_UNAVAILABLE');}};}
const c=new MetaController({port:new HttpMetaPort(),storage,onChange(s){if(location.hash!==`#${s.route}`)history.replaceState({p20:true},'',`#${s.route}`);render(s,root);feedback.textContent=[s.message,s.error].filter(Boolean).join(' ');feedback.classList.toggle('visible',!!feedback.textContent);}});
const route=location.hash.slice(1);if(ROUTES.includes(route))c.route=route;
const dialog=document.getElementById('confirm-dialog');let confirmedIntent=null;
function navigate(r){if(ROUTES.includes(r)){history.pushState({p20:true},'',`#${r}`);c.navigate(r);}}
root.addEventListener('change',event=>{if(event.target.matches('[data-slot]'))c.setSlot(Number(event.target.dataset.slot),event.target.value||null);});
root.addEventListener('keydown',event=>{if(event.repeat && ['Enter',' '].includes(event.key))event.preventDefault();});
root.addEventListener('click',event=>{
 const el=event.target.closest('[data-action]');if(!el||el.disabled)return;event.preventDefault();
 const a=el.dataset.action,id=el.dataset.id;
 if(a==='nav')navigate(el.dataset.route);
 else if(a==='refresh')c.refresh();
 else if(a==='lookup')c.lookupPending();
 else if(a==='select-character')c.selectCharacter(id);
 else if(a==='grow'){c.selectCharacter(id);navigate('growth');}
 else if(a==='select-stage')c.selectStage(id);
 else if(a==='reset-party')c.resetDraft();
 else if(a==='save-party')c.dispatch('SET_PARTY',{ordered_character_ids:c.partyDraft});
 else if(a==='enter-stage'){c.selectStage(id);c.dispatch('ENTER_STAGE',{stage_id:id});}
 else if(a==='claim'&&c.view.settlement)c.dispatch('CLAIM_STAGE_REWARD',{battle_id:c.view.settlement.battle_id});
 else if(a==='level-dialog'&&c.selected){
   const x=c.selected,a=x.level_action;confirmedIntent={character_id:x.character_id,from_rank:a.from_rank,to_rank:a.to_rank};
   document.getElementById('confirm-description').textContent=`${x.display_name}：Lv.${a.from_rank} → Lv.${a.to_rank}。本次配置消耗：${a.costs.map(r=>r.amount+' 训练代币').join('，')||'—'}（测试数值）。`;
   dialog.returnValue='';dialog.showModal();
 }else if(a==='equip'&&c.selected){const select=document.getElementById('equipment-select');const option=select?.selectedOptions[0];if(select?.value&&option)c.dispatch('SET_EQUIPMENT',{character_id:c.selected.character_id,items:[{slot:option.dataset.slot,instance_id:select.value}]});}
 else if(a==='unequip'&&c.selected)c.dispatch('SET_EQUIPMENT',{character_id:c.selected.character_id,items:[]});
});
dialog.addEventListener('close',()=>{if(dialog.returnValue==='confirm'&&confirmedIntent)c.dispatch('LEVEL_UP',confirmedIntent);confirmedIntent=null;});
window.addEventListener('popstate',()=>c.navigate(ROUTES.includes(location.hash.slice(1))?location.hash.slice(1):'home'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)c.pause();else c.refresh();});
window.addEventListener('online',()=>c.refresh());
window.addEventListener('offline',()=>{c.phase=c.pending?'UNKNOWN':'DISCONNECTED';c.error='网络连接已断开。';c.emit();});
window.addEventListener('pagehide',()=>c.pause());
window.addEventListener('pageshow',event=>{if(event.persisted)c.refresh();});
await c.refresh();
