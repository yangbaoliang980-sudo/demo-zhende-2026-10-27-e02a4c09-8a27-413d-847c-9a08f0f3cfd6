const value=id=>document.getElementById(id).value;
async function send(data){const r=await fetch('/api/fixture',{method:'POST',headers:{'Content-Type':'application/json','X-P20-UI':'1'},body:JSON.stringify(data)});document.getElementById('lab-output').textContent=JSON.stringify(await r.json());}
document.getElementById('reset').onclick=()=>send({action:'reset',scenario:value('scenario')});
document.getElementById('study').onclick=()=>send({action:'learning',state:value('learning')});
document.getElementById('result').onclick=()=>send({action:'result',outcome:value('outcome')});
document.getElementById('save-state').onclick=()=>send({action:'save',state:value('save')});
document.getElementById('lost').onclick=()=>send({action:'fault',value:'after_publish_unknown'});
