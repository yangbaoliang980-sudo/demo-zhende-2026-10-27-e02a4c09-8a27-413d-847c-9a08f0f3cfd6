// The host must inject this proposal. It does not grant production authority.
export class HttpMetaPort {
  constructor(base='',fetcher=globalThis.fetch.bind(globalThis),{timeoutMs=8000}={}){this.base=base;this.fetcher=fetcher;this.timeoutMs=timeoutMs;}
  async request(path,payload){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),this.timeoutMs);
    try{
      const response=await this.fetcher(this.base+path,{method:payload?'POST':'GET',headers:payload?{'Content-Type':'application/json','X-P20-UI':'1'}:{},body:payload?JSON.stringify(payload):undefined,cache:'no-store',credentials:'same-origin',signal:controller.signal});
      if(!response.ok)throw new Error(`HTTP_${response.status}`);
      return await response.json();
    }finally{clearTimeout(timer);}
  }
  read(){return this.request('/api/view');}
  submit(intent){return this.request('/api/command',intent);}
  lookup(intent){return this.request('/api/lookup',intent);}
}
