import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {validateView,canonical,sha256,learningLabel,stageLabel,reasonText,ROUTES,copy,binding,INTENT_VERSION} from '../../ui/meta/model.mjs';
import {MetaController,NAV_KEY,PENDING_KEY} from '../../ui/meta/controller.mjs';
import {HttpMetaPort} from '../../ui/meta/port.mjs';
const fixtures=new URL('./fixtures/',import.meta.url);
const fixture=name=>JSON.parse(fs.readFileSync(new URL(name+'.json',fixtures),'utf8'));
const BASE=fixture('demo'),UP=fixture('upgrade_committed');
const CID=BASE.characters[0].character_id;const PAYLOAD={character_id:CID,from_rank:1,to_rank:2};
class MemoryStorage{
 constructor(){this.data=new Map();this.failSet=false;this.failGet=false;this.failRemove=false;}
 getItem(k){if(this.failGet)throw Error('blocked storage');return this.data.get(k)||null;}
 setItem(k,v){if(this.failSet)throw Error('storage full');this.data.set(k,v);}
 removeItem(k){if(this.failRemove)throw Error('remove blocked');this.data.delete(k);}
}
function deferred(){let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});return {promise,resolve,reject};}
function setup(initial=BASE){
 const storage=new MemoryStorage();let current=copy(initial),seq=0;
 const port={submits:[],lookups:[],reads:0,async read(){this.reads++;return copy(current);},async submit(intent){this.submits.push(copy(intent));return response(intent,current);},async lookup(intent){this.lookups.push(copy(intent));return response(intent,current);}};
 const c=new MetaController({port,storage,idFactory:()=>`p20.unit.${++seq}`});
 return {c,port,storage,setView(v){current=copy(v);}};
}
async function response(intent,view=BASE,status='COMMITTED_SIMULATION'){
 const next=copy(view);next.sequence+=100;
 return {request_id:intent.request_id,request_sha256:await sha256(intent),status,reason:'FIXTURE_REPLY_ONLY',durable:false,view:next};
}
async function ready(initial=BASE){const s=setup(initial);await s.c.refresh();return s;}

for(const filename of fs.readdirSync(fileURLToPath(fixtures)).filter(x=>x.endsWith('.json'))){
 test(`native owner fixture validates: ${filename}`,()=>{const v=JSON.parse(fs.readFileSync(new URL(filename,fixtures),'utf8'));assert.equal(validateView(v).schema_version,v.schema_version);});
}
const invalid=[
 ['view version',v=>v.schema_version='wrong','E_VIEW_VERSION'],
 ['production mode cannot be self enabled',v=>v.mode='PRODUCTION','E_VIEW_MODE'],
 ['unsafe revision',v=>v.revisions.meta=Number.MAX_SAFE_INTEGER+1,'E_VIEW_REVISION'],
 ['boolean sequence',v=>v.sequence=true,'E_VIEW_SEQUENCE'],
 ['null identity',v=>v.identity=null,'E_VIEW_IDENTITY'],
 ['source hash missing',v=>v.source_hashes.stage='','E_VIEW_SOURCE_HASH'],
 ['save unknown state',v=>v.save.state='SUCCESS','E_SAVE_STATE'],
 ['save other store',v=>v.save.store_instance='other','E_SAVE_STORE_BINDING'],
 ['wallet other player',v=>v.wallet.beneficiary_id='other','E_WALLET_BINDING'],
 ['wallet wrong revision',v=>v.wallet.revision++,'E_WALLET_BINDING'],
 ['negative available',v=>v.wallet.balances[0].available=-1,'E_WALLET_BALANCE'],
 ['boolean reserved',v=>v.wallet.balances[0].reserved=true,'E_WALLET_BALANCE'],
 ['duplicate resource',v=>v.wallet.balances.push(copy(v.wallet.balances[0])),'E_WALLET_ROWS'],
 ['duplicate character',v=>v.characters.push(copy(v.characters[0])),'E_CHARACTER_ROWS'],
 ['unknown character in party',v=>v.party.slots[0]='unknown','E_PARTY_MEMBER'],
 ['duplicate party member',v=>v.party.slots[1]=v.party.slots[0],'E_PARTY_MEMBER'],
 ['party count not three',v=>v.party.slots.pop(),'E_PARTY_SHAPE'],
 ['party false validity',v=>v.party.valid=false,'E_PARTY_VALID'],
 ['negative character stat',v=>v.characters[0].stats.max_hp=-2,'E_CHARACTER_STATS'],
 ['character stale source',v=>v.characters[0].source_revision--,'E_CHARACTER_BINDING'],
 ['level quote wrong rank',v=>v.characters[0].level_action.from_rank++,'E_LEVEL_BINDING'],
 ['negative quote',v=>v.characters[0].level_action.costs[0].amount=-1,'E_LEVEL_COST'],
 ['stage source mismatch',v=>v.stage_progress.source_snapshot_sha256='a'.repeat(64),'E_STAGE_BINDING'],
 ['stage other profile',v=>v.stage_progress.player_save_scope_id='other','E_STAGE_BINDING'],
 ['stage unknown status',v=>v.stage_progress.stages[0].status='PAID','E_STAGE_FIELDS'],
 ['lock-unlocked conflict',v=>v.stage_progress.stages[1].unlocked=true,'E_STAGE_INCONSISTENT'],
 ['locked button available',v=>v.stage_details[1].action_enabled=true,'E_STAGE_ACTION_BINDING'],
 ['stage catalog drift',v=>v.stage_details[0].stage_id='other','E_STAGE_CATALOG_BINDING'],
 ['missing stage view with details',v=>v.stage_progress=null,'E_STAGE_DATA_MISSING'],
 ['negative pending count',v=>v.learning.pending_count=-1,'E_LEARNING_TRANSPORT'],
 ['unknown connection',v=>v.learning.connection='PAID','E_LEARNING_TRANSPORT'],
 ['unbound data must be placeholders',v=>{v.mode='UNBOUND';v.capabilities.write_allowed=false;},'E_UNBOUND_PLACEHOLDER_DATA'],
];
for(const [name,mutate,error] of invalid)test(`reject malformed binding: ${name}`,()=>{const v=copy(BASE);mutate(v);assert.throws(()=>validateView(v),new RegExp(error));});

test('view and nested records are detached and frozen',()=>{const raw=copy(BASE),v=validateView(raw);raw.wallet.balances[0].available=999;assert.equal(v.wallet.balances[0].available,15);assert.throws(()=>{v.party.slots[0]='x';});});
test('canonical hashing follows sorted keys and Unicode UTF-8',async()=>{assert.equal(canonical({b:'言',a:1}),' {"a":1,"b":"言"}'.trim());assert.equal(await sha256({b:'言',a:1}),await sha256({a:1,b:'言'}));});
for(const state of ['applied','quarantined','pending_reconciliation','rejected','reverted','redelivery','reconciling'])test(`learning status never promotes fixture to credited: ${state}`,()=>{const v=fixture('learning_'+state);const label=learningLabel(v.learning,v.mode);assert.equal(label.credited,false);assert.ok(!label.title.includes('到账'));assert.ok(!label.title.includes('已入账'));});
test('APPLIED with simulator durable receipt stays test-only',()=>{const v=fixture('learning_applied');assert.equal(v.learning.query.receipt.durable,true);assert.equal(learningLabel(v.learning,v.mode).key,'APPLIED_SIMULATION');});
test('self-reported production receipt lacks accepted adapter proof',()=>{const l=fixture('learning_applied').learning;l.query.evidence_scope='P21_PRODUCTION';l.query.receipt.origin='P21_PRODUCTION';const v=learningLabel(l,'UNBOUND');assert.equal(v.credited,false);assert.equal(v.key,'APPLIED_UNVERIFIED');});
test('disconnected does not masquerade as rejected reward',()=>{const l=learningLabel({connection:'DISCONNECTED',pending_count:0,query:null});assert.equal(l.title,'Anki 未连接');assert.equal(l.credited,false);});
test('quarantine, review and locked stage labels are distinct',()=>{assert.equal(stageLabel({status:'PENDING_RECONCILIATION'}),'结算已隔离');assert.equal(stageLabel({status:'REVIEW_REQUIRED'}),'进度待核对');assert.equal(stageLabel({status:'LOCKED'}),'未解锁');});
test('unknown reason is preserved for receiver diagnosis',()=>assert.equal(reasonText('E_NEW_OWNER_REASON'),'E_NEW_OWNER_REASON'));

test('read-only navigation through every page emits no command',async()=>{const {c,port}=await ready();for(const route of ROUTES)assert.equal(c.navigate(route),true);assert.equal(port.submits.length,0);});
test('invalid route is rejected without changing location',async()=>{const {c}=await ready();assert.equal(c.navigate('../../wallet'),false);assert.equal(c.route,'home');});
test('Anki disconnected does not block unrelated menu play',async()=>{const {c}=await ready();assert.equal(c.view.learning.connection,'DISCONNECTED');assert.equal(c.canMutate,true);});
test('empty and unbound retain navigation while action is blocked',async()=>{const {c,port}=await ready(fixture('unbound'));c.navigate('growth');assert.equal(c.canMutate,false);assert.equal((await c.dispatch('LEVEL_UP',PAYLOAD)).status,'BLOCKED_UI');assert.equal(port.submits.length,0);});
test('party editing swaps occupied slots without changing snapshot',async()=>{const {c}=await ready();const original=[...c.view.party.slots];c.setSlot(0,original[2]);assert.deepEqual(c.partyDraft,[original[2],original[1],original[0]]);assert.deepEqual(c.view.party.slots,original);assert.equal(c.draftDirty,true);});
test('incomplete party cannot submit',async()=>{const {c,port}=await ready();c.setSlot(0,null);assert.equal((await c.dispatch('SET_PARTY',{ordered_character_ids:c.partyDraft})).status,'BLOCKED_UI');assert.equal(port.submits.length,0);});
test('draft reset restores domain order',async()=>{const {c}=await ready();c.setSlot(0,c.partyDraft[2]);c.resetDraft();assert.deepEqual(c.partyDraft,c.view.party.slots);assert.equal(c.draftDirty,false);});
test('double dispatch synchronous lock gives exactly one request',async()=>{const {c,port}=await ready();const wait=deferred();port.submit=async i=>{port.submits.push(i);return wait.promise;};const first=c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'SENDING');assert.equal((await c.dispatch('LEVEL_UP',PAYLOAD)).status,'BLOCKED_UI');await new Promise(r=>setTimeout(r,5));assert.equal(port.submits.length,1);wait.resolve(await response(port.submits[0],UP));await first;assert.equal(c.view.wallet.balances[0].available,11);});
test('no optimistic balance changes while request is pending',async()=>{const {c,port}=await ready();const wait=deferred();port.submit=async i=>{port.submits.push(i);return wait.promise;};const call=c.dispatch('LEVEL_UP',PAYLOAD);await new Promise(r=>setTimeout(r,5));assert.equal(c.view.wallet.balances[0].available,15);assert.equal(c.view.characters[0].level,1);wait.resolve(await response(port.submits[0],UP));await call;assert.equal(c.view.characters[0].level,2);});
test('save migration failure disables all mutations',async()=>{const v=copy(BASE);v.save.state='RECOVERY_REQUIRED';const {c,port}=await ready(v);c.navigate('chapters');assert.equal(c.canMutate,false);assert.equal((await c.dispatch('ENTER_STAGE',{stage_id:v.stage_details[0].stage_id})).status,'BLOCKED_UI');assert.equal(port.submits.length,0);});
test('read-only save disables mutations',async()=>{const v=copy(BASE);v.save.state='READ_ONLY';const {c}=await ready(v);assert.equal(c.canMutate,false);});
test('response loss retains original full request in storage',async()=>{const {c,port,storage}=await ready();port.submit=async i=>{port.submits.push(copy(i));throw Error('response lost');};await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'UNKNOWN');const pending=JSON.parse(storage.getItem(PENDING_KEY));assert.deepEqual(pending.intent,port.submits[0]);assert.equal(c.canMutate,false);});
test('lookup resolves without issuing a second mutation',async()=>{const {c,port}=await ready();port.submit=async i=>{port.submits.push(copy(i));throw Error('lost');};port.lookup=async i=>{port.lookups.push(copy(i));return response(i,UP);};await c.dispatch('LEVEL_UP',PAYLOAD);await c.lookupPending();assert.equal(port.submits.length,1);assert.equal(port.lookups.length,1);assert.deepEqual(port.submits[0],port.lookups[0]);assert.equal(c.pending,null);assert.equal(c.view.wallet.balances[0].available,11);});
test('reload restores pending intent and never auto-resubmits',async()=>{const {c,port,storage}=await ready();port.submit=async i=>{port.submits.push(copy(i));throw Error('lost');};await c.dispatch('LEVEL_UP',PAYLOAD);const reopened=new MetaController({port,storage});await reopened.refresh();assert.equal(reopened.phase,'UNKNOWN');assert.deepEqual(reopened.pending,c.pending);assert.equal(port.submits.length,1);});
test('successful known response clears persisted pending before next action',async()=>{const {c,storage}=await ready();await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(storage.getItem(PENDING_KEY),null);assert.equal(c.pending,null);assert.equal(c.phase,'READY');});
test('storage write failure blocks network submission',async()=>{const {c,port,storage}=await ready();storage.failSet=true;assert.equal((await c.dispatch('LEVEL_UP',PAYLOAD)).status,'BLOCKED_STORAGE');assert.equal(port.submits.length,0);assert.equal(c.canMutate,false);});
test('storage read corruption blocks changes without erasing evidence',async()=>{const s=setup();s.storage.setItem(PENDING_KEY,'{broken');const c=new MetaController({port:s.port,storage:s.storage});await c.refresh();assert.equal(c.storageFault,true);assert.equal(c.canMutate,false);assert.equal(s.storage.getItem(PENDING_KEY),'{broken');});
test('storage remove failure retains unknown even after new snapshot',async()=>{const {c,storage,port}=await ready();port.submit=i=>response(i,UP);storage.failRemove=true;await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);assert.equal(c.canMutate,false);});
test('receipt request hash mismatch cannot clear pending',async()=>{const {c,port}=await ready();port.submit=async i=>({...await response(i,UP),request_sha256:'0'.repeat(64)});await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);assert.match(c.error,/E_REPLY_BINDING/);});
test('candidate is not a committed UI reply',async()=>{const {c,port}=await ready();port.submit=i=>response(i,BASE,'CANDIDATE');await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);});
test('formal receipt cannot be smuggled through fixture reply',async()=>{const {c,port}=await ready();port.submit=async i=>({...await response(i,UP),durable:true});await c.dispatch('LEVEL_UP',PAYLOAD);assert.equal(c.phase,'UNKNOWN');assert.match(c.error,/E_ISOLATED_RECEIPT_SCOPE/);});
test('unknown lookup remains locked and preserves request',async()=>{const {c,port}=await ready();port.submit=async()=>{throw Error('lost');};port.lookup=i=>response(i,BASE,'UNKNOWN');await c.dispatch('LEVEL_UP',PAYLOAD);await c.lookupPending();assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);});
test('absent lookup cannot be treated as safe replay',async()=>{const {c,port}=await ready();port.submit=async()=>{throw Error('lost');};port.lookup=i=>response(i,BASE,'ABSENT');await c.dispatch('LEVEL_UP',PAYLOAD);await c.lookupPending();assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);});
test('host restart cannot clear prior-instance unknown operation',async()=>{const {c,port,setView}=await ready();port.submit=async()=>{throw Error('lost');};await c.dispatch('LEVEL_UP',PAYLOAD);const v=copy(BASE);v.identity.session_id='new.session';v.sequence=500;setView(v);await c.refresh();port.lookup=i=>response(i,v);await c.lookupPending();assert.equal(c.phase,'UNKNOWN');assert.ok(c.pending);assert.match(c.error,/E_REPLY_STORE_FENCE/);});
test('restored pending tampering never sends lookup',async()=>{const {c,port,storage}=await ready();port.submit=async()=>{throw Error('lost');};await c.dispatch('LEVEL_UP',PAYLOAD);const p=JSON.parse(storage.getItem(PENDING_KEY));p.intent.payload.to_rank=4;storage.setItem(PENDING_KEY,JSON.stringify(p));const re=new MetaController({port,storage});await re.refresh();await re.lookupPending();assert.match(re.error,/E_PENDING_HASH/);assert.equal(port.lookups.length,0);});
test('old view cannot roll back displayed wallet',async()=>{const {c}=await ready(UP);const old=copy(BASE);assert.equal(c.adoptView(old),false);assert.equal(c.view.wallet.balances[0].available,11);});
test('same sequence differing content fails closed',async()=>{const {c}=await ready();const conflict=copy(BASE);conflict.wallet.balances[0].available=999;assert.throws(()=>c.adoptView(conflict),/E_SAME_SEQUENCE_CONFLICT/);assert.equal(c.view.wallet.balances[0].available,15);});
test('larger UI sequence cannot hide domain revision rollback',async()=>{const {c}=await ready(UP);const old=copy(BASE);old.sequence=999;assert.throws(()=>c.adoptView(old),/E_REVISION_ROLLBACK/);});
test('out-of-order read completion does not replace current view',async()=>{const {c,port}=await ready();const a=deferred(),b=deferred();let n=0;port.read=()=>++n===1?a.promise:b.promise;const read1=c.refresh(),read2=c.refresh();b.resolve(UP);await read2;a.resolve(BASE);await read1;assert.equal(c.view.wallet.balances[0].available,11);});
test('disconnect keeps last snapshot marked noninteractive',async()=>{const {c,port}=await ready();port.read=async()=>{throw Error('offline');};await c.refresh();assert.equal(c.phase,'DISCONNECTED');assert.equal(c.canMutate,false);assert.equal(c.view.wallet.balances[0].available,15);});
test('reconnect clears old network error',async()=>{const {c,port}=await ready();port.read=async()=>{throw Error('offline');};await c.refresh();port.read=async()=>BASE;await c.refresh();assert.equal(c.phase,'READY');assert.equal(c.error,'');});
test('background pause prevents stale actions until refreshed',async()=>{const {c}=await ready();c.pause();assert.equal(c.phase,'STALE');assert.equal(c.canMutate,false);await c.refresh();assert.equal(c.phase,'READY');});
test('navigation persists only UI preferences',async()=>{const {c,storage}=await ready();c.navigate('growth');const data=JSON.parse(storage.getItem(NAV_KEY));assert.deepEqual(Object.keys(data).sort(),['character_id','route','stage_id','version']);assert.equal(data.route,'growth');});
test('party draft does not silently persist as saved domain state',async()=>{const {c,port,storage}=await ready();c.setSlot(0,c.partyDraft[2]);const re=new MetaController({port,storage});await re.refresh();assert.deepEqual(re.partyDraft,BASE.party.slots);});
test('locked stage and active battle cannot create admission',async()=>{const {c,port}=await ready();assert.equal((await c.dispatch('ENTER_STAGE',{stage_id:BASE.stage_details[1].stage_id})).status,'BLOCKED_UI');assert.equal(port.submits.length,0);const a=await ready(fixture('active_battle'));assert.equal((await a.c.dispatch('ENTER_STAGE',{stage_id:BASE.stage_details[0].stage_id})).status,'BLOCKED_UI');});
test('settlement page opening never claims',async()=>{const {c,port}=await ready(fixture('settlement_pending'));c.navigate('settlement');await c.refresh();assert.equal(port.submits.length,0);});
test('committed and quarantined settlement cannot be claimed',async()=>{for(const f of ['settlement_committed','stage_review']){const {c,port}=await ready(fixture(f));assert.equal((await c.dispatch('CLAIM_STAGE_REWARD',{battle_id:c.view.settlement.battle_id})).status,'BLOCKED_UI');assert.equal(port.submits.length,0);}});
test('late action response does not hijack a newer navigation',async()=>{const {c,port}=await ready();const wait=deferred();port.submit=async i=>{port.submits.push(i);return wait.promise;};const call=c.dispatch('ENTER_STAGE',{stage_id:BASE.stage_details[0].stage_id});await new Promise(r=>setTimeout(r,5));c.navigate('characters');wait.resolve(await response(port.submits[0]));await call;assert.equal(c.route,'characters');});
test('disposed controller ignores read completion',async()=>{const {c,port}=await ready();const wait=deferred();port.read=()=>wait.promise;const call=c.refresh();c.dispose();wait.resolve(UP);assert.equal(await call,false);assert.equal(c.view.wallet.balances[0].available,15);});
test('HTTP port uses read-only lookup endpoint and preserves payload',async()=>{const calls=[];const port=new HttpMetaPort('',async(...args)=>{calls.push(args);return {ok:true,json:async()=>({ok:true})};});await port.lookup({a:1});assert.equal(calls[0][0],'/api/lookup');assert.equal(calls[0][1].headers['X-P20-UI'],'1');assert.deepEqual(JSON.parse(calls[0][1].body),{a:1});});
test('HTTP error is not parsed as a committed result',async()=>{const port=new HttpMetaPort('',async()=>({ok:false,status:503}));await assert.rejects(()=>port.submit({}),/HTTP_503/);});
test('native fetch retains global receiver in browser-compatible path',async()=>{const original=globalThis.fetch;try{globalThis.fetch=async function(){assert.equal(this,globalThis);return {ok:true,json:async()=>({ok:true})};};const port=new HttpMetaPort();assert.deepEqual(await port.read(),{ok:true});}finally{globalThis.fetch=original;}});
