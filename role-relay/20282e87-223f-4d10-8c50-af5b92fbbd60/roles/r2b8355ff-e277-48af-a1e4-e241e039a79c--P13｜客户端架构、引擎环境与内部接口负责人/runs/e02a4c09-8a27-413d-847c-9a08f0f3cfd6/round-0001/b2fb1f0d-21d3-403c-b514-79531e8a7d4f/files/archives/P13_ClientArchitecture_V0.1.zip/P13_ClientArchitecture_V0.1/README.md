# P13｜客户端架构、引擎环境与内部接口交付

**已完成本岗位可执行隔离交付；目标游戏 Runtime 仍 BLOCKED，真实引擎启动/Anki 联动/跨模块整合和独立门禁均 NOT_RUN。**

- 任务：P13-S00-ARCH-001；上游任务：P01 TASK-00-02。
- 交付：P13-CLIENT-ARCH/0.1.0-isolated。
- 内部契约：YLTT-INTERNAL/0.1.0-isolated。
- 日期：2026-10-29（UTC+08）；精确运行时间保留在 UTC 原始回执。
- 本轮直接由 P13 完成；没有创建子角色，没有修改其他 owner 的业务源码，没有 GitHub 写入或合并提交。

## 1. 本轮实际结果

已递归解包核验 **25 个不同 ZIP、1,268 个文件成员、484 条转交清单、642 条上游交付清单**。保留 **28 份主要上游原字节**与 P12 完整原 ZIP，读取 P01/P02/P04/P08/V6 及 P11/P12 的相关实际内容。两个指定 GitHub 固定树也已读取，并将已有文件字节与其 Git blob/大小绑定；并非只看文件名。

未取得可识别的目标游戏工程，当前主机 PATH 未发现 Godot/Unity/.NET/Anki。**Python 框架能运行，不代表游戏引擎能启动。** 结论仅限本次附件、指定固定树和执行主机，不推断用户其他工程不存在。

交付包含 **21 类公开 DTO、19 类战斗事件形状、21 个 JSON 样例**，以及严格解析/规范指纹、不可变消息、端口装配检查、有限容量线程邮箱、只读事件顺序守卫、通用脚本化 Mock、环境/引擎探针源码、测试与原始日志。没有重写 P14 战斗、P17 钱包、P21 存档或 P19/P29 界面/动画。

## 2. 强制文件与阅读顺序

| 文件 | 用途 |
|---|---|
| [engineering_inventory.tsv](architecture/engineering_inventory.tsv) | 2,272 行盘点：实际字节、远端树元数据和当前工具发现分级 |
| [actual_path_mapping.json](architecture/actual_path_mapping.json) | 已核验的隔离路径、来源/授权、只读输入；生产路径 null |
| [do_not_touch.txt](architecture/do_not_touch.txt) | 上游保护与默认拒绝的修改边界 |
| [architecture_adr.md](architecture/architecture_adr.md) | 引擎待决、所有权、整数、线程、视图和 P12 耦合决策 |
| [internal_api_contracts.json](contracts/internal/internal_api_contracts.json) | 内部契约版本、各 IC owner、唯一写入者与兼容规则 |
| [internal_dto.schema.json](contracts/internal/internal_dto.schema.json) | 实体 JSON Schema；语义见同目录 contract_semantics.md |
| [verification_status.json](architecture/verification_status.json) | 作者检查、正式接入、真机与独立验收分层状态 |
| [integration_handoff.md](architecture/integration_handoff.md) | 运行入口、各接收方可用工件、线程与变更约束 |

代码布局和依赖图在 architecture/code_layout.md、module_graph.json、dependency_diagram.mmd。P19/P29 的显示租约、掉序与取消合同在 contracts/internal/presentation_adapter_spec.md。7 条 RFC/CR 均随包准备，未冒充其他 owner 已签收。

## 3. 实际验证

| 层级 | 实际结果 | 范围 |
|---|---|---|
| P13 作者单元/接口边界 | PASS，54/54 | 标准库框架；不含 P14 业务或实际 UI |
| JSON Schema 算法对照 | PASS，4,540 个实例 | jsonschema 4.25.1；另有 432 个因线格式限制排除，未混入比较数 |
| Python/JavaScript 规范 JSON 与 SHA | PASS，25/25 | 同一固定向量的规范字节与哈希完全相同 |
| 所有权与源码依赖 | PASS | 5 个关联 IC、9 个实际核心模块、28 份原字节；无循环 |
| 隔离接线示例 | PASS | 合成输入/固定响应；明确未执行战斗/钱包/渲染/Anki |
| 原样 P12 解析与 ACK/账本协作复跑 | PASS，46/46 | 在原包内单独运行；不是 P13-P12 正式接入 |
| 环境发现/正式前置检查 | BLOCKED，exit 3 | 已实际执行检查；未取得目标工程/设备/正式合同 |
| 引擎启动、目标 UI、真实 Anki、P21 生产事务、E2E | NOT_RUN | 没有用 Mock 代替 |
| P32 独测、P33 人工、P35 独审 | NOT_RUN | 未代签 |

每次作者运行有 command argv、cwd、时间、退出码、stdout/stderr、日志 SHA 和执行时源码快照。早期依赖下载失败、静态审阅修订及上游规划路径歧义见 architecture/defect_log.json。最终核心源码/Schema 与实际执行快照绑定在 architecture/evidence/final_source_binding.json。

## 4. 下一位直接运行

在解压根使用 **Python 3.12**；普通框架/测试只有标准库依赖。

```bash
python -B architecture/tools/verify_delivery.py
python -B -m unittest discover -s runtime/framework/tests -p 'test_*.py' -v
python -B -m runtime.framework.yltt_framework.demo
python -B architecture/tools/check_architecture.py
python -B architecture/tools/preflight.py
```

前四条成功应返回 0；最后一条当前应返回 **3 / BLOCKED**，不能把它改成 0 充当放行。复测不写入已冻结包；独立审查者保存自己的外部日志和接收回执。

可选独立算法核验（建议在自己的虚拟环境安装，普通测试不需要）：

```bash
python -m pip install -r architecture/requirements-dev.txt
python -B architecture/tools/schema_oracle.py
node architecture/tools/canonical_oracle.js
```

重新核验真实目标环境用 runtime/framework/probes/ 下的工具；本轮只执行 environment probe。目标引擎导入、主场景、渲染/导出与 E2E 必须分别取得证据。复现原始附件递归盘点还需原三份上传 ZIP；本包保留了所有盘点/清单结果和主要消费文件，P13 主测试不依赖再次下载附件或 GitHub。

## 5. 准确的接手边界

P14 唯一提交 BattleState/费用；P15 仅给 DeckPatchCandidate；P16 仅给意图/阶段候选。P17 唯一钱包业务路径，P21 唯一物理存档；P11 学习资格与 P18 关卡进度分域。P19 绑定最终快照并提供显示租约，P29 只做临时表现。

P12 当前 bridge 对 P11 私有账本结构的访问已登记 RFC。P13 给出 StudyStatusView/CommitProofView 等提案，由原 owner 修改自己的适配，原 wire 协议保持不变。正式内外协议联合接收仍未完成。

本次向 **17 个接收岗位准备 65 条带实际 SHA 的工件交接记录**，见 architecture/downstream_handoff.json；均 PREPARED_NOT_ACKNOWLEDGED。接收方可使用隔离 DTO/Mock 继续其已获授权的独立研发，但不能据此覆盖真实工程。

## 6. 目标 Runtime 解除阻塞需要什么

P01 转交真实游戏源码的固定 commit/ZIP SHA、工程根、入口配置、原 owner 和只读探针授权；P34 转交目标 OS/架构、硬件、引擎完整版本/可执行路径与哈希、Anki 完整版本。P13 再完成真实映射和引擎探针，P22 提供正式内容 ID/Schema，P14/P17/P21 等接收各自接口，P32/P35 在固定版本独立验证。

详细缺项分阶段列在 architecture/blockers.json；S05 政策/真实事件和 S08 整合授权没有被误当成本包隔离交付的前置条件。引擎、正式数量、奖值与用户偏好不在本轮代批。

## 7. 字节完整性与下载对应

delivery_manifest.sha256.tsv 记录包内其他全部文件，排除自身以避免循环哈希。包外 delivery_receipt.json 记录 ZIP、清单和独立导出对应的真实文件名、相对路径、大小及 SHA-256。原 ZIP 已重新解压核验。对应的独立下载文件与包内文件保持同名、同字节。

所有代码均在本岗位隔离路径内；本文是交接入口，不是整套游戏完成或正式发布声明。
