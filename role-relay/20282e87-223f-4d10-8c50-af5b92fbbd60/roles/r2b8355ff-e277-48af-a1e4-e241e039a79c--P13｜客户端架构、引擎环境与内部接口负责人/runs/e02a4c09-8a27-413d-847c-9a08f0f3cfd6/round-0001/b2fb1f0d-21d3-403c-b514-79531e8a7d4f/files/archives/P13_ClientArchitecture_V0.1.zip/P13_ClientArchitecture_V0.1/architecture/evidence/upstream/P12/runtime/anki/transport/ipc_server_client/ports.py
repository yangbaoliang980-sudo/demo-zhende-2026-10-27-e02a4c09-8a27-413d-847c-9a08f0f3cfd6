"""Only a transport seam. P11 owns business state, P21 owns physical commit."""
from typing import Protocol

class LedgerPort(Protocol):
    def handle(self, raw: bytes): ...
    def query(self, inbox_id: str): ...

class ReceiptAuthority(Protocol):
    def snapshot(self): ...
    def lookup(self, transaction_id: str): ...

class Backpressure(Exception):
    """P21/P11 adapter cannot admit work; caller retains the original outbox item."""

class BackendUnavailable(Exception):
    """Commit result may be unknown; requires authoritative query before replay."""
