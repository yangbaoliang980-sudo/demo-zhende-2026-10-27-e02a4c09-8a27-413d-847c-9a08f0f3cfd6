"""Typed seams only. Implementations belong to the named V6 owners."""
from __future__ import annotations
from typing import Protocol
from .codec import FrozenMessage


class UnboundPort(RuntimeError):
    """No production or domain implementation is provided by P13."""


class BattlePort(Protocol):  # P14; IC-05 owner approval remains required.
    def submit(self, command: FrozenMessage) -> FrozenMessage: ...  # BattleReply
    def snapshot(self, battle_id: str) -> FrozenMessage: ...  # BattleSnapshot


class DeckPlanner(Protocol):  # P15; pure candidate only.
    def propose(self, command: FrozenMessage, snapshot: FrozenMessage) -> FrozenMessage: ...


class EnemyPlanner(Protocol):  # P16; no state mutation.
    def propose(self, snapshot: FrozenMessage) -> FrozenMessage: ...


class WalletPlanner(Protocol):  # P17; never physical I/O.
    def propose(self, intent_ref: str, snapshot: FrozenMessage) -> FrozenMessage: ...


class PartyReader(Protocol):  # P17
    def snapshot(self, party_id: str) -> FrozenMessage: ...


class StudyResultReader(Protocol):  # P11; RFC-P13-002, P12 consumes it.
    def read_scoped(self, query: FrozenMessage) -> FrozenMessage: ...


class CommitAuthority(Protocol):  # P21; technical proposal, NOT IC-19 acceptance.
    def lookup(self, transaction_id: str) -> FrozenMessage: ...


class AtomicCommitPort(Protocol):  # P21; RFC only, no P13 persistence implementation.
    def submit(self, proposal: FrozenMessage) -> FrozenMessage: ...  # CommitLookupView


class ProgressReader(Protocol):  # P18
    def snapshot(self, profile_id: str) -> FrozenMessage: ...


class PresentationAdapter(Protocol):  # P19 implements public anchors, P29 consumes.
    def reconcile(self, snapshot: FrozenMessage) -> None: ...
    def begin(self, batch: FrozenMessage) -> str: ...  # Opaque P19 view lease.
    def display_bars(self, lease_id: str, unit_id: str, hp: int, shield: int) -> None: ...
    def finish(self, lease_id: str) -> None: ...
    def cancel(self, lease_id: str) -> None: ...


class ContentReader(Protocol):  # P22 schema/ID, P30 imports. No disk path in DTO.
    def resolve(self, asset_ref: FrozenMessage) -> bytes: ...


PORT_OWNERS = {'battle':'P14','deck':'P15','enemy':'P16','wallet':'P17',
               'party':'P17','study':'P11','commit':'P21','progress':'P18',
               'presentation':'P19','content':'P30'}


class PortRegistry:
    """Detect composition mistakes; not a security boundary against Python code.

    Construction is exclusively the authorized composition root's job. Wire DTOs
    have no owner field and must never be passed to bind(). Duplicate providers
    and ownership mismatches are rejected before a framework can start.
    """
    def __init__(self):
        self._ports = {}
        self._frozen = False

    def bind(self, name, owner, implementation):
        if self._frozen:
            raise ValueError('REGISTRY_FROZEN')
        if name not in PORT_OWNERS or PORT_OWNERS[name] != owner:
            raise ValueError('PORT_OWNER_MISMATCH')
        if name in self._ports:
            raise ValueError('DUPLICATE_PORT_PROVIDER')
        if implementation is None:
            raise ValueError('NULL_IMPLEMENTATION')
        self._ports[name] = implementation

    def freeze(self):
        self._frozen = True

    def get(self, name):
        if not self._frozen:
            raise ValueError('REGISTRY_NOT_FROZEN')
        if name not in self._ports:
            raise UnboundPort('DOMAIN_PORT_NOT_BOUND:' + name)
        return self._ports[name]


def require_isolated(mode='isolated'):
    if mode != 'isolated':
        raise UnboundPort('PRODUCTION_BOOTSTRAP_NOT_IMPLEMENTED_OR_AUTHORIZED')

