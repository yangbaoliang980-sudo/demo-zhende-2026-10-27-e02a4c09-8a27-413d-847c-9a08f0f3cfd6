# P12｜IC-14 / IC-18版本化接收提案

任务 `P12-S04-S05-TRANSPORT-001`，版本 `P12-RFC/0.1.0-isolated`。状态 **PREPARED_NOT_ACKNOWLEDGED**。本文件随包交接，没有通过GitHub issue、PR、邮件或即时消息发送给他人。

正式P12合同base SHA：null（未收到）。本次候选target SHA见 `change_requests.json`。P11、P10提案的base SHA按实际收到字节保存；缺失的正式base不以全零哈希替代。所有源快照保持原字节。

| 变更请求 | 接收owner | 本次具体候选 | 所需接收证据 |
|---|---|---|---|
| P12-RFC-IC14-001 | P12；协同P10/P13/P38 | 封闭Envelope、三类请求、配对作用域、严格字节解析、候选认证和本机绑定 | P10目标版真实源字段、身份/Undo/epoch证据；P13 DTO映射；P38最小字段批准 |
| P12-RFC-IC18-001 | P12；协同P11/P21 | 成功ACK门禁、ACK_QUARANTINED持续跟踪、UNKNOWN先查询、精简凭证 | P11确认PENDING/REVERTED映射；P21生产权威查询、恢复栅栏和凭证来源 |
| P12-RFC-P13-001 | P13 | 本包接口边界与三个设计路径的实际映射请求 | actual_path_mapping.json、真实固定提交、引擎、改动白名单和目标宿主适配 |
| P12-RFC-P34-001 | P34；协同P13 | 文件/Unix socket/pipe/loopback比较与Linux候选实测 | 目标OS/架构/Anki版本、端点发现与防火墙/权限/休眠恢复测试 |
| P12-RFC-P38-001 | P38 | 配对/HMAC、字段白名单、查询隔离、日志与outbox留存提案 | 本机绑定和字段最小化独立审核，Windows DACL及留存策略 |

## 对P11-RFC-018-001的具体回应

接收P11的五态业务模型作为隔离协作基础，不修改P11枚举。线上保留四个核心处置：ACK_APPLIED、ACK_QUARANTINED、RETRY_LATER、REJECTED。为避免把撤销或查询误称奖励，另提供无新授奖含义的STATUS响应。

- P11 ACK_RECEIVED只说明原输入持久收件；P12不将它输出为奖励ACK。只读查询当前未处理行后返回RETRY_LATER并允许同字节SUBMIT。
- P11 ACK_REVERTED映射STATUS/REVERTED，凭证同样需确认；客户端不据此执行钱包变化。
- P11 ACK_PENDING_RECONCILIATION映射RETRY_LATER，保留已持久凭证（若可证明）及未决标志。涉及部分回收时不声称未授奖。
- P11 ACK_REJECTED映射业务REJECTED及其持久凭证；传输层REJECTED另以ledger_state=null区分。
- ACK_QUARANTINED后不删除outbox。本版本不提供自动清理API；政策须P10/P21/P38另行确认。

这一映射已运行Mock契约测试，不等于P11、P21或P35已签署正式合同。精简凭证只承载查验关联，不能替代P21的恢复连续性和可信提交端口。

## 对P10-RFC-IC14-IC15的具体回应

本版未假定参考Anki存在state_did_redo，也没有从计数器、revlog或时间生成身份。REVIEW/UNDO/RESTORE仅为隔离语义。P10的QUARANTINED.json被作为能力报告读取，绝不转换为学习事件。0个真实样本的空数组未被填充合成数据冒充真实采集。

真实插件仍由P10开发。P12提供的plugin Mock只调用协议和传输outbox，未注册Hook、未安装插件、未打开或修改Anki collection。P10需要将获批来源事件与outbox持久入队纳入自己的采集故障模型；采集前丢失不是本次传输重试能够解决的问题。

## 补齐依赖后的边界

P13接收实际路径和宿主架构，P10提供真实源证据，P21提供生产事务/查询凭证，P11接收协作映射后再提交下一协议版本。P32执行独立测试，P38审核本机绑定与最小字段，P35独立门禁。跨模块合并只由用户另行指定的EXT-INTEGRATOR执行。本包不存在合并提交、正式安装器或发布声明。
