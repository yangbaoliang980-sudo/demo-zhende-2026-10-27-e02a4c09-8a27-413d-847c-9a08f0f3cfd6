"""Explicit isolated fixtures, not production providers."""
