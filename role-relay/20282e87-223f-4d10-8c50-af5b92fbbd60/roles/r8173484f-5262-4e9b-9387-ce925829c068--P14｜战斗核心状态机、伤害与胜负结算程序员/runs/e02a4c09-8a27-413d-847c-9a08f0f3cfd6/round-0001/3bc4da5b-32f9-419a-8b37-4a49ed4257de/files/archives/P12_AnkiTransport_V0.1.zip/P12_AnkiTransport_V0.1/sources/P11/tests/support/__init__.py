"""Isolated synthetic collaborators. Never ship as P17/P21 implementations."""
