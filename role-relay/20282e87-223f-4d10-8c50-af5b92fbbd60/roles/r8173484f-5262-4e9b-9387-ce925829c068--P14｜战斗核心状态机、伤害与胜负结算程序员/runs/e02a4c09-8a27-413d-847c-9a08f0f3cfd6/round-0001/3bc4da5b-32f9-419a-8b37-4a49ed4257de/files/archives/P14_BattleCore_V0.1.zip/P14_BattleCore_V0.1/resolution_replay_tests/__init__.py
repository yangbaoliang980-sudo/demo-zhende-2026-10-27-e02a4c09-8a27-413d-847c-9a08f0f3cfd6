"""Author-owned tests. They do not constitute P32/P35 independent acceptance."""
