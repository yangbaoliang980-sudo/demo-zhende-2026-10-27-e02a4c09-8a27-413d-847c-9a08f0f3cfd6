"""P12-ANKI-TRANSPORT/0.1.0-isolated. No production bootstrap is provided."""
__version__ = '0.1.0-isolated'
