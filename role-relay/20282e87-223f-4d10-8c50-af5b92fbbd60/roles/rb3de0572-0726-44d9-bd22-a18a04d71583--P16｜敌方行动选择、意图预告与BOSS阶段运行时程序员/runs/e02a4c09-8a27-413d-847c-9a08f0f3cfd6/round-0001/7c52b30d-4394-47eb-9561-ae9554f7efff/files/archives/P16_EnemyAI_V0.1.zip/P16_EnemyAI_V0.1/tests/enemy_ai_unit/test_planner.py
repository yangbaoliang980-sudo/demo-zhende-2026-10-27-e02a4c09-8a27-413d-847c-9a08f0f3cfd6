import copy,json,unittest
from dataclasses import FrozenInstanceError,replace
from concurrent.futures import ThreadPoolExecutor
from enemy_ai import (AiError,Catalog,Charge,bundled_catalog,publish_intent,resolve_intent,validate_start_snapshot)
from enemy_ai.types import FrozenMessage,PhaseCheckpoint
from enemy_ai.planner import _seal
from examples.fixture_inputs import snapshot,context,changed,NORMAL,ELITE,BOSS,P1,P2,P3


class PlannerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cat=bundled_catalog()

    def assert_code(self,code,call):
        with self.assertRaises(AiError) as cm:call()
        self.assertEqual(code,cm.exception.code)

    def run_slot(self,s,c):
        p=publish_intent(s,c,self.cat)
        return p,resolve_intent(s,c,self.cat,p.announcement)

    def test_normal_preview_and_action(self):
        s=snapshot();c=context(s);p,r=self.run_slot(s,c)
        self.assertEqual(('STRIKE',('H1',),8),(p.action.kind,p.action.target_ids,p.action.base_amount_per_hit))
        self.assertEqual(p.action,r.action);self.assertEqual(p.announcement.token,r.announcement.token)
        self.assertEqual(0,r.behavior_candidate.value['proposed_fields']['last_successful_single_target_slot'])
        self.assertIsNone(p.behavior_candidate);self.assertFalse(r.view.value['slot_consumed'])

    def test_preview_no_state_or_rng_mutation(self):
        s=snapshot();c=context(s);before=(s.raw,c.message().raw,self.cat.spec.raw)
        reads=[publish_intent(s,c,self.cat).message().raw for _ in range(10)]
        self.assertEqual(1,len(set(reads)));self.assertEqual(before,(s.raw,c.message().raw,self.cat.spec.raw))

    def test_same_snapshot_and_seed_concurrent(self):
        s=snapshot();c=context(s)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:self.run_slot(s,c)[1].message().raw,range(24)))
        self.assertEqual(1,len(set(results)))

    def test_seed_domain_extremes_no_rng_draws(self):
        for seed in (1,20261028,0xffffffff):
            s=snapshot(seed=seed);p,r=self.run_slot(s,context(s))
            self.assertEqual(s.value['rng'],r.rng.value);self.assertEqual(0,r.message().value['rng_draws_delta'])

    def test_valid_nonzero_rng_history_preserved(self):
        from upstream.P14.battle_core.rng import advance
        s=snapshot();c=context(s)
        s,c=changed(s,c,lambda x:x['rng'].update(state=advance(x['rng']['initial_seed'],12345),draw_count=12345))
        _,r=self.run_slot(s,c);self.assertEqual(s.value['rng'],r.rng.value)

    def test_rng_history_mismatch_rejected(self):
        s=snapshot();c=context(s);s,c=changed(s,c,lambda x:x['rng'].update(draw_count=1))
        self.assert_code('RNG_HISTORY_INVALID',lambda:publish_intent(s,c,self.cat))

    def test_rotation_and_wrap(self):
        for last,target in [(-1,'H1'),(0,'H2'),(1,'H3'),(2,'H1')]:
            s=snapshot();p=publish_intent(s,context(s,last_successful_single_target_slot=last),self.cat)
            self.assertEqual((target,),p.action.target_ids)

    def test_input_array_order_does_not_choose_target(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat)
        s2,c2=changed(s,c,lambda v:v['units'].reverse())
        self.assertEqual(p.action,publish_intent(s2,c2,self.cat).action)

    def test_dead_targets_ignored_at_publish(self):
        s=snapshot();c=context(s);s,c=changed(s,c,lambda v:v['units'][0].update(hp=0))
        self.assertEqual(('H2',),publish_intent(s,c,self.cat).action.target_ids)

    def test_locked_target_dies_no_retarget(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat)
        s,c=changed(s,c,lambda v:v['units'][0].update(hp=0))
        r=resolve_intent(s,c,self.cat,p.announcement)
        self.assertEqual(('SKIP',(), 'LOCKED_TARGET_INVALID'),(r.action.kind,r.action.target_ids,r.reason))
        self.assertEqual(-1,r.behavior_candidate.value['proposed_fields']['last_successful_single_target_slot'])

    def test_locked_target_removed_no_retarget(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat)
        s,c=changed(s,c,lambda v:v['units'].pop(0),targetable_ids=('H2','H3'))
        self.assertEqual('LOCKED_TARGET_INVALID',resolve_intent(s,c,self.cat,p.announcement).reason)

    def test_no_target_preview_is_frozen_skip(self):
        s=snapshot();c=context(s,targetable_ids=());p=publish_intent(s,c,self.cat)
        c=replace(c,targetable_ids=('H1','H2','H3'))
        r=resolve_intent(s,c,self.cat,p.announcement)
        self.assertEqual(('SKIP','NO_VALID_TARGET'),(r.action.kind,r.reason))

    def test_targetability_removed_after_preview(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat)
        r=resolve_intent(s,replace(c,targetable_ids=('H2','H3')),self.cat,p.announcement)
        self.assertEqual('LOCKED_TARGET_INVALID',r.reason)

    def test_sweep_filters_no_new_targets(self):
        s=snapshot(BOSS,phase_id=P2);c=context(s,targetable_ids=('H1','H2'));p=publish_intent(s,c,self.cat)
        s,c=changed(s,c,lambda v:v['units'][1].update(hp=0),targetable_ids=('H1','H2','H3'))
        r=resolve_intent(s,c,self.cat,p.announcement)
        self.assertEqual(('H1',),r.action.target_ids);self.assertEqual(['H2'],r.view.value['removed_target_ids'])
        self.assertEqual('LOCKED_TARGETS_FILTERED',r.view.value['deviation_reason'])
        self.assertEqual(-1,r.behavior_candidate.value['proposed_fields']['last_successful_single_target_slot'])

    def test_charge_is_zero_damage_and_does_not_advance_cursor(self):
        s=snapshot(ELITE);c=context(s,state_id='E_CHARGE',enemy_slot=7);p,r=self.run_slot(s,c)
        self.assertEqual((0,0,24),(p.action.base_amount_per_hit,p.action.hit_count,p.action.future_release_base_amount))
        after=r.behavior_candidate.value['proposed_fields']
        self.assertEqual((8,7+1), (after['enemy_slot'],after['charge']['ready_slot']))
        self.assertEqual(['H1'],after['charge']['locked_target_ids']);self.assertEqual(-1,after['last_successful_single_target_slot'])

    def release_input(self,ready_slot=7,cooldown=0):
        s=snapshot(ELITE);c=context(s,state_id='E_RELEASE',enemy_slot=7,heavy_cooldown=cooldown,
            charge=Charge('MOCK_P06_SKILL_E_RELEASE',('H2',),0,ready_slot,'fixture:charge'))
        return s,c

    def test_release_uses_charge_target_not_rotation(self):
        s,c=self.release_input();p,r=self.run_slot(s,c)
        self.assertEqual(('H2',),r.action.target_ids)
        self.assertEqual(2,r.behavior_candidate.value['proposed_fields']['heavy_cooldown'])
        self.assertIsNone(r.behavior_candidate.value['proposed_fields']['charge'])

    def test_release_missing_early_expired_all_skip(self):
        for mode in ('missing','early','expired'):
            s,c=self.release_input(8 if mode=='early' else 6)
            if mode=='missing':c=replace(c,charge=None)
            p,r=self.run_slot(s,c)
            self.assertEqual('CHARGE_'+mode.upper(),r.reason)
            self.assertEqual('E_RECOVER',r.behavior_candidate.value['proposed_fields']['state_id'])
            self.assertEqual(0 if mode=='missing' else 2,r.behavior_candidate.value['proposed_fields']['heavy_cooldown'])

    def test_charge_with_cooldown_advances_once(self):
        s=snapshot(ELITE);c=context(s,state_id='E_CHARGE',heavy_cooldown=1);p,r=self.run_slot(s,c)
        self.assertEqual('COOLDOWN',r.reason)
        self.assertEqual(('E_RELEASE',0),(r.behavior_candidate.value['proposed_fields']['state_id'],r.behavior_candidate.value['proposed_fields']['heavy_cooldown']))

    def test_charge_cooldown_contradiction_rejects(self):
        s,c=self.release_input(cooldown=1)
        self.assert_code('CHARGE_COOLDOWN_CONFLICT',lambda:publish_intent(s,c,self.cat))

    def test_unknown_release_marker_rejects(self):
        s,c=self.release_input();c=replace(c,charge=replace(c.charge,release_skill_id='unknown'))
        self.assert_code('CHARGE_SKILL_UNKNOWN',lambda:publish_intent(s,c,self.cat))

    def test_recovery_cooldown_ticks_only_in_candidate(self):
        s=snapshot(ELITE);c=context(s,state_id='E_RECOVER',heavy_cooldown=2);p,r=self.run_slot(s,c)
        self.assertEqual(2,c.heavy_cooldown);self.assertEqual(1,r.behavior_candidate.value['proposed_fields']['heavy_cooldown'])

    def test_dead_actor_no_slot_or_cooldown(self):
        s=snapshot();c=context(s,heavy_cooldown=2)
        def mut(v):
            e=v['units'][-1];e['hp']=0
            other=copy.deepcopy(e);other.update(unit_id='E2',slot=1,hp=24);v['units'].append(other)
        s,c=changed(s,c,mut);r=publish_intent(s,c,self.cat)
        self.assertEqual('ACTOR_DEAD',r.reason);self.assertIsNone(r.behavior_candidate);self.assertEqual(2,c.heavy_cooldown)

    def test_terminal_preempts_action(self):
        s=snapshot();c=context(s);s,c=changed(s,c,lambda v:v['units'][-1].update(hp=0))
        r=publish_intent(s,c,self.cat);self.assertEqual('TERMINAL',r.disposition);self.assertIsNone(r.intent)

    def test_pending_reactions_preempt_terminal(self):
        s=snapshot();c=context(s,pending_reactions=1);s,c=changed(s,c,lambda v:v['units'][-1].update(hp=0))
        self.assertEqual('DEFER',publish_intent(s,c,self.cat).disposition)

    def test_pending_phase_halts_old_attack(self):
        s=snapshot(BOSS);c=context(s)
        s,c=changed(s,c,lambda v:v['boss_states'][0]['proposed_phase_ids'].append(P2))
        self.assertEqual('PHASE_COMMIT_PENDING',publish_intent(s,c,self.cat).reason)

    def test_entry_wait_one_candidate_no_phase_write(self):
        s=snapshot(BOSS,phase_id=P2);c=context(s,entry_wait_pending=True,heavy_cooldown=2);p,r=self.run_slot(s,c)
        after=r.behavior_candidate.value['proposed_fields']
        self.assertEqual('ENTRY_WAIT',r.action.kind);self.assertFalse(after['entry_wait_pending'])
        self.assertEqual(1,after['heavy_cooldown']);self.assertNotIn('phase_id',after);self.assertNotIn('phase_epoch',after)

    def test_phase_replaced_old_heavy_is_wait(self):
        s=snapshot(BOSS);c=context(s,state_id=P1+':2',enemy_slot=3,charge=Charge('MOCK_P06_SKILL_B_RELEASE',('H1',),0,3,'fixture:charge'))
        p=publish_intent(s,c,self.cat)
        s2=snapshot(BOSS,phase_id=P2,hp=70)
        c2=context(s2,enemy_slot=3,entry_wait_pending=True,heavy_cooldown=2)
        r=resolve_intent(s2,c2,self.cat,p.announcement)
        self.assertEqual(('ENTRY_WAIT','PHASE_REPLACED'),(r.action.kind,r.reason))

    def test_phase_epoch_conflict_without_wait_rejects(self):
        s=snapshot(BOSS);c=context(s);p=publish_intent(s,c,self.cat)
        s2=snapshot(BOSS,phase_id=P2);c2=context(s2)
        self.assert_code('INTENT_PHASE_EPOCH_MISMATCH',lambda:resolve_intent(s2,c2,self.cat,p.announcement))

    def test_missing_graph_only_recommendation(self):
        cat=Catalog.from_bytes(self.cat.spec.raw);s=snapshot(BOSS);c=context(s)
        p=publish_intent(s,c,cat);r=resolve_intent(s,c,cat,p.announcement)
        self.assertEqual('DEGRADATION_RECOMMENDATION',r.disposition)
        self.assertEqual('DEGRADED_WAIT',r.action.kind)
        self.assertEqual(P1,s.value['boss_states'][0]['current_phase_id'])

    def test_degraded_mode_stays_degraded_after_graph_restored(self):
        s=snapshot(BOSS);c=context(s,state_id='DEGRADED_STRIKE',degraded=True);p,r=self.run_slot(s,c)
        self.assertEqual('MOCK_P06_SKILL_B_STRIKE',r.action.skill_id)
        self.assertTrue(r.behavior_candidate.value['proposed_fields']['degraded'])

    def test_low_hp_start_without_history_rejects(self):
        s=snapshot(BOSS,hp=30);c=context(s)
        self.assert_code('INVALID_PHASE_HISTORY',lambda:validate_start_snapshot(s,c,self.cat))

    def test_unknown_phase_rejects(self):
        s=snapshot(BOSS);c=context(s);s,c=changed(s,c,lambda v:v['boss_states'][0].update(current_phase_id='unknown'))
        self.assert_code('UNKNOWN_PHASE',lambda:publish_intent(s,c,self.cat))

    def test_unsupported_snapshot_version_rejects(self):
        s=snapshot().value;s['contract_version']='old';c=context(snapshot())
        self.assert_code('SNAPSHOT_VERSION_UNSUPPORTED',lambda:publish_intent(s,c,self.cat))

    def test_stale_context_rejected(self):
        s=snapshot();c=context(s);v=s.value;v['revision']+=1
        self.assert_code('BEHAVIOR_SNAPSHOT_BINDING_MISMATCH',lambda:publish_intent(v,c,self.cat))

    def test_future_revision_announcement_rejects(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['source_revision']=2
        self.assert_code('STALE_OR_FUTURE_ANNOUNCEMENT',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_old_turn_announcement_rejects(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);s,c=changed(s,c,lambda v:v.update(turn_number=2))
        self.assert_code('INTENT_SLOT_EXPIRED',lambda:resolve_intent(s,c,self.cat,p.announcement))

    def test_tampered_announcement_digest_rejects(self):
        from enemy_ai import Announcement
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['action']['base_amount_per_hit']=99
        self.assert_code('ANNOUNCEMENT_DIGEST_MISMATCH',lambda:resolve_intent(s,c,self.cat,Announcement(FrozenMessage.from_value(v))))

    def test_resealed_forged_amount_rejects_content(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['action']['base_amount_per_hit']=99
        self.assert_code('INTENT_CONTENT_MISMATCH',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_wrong_battle_announcement_rejects(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['battle_id']='other'
        self.assert_code('INTENT_ACTOR_OR_BATTLE_MISMATCH',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_duplicate_locked_targets_rejects(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['action']['target_ids']=['H1','H1']
        self.assert_code('INTENT_TARGET_SHAPE',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_non_string_locked_targets_reject_without_type_error(self):
        for bad in ({'id':'H1'}, ['H1'], True, 1, None):
            with self.subTest(bad=bad):
                s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value
                v['action']['target_ids']=[bad]
                self.assert_code('INTENT_TARGET_SHAPE',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_non_string_behavior_ids_reject_without_type_error(self):
        for field in ('targetable_ids','phase_committed_ids'):
            with self.subTest(field=field):
                s=snapshot();c=context(s)
                self.assert_code('DUPLICATE_OR_MUTABLE_IDS',lambda:replace(c,**{field:({'id':'H1'},)}))

    def test_wrong_side_locked_target_rejects(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['action']['target_ids']=['E1']
        self.assert_code('INTENT_TARGET_SIDE_MISMATCH',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_frozen_output_detached(self):
        s=snapshot();c=context(s);p,r=self.run_slot(s,c);v=r.message().value;v['action']['base_amount_per_hit']=999
        self.assertEqual(8,r.action.base_amount_per_hit)
        with self.assertRaises(FrozenInstanceError):c.heavy_cooldown=99

    def test_candidate_contains_no_authoritative_fields(self):
        s=snapshot();c=context(s);_,r=self.run_slot(s,c)
        forbidden={'hp','shield','phase','phase_id','phase_epoch','revision','energy','wallet'}
        self.assertFalse(forbidden&set(r.behavior_candidate.value['proposed_fields']))
        self.assertEqual('P14',r.behavior_candidate.value['commit_owner'])

    def test_boolean_intent_amount_rejected(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['action']['hit_count']=True
        self.assert_code('INTENT_AMOUNT_TYPE_INVALID',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_boolean_epoch_rejected(self):
        s=snapshot();c=context(s);p=publish_intent(s,c,self.cat);v=p.announcement.value;v['phase_epoch']=False
        self.assert_code('ANNOUNCEMENT_INTEGER_INVALID',lambda:resolve_intent(s,c,self.cat,_seal(v)))

    def test_slot_capacity_rejected_without_overflow(self):
        from enemy_ai.types import MAX_INTEGER
        s=snapshot();c=context(s,enemy_slot=MAX_INTEGER);p=publish_intent(s,c,self.cat)
        self.assert_code('ACTION_SLOT_CAPACITY_REACHED',lambda:resolve_intent(s,c,self.cat,p.announcement))


class ContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cat=bundled_catalog()

    def test_content_keys_do_not_use_wire_profile(self):
        self.assertIn('SRC-P02-RULE',self.cat.spec.value['source_hashes'])
        self.assertEqual('P06-ENEMY-0.1.0-proposal',self.cat.spec.value['format_version'])

    def test_hash_binding(self):
        with self.assertRaisesRegex(AiError,'CONTENT_HASH_MISMATCH'):
            Catalog.from_bytes(self.cat.spec.raw,expected_spec_sha256='0'*64)

    def test_duplicate_json_key(self):
        with self.assertRaisesRegex(AiError,'DUPLICATE_JSON_KEY'):
            Catalog.from_bytes(b'{"x":1,"x":2}')

    def test_no_summon_config_is_invented(self):
        self.assertNotIn('SUMMON',{s['action_kind'] for s in self.cat.spec.value['skills']})
        value=self.cat.spec.value;value['skills'][0]['action_kind']='SUMMON'
        with self.assertRaisesRegex(AiError,'UNSUPPORTED_ACTION_KIND'):
            Catalog.from_bytes(json.dumps(value).encode())

    def test_unknown_skill_reference_rejects(self):
        value=self.cat.spec.value;value['enemies'][0]['states'][0]['skill_id']='unknown'
        with self.assertRaisesRegex(AiError,'STATE_REFERENCE_INVALID'):
            Catalog.from_bytes(json.dumps(value).encode())

    def test_missing_baseline_rejects(self):
        value=self.cat.spec.value;value['enemies'][2]['degraded_basic_skill_id']='unknown'
        with self.assertRaisesRegex(AiError,'BASELINE_SKILL_MISSING'):
            Catalog.from_bytes(json.dumps(value).encode())

    def test_cyclic_graph_has_bounded_degradation(self):
        value=self.cat.graph.value;value['transitions'][1]['to_phase_id']=P1
        cat=Catalog.from_bytes(self.cat.spec.raw,json.dumps(value).encode())
        self.assertIsNone(cat.graph);self.assertEqual('GRAPH_NON_MONOTONIC_OR_CYCLIC',cat.graph_error)
        s=snapshot(BOSS);p=publish_intent(s,context(s),cat)
        self.assertEqual('DEGRADATION_RECOMMENDATION',p.disposition)

    def test_missing_graph_does_not_affect_normal(self):
        cat=Catalog.from_bytes(self.cat.spec.raw);s=snapshot();c=context(s)
        self.assertEqual(publish_intent(s,c,self.cat).action,publish_intent(s,c,cat).action)

    def test_content_values_detached(self):
        value=self.cat.spec.value;value['skills'][0]['base_amount_per_hit']=999
        self.assertEqual(8,self.cat.spec.value['skills'][0]['base_amount_per_hit'])
