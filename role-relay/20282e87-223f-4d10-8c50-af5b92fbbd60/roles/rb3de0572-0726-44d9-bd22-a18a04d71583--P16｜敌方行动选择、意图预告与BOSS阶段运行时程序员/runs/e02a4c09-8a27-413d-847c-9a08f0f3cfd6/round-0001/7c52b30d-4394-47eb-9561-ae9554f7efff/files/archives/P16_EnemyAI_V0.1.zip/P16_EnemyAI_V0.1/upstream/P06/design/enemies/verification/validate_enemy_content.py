#!/usr/bin/env python3
"""P06 author-side content lint. Never selects AI actions or commits battle state.

Only structure, provenance, finite graph and EXPECTED_ONLY fixture consistency are
checked. P16/P14 behavior tests remain NOT_RUN, regardless of this script's result.
Python 3.10+ standard library; safe to run from any working directory.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
VERSION = 'P06-ENEMY-0.1.0-proposal'

class InvalidContent(ValueError):
    pass

def require(ok, code, detail):
    if not ok:
        raise InvalidContent(f'{code}: {detail}')

def integer(x, low=0, high=21474836):
    return type(x) is int and low <= x <= high

def load_tsv(path):
    with path.open(encoding='utf-8-sig', newline='') as f:
        reader=csv.DictReader(f, delimiter='\t')
        require(reader.fieldnames and len(reader.fieldnames)==len(set(reader.fieldnames)), 'TSV_HEADER', str(path))
        rows=list(reader)
    require(rows and all(None not in r and all(v is not None for v in r.values()) for r in rows), 'TSV_ROWS', str(path))
    return rows

def unique(items, field, code):
    keys=[x[field] for x in items]
    require(len(keys)==len(set(keys)), code, field)
    return {x[field]:x for x in items}

def exact_json(path):
    def unique_pairs(pairs):
        d={}
        for k,v in pairs:
            require(k not in d, 'DUPLICATE_JSON_KEY', f'{path}:{k}')
            d[k]=v
        return d
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=unique_pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(InvalidContent('NON_FINITE_NUMBER: '+x)))

def validate(spec, graph, intents, cases):
    checks=[]
    require(spec['format_version']==graph['format_version']==VERSION,'VERSION','content version mismatch')
    require(spec['production_enabled'] is False and spec['authorization']['real_engine_write'] is False,
            'SCOPE','candidate content must not imply production/write authorization')
    require(spec['runtime_test_status']=='NOT_RUN' and spec['formal_integration_status']=='BLOCKED',
            'EVIDENCE_LEVEL','content lint cannot declare runtime/integration pass')
    require(spec['authorization']['actual_path_mapping'] is None and spec['authorization']['repository_base_sha'] is None,
            'AUTHORITY','missing engineering evidence must remain explicit')
    require(spec['input_versions']['P07'] is None and spec['input_versions']['P13_DTO'] is None,
            'MISSING_UPSTREAM','cannot fabricate approval versions')
    checks.append('version_scope_and_authority')
    skills=unique(spec['skills'],'skill_id','DUPLICATE_SKILL')
    enemies=unique(spec['enemies'],'enemy_id','DUPLICATE_ENEMY')
    intent_map=unique(intents,'intent_id','DUPLICATE_INTENT')
    require(set(x['tier'] for x in enemies.values())=={'NORMAL','ELITE','BOSS'},'TIERS','three sample categories required')
    for sid,s in skills.items():
        require(sid.startswith('MOCK_P06_') and s['intent_id'] in intent_map,'ID_REFERENCE',sid)
        require(s['production_enabled'] is False,'SCOPE',sid)
        for key in ['base_amount_per_hit','hit_count','future_release_base_amount','cooldown_on_success_slots']:
            require(integer(s[key]),'SKILL_INTEGER',sid+':'+key)
        require(s['no_valid_target']=='SKIP_NO_VALID_TARGET','NO_TARGET_FALLBACK',sid)
        require(s['grants_extra_action'] is False and not s['status_applications'],'UNAPPROVED_EXTENSION',sid)
        i=intent_map[s['intent_id']]
        require(i['skill_id']==sid and i['semantic_kind']==s['action_kind'],'INTENT_REFERENCE',sid)
        require(int(i['current_base_amount_per_hit'])==s['base_amount_per_hit'] and int(i['current_hit_count'])==s['hit_count']
                and int(i['future_base_amount_per_hit'])==s['future_release_base_amount'],'INTENT_AMOUNT',sid)
        require(i['version']==VERSION and i['target_policy']==s['target_policy'],'INTENT_VERSION_TARGET',sid)
        if s['action_kind'] in {'CHARGE','RECOVER','ENTRY_WAIT','SKIP','DEGRADED_WAIT'}:
            require(s['base_amount_per_hit']==s['hit_count']==0 and s['effect_code']=='NONE','ZERO_DAMAGE_ACTION',sid)
        else:
            require(s['base_amount_per_hit']>0 and s['hit_count']==1 and s['effect_code']=='DAMAGE','DAMAGE_ACTION',sid)
        if s['action_kind']=='CHARGE':
            require(s['future_release_base_amount']>0 and s['charge_requirement']=='CREATE_IF_HEAVY_CD_ZERO','CHARGE_RULE',sid)
        if s['action_kind']=='RELEASE':
            require(s['cooldown_on_success_slots']==2 and s['charge_requirement']=='REQUIRE_COMMITTED_READY_CHARGE','RELEASE_RULE',sid)
    checks.append('skill_and_preview_semantics')
    all_states={}
    for eid,e in enemies.items():
        require(integer(e['max_hp'],1) and integer(e['initial_shield']) and integer(e['baseline_attack'],1),'ENEMY_NUMBERS',eid)
        require(e['initial_shield']<=e['shield_cap_fixture']==40,'SHIELD_CAP_FIXTURE',eid)
        require(e['production_enabled'] is False,'SCOPE',eid)
        require(not e['on_death_reaction_ids'] and not e['allowed_new_status_ids'],'UNAPPROVED_ENEMY_EXTENSION',eid)
        require(e['immunity']['DAMAGE'] is False and e['immunity']['DOT'] is False
                and e['immunity']['PHASE_TRANSITION_INVULNERABILITY'] is False,'IMMUNITY',eid)
        states=unique(e['states'],'state_id','DUPLICATE_STATE')
        require(e['initial_state_id'] in states,'INITIAL_STATE',eid)
        for st in states.values():
            require(st['skill_id'] in skills and st['next_state_id'] in states,'STATE_SUCCESSOR',eid+':'+st['state_id'])
            all_states[(eid,st['state_id'])]=st
        # Each declared cycle must return to a repeated node in <= number of states;
        # it cannot strand a node or call an unregistered action. Attack opportunity
        # is checked as a graph property, not by running decisions.
        for start in states:
            seen=[];cur=start
            while cur not in seen:
                seen.append(cur);cur=states[cur]['next_state_id']
                require(len(seen)<=len(states),'UNBOUNDED_CYCLE',eid)
            cycle=seen[seen.index(cur):]
            require(any(skills[states[x]['skill_id']]['effect_code']=='DAMAGE' for x in cycle),
                    'NO_DAMAGE_CYCLE',eid+':'+start)
    checks.append('all_18_cycle_states_have_actions_and_successors')
    phases=unique(graph['phases'],'phase_id','DUPLICATE_PHASE')
    require(graph['initial_phase_id'] in phases,'PHASE_INITIAL','missing initial phase')
    ranks=[p['rank'] for p in phases.values()]
    require(sorted(ranks)==list(range(len(phases))),'PHASE_RANKS','unique contiguous ranks required')
    adj={p:[] for p in phases};thresholds=[]
    for edge in graph['transitions']:
        a,b=edge['from_phase_id'],edge['to_phase_id']
        require(a in phases and b in phases,'PHASE_REFERENCE',str(edge))
        require(phases[b]['rank']==phases[a]['rank']+1,'PHASE_ORDER','no reverse/skip/cycle')
        require(integer(edge['threshold_percent'],1,99),'THRESHOLD_INTEGER',str(edge))
        frac=edge['threshold_max_hp_fraction']
        require(integer(frac['numerator'],1) and integer(frac['denominator'],1)
                and frac['numerator']*100==frac['denominator']*edge['threshold_percent'],'THRESHOLD_FRACTION',str(edge))
        adj[a].append(b);thresholds.append((phases[a]['rank'],edge['threshold_percent']))
    require(len(graph['transitions'])==len(phases)-1,'PHASE_EDGE_COUNT','single directed chain expected')
    ordered=[t for _,t in sorted(thresholds)]
    require(all(ordered[i]>ordered[i+1] for i in range(len(ordered)-1)),'THRESHOLD_ORDER','thresholds must decrease')
    seen=set();cur=graph['initial_phase_id']
    while cur not in seen:
        seen.add(cur)
        require(len(adj[cur])<=1,'AMBIGUOUS_PHASE_BRANCH',cur)
        if not adj[cur]:break
        cur=adj[cur][0]
    require(seen==set(phases),'PHASE_REACHABILITY','unreachable phase')
    max_hp=graph['max_hp_fixture']
    require(integer(max_hp,1),'GRAPH_HP','positive bounded integer')
    require(graph['trigger']['exact_boundaries_at_125_hp']=={
        'phase_2_largest_qualifying_hp':max_hp*ordered[0]//100,
        'phase_3_largest_qualifying_hp':max_hp*ordered[1]//100},'INTEGER_BOUNDARY','integer floor of threshold differs')
    require(set(x['from_phase_id'] for x in graph['terminal_exits'])==set(phases),'TERMINAL_EXIT','all phases need closed exit')
    for p in phases.values():
        require(p['entry_damage']==p['entry_heal']==p['entry_shield']==0 and p['entry_cleanse'] is False and p['invulnerable'] is False,
                'PHASE_ENTRY_EFFECT','no hidden phase damage/heal/immunity')
        require((graph['enemy_id'],p['initial_state_id']) in all_states and p['entry_wait_skill_id'] in skills,'PHASE_ENTRY_REFERENCE',p['phase_id'])
    de=graph['degraded_exit']
    require(de['first_skill_id'] in skills and de['then_skill_id'] in skills
            and skills[de['first_skill_id']]['base_amount_per_hit']==0
            and skills[de['then_skill_id']]['effect_code']=='DAMAGE'
            and de['reenter_graph_in_same_battle'] is False,'DEGRADED_PROGRESS','one no-damage notice then explicit base action')
    require(de['phase_id_handling']=='KEEP_LAST_COMMITTED_PHASE_ID;DEGRADED_BASIC_IS_BEHAVIOR_MODE',
            'DEGRADED_PHASE_ID','fallback mode must not invent a registered phase')
    checks.append('phase_graph_monotonic_reachable_and_terminal_safe')
    require(spec['policies']['rng']['draws_per_enemy_decision']==0,'RNG','fixed pattern must not consume RNG')
    require(spec['policies']['targeting']['no_valid_target']=='SKIP_NO_VALID_TARGET'
            and spec['policies']['targeting']['auto_retarget'] is False,'TARGETING','must not silently retarget')
    require(spec['policies']['cooldown']['skips_tick'] is True and spec['policies']['cooldown']['entry_wait_ticks'] is True,
            'COOLDOWN_PROGRESS','blocked slots must not deadlock cooldown')
    checks.append('global_progress_and_no_retarget_invariants')

    unique(cases,'case_id','DUPLICATE_CASE');covered=set();groups={}
    for row in cases:
        cid=row['case_id'];before=json.loads(row['input_json']);stim=json.loads(row['stimulus_json']);ex=json.loads(row['expected_json'])
        require(row['runtime_status']=='NOT_RUN' and row['author_check']=='STATIC_INTEGRITY_ONLY','CASE_EVIDENCE_LEVEL',cid)
        require(row['binding']=='P06_PROPOSAL_EXPECTED_ONLY','CASE_BINDING',cid)
        require(before['enemy']['enemy_id'] in enemies,'CASE_ENEMY',cid)
        require(str(before['seed'])==row['seed'] and ex['rng_draws_delta']==0,'CASE_RNG',cid)
        if row['category']!='INVALID_INPUT':
            require(integer(before['seed'],1,4294967295),'SEED_RANGE',cid)
            require(before['alive_enemy_count']==int(before['enemy']['hp']>0)+sum(x['hp']>0 for x in before['other_enemies']),
                    'INPUT_ALIVE_COUNT',cid)
        action=ex['action_id']
        if action!='NONE':
            require(action in skills,'CASE_ACTION',cid)
            a=skills[action]
            require(ex['intent_id']==a['intent_id'] and ex['preview_base_amount_per_hit']==a['base_amount_per_hit']
                    and ex['preview_hit_count']==a['hit_count']
                    and ex['future_release_base_amount']==a['future_release_base_amount'],'CASE_PREVIEW',cid)
            if a['target_policy'] not in {'NONE'}:
                require(len(ex['ordered_target_ids'])>0,'CASE_EMPTY_TARGET',cid)
        else:
            require(ex['intent_id']=='NONE' and ex['preview_base_amount_per_hit']==0,'CASE_NO_ACTION',cid)
        if ex['outcome'] in {'WIN','LOSS','DRAW','ABORTED','FAULTED','DEFER'}:
            require(action=='NONE' and ex['phase_proposals']==[],'TERMINAL_PRECEDENCE',cid)
        require(all(p in phases for p in ex['phase_proposals']),'CASE_PHASE_REFERENCE',cid)
        require([phases[p]['rank'] for p in ex['phase_proposals']]==sorted(set(phases[p]['rank'] for p in ex['phase_proposals'])),
                'CASE_PHASE_ORDER',cid)
        if row['category']=='NOMINAL_STATE':
            key=(before['enemy']['enemy_id'],before['enemy']['state_id']);covered.add(key)
            require(key in all_states and action==all_states[key]['skill_id'] and ex['next_state_id']==all_states[key]['next_state_id'],
                    'CASE_STATE_COHERENCE',cid)
        if row['category']=='PHASE_CHECKPOINT':
            # Check the author's boundary arithmetic only. This does not exercise
            # P16/P14, create runtime intents, or mutate any snapshot.
            require(ex['phase_after']==before['enemy']['phase_id'] and ex['phase_is_proposal_only'] is True,
                    'PROPOSAL_NOT_COMMIT',cid)
            hp=stim['after_hp'];pa=stim['after_alive_player_count'];ea=stim['after_alive_enemy_count']
            require(ea==int(hp>0)+sum(x['hp']>0 for x in before['other_enemies']),
                    'CHECKPOINT_OTHER_ENEMIES',cid)
            pending=stim['after_pending_reactions']
            outcome='DEFER' if pending else ('DRAW' if pa==ea==0 else 'LOSS' if pa==0 else 'WIN' if ea==0 else 'ONGOING')
            require(ex['outcome']==outcome,'CASE_TERMINAL_COUNTS',cid)
            expected=[]
            if outcome=='ONGOING' and hp>0:
                current_rank=phases[before['enemy']['phase_id']]['rank']
                already=set(before['enemy']['phase_proposed_ids'])
                for edge in sorted(graph['transitions'],key=lambda x:phases[x['from_phase_id']]['rank']):
                    if phases[edge['from_phase_id']]['rank']<current_rank:continue
                    if edge['to_phase_id'] in already:continue
                    t=edge['threshold_percent'];mx=before['enemy']['max_hp']
                    if stim['before_hp']*100>mx*t and hp*100<=mx*t:expected.append(edge['to_phase_id'])
            require(ex['phase_proposals']==expected,'CASE_THRESHOLD_ARITHMETIC',cid)
        if 'expected_damage_projection' in ex:
            d=ex['expected_damage_projection']
            require(all(integer(v) for v in d.values()),'CASE_DAMAGE_INTEGER',cid)
            require(d['raw']==d['absorbed']+d['hp_loss']+d['overkill'],'CASE_DAMAGE_CONSERVATION',cid)
            target=next(p for p in before['party'] if p['unit_id']==ex['ordered_target_ids'][0])
            require(d['raw']==ex['preview_base_amount_per_hit']*ex['preview_hit_count']
                    and d['absorbed']==min(target['shield'],d['raw']) and d['hp_loss']==min(target['hp'],d['raw']-d['absorbed']),
                    'CASE_DAMAGE_EXPECTATION',cid)
        if row['equivalence_pair']:
            groups.setdefault(row['equivalence_pair'],[]).append((cid,ex))
    require(covered==set(all_states),'NOMINAL_COVERAGE','every declared state needs a concrete nominal case')
    required={'GRAPH_MISSING','GRAPH_DEGRADED_CONTINUES','ART_MISSING','ART_ALL_MISSING','PHASE_ACCEPT','PHASE_DUPLICATE',
              'PHASE_ENTRY_WAIT','DOT_LETHAL','NO_LEGAL_TARGET','CHARGE_GUARD','COMMAND_DUPLICATE','CLOSED_REENTRY'}
    require(required<=set(r['category'] for r in cases),'BOUNDARY_COVERAGE','critical categories missing')
    for group,items in groups.items():
        require(len(items)>=2,'EQUIVALENCE_PAIR',group)
        normalized=[{k:v for k,v in ex.items() if k!='rng_state_after'} for _,ex in items]
        require(all(x==normalized[0] for x in normalized),'EXPECTED_EQUIVALENCE',group)
    checks.append('89_expected_only_rows_and_boundary_arithmetic')
    return checks

def validate_files(root=ROOT):
    c=root/'content/enemies';d=root/'design/enemies'
    spec=exact_json(c/'enemy_specs.json');graph=exact_json(c/'boss_phase_graph.json')
    intents=load_tsv(c/'intent_dictionary.tsv');cases=load_tsv(c/'enemy_truth_cases.tsv')
    checks=validate(spec,graph,intents,cases)
    receipts=load_tsv(d/'source_input_receipt.tsv')
    require(len(receipts)==len(spec['source_hashes']),'SOURCE_SET','every bound input needs a preserved copy')
    for r in receipts:
        p=root/r['preserved_relative_path']
        require(p.resolve().is_relative_to(root.resolve()),'SOURCE_PATH','must stay inside delivery')
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        require(p.stat().st_size==int(r['actual_bytes']) and h==r['sha256']==spec['source_hashes'][r['source_id']],
                'SOURCE_HASH',r['source_id'])
    require(spec['source_hashes']==graph['source_hashes'],'SOURCE_BINDING','spec and phase graph must consume same fixed bytes')
    params=load_tsv(d/'evidence/readonly_upstream/p05_balance_parameters.tsv')
    pmap={r['parameter_id']:int(r['value']) for r in params if r['parameter_id'].startswith('MODEL/') and r['value'].isdigit()}
    for e in spec['enemies']:
        prefix='MODEL/'+e['tier'].lower()+'_enemy_'
        require(e['max_hp']==pmap[prefix+'hp'] and e['baseline_attack']==pmap[prefix+'atk'],'P05_BUDGET_BASE',e['enemy_id'])
    elite=next(e for e in spec['enemies'] if e['tier']=='ELITE')
    require(elite['initial_shield']==pmap['MODEL/elite_enemy_shield'],'P05_ELITE_SHIELD','must preserve budget trace')
    actions=load_tsv(d/'enemy_action_table.tsv')
    declared={(e['enemy_id'],s['state_id']):s for e in spec['enemies'] for s in e['states']}
    require(len(actions)==len(declared),'ACTION_TABLE_COVERAGE','row count mismatch')
    for row in actions:
        key=(row['enemy_id'],row['state_id'])
        require(key in declared and row['skill_id']==declared[key]['skill_id'] and row['next_state']==declared[key]['next_state_id'],
                'ACTION_TABLE_REFERENCE',str(key))
        skill=next(s for s in spec['skills'] if s['skill_id']==row['skill_id'])
        require(row['intent_id']==skill['intent_id'] and row['kind']==skill['action_kind']
                and int(row['base_amount_per_hit'])==skill['base_amount_per_hit']
                and int(row['hit_count'])==skill['hit_count']
                and int(row['future_release_amount'])==skill['future_release_base_amount'],
                'ACTION_TABLE_AMOUNT',str(key))
    budgets=load_tsv(d/'budget_trace.tsv')
    for row in budgets:
        e=next(e for e in spec['enemies'] if e['enemy_id']==row['enemy_id'])
        states=[s for s in e['states'] if s.get('phase_id','NONE')==row['phase_id']]
        total=0
        for state in states:
            skill=next(s for s in spec['skills'] if s['skill_id']==state['skill_id'])
            total+=skill['base_amount_per_hit']*skill['hit_count']*(3 if skill['action_kind']=='SWEEP' else 1)
        require(total==int(row['cycle_base_damage_max_3_targets'])==int(row['mean_numerator'])
                and len(states)==int(row['cycle_slots'])==int(row['mean_denominator']),
                'CYCLE_BUDGET_ARITHMETIC',row['enemy_id']+':'+row['phase_id'])
    requirement_ids={r['requirement_id'] for r in load_tsv(d/'evidence/readonly_upstream/p01_requirements_traceability.tsv')}
    require(set(spec['requirements'])<=requirement_ids,'REQUIREMENT_REFERENCE','unknown P01 requirement ID')
    checks.append('preserved_source_sha256_and_p05_numeric_trace')
    checks.append('action_table_cycle_budget_and_requirement_cross_references')
    return {'status':'PASS','validation_layer':'P06_AUTHOR_STATIC_CONTENT_ONLY','checks':checks,
            'enemy_samples':len(spec['enemies']),'skills':len(spec['skills']),'nominal_states':len(declared),
            'expected_only_cases':len(cases),'runtime_cases_executed':0,
            'P16_AI_runtime':'NOT_RUN','P14_contract_runtime':'NOT_RUN','P32_independent':'NOT_RUN','P35_gate':'NOT_RUN'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    args=parser.parse_args()
    try:
        result=validate_files(args.root)
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (InvalidContent,KeyError,ValueError,OSError,StopIteration) as exc:
        print(json.dumps({'status':'FAIL','validation_layer':'P06_AUTHOR_STATIC_CONTENT_ONLY','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
