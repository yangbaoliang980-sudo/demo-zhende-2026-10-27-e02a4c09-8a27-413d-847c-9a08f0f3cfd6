# P06｜敌方怪物、BOSS机制与行为交付 V0.1

**交付状态：`LOCAL_CONTENT_DELIVERED / FORMAL_INTEGRATION_BLOCKED`。**

任务 `P06-S03-ENEMY-001`；版本 `P06-ENEMY-0.1.0-proposal`；日期 2026-10-28（UTC+08:00）。主需求为 P01 `REQ-009`，关联 `REQ-019/023/024/038`。本次依据当前用户的 P06 执行指令启动本岗隔离交付，未改写 P01 历史启动登记，也未宣布其他岗位已启动。

本包交付可解析的敌人内容、意图语义、阶段图、固定状态用例及作者验证工具。**不是敌人 AI 实现、可运行游戏或正式内容批准。** S03 优先部分是一只普通怪的行为与预告。精英和 BOSS 为同一内容契约下的提前机制样本，用于消除 S07 边界歧义，不表示 S07 运行门禁已通过。三个样本不决定最终敌人数量。

## 1. 先读与使用

四项强制产物均为实体文件，可直接编辑、解析和逐字节校验。

| 相对路径 | 内容 | 接收岗位 |
| --- | --- | --- |
| `content/enemies/enemy_specs.json` | 3 类敌人样本、13 个动作、18 个循环状态；目标、蓄力、冷却、异常与退路 | P05/P07/P16/P22/P32 |
| `content/enemies/intent_dictionary.tsv` | 13 条预告语义；当前伤害与未来重击数值分开；合法偏差原因 | P16/P19/P27/P32 |
| `content/enemies/boss_phase_graph.json` | 3 个阶段、2 条单向阈值边、终局出口与逻辑图缺失退路 | P02/P14/P16/P27/P32 |
| `content/enemies/enemy_truth_cases.tsv` | 89 条完整输入投影、固定种子、操作、期望投影和来源锚点 | P16/P14/P32/P35 |

辅助成果在 `design/enemies/`：敌方行动表 `enemy_action_table.tsv`、状态覆盖 `state_coverage.tsv`、全局状态退路 `state_resolution_rules.tsv`、数值引用 `budget_trace.tsv`、BOSS 状态图 `boss_phase_graph.mmd`、字段说明 `content_format.md`、机制说明 `behavior_and_counterplay.md`、资源需求 `asset_requests.tsv`、RFC/阻塞说明 `interface_rfc_and_blockers.md`、下游回执模板 `downstream_handoff.tsv` 和完整哈希清单 `delivery_manifest.sha256.tsv`。

**路径边界：**这些是隔离包内的相对路径。P13 `actual_path_mapping.json`、`do_not_touch.txt` 和工程写入白名单未到场；本包不能被解释成获准写入真实工程。根 `README.md` 仅为包级入口；本岗新产物都在 `design/enemies/**`、`content/enemies/**`，其中 `evidence/readonly_upstream/` 仅保留源字节，不得改写。

## 2. 上游证据与使用边界

已读取上传包中的实际内容，而非只读取目录或文件名。

| 核验项 | 本次结果 |
| --- | --- |
| 外层转交文件 | 34/34 大小与 SHA-256 匹配；ZIP CRC 通过 |
| P01 内层 ZIP | 16 项；内部清单 15/15 匹配 |
| P02 内层 ZIP | 15 项；内部清单 14/14 匹配 |
| P03 内层 ZIP | 17 项；内部清单 16/16 匹配 |
| P04 内层 ZIP | 20 项；内部清单 19/19 匹配 |
| P05 内层 ZIP | 20 项；内部清单 19/19 匹配 |
| V6 原文 | 经 GitHub 读取固定提交；本地重算 SHA-256 及 Git blob 均匹配 |
| P05 固定归档 | 读取远端清单；完整 ZIP 与参数表的大小、SHA-256 和 Git blob 均匹配 |

固定来源：V6 `8c370d731c323f86ff19642f4cc73f818498f641`；P05 接力归档 `18e7cd9af350fad790a4970250b6b27c595a7868`。P02 规则版本为 `P02-BATTLE-0.1.0-draft`，P05 数值版本为 `P05-BALANCE-0.1.0-provisional`，均不是已签正式引擎契约。

`source_input_receipt.tsv` 给出 13 份实际使用源文件的原路径、保存路径、完整 SHA-256、版本和 owner；`evidence/input_verification.json` 记录 34 个转交文件及各内层包的核验结果。独立附件中部分 TSV 仅含表头，尤其 `effect_priority.tsv` 只有 11 字节，本次采用 P02 ZIP 内完整 30 条规则，未把表头当作完整规范。P01 的决策表同样采用完整内层版本。

**未取得：**P07 `stage_graph.json`、`stage_rewards.tsv`、`stage_retry_cases.json` 及节奏/关卡放置批准；P13 正式映射、DTO 和真实工程；P22 注册表/Schema；P34 目标环境证据。缺失结论仅针对本次附件与指定固定仓库快照，不代表其他位置不存在工程。

## 3. 敌人样本与数值

所有内容 ID 以 `MOCK_P06_` 开头、`production_enabled=false`；名称和模式是本岗草案，尚未占用 P22 正式注册 ID。

| 类别 / 测试 ID | 名称 | HP / 初始盾 | 行动循环 | 基础数值来源 |
| --- | --- | --- | --- | --- |
| 普通 `MOCK_P06_ENEMY_001` | 游离字屑 | 24 / 0 | 散字冲撞，每次单体基础8 | P05 `normal_enemy_hp/atk` |
| 精英 `MOCK_P06_ENEMY_002` | 锁页卫士 | 55 / 4 | 单体12 → 蓄力0 → 单体24 → 整理0 | P05 `elite_enemy_hp/atk/shield`；重击倍率由P06提案 |
| BOSS `MOCK_P06_ENEMY_003` | 失序校勘者 | 125 / 0 | 按下表阶段循环 | P05 `boss_enemy_hp/atk`；蓄力/群攻由P06提案 |

| BOSS 阶段 | 循环 | 三名合法目标时，每完整循环基础伤害上界 |
| --- | --- | --- |
| P1 校勘 | 单体18 → 蓄力0 → 单体36 → 整理0 | 54 / 4行动槽 |
| P2 散页 | 群攻每名6 → 蓄力0 → 单体36 → 整理0 | 54 / 4行动槽 |
| P3 终句 | 单体18 → 群攻每名6 → 蓄力0 → 单体36 → 整理0 | 72 / 5行动槽 |

P05 原模拟的 125 HP BOSS 每回合单次18、没有阶段。本包增加蓄力、整理、阶段等待和目标锁定，因此不能继承 P05 的“20回合胜利”或其他难度结论。上表只做循环算术，不预测真实通关时长。P05 必须用本包固定版本重新评估；P07 决定关卡节奏；P01 负责难度/数量范围批准。本包没有修改掉落或学习收益。

## 4. 已明确的边界

**先终局，后阶段。**按 P02 顺序完成伤害、死亡与合法反应，再统一判定 WIN/LOSS/DRAW。只在非终局且 BOSS 存活时检查阶段。阈值使用整数比较：`before_hp*100 > max_hp*threshold_percent` 且 `after_hp*100 <= max_hp*threshold_percent`。125 HP 下，60%对应75；30%的最大符合整数HP为37，不能四舍五入到38。

- `76→75`：仅提出 P2；提案本身不写当前阶段。
- `80→30`：按图顺序提出 P2、P3。P14 受理后原子进入最终阶段，只有一次阶段等待，没有两次免费攻击。
- `80→0`：最后敌人被杀且玩家存活时只产生 WIN，不切阶段、不回血、不复活。
- BOSS 死但别的敌人活着：战斗继续，但死 BOSS 仍不得切阶段。
- BOSS 存活而玩家被合法反应全灭：LOSS 优先，不切阶段。
- 双方被根效果及死亡反应清空：DRAW；反应未排空之前不能提前 WIN。

**预告不偷换。**单体目标按稳定阵位轮换选择，P14 提交预告后锁定技能、基础数值、目标名单和阶段版本。目标失效时明确跳过，不能暗中打另一人。群攻只从锁定名单移除已失效对象，不追加新目标。基础伤害不等于扣血，护盾减伤由 P14 的 `DAMAGE_APPLIED` 结果显示。

**蓄力有完整反制窗口。**蓄力当次伤害为0，下一次敌方行动才尝试重击。释放成功后 HEAVY 冷却为2，阻塞之后两个行动槽；恢复、明确跳过及阶段等待槽也按规则递减。重复命令和死亡单位不递减。阶段切换取消原蓄力；取消时冷却设置为2一次，不能重复切阶段刷新动作。

**区分缺逻辑图和缺图片。**缺阶段逻辑图且基础攻击仍有效时，进入本局不可反复退出的 `DEGRADED_BASIC` 行为模式：一次零伤提示后持续预告基础攻击，保留最后已提交 `phase_id`。若基础招式也无效则拒绝加载或受控 FAULTED，不能永远空转。只有阶段图片缺失时，逻辑、阶段、蓄力和 RNG 均不变；优先复用同一敌人的已批准主图/上一张图，没有可用图则仅显示明确标识的文字诊断视图，正式美术门禁仍 BLOCKED。

更完整的目标、冷却、异常、免疫和反制顺序见 `behavior_and_counterplay.md`。所有跨模块新增字段及阶段受理规则仍是 RFC 候选，不覆盖 P02/P13/P14/P16 既有产物。

## 5. 验证与复算

在解压包根目录使用 Python 3.10+ 标准库：

```bash
python design/enemies/verification/validate_enemy_content.py
python -m unittest discover -s design/enemies/verification -p "test_*.py" -v
python design/enemies/verification/verify_manifest.py
```

第一条检查版本/授权标记、源 SHA、数值引用、意图和技能一致、每个循环状态的后继、阶段图单向可达、终局出口、降级进展、89条用例的静态一致性与阈值算术。第二条执行 **22 个作者校验器测试**，其中21个是负向变异：确保错误预告、阶段倒退、致死后提阶段、假冒PASS、缺退路等会被拒绝。第三条检查交付文件的字节、大小和白名单。

**89条是期望用例，不是89次真实 AI 执行。**P16/P14 应在获批 DTO 上适配这些输入投影，由 P32 运行真实实现并记录观测值；本包不含敌人选择实现，不调用游戏/Anki，不产出伪造的运行观测。作者日志、实际命令、退出码及环境指纹见 `evidence/validation_run_01.json` 和对应 stdout/stderr。复解压结果见外层交付回执。

| 验收层级 | 状态 |
| --- | --- |
| 源文件字节核验 | PASS，P06实际执行 |
| P06内容静态自检 | PASS，实际执行 |
| P06校验器作者测试 | PASS，22/22实际执行 |
| 独立设计签署 / P35 SPEC Gate | NOT_RUN |
| P13/P22正式内容与DTO契约 | BLOCKED |
| P16 AI模块单元运行 | NOT_RUN |
| P14真实结算/契约运行 | NOT_RUN |
| P32独立自动化 / P33人工 / P35独审 | NOT_RUN |
| 游戏真机 / 动画等价真实测试 / Anki E2E | NOT_RUN |
| 正式工程写入 / 跨模块集成 | BLOCKED |

## 6. 接收、修订与边界

P05 接收数值轨迹与新循环，重新评估预算；P07 接收敌人类型与图，提供版本化关卡节奏；P16 接收四项主产物实现选择与预告；P27/P30 接收资源需求并保证缺图退路；P32 接收89条期望用例和原始日志；P35独立审查来源、权限和证据分层。P13处理 DTO/路径，P22处理正式ID，P14保持唯一权威提交。各项回执目前为 `PREPARED_NOT_ACKNOWLEDGED`，没有虚报签收。

IC owner 已从 V6 原文核实：IC-06=P06；IC-07=P14；IC-12=P16。本包 RFC 已成文，未发送为已签合同，也未改动其他岗位文件。发生差异须保留本包旧 SHA、对方实际 base SHA 与 ChangeRequest；连续两轮返工无新证据交 P01。代码整合仍由用户后续指定的 EXT-INTEGRATOR 执行。

逐件大小、SHA-256、格式/版本、源输入哈希、接收人和修改白名单见 `design/enemies/delivery_manifest.sha256.tsv`。清单不自哈希；它与最终 ZIP 的哈希由外层 `P06_delivery_receipt.json` 给出，避免循环自引用。
