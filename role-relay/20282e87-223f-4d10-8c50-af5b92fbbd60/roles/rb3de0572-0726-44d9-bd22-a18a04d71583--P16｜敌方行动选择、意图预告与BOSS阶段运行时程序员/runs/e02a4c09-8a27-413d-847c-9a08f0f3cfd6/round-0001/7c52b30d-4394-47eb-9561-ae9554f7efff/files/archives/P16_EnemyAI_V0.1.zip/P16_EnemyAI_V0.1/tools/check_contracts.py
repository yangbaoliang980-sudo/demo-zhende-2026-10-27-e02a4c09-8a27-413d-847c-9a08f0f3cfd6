"""Use the original P13 validator, without monkey-patching its schema."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from upstream.P13.runtime.framework.yltt_framework.contracts import validate
from upstream.P13.runtime.framework.yltt_framework.codec import ContractError

def check():
    fixtures=json.loads((ROOT/'intent_replay_fixtures.json').read_text())['fixtures']
    counts={};expected_invalid=[];failures=[]
    def item(value,dto,case):
        try:validate(value,dto);counts[dto]=counts.get(dto,0)+1
        except ContractError as exc:failures.append({'case_id':case,'dto':dto,'error':str(exc)})
    for fixture in fixtures:
        case=fixture['case_id'];out=fixture['expected_output'];snapshot=fixture['request']['snapshot']
        try:validate(snapshot,'BattleSnapshot');counts['BattleSnapshot']=counts.get('BattleSnapshot',0)+1
        except ContractError as exc:
            if out['status']=='REJECTED':expected_invalid.append({'case_id':case,'error':str(exc)})
            else:failures.append({'case_id':case,'error':str(exc)})
        result=out.get('result',{})
        if result.get('intent') is not None:item(result['intent'],'EnemyIntent',case)
        for proposal in result.get('proposals',[]):item(proposal,'PhaseProposal',case)
    return {'status':'AUTHOR_CONTRACT_PASS' if not failures else 'FAIL','validator':'UNMODIFIED_P13_ORIGINAL',
            'valid_messages':sum(counts.values()),'by_dto':counts,'expected_invalid_inputs':expected_invalid,
            'failures':failures,'formal_contract_acceptance':'BLOCKED','independent_P32':'NOT_RUN'}

if __name__=='__main__':
    result=check();print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(1 if result['failures'] else 0)
