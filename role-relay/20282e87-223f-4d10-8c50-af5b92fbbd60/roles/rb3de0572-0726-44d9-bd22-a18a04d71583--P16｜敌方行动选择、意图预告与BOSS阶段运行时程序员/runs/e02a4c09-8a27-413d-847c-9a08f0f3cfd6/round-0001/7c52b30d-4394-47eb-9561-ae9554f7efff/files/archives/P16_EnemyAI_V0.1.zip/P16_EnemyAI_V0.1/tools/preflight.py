"""Evidence-based formal gate. Never approves production from an isolated run."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
mapping=json.loads((ROOT/'upstream/P13/architecture/actual_path_mapping.json').read_text())
paths=[m for m in mapping['mappings'] if m['owner']=='P16']
blockers=json.loads((ROOT/'handoff/blockers.json').read_text())['items']
open_items=[b for b in blockers if b['status']=='BLOCKED']
result={'status':'BLOCKED','exit_code':3,'task_id':'P16-S03-AI-001',
    'observed_P13_production_write_authorized':mapping['production_write_authorized'],
    'P16_actual_paths':paths,'unmet_items':open_items,
    'independent_P32':'NOT_RUN','independent_P33':'NOT_RUN','independent_P35':'NOT_RUN',
    'target_engine':'NOT_RUN','game_E2E':'NOT_RUN'}
print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(3)
