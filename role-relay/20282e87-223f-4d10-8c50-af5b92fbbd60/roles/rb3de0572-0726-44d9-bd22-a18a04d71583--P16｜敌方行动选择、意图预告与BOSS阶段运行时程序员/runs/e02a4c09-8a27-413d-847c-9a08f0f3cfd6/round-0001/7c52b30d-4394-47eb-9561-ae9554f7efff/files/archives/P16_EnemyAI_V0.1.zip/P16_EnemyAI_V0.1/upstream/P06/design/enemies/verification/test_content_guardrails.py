"""Negative mutation checks for the P06 content linter, not enemy-AI tests."""
import copy
import json
from pathlib import Path
import unittest
from validate_enemy_content import ROOT, InvalidContent, validate, validate_files, load_tsv

class ContentGuardrails(unittest.TestCase):
    def setUp(self):
        base=ROOT/'content/enemies'
        self.spec=json.loads((base/'enemy_specs.json').read_text())
        self.graph=json.loads((base/'boss_phase_graph.json').read_text())
        self.intents=load_tsv(base/'intent_dictionary.tsv')
        self.cases=load_tsv(base/'enemy_truth_cases.tsv')

    def reject(self, code):
        with self.assertRaisesRegex(InvalidContent, code):
            validate(self.spec,self.graph,self.intents,self.cases)

    def test_delivery_is_structurally_valid(self):
        result=validate_files()
        self.assertEqual(result['status'],'PASS')
        self.assertEqual(result['runtime_cases_executed'],0)

    def test_blocks_fabricated_production_approval(self):
        self.spec['production_enabled']=True;self.reject('SCOPE')

    def test_blocks_missing_no_target_fallback(self):
        self.spec['skills'][0]['no_valid_target']='UNDEFINED';self.reject('NO_TARGET_FALLBACK')

    def test_blocks_preview_damage_mismatch(self):
        self.intents[0]['current_base_amount_per_hit']='80';self.reject('INTENT_AMOUNT')

    def test_blocks_charge_as_immediate_damage(self):
        self.spec['skills'][2]['base_amount_per_hit']=24
        self.intents[2]['current_base_amount_per_hit']='24'
        self.reject('ZERO_DAMAGE_ACTION')

    def test_blocks_negative_cooldown(self):
        self.spec['skills'][3]['cooldown_on_success_slots']=-1;self.reject('SKILL_INTEGER')

    def test_blocks_missing_state_successor(self):
        self.spec['enemies'][0]['states'][0]['next_state_id']='MISSING';self.reject('STATE_SUCCESSOR')

    def test_blocks_no_damage_infinite_behavior_cycle(self):
        self.spec['enemies'][0]['states'][0]['skill_id']='MOCK_P06_SKILL_SAFE_SKIP';self.reject('NO_DAMAGE_CYCLE')

    def test_blocks_backward_phase_cycle(self):
        self.graph['transitions'][1]['to_phase_id']='MOCK_P06_PHASE_1';self.reject('PHASE_ORDER')

    def test_blocks_unreachable_phase(self):
        self.graph['transitions'].pop();self.reject('PHASE_EDGE_COUNT')

    def test_blocks_float_threshold(self):
        self.graph['transitions'][0]['threshold_percent']=60.0;self.reject('THRESHOLD_INTEGER')

    def test_blocks_boolean_as_integer(self):
        self.spec['enemies'][0]['max_hp']=True;self.reject('ENEMY_NUMBERS')

    def test_blocks_hidden_phase_heal(self):
        self.graph['phases'][1]['entry_heal']=1;self.reject('PHASE_ENTRY_EFFECT')

    def test_blocks_missing_terminal_exit(self):
        self.graph['terminal_exits'].pop();self.reject('TERMINAL_EXIT')

    def test_blocks_graph_fallback_that_never_attacks(self):
        self.graph['degraded_exit']['then_skill_id']='MOCK_P06_SKILL_SAFE_SKIP';self.reject('DEGRADED_PROGRESS')

    def test_blocks_runtime_pass_on_expected_only_fixture(self):
        self.cases[0]['runtime_status']='PASS';self.reject('CASE_EVIDENCE_LEVEL')

    def test_blocks_lethal_threshold_resurrection_expectation(self):
        row=next(r for r in self.cases if '同时致死' in r['scenario_zh'])
        ex=json.loads(row['expected_json']);ex['phase_proposals']=['MOCK_P06_PHASE_2']
        row['expected_json']=json.dumps(ex);self.reject('TERMINAL_PRECEDENCE')

    def test_blocks_skipping_first_crossed_phase(self):
        row=next(r for r in self.cases if '一次跨两个阈值' in r['scenario_zh'])
        ex=json.loads(row['expected_json']);ex['phase_proposals']=['MOCK_P06_PHASE_3']
        row['expected_json']=json.dumps(ex);self.reject('CASE_THRESHOLD_ARITHMETIC')

    def test_blocks_missing_nominal_state_case(self):
        self.cases=self.cases[1:];self.reject('NOMINAL_COVERAGE')

    def test_blocks_automatic_retarget_policy(self):
        self.spec['policies']['targeting']['auto_retarget']=True;self.reject('TARGETING')

    def test_blocks_cooldown_that_stalls_on_skips(self):
        self.spec['policies']['cooldown']['skips_tick']=False;self.reject('COOLDOWN_PROGRESS')

    def test_blocks_unapproved_on_death_attack(self):
        self.spec['enemies'][2]['on_death_reaction_ids']=['UNAPPROVED_RETALIATE'];self.reject('UNAPPROVED_ENEMY_EXTENSION')

if __name__=='__main__':
    unittest.main(verbosity=2)
