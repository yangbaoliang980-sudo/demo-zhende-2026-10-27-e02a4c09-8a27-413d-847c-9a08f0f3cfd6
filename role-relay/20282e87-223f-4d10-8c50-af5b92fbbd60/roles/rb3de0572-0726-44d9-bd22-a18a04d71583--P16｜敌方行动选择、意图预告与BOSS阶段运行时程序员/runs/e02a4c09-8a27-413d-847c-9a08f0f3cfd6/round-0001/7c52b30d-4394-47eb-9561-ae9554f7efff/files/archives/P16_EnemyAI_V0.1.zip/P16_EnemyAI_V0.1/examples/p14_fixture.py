"""Author contract-test assembly using original, unmodified P14 sources.

All initial state and policy values here are explicit fixtures. This is not the
EXT-INTEGRATOR's game composition and cannot persist P06 behavior candidates.
"""
from enemy_ai import P14SingleSlotAdapter,publish_intent,bundled_catalog
from enemy_ai.types import wire
from upstream.P14.battle_core import BattleCore,Rules,Action,Effect,Dot
from upstream.P14.battle_core.model import BossEdge,SourceBinding
from upstream.P14.battle_core.ports import CandidateRejected


def make_rules(catalog,*,cards=(),statuses=(),boss_edges=(),target_counts=None):
    counts=target_counts or {}
    specs=[]
    for s in catalog.spec.value['skills']:
        count=0 if s['target_policy']=='NONE' else (3 if s['target_policy']=='LOCK_ALL_ALIVE' else 1)
        effects=() if s['effect_code']=='NONE' else (Effect(0,'DAMAGE',s['base_amount_per_hit']),)
        specs.append(Action(s['skill_id'],'PLAYER',counts.get(s['skill_id'],count),effects))
    return Rules('P02-BATTLE-0.1.0-draft','P06-ENEMY-0.1.0-proposal','fixture:p16:deck',
        'ENEMY_EXIT',0,None,'UNCAPPED_TEST_ONLY',cards=tuple(cards),skills=tuple(specs),statuses=tuple(statuses),
        boss_edges=tuple(boss_edges),source_bindings=(SourceBinding('P06','P06-ENEMY-0.1.0-proposal',catalog.source_sha256),))


def boss_edges(catalog,unit_id):
    return tuple(BossEdge(unit_id,e['from_phase_id'],e['to_phase_id'],
        e['threshold_max_hp_fraction']['numerator'],e['threshold_max_hp_fraction']['denominator'],True)
        for e in catalog.graph.value['transitions'])


def make_core(snap,behavior,*,announcement=None,rules=None,interrupt=None,provider_wrapper=None,deck=None):
    cat=bundled_catalog();p=publish_intent(snap,behavior,cat)
    ann=announcement or p.announcement
    adapter=P14SingleSlotAdapter(cat,behavior,ann,rejection_type=CandidateRejected,scope='ONE_SLOT_CONTRACT_TEST_ONLY')
    provider=provider_wrapper(adapter) if provider_wrapper else adapter
    core=BattleCore(wire('BattleState',snapshot=snap.value,accepted_commands=[]),rules or make_rules(cat),
        stage_id='fixture:p16:stage',profile_scope='fixture:p16:profile',enemy_planner=provider,
        deck_planner=deck,test_interrupt=interrupt)
    return core,p,adapter


def command(core,kind='SYSTEM_ENEMY_ACTION',cid='fixture:enemy:1',revision=None,payload=None):
    s=core.state().value['snapshot']
    return wire('BattleCommand',battle_id=s['battle_id'],command_id=cid,
        expected_revision=s['revision'] if revision is None else revision,kind=kind,payload=payload or {})


def authority_bytes(core):
    return (core.state().raw,None if core.result() is None else core.result().raw,
        tuple(x.raw for x in core.committed_batches()),tuple(x.raw for x in core.resolution_traces()),
        core.export_replay().sha256)


class CountProvider:
    def __init__(self,inner):self.inner=inner;self.calls=0
    def propose(self,snapshot):
        self.calls+=1;return self.inner.propose(snapshot)


class DeclaredDeckFixture:
    """P15 stand-in: supplies exact test moves/delta, no deck or cost algorithm."""
    def __init__(self,moves=(),energy_delta=0):
        self.moves=tuple(dict(m) for m in moves);self.energy_delta=energy_delta
    def propose(self,command,snapshot):
        c=command.value;s=snapshot.value
        return wire('DeckPatchCandidate',battle_id=s['battle_id'],command_id=c['command_id'],
            expected_revision=s['revision'],command_sha256=command.sha256,snapshot_sha256=snapshot.sha256,
            policy_version='fixture:p16:deck',energy_delta=self.energy_delta,moves=list(self.moves),
            rng_before=s['rng'],rng_after=s['rng'])
