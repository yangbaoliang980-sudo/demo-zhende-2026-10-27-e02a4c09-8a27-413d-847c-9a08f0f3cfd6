from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from examples.demo import run_demo
expected=json.loads((ROOT/'examples/demo_execution.json').read_text())
actual=run_demo()
ok=actual==expected
print(json.dumps({'status':'AUTHOR_DEMO_REPLAY_PASS' if ok else 'FAIL',
    'recomputed_from_initial_inputs':True,'p14_replay_sha256':actual['p14_replay']['sha256'],
    'full_execution_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()},indent=2))
sys.exit(0 if ok else 1)
