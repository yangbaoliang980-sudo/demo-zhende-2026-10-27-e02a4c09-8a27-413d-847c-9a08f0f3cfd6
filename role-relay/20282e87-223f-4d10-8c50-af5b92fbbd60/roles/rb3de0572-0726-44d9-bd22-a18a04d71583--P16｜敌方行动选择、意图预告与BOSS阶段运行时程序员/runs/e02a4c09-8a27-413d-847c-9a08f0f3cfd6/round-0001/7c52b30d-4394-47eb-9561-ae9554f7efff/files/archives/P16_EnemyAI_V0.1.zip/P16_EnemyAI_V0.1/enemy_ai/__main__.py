from examples.demo import run_demo
import json
print(json.dumps(run_demo()['summary'],ensure_ascii=False,indent=2))
