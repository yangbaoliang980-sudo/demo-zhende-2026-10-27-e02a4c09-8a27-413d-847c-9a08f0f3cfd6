"""Author unit and unchanged-upstream contract checks."""
