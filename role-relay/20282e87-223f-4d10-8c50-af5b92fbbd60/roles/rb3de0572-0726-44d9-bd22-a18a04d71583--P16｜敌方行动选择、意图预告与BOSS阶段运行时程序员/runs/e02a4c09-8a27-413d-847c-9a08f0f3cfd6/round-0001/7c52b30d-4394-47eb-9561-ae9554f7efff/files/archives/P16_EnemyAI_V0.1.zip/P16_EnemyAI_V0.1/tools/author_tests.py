from pathlib import Path
import sys,unittest,json
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
result=unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({'validation_layer':'P16_AUTHOR_ONLY','tests_run':result.testsRun,
    'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
    'status':'AUTHOR_PASS' if result.wasSuccessful() else 'FAIL','P32':'NOT_RUN','P35':'NOT_RUN'},indent=2))
sys.exit(0 if result.wasSuccessful() else 1)
