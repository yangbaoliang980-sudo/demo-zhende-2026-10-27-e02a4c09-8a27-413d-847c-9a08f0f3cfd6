"""Validate a P14/P13 read-only snapshot and its explicit local extension."""
from upstream.P14.battle_core.rng import advance
from .types import (AiError, BehaviorSnapshot, CONTENT_VERSION, CONTRACT_VERSION,
                    RULES_VERSION, FrozenMessage, checked, integer, require)

SUPPORTED_STATUS_IDS = {'MOCK_P03_STATUS_BURN','MOCK_P03_STATUS_BURN_STRONG'}


def observed_outcome(snapshot):
    players=any(u['side']=='PLAYER' and u['hp']>0 for u in snapshot['units'])
    enemies=any(u['side']=='ENEMY' and u['hp']>0 for u in snapshot['units'])
    return 'ONGOING' if players and enemies else ('WIN' if players else ('LOSS' if enemies else 'DRAW'))


def phase_order(enemy):
    return tuple(dict.fromkeys(s['phase_id'] for s in enemy['states'] if 'phase_id' in s))


def validate_inputs(snapshot, behavior, catalog):
    raw=snapshot.value if isinstance(snapshot,FrozenMessage) else snapshot
    require(type(raw) is dict and raw.get('contract_version')==CONTRACT_VERSION, 'SNAPSHOT_VERSION_UNSUPPORTED')
    msg=checked(raw,'BattleSnapshot'); s=msg.value
    require(type(behavior) is BehaviorSnapshot,'BEHAVIOR_SNAPSHOT_REQUIRED')
    require((behavior.battle_id,behavior.revision,behavior.snapshot_sha256)==(s['battle_id'],s['revision'],msg.sha256), 'BEHAVIOR_SNAPSHOT_BINDING_MISMATCH')
    require(s['rules_version']==RULES_VERSION,'RULES_VERSION_UNSUPPORTED')
    require(s['content_version']==CONTENT_VERSION,'CONTENT_VERSION_MISMATCH')
    units={u['unit_id']:u for u in s['units']}
    require({u['side'] for u in units.values()}=={'PLAYER','ENEMY'},'BOTH_SIDES_REQUIRED')
    require(behavior.actor_id in units and units[behavior.actor_id]['side']=='ENEMY','ACTOR_UNKNOWN_OR_WRONG_SIDE')
    actor=units[behavior.actor_id]; enemy=catalog.enemy(actor['definition_id'])
    party=[u for u in units.values() if u['side']=='PLAYER']
    require(1<=len(party)<=3,'PARTY_SIZE_UNSUPPORTED')
    require(set(behavior.targetable_ids)<={u['unit_id'] for u in party},'TARGETABLE_IDS_INVALID')
    for u in units.values():
        integer(u['max_hp'],1,21474836,'FIXTURE_INTEGER_RANGE')
        for stat in u['statuses']:
            require(stat['status_id'] in SUPPORTED_STATUS_IDS,'UNSUPPORTED_STATUS')
    require(actor['max_hp']==enemy['max_hp'],'ENEMY_STATS_VERSION_MISMATCH')
    rng=s['rng']
    require(advance(rng['initial_seed'],rng['draw_count'])==rng['state'],'RNG_HISTORY_INVALID')
    if s['phase'] not in ('CREATED','TERMINAL','ABORTED','FAULTED'):
        require(s['turn_number']>=1,'ACTIVE_TURN_NUMBER_REQUIRED')
    states={x['state_id']:x for x in enemy['states']}
    boss=next((b for b in s['boss_states'] if b['unit_id']==behavior.actor_id),None)
    if enemy['tier']=='BOSS':
        require(boss is not None,'BOSS_STATE_MISSING')
        order=phase_order(enemy); current=boss['current_phase_id']
        require(current in order,'UNKNOWN_PHASE')
        rank=order.index(current)
        require(behavior.phase_committed_ids==order[:rank+1],'INVALID_PHASE_HISTORY')
        require((rank==0 and behavior.phase_epoch==0) or (rank>0 and 1<=behavior.phase_epoch<=rank),'INVALID_PHASE_EPOCH')
        proposed=boss['proposed_phase_ids']
        require(all(p in order[1:] for p in proposed),'UNKNOWN_PROPOSED_PHASE')
        require(proposed==sorted(proposed,key=order.index),'PHASE_PROPOSAL_ORDER_INVALID')
        pending=[p for p in proposed if p not in behavior.phase_committed_ids]
        require(pending==list(order[rank+1:rank+1+len(pending)]),'PHASE_PROPOSAL_GAP')
        if behavior.degraded:
            require(behavior.state_id=='DEGRADED_STRIKE' and not behavior.entry_wait_pending and behavior.charge is None,'DEGRADED_STATE_INVALID')
        else:
            require(behavior.state_id in states and states[behavior.state_id]['phase_id']==current,'STATE_PHASE_MISMATCH')
        if behavior.entry_wait_pending:
            require(rank>0 and behavior.state_id==enemy['phase_initial_state_ids'][current] and behavior.charge is None,'ENTRY_WAIT_STATE_INVALID')
    else:
        require(boss is None and behavior.state_id in states,'STATE_UNKNOWN')
        require(behavior.phase_epoch==0 and behavior.phase_committed_ids==() and not behavior.entry_wait_pending and not behavior.degraded,'NON_BOSS_PHASE_STATE')
    if behavior.charge is not None:
        ch=behavior.charge
        releases={x['skill_id'] for x in enemy['states'] if catalog.skill(x['skill_id'])['action_kind']=='RELEASE'}
        require(ch.release_skill_id in releases,'CHARGE_SKILL_UNKNOWN')
        require(ch.phase_epoch==behavior.phase_epoch,'CHARGE_EPOCH_MISMATCH')
        require(behavior.heavy_cooldown==0,'CHARGE_COOLDOWN_CONFLICT')
        require(behavior.state_id in states and states[behavior.state_id]['skill_id']==ch.release_skill_id,'CHARGE_STATE_MISMATCH')
    return msg,s,actor,enemy,boss


def validate_start_snapshot(snapshot,behavior,catalog):
    msg,s,actor,enemy,boss=validate_inputs(snapshot,behavior,catalog)
    if boss is not None and not behavior.degraded and catalog.graph is not None and behavior.graph_available:
        graph=catalog.graph.value; order=phase_order(enemy)
        reached=set(behavior.phase_committed_ids)|set(boss['proposed_phase_ids'])
        for edge in graph['transitions']:
            if actor['hp']>0 and actor['hp']*100<=actor['max_hp']*edge['threshold_percent']:
                require(edge['to_phase_id'] in reached,'INVALID_PHASE_HISTORY')
    return msg
