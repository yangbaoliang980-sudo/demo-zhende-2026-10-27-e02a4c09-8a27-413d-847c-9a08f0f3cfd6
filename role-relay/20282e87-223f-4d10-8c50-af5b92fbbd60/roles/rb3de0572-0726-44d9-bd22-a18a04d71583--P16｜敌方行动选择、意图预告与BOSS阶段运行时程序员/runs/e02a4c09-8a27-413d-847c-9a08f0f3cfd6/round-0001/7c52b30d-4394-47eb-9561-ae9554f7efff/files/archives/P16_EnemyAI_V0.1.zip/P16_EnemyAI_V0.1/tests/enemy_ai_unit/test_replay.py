import os,sys,subprocess,unittest,json,hashlib,copy,tempfile
from pathlib import Path
from tools.replay_fixtures import replay
ROOT=Path(__file__).resolve().parents[2]

class ReplayTests(unittest.TestCase):
    def test_recompute_frozen_inputs(self):
        result=replay(ROOT/'intent_replay_fixtures.json')
        self.assertEqual('AUTHOR_REPLAY_PASS',result['status']);self.assertEqual(86,result['cases'])

    def test_three_processes_hash_seeds_same_execution_digest(self):
        outputs=[]
        for seed in ('1','222','random'):
            p=subprocess.run([sys.executable,'-B','tools/replay_fixtures.py','--digest-only'],cwd=ROOT,
                env={**os.environ,'PYTHONHASHSEED':seed,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
            self.assertEqual(0,p.returncode,p.stderr);outputs.append(p.stdout.strip())
        self.assertEqual(1,len(set(outputs)))

    def test_changed_fixture_expected_output_detected(self):
        data=json.loads((ROOT/'intent_replay_fixtures.json').read_text())
        data['fixtures'][0]['expected_output']['result']['action']['base_amount_per_hit']=999
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'changed.json';p.write_text(json.dumps(data))
            result=replay(p)
        self.assertEqual('FAIL',result['status']);self.assertEqual('P06-ET-001',result['failures'][0]['case_id'])
