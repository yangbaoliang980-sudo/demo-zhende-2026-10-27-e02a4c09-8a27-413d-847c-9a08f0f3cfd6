"""Versioned isolated fixture composition. Not a shipped game host."""
