#!/usr/bin/env python3
"""Verify a P06 delivery file manifest; does not modify any file."""
import csv
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[3]
MANIFEST='design/enemies/delivery_manifest.sha256.tsv'

def main():
    errors=[]
    with (ROOT/MANIFEST).open(encoding='utf-8',newline='') as f:
        rows=list(csv.DictReader(f,delimiter='\t'))
    seen=set()
    for row in rows:
        rel=row['relative_path'];p=ROOT/rel
        if rel in seen:errors.append('duplicate path: '+rel)
        seen.add(rel)
        if not p.resolve().is_relative_to(ROOT.resolve()):
            errors.append('out-of-package path: '+rel);continue
        if not p.is_file():errors.append('missing: '+rel);continue
        b=p.read_bytes()
        if len(b)!=int(row['actual_bytes']) or hashlib.sha256(b).hexdigest()!=row['sha256']:
            errors.append('bytes/hash mismatch: '+rel)
        if not (rel=='README.md' or rel.startswith('content/enemies/') or rel.startswith('design/enemies/')):
            errors.append('outside local whitelist: '+rel)
        if row['real_engine_write_authorized']!='NO' or row['actual_path_mapping_status']!='BLOCKED_NOT_RECEIVED':
            errors.append('fabricated engineering authority: '+rel)
        sources=json.loads(row['source_input_hashes_json'])
        if not sources or any(len(v)!=64 for v in sources.values()):errors.append('invalid source hashes: '+rel)
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    extra=actual-seen-{MANIFEST}
    if extra:errors.append('unlisted files: '+', '.join(sorted(extra)))
    print(json.dumps({'status':'FAIL' if errors else 'PASS','files_verified':len(rows),'manifest_self_hash':'IN_EXTERNAL_DELIVERY_RECEIPT',
                      'errors':errors,'scope':'PACKAGE_BYTES_ONLY_NOT_RUNTIME'},ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__=='__main__':
    raise SystemExit(main())
