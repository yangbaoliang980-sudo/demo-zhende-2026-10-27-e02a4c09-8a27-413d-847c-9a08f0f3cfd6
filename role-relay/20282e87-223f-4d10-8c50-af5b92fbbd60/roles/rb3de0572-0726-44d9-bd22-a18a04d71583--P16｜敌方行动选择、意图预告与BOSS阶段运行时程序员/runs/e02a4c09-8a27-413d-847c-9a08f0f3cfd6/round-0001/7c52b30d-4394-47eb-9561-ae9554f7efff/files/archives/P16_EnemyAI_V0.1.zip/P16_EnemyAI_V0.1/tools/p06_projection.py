"""Run original P06 expectations against P16, with field-level scope limits."""
from pathlib import Path
import sys,json,csv,hashlib,copy
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from enemy_ai import (AiError,BehaviorSnapshot,Announcement,PhaseCheckpoint,bundled_catalog,
                     publish_intent,resolve_intent,propose_phases,validate_start_snapshot,Catalog)
from enemy_ai.types import FrozenMessage
from examples.fixture_inputs import project_p06_input

SOURCE=ROOT/'upstream/P06/content/enemies/enemy_truth_cases.tsv'
UNBOUND={'P14_ACCEPT_PHASE_PROPOSALS':'P14_PHASE_ACCEPTANCE_NOT_IMPLEMENTED',
         'DUPLICATE_ACCEPTED_COMMAND':'AUTHORITATIVE_COMMAND_RECEIPT_NOT_IN_P06_PROJECTION'}
ALIASES={'REJECT_INVALID_PHASE_HISTORY':'INVALID_PHASE_HISTORY','REJECT_UNSUPPORTED_STATUS':'UNSUPPORTED_STATUS',
         'REJECT_INVALID_HP':'SNAPSHOT_OR_DTO_INVALID','REJECT_INVALID_SEED':'SNAPSHOT_OR_DTO_INVALID',
         'REJECT_FIXTURE_INTEGER_RANGE':'FIXTURE_INTEGER_RANGE','REJECT_UNKNOWN_PHASE':'UNKNOWN_PHASE'}


def rows():
    return list(csv.DictReader(SOURCE.open(encoding='utf-8'),delimiter='\t'))


def request_for(row):
    data=json.loads(row['input_json']);st=json.loads(row['stimulus_json']);op=st['operation']
    s,c,a=project_p06_input(data,st)
    return {'operation':op,'snapshot':s.value,'behavior':c.message().value,
            'announcement':None if a is None else a.value,'stimulus':st}


def execute_request(request):
    """Consumes input only. Never reads a P06 expected value."""
    try:
        s=FrozenMessage.from_value(request['snapshot']);c=BehaviorSnapshot.from_value(request['behavior'])
        a=None if request['announcement'] is None else Announcement(FrozenMessage.from_value(request['announcement']))
        cat=bundled_catalog();op=request['operation'];st=request['stimulus']
        before=(s.raw,c.message().raw,cat.spec.raw)
        if op in ('PUBLISH_NEXT_INTENT','NEW_SYSTEM_ENEMY_ACTION'):
            result=publish_intent(s,c,cat).message().value
        elif op in ('RESOLVE_FROZEN_SLOT','OWNER_ENTRY_THEN_RESOLVE'):
            result=resolve_intent(s,c,cat,a).message().value
        elif op=='DRAINED_CHECKPOINT':
            result=propose_phases(s,c,cat,PhaseCheckpoint('fixture:p06:root',st['before_hp'],100)).message().value
        elif op=='VALIDATE_START_SNAPSHOT':
            validate_start_snapshot(s,c,cat);result={'valid':True}
        elif op=='READ_COMMITTED_PREVIEW':
            # P06 has no P14 persisted intent record. Only the immutable record
            # supplied as a fixture is read; no producer/authoritative ACK claimed.
            reads=[a.data.raw for _ in range(st['read_count'])]
            assert len(set(reads))==1
            result={'read_only':True,'announcement':a.value,'new_event_count':0}
        elif op=='LOAD_CONTENT':
            spec=cat.spec.value
            if not st['baseline_skill_available']:
                boss=next(e for e in spec['enemies'] if e['tier']=='BOSS')
                boss['degraded_basic_skill_id']='fixture:missing_baseline'
            Catalog.from_bytes(json.dumps(spec,ensure_ascii=False).encode());result={'valid':True}
        else:
            return {'status':'BLOCKED','reason':UNBOUND.get(op,'UNSUPPORTED_OPERATION')}
        assert before==(s.raw,c.message().raw,cat.spec.raw)
        return {'status':'RETURNED','result':result,'input_bytes_unchanged':True}
    except AiError as exc:
        return {'status':'REJECTED','code':exc.code,'authoritative_state_changed':False}


def compare(row,actual):
    expected=json.loads(row['expected_json']);op=json.loads(row['stimulus_json'])['operation']
    checked=[];unverified=[];failures=[]
    def eq(label,got,want):
        checked.append(label)
        if got!=want:failures.append({'field':label,'expected':want,'actual':got})
    if actual['status']=='REJECTED':
        eq('rejection_code',actual['code'],ALIASES.get(expected['reason'],expected['reason']))
        eq('no_authoritative_write',actual['authoritative_state_changed'],False)
        unverified=['P14_fault_or_rejection_commit','new_event_count','full_engine_result']
    elif actual['status']=='BLOCKED':
        return {'status':'BLOCKED','reason':actual['reason'],'checked_fields':[],'unverified_fields':list(expected),'failures':[]}
    else:
        result=actual['result'];eq('input_bytes_unchanged',actual['input_bytes_unchanged'],True)
        if op=='DRAINED_CHECKPOINT':
            eq('ordered_phase_proposals',[p['to_phase_id'] for p in result['proposals']],expected['phase_proposals'])
            eq('observed_checkpoint_outcome',result['evidence']['observed_outcome'],expected['outcome'])
            eq('phase_still_original',result['evidence']['phase_before'],expected['phase_after'])
            eq('no_authoritative_write',result['authoritative_state_changed'],False)
            if expected['reason']=='REACTIONS_PENDING':eq('reason',result['reason'],'REACTIONS_PENDING')
            unverified=['P14_damage_and_reactions','P14_phase_acceptance']
        elif op=='READ_COMMITTED_PREVIEW':
            eq('read_only',result['read_only'],True)
            eq('frozen_action',result['announcement']['action']['skill_id'],expected['action_id'])
            eq('new_events_from_P16',result['new_event_count'],0)
            unverified=['P14_persisted_preview']
        elif 'action' in result:
            action=result['action'];view=result['view'];candidate=result['behavior_candidate']
            got={'action_id':'NONE' if action is None else action['skill_id'],
                 'intent_id':'NONE' if action is None else action['intent_dictionary_id'],
                 'ordered_target_ids':[] if action is None else action['target_ids'],
                 'preview_base_amount_per_hit':0 if action is None else action['base_amount_per_hit'],
                 'preview_hit_count':0 if action is None else action['hit_count'],
                 'future_release_base_amount':0 if action is None else action['future_release_base_amount'],
                 'rng_draws_delta':result['rng_draws_delta'],'outcome':view['observed_outcome']}
            for field in got:
                eq(field,got[field],expected[field])
            reason=expected['reason']
            if reason=='DOT_TERMINAL_PREEMPTS_RELEASE':reason='TERMINAL_PREEMPTS_ACTION'
            eq('reason',result['reason'],reason)
            e=json.loads(row['input_json'])['enemy']
            after=candidate['proposed_fields'] if candidate else {}
            mapping={'next_state_id':'state_id','heavy_cooldown_after':'heavy_cooldown',
                     'charge_after':'charge','cursor_after':'last_successful_single_target_slot',
                     'entry_wait_pending_after':'entry_wait_pending','degraded_after':'degraded'}
            for ek,ak in mapping.items():
                if ek in expected:
                    fallback=e.get(ak)
                    eq('candidate.'+ak,after.get(ak,fallback),expected[ek])
            if 'charge_ready_slot_after' in expected:
                eq('candidate.charge.ready_slot',after['charge']['ready_slot'],expected['charge_ready_slot_after'])
            if 'charge_target_ids_after' in expected:
                eq('candidate.charge.locked_target_ids',after['charge']['locked_target_ids'],expected['charge_target_ids_after'])
            if 'slot_consumed' in expected:
                eq('candidate.consume_slot',False if candidate is None else candidate['consume_slot'],expected['slot_consumed'])
            if 'rng_state_after' in expected:eq('rng_preserved',result['rng']['state'],expected['rng_state_after'])
            if 'removed_target_ids' in expected:eq('removed_target_ids',view['removed_target_ids'],expected['removed_target_ids'])
            if 'phase_after' in expected:
                eq('phase_not_written',json.loads(row['input_json'])['enemy']['phase_id'],expected['phase_after'])
            unverified=['P14_behavior_candidate_commit','P14_intent_storage','P19_actual_UI']
            for key in ('expected_damage_projection','presentation_fallback','art_release_status','enemy_hp_after','behavior_mode_after'):
                if key in expected:unverified.append(key)
        else:
            failures.append({'field':'unexpected_validation_success','expected':expected,'actual':result})
    return {'status':'AUTHOR_P16_PROJECTION_PASS' if not failures else 'FAIL',
            'checked_fields':checked,'unverified_fields':unverified,'failures':failures}


def run_all():
    results=[];fixtures=[]
    for row in rows():
        operation=json.loads(row['stimulus_json'])['operation']
        if operation in UNBOUND:
            actual={'status':'BLOCKED','reason':UNBOUND[operation]};request=None
        else:
            request=request_for(row);actual=execute_request(request)
        comparison=compare(row,actual)
        result={'case_id':row['case_id'],'scenario':row['scenario_zh'],'operation':operation,
                'layer':'P16_SOURCE_EXPECTATION_PROJECTION_NOT_FULL_P14_COMMIT',**comparison,'actual':actual}
        results.append(result)
        if request is not None:
            fixtures.append({'case_id':row['case_id'],'source_case_sha256':hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
                'input_scope':'EXPLICIT_P06_TO_P13_FIXTURE_PROJECTION','request':request,
                'expected_output':actual,'expected_output_sha256':hashlib.sha256(json.dumps(actual,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                'source_expectation_check':comparison})
    counts={status:sum(r['status']==status for r in results) for status in sorted({r['status'] for r in results})}
    return {'format_version':'P16-P06-PROJECTION/0.1.0','source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            'summary':counts,'results':results},fixtures


if __name__=='__main__':
    report,fixtures=run_all()
    if '--write' in sys.argv:
        (ROOT/'evidence/p06_projection_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        (ROOT/'intent_replay_fixtures.json').write_text(json.dumps({'format_version':'P16-INTENT-REPLAY/0.1.0-isolated',
            'scope':'P16_REAL_EXECUTION_ON_VERSIONED_MOCK_INPUTS_NOT_GAME_INTEGRATION',
            'source_sha256':report['source_sha256'],'fixtures':fixtures},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report['summary']))
    for result in report['results']:
        if result['status']=='FAIL':print(json.dumps(result,ensure_ascii=False))
    sys.exit(1 if report['summary'].get('FAIL') else 0)
