"""Recompute each fixed request; compare full outputs and input-bound digests."""
from pathlib import Path
import sys,json,hashlib,argparse
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from tools.p06_projection import execute_request


def replay(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    if data['format_version']!='P16-INTENT-REPLAY/0.1.0-isolated':raise ValueError('REPLAY_VERSION')
    digest=hashlib.sha256();failures=[]
    for fixture in data['fixtures']:
        actual=execute_request(fixture['request'])
        raw=json.dumps(actual,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()
        actual_sha=hashlib.sha256(raw).hexdigest()
        digest.update(fixture['case_id'].encode()+b'\0'+actual_sha.encode())
        if actual!=fixture['expected_output'] or actual_sha!=fixture['expected_output_sha256']:
            failures.append({'case_id':fixture['case_id'],'actual':actual,'actual_sha256':actual_sha})
    return {'status':'FAIL' if failures else 'AUTHOR_REPLAY_PASS','cases':len(data['fixtures']),
            'execution_digest':digest.hexdigest(),'failures':failures}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--file',type=Path,default=ROOT/'intent_replay_fixtures.json');p.add_argument('--digest-only',action='store_true');a=p.parse_args()
    result=replay(a.file)
    print(result['execution_digest'] if a.digest_only else json.dumps(result,ensure_ascii=False,indent=2))
    sys.exit(0 if not result['failures'] else 1)
