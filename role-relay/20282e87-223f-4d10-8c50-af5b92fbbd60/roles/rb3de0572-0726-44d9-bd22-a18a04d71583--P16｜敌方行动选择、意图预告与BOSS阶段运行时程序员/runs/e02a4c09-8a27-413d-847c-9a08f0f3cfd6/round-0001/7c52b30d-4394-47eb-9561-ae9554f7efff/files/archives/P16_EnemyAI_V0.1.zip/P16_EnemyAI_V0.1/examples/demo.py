"""One enemy slot with real P16 + unmodified P14, and a pure boss proposal."""
from pathlib import Path
import argparse,json,sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from enemy_ai import bundled_catalog,publish_intent,resolve_intent,propose_phases,PhaseCheckpoint
from examples.fixture_inputs import snapshot,context,changed,BOSS
from examples.p14_fixture import make_core,command,DeclaredDeckFixture


def run_demo():
    catalog=bundled_catalog();s=snapshot(battle_phase='PLAYER_READY');c=context(s)
    s,c=changed(s,c,lambda v:v['units'][0].update(shield=4))
    initial_bytes=s.raw;preview=publish_intent(s,c,catalog)
    core,_,adapter=make_core(s,c,announcement=preview.announcement,deck=DeclaredDeckFixture())
    records=[]
    end=command(core,'END_TURN','fixture:demo:end');end_reply=core.submit(end)
    records.append({'channel':'USER','command':end.value,'reply':end_reply.value})
    enemy=command(core,cid='fixture:demo:enemy');reply=core.submit_system(enemy)
    records.append({'channel':'SYSTEM','command':enemy.value,'reply':reply.value})
    retry=core.submit_system(enemy)
    records.append({'channel':'SYSTEM','command':enemy.value,'reply':retry.value})
    assert initial_bytes==s.raw
    damage=[e['data'] for e in reply.value['commit']['events'] if e['event_type']=='DAMAGE_APPLIED']
    final=core.state().value['snapshot']
    boss_snapshot=snapshot(BOSS,hp=30);boss_context=context(boss_snapshot)
    phase=propose_phases(boss_snapshot,boss_context,catalog,PhaseCheckpoint('fixture:checkpoint:80to30',80,10))
    summary={'scope':'ONE_SLOT_ISOLATED_CONTRACT_EXECUTION',
        'actual_modules':['P16 enemy_ai','P14 original battle_core','P13 original codec/schema'],
        'fixture_dependencies':['P17 three-unit initial party','P15 declared END_TURN no-move candidate',
            'P06 provisional enemy content','P16 behavior extension not persisted by P14'],
        'requests':len(records),'commits':len(core.committed_batches()),
        'duplicate_no_op':sum(r['reply']['result']=='DUPLICATE_NO_OP' for r in records),
        'preview_base_damage':preview.action.base_amount_per_hit,'damage_events':damage,
        'hero_hp_before':s.value['units'][0]['hp'],'hero_hp_after':final['units'][0]['hp'],
        'final_revision':final['revision'],'rng_unchanged':final['rng']==s.value['rng'],
        'phase_proposal_order':[p.value['to_phase_id'] for p in phase.proposals],
        'boss_phase_still_original':boss_snapshot.value['boss_states'][0]['current_phase_id'],
        'p14_behavior_commit':'BLOCKED','p14_phase_acceptance':'BLOCKED','game_E2E':'NOT_RUN'}
    return {'version':'P16-DEMO/0.1.0-isolated','summary':summary,
        'initial_snapshot':s.value,'behavior_fixture':c.message().value,'preview':preview.message().value,
        'requests':records,'final_state':core.state().value,'p14_replay':core.export_replay().value(),
        'boss_checkpoint_fixture':{'snapshot':boss_snapshot.value,'behavior':boss_context.message().value,
             'before_hp':80,'trigger_event_seq':10,'root_command_id':'fixture:checkpoint:80to30'},
        'boss_phase_proposal':phase.message().value}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--write',action='store_true');a=p.parse_args();data=run_demo()
    if a.write:
        (ROOT/'examples/demo_execution.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
        (ROOT/'evidence/demo_summary.json').write_text(json.dumps(data['summary'],ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(data['summary'],ensure_ascii=False,indent=2))
