"""Explicit fixture inputs, never production defaults or authoritative commits."""
from dataclasses import replace
import copy
from enemy_ai import BehaviorSnapshot, Charge, BEHAVIOR_VERSION, bundled_catalog
from enemy_ai.types import CONTENT_VERSION, RULES_VERSION, wire, FrozenMessage, EnemyAction
from enemy_ai.planner import announcement_record, _seal

NORMAL='MOCK_P06_ENEMY_001'
ELITE='MOCK_P06_ENEMY_002'
BOSS='MOCK_P06_ENEMY_003'
P1='MOCK_P06_PHASE_1'; P2='MOCK_P06_PHASE_2'; P3='MOCK_P06_PHASE_3'


def snapshot(enemy_id=NORMAL,*,battle_phase='ENEMY_READY',phase_id=None,hp=None,seed=20261028):
    catalog=bundled_catalog(); enemy=catalog.enemy(enemy_id)
    units=[{'unit_id':'H'+str(i+1),'definition_id':'fixture:hero:'+str(i+1),'side':'PLAYER','slot':i,
            'hp':50,'max_hp':50,'shield':0,'statuses':[]} for i in range(3)]
    units.append({'unit_id':'E1','definition_id':enemy_id,'side':'ENEMY','slot':0,
                  'hp':enemy['max_hp'] if hp is None else hp,'max_hp':enemy['max_hp'],
                  'shield':enemy['initial_shield'],'statuses':[]})
    boss_states=[]
    if enemy['tier']=='BOSS':
        boss_states=[{'unit_id':'E1','current_phase_id':phase_id or P1,'proposed_phase_ids':[]}]
    return wire('BattleSnapshot',battle_id='fixture:p16',revision=0,rules_version=RULES_VERSION,
        content_version=CONTENT_VERSION,phase=battle_phase,turn_number=1,energy=3,units=units,
        card_instances=[],zones={'draw':[],'hand':[],'discard':[],'exhaust':[]},
        rng={'algorithm':'xorshift32-v1','initial_seed':seed,'state':seed,'draw_count':0},
        last_event_seq=10,outcome='ONGOING',boss_states=boss_states)


def context(snap,**changes):
    s=snap.value;actor=next(u for u in s['units'] if u['side']=='ENEMY')
    enemy=bundled_catalog().enemy(actor['definition_id'])
    boss=next((b for b in s['boss_states'] if b['unit_id']==actor['unit_id']),None)
    history=() if boss is None else (P1,P2,P3)[:(P1,P2,P3).index(boss['current_phase_id'])+1]
    state=enemy['initial_state_id'] if boss is None else enemy['phase_initial_state_ids'][boss['current_phase_id']]
    values={'schema_version':BEHAVIOR_VERSION,'battle_id':s['battle_id'],'actor_id':actor['unit_id'],
        'revision':s['revision'],'snapshot_sha256':snap.sha256,'enemy_slot':1,'state_id':state,
        'phase_epoch':0 if len(history)<=1 else 1,'heavy_cooldown':0,
        'last_successful_single_target_slot':-1,'charge':None,'entry_wait_pending':False,'degraded':False,
        'phase_committed_ids':history,'targetable_ids':tuple(u['unit_id'] for u in s['units'] if u['side']=='PLAYER'),
        'pending_reactions':0,'graph_available':True}
    values.update(changes);return BehaviorSnapshot(**values)


def changed(snap,ctx,mutator,**behavior_changes):
    value=snap.value;mutator(value);out=FrozenMessage.from_value(value)
    return out,replace(ctx,revision=value['revision'],snapshot_sha256=out.sha256,**behavior_changes)


def project_p06_input(original,stimulus=None):
    """P06 fixture -> P13-shaped snapshot + explicit P16 behavior extension.

    Missing DTO fields are fixture constants: turn=7, last_event_seq=100,
    actor unit id=fixture:actor, no cards/energy. No P06 expected result is read.
    Supplied post-DOT/checkpoint data is input, not execution of P14 damage.
    """
    p=copy.deepcopy(original); st=stimulus or {}; e=p['enemy']
    op=st.get('operation')
    if op=='DRAINED_CHECKPOINT':
        e['hp']=st['after_hp'];p['pending_reactions']=st['after_pending_reactions']
        for i,u in enumerate(p['party']):
            if i>=st['after_alive_player_count']:u['hp']=0
    if op=='OWNER_ENTRY_THEN_RESOLVE':
        e['hp']=st['supplied_after_dot_hp']
        e['statuses']=st.get('supplied_after_dot_statuses',e['statuses'])
    def statuses(items,source):
        return [{'status_instance_id':'fixture:status:'+source+':'+str(i),'status_id':a['status_id'],
                 'source_unit_id':source,'stacks':1,'remaining_triggers':a.get('remaining_owner_turns',1),
                 'insert_order':i} for i,a in enumerate(items)]
    units=[{'unit_id':u['unit_id'],'definition_id':'fixture:hero:'+str(u['formation_slot']),
            'side':'PLAYER','slot':u['formation_slot'],'hp':u['hp'],'max_hp':u['max_hp'],
            'shield':u['shield'],'statuses':[]} for u in p['party']]
    units.append({'unit_id':'fixture:actor','definition_id':e['enemy_id'],'side':'ENEMY','slot':0,
        'hp':e['hp'],'max_hp':e['max_hp'],'shield':e['shield'],'statuses':statuses(e['statuses'],'fixture:actor')})
    for i,u in enumerate(p.get('other_enemies',[])):
        units.append({'unit_id':u['unit_id'],'definition_id':u['enemy_id'],'side':'ENEMY','slot':i+1,
                      'hp':u['hp'],'max_hp':u['max_hp'],'shield':0,'statuses':[]})
    if op=='DRAINED_CHECKPOINT':
        alive=sum(u['side']=='ENEMY' and u['hp']>0 for u in units)
        if alive!=st['after_alive_enemy_count']:
            raise ValueError('P06_ALIVE_COUNT_PROJECTION_MISMATCH')
    s={'contract_version':'YLTT-INTERNAL/0.1.0-isolated','dto_type':'BattleSnapshot',
       'battle_id':p['battle_id'],'revision':p['battle_revision'],'rules_version':RULES_VERSION,
       'content_version':p['content_version'],'phase':p['battle_phase'],'turn_number':7,
       'energy':0,'units':units,'card_instances':[],
       'zones':{'draw':[],'hand':[],'discard':[],'exhaust':[]},
       'rng':{'algorithm':'xorshift32-v1','initial_seed':p['seed'],'state':p['rng_state'],'draw_count':p['rng_draw_count']},
       'last_event_seq':100,'outcome':p['outcome'],
       'boss_states':[] if e['phase_id']=='NONE' else [{'unit_id':'fixture:actor',
           'current_phase_id':e['phase_id'],'proposed_phase_ids':e['phase_proposed_ids']}]}
    msg=FrozenMessage.from_value(s)
    c=BehaviorSnapshot(BEHAVIOR_VERSION,s['battle_id'],'fixture:actor',s['revision'],msg.sha256,
        p['enemy_slot'],e['state_id'],e['phase_epoch'],e['heavy_cooldown'],e['last_successful_single_target_slot'],
        None if e['charge'] is None else Charge.from_value(e['charge']),e['entry_wait_pending'],e['degraded'],
        tuple(e['phase_committed_ids']),tuple(u['unit_id'] for u in p['party'] if u['targetable']),
        p['pending_reactions'],p['phase_graph_present'])
    ann=None
    if p['frozen_intent'] is not None:
        f=p['frozen_intent'];skill=bundled_catalog().skill(f['skill_id'])
        action=EnemyAction(f['skill_id'],f['intent_id'],skill['action_kind'],tuple(f['ordered_target_ids']),
                          f['base_amount_per_hit'],f['hit_count'],skill['future_release_base_amount'])
        record=announcement_record(msg,s,c,bundled_catalog(),action,'NONE').value
        record['content_version']=f['content_version'];record['phase_epoch']=f['phase_epoch']
        ann=_seal(record)
    return msg,c,ann
