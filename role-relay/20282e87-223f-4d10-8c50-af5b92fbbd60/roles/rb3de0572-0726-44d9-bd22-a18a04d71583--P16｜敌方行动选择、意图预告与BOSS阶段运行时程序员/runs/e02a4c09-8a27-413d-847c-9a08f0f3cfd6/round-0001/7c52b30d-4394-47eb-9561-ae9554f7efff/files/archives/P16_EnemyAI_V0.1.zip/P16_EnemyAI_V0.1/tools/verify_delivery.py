"""Verify delivery bytes and hash-bound upstream copies, without editing files."""
from pathlib import Path
import hashlib,csv,json,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
def verify():
    errors=[];count=0
    manifest=ROOT/'delivery_manifest.sha256.tsv'
    if not manifest.is_file():return {'status':'FAIL','errors':['MANIFEST_NOT_FOUND']}
    rows=list(csv.DictReader(manifest.open(encoding='utf-8'),delimiter='\t'))
    names=set()
    for row in rows:
        path=ROOT/row['relative_path'];names.add(row['relative_path'])
        if not path.resolve().is_relative_to(ROOT.resolve()):errors.append('UNSAFE_PATH');continue
        if not path.is_file():errors.append('MISSING:'+row['relative_path']);continue
        b=path.read_bytes();count+=1
        if len(b)!=int(row['size_bytes']) or hashlib.sha256(b).hexdigest()!=row['sha256']:
            errors.append('HASH_OR_SIZE:'+row['relative_path'])
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual!=names|{'delivery_manifest.sha256.tsv'}:
        errors.append('FILE_SET_MISMATCH:'+json.dumps(sorted(actual^(names|{'delivery_manifest.sha256.tsv'}))))
    source=json.loads((ROOT/'evidence/source_input_receipt.json').read_text())
    input_count=0
    for r in source['upstream_files']:
        p=ROOT/r['relative_path'];b=p.read_bytes();input_count+=1
        if len(b)!=r['size_bytes'] or hashlib.sha256(b).hexdigest()!=r['sha256']:
            errors.append('UPSTREAM_COPY_CHANGED:'+r['relative_path'])
    archive_bindings=0
    for archive in sorted((ROOT/'upstream/archives').glob('*.zip')):
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:errors.append('UPSTREAM_ARCHIVE_CRC:'+archive.name)
            role=archive.name[:3]
            for r in source['upstream_files']:
                prefix='upstream/'+role+'/'
                if r['relative_path'].startswith(prefix):
                    relative=r['relative_path'][len(prefix):]
                    member=relative if role=='P06' else archive.stem+'/'+relative
                    if member not in z.namelist():errors.append('UPSTREAM_ARCHIVE_MEMBER_MISSING:'+member);continue
                    if z.read(member)!=(ROOT/r['relative_path']).read_bytes():errors.append('UPSTREAM_ARCHIVE_BYTE_MISMATCH:'+member)
                    archive_bindings+=1
    projection=json.loads((ROOT/'enemy_intent_schema.json').read_text())
    upstream_schema=json.loads((ROOT/'upstream/P13/contracts/internal/internal_dto.schema.json').read_text())
    for k in ('EnemyIntent','PhaseProposal'):
        if projection['$defs'][k]!=upstream_schema['$defs'][k]:errors.append('SHARED_SCHEMA_CHANGED:'+k)
    return {'status':'PASS' if not errors else 'FAIL','manifest_files_verified':count,
        'upstream_copies_verified':input_count,'copies_compared_to_original_archive':archive_bindings,
        'errors':errors,'manifest_self_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest()}
if __name__=='__main__':
    result=verify();print(json.dumps(result,ensure_ascii=False,indent=2));sys.exit(0 if result['status']=='PASS' else 1)
