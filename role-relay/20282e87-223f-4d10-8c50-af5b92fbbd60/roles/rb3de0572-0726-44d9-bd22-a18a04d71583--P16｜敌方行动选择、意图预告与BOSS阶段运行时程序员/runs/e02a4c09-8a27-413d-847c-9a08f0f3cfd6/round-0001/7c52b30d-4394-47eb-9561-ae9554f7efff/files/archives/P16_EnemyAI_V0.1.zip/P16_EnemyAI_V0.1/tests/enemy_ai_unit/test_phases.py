import unittest,copy
from dataclasses import replace
from enemy_ai import bundled_catalog,propose_phases,PhaseCheckpoint,Catalog,AiError
from examples.fixture_inputs import snapshot,context,changed,BOSS,P1,P2,P3


class PhaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.cat=bundled_catalog()

    def case(self,before,after,phase=P1,**kwargs):
        s=snapshot(BOSS,phase_id=phase,hp=after);c=context(s,**kwargs)
        return s,c,propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',before,10))

    def test_integer_thresholds(self):
        for before,after,phase,expected in [(76,75,P1,[P2]),(77,76,P1,[]),(38,37,P2,[P3]),(39,38,P2,[]),(80,30,P1,[P2,P3])]:
            with self.subTest(before=before,after=after):
                _,_,p=self.case(before,after,phase)
                self.assertEqual(expected,[x.value['to_phase_id'] for x in p.proposals])

    def test_two_thresholds_one_wait_no_extra_action(self):
        s,c,p=self.case(80,30);before=s.raw
        self.assertEqual(2,len(p.proposals));req=p.evidence.value['acceptance_requirements']
        self.assertEqual((1,1,0,0),(req['phase_epoch_increments'],req['entry_wait_count_if_accepted'],req['extra_actions'],req['summons']))
        self.assertEqual(P3,req['final_phase_id']);self.assertEqual(before,s.raw)
        self.assertEqual(P1,s.value['boss_states'][0]['current_phase_id'])

    def test_repeated_phase_plan_same_bytes(self):
        s,c,p=self.case(80,30)
        self.assertEqual(p.message().raw,propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10)).message().raw)

    def test_phase_identity_does_not_change_with_retry_command(self):
        s,c,p=self.case(80,30)
        other=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:retry',80,10))
        self.assertEqual([x.value['proposal_id'] for x in p.proposals],[x.value['proposal_id'] for x in other.proposals])

    def test_already_pending_phase_not_reproposed(self):
        s=snapshot(BOSS,hp=30);c=context(s)
        s,c=changed(s,c,lambda v:v['boss_states'][0]['proposed_phase_ids'].append(P2))
        p=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',74,10))
        self.assertEqual([P3],[x.value['to_phase_id'] for x in p.proposals])

    def test_all_pending_no_repeated_phase_or_wait(self):
        s=snapshot(BOSS,hp=30);c=context(s)
        s,c=changed(s,c,lambda v:v['boss_states'][0].update(proposed_phase_ids=[P2,P3]))
        p=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10))
        self.assertEqual((),p.proposals);self.assertEqual(0,p.evidence.value['acceptance_requirements']['entry_wait_count_if_accepted'])

    def test_death_precedes_phase(self):
        _,_,p=self.case(80,0)
        self.assertEqual((),p.proposals);self.assertEqual('WIN',p.evidence.value['observed_outcome'])

    def test_dead_boss_while_other_enemy_alive_no_phase(self):
        s=snapshot(BOSS,hp=0);c=context(s)
        def mut(v):
            v['units'].append({'unit_id':'E2','definition_id':'MOCK_P06_ENEMY_001','side':'ENEMY','slot':1,'hp':24,'max_hp':24,'shield':0,'statuses':[]})
        s,c=changed(s,c,mut);p=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10))
        self.assertEqual('ACTOR_DEAD',p.reason);self.assertEqual((),p.proposals)

    def test_both_sides_dead_observed_draw(self):
        s=snapshot(BOSS,hp=0);c=context(s)
        s,c=changed(s,c,lambda v:[u.update(hp=0) for u in v['units'] if u['side']=='PLAYER'])
        p=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10))
        self.assertEqual('DRAW',p.evidence.value['observed_outcome']);self.assertEqual((),p.proposals)

    def test_reactions_pending_defers_before_win(self):
        _,_,p=self.case(80,0,pending_reactions=1)
        self.assertEqual(('DEFER','REACTIONS_PENDING',()),(p.disposition,p.reason,p.proposals))

    def test_healing_recross_never_regresses(self):
        _,_,p=self.case(80,70,P2)
        self.assertEqual((),p.proposals)

    def test_terminal_phase_no_successor(self):
        _,_,p=self.case(30,10,P3);self.assertEqual((),p.proposals)

    def test_no_cross_from_equal_threshold(self):
        _,_,p=self.case(75,74);self.assertEqual((),p.proposals)

    def test_transient_damage_ignored_final_checkpoint_only(self):
        _,_,p=self.case(80,80);self.assertEqual((),p.proposals)

    def test_unknown_phase_history_gap_rejected(self):
        s=snapshot(BOSS);c=context(s);s,c=changed(s,c,lambda v:v['boss_states'][0].update(proposed_phase_ids=[P3]))
        with self.assertRaisesRegex(AiError,'PHASE_PROPOSAL_GAP'):
            propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10))

    def test_future_trigger_sequence_rejected(self):
        s=snapshot(BOSS);c=context(s)
        with self.assertRaisesRegex(AiError,'TRIGGER_EVENT_NOT_OBSERVED'):
            propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,11))

    def test_missing_graph_recommendation_no_proposals(self):
        cat=Catalog.from_bytes(self.cat.spec.raw);s=snapshot(BOSS,hp=30);c=context(s)
        p=propose_phases(s,c,cat,PhaseCheckpoint('fixture:root',80,10))
        self.assertEqual('DEGRADATION_RECOMMENDATION',p.disposition);self.assertEqual((),p.proposals)
        self.assertTrue(p.evidence.value['degradation_recommendation']['keep_current_phase'])

    def test_persistent_degraded_mode_never_reenters_graph(self):
        s=snapshot(BOSS,hp=30);c=context(s,state_id='DEGRADED_STRIKE',degraded=True)
        p=propose_phases(s,c,self.cat,PhaseCheckpoint('fixture:root',80,10))
        self.assertEqual(('NO_OP','DEGRADED_MODE'),(p.disposition,p.reason))
