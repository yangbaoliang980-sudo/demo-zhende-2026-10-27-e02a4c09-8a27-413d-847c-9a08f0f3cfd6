"""Record the actual command, source bytes, stdout/stderr and exit status."""
import hashlib,json,os,pathlib,subprocess,sys,time,zipfile,platform

ROOT=pathlib.Path(__file__).resolve().parents[1]
def record(name,command):
    out=ROOT/'evidence/runs'/name; out.mkdir(parents=True,exist_ok=False)
    paths=[]
    for base in ('enemy_ai','tests','examples','tools','upstream'):
        paths.extend(p for p in (ROOT/base).rglob('*') if p.is_file() and 'archives' not in p.parts and '__pycache__' not in p.parts)
    for p in (ROOT/'intent_replay_fixtures.json',ROOT/'boss_transition_cases.tsv'):
        if p.exists(): paths.append(p)
    bindings=[]
    with zipfile.ZipFile(out/'executed_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(paths)):
            b=p.read_bytes();rel=p.relative_to(ROOT).as_posix();z.writestr(rel,b)
            bindings.append({'path':rel,'size_bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    start=time.time()
    completed=subprocess.run(command,cwd=ROOT,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    (out/'stdout.log').write_bytes(completed.stdout);(out/'stderr.log').write_bytes(completed.stderr)
    receipt={'command':command,'cwd':str(ROOT),'exit_code':completed.returncode,'started_utc_epoch':start,
        'duration_seconds':round(time.time()-start,6),'python':sys.version,'platform':platform.platform(),
        'source_bindings':bindings,'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(),
        'stderr_sha256':hashlib.sha256(completed.stderr).hexdigest(),
        'executed_sources_zip_sha256':hashlib.sha256((out/'executed_sources.zip').read_bytes()).hexdigest()}
    (out/'run.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'name':name,'exit_code':completed.returncode,'duration_seconds':receipt['duration_seconds'],'source_files':len(bindings)}))
    if completed.stdout: print(completed.stdout.decode(errors='replace')[-7000:])
    if completed.stderr: print(completed.stderr.decode(errors='replace')[-10000:])
    return completed.returncode

if __name__=='__main__':
    sys.exit(record(sys.argv[1],sys.argv[2:]))
