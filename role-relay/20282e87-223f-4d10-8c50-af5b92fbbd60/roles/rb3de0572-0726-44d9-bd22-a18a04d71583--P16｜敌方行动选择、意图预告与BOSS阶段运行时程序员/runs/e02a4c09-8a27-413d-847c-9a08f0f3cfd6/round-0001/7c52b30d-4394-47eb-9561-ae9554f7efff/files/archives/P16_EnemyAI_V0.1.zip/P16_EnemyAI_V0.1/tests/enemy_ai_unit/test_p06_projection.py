"""Source truth rows are expectations, not generated from the selector."""
import unittest,json
from tools.p06_projection import rows,request_for,execute_request,compare,UNBOUND

class P06ProjectionTests(unittest.TestCase):pass

def case_test(row):
    def test(self):
        actual=execute_request(request_for(row));comparison=compare(row,actual)
        self.assertEqual('AUTHOR_P16_PROJECTION_PASS',comparison['status'],comparison['failures'])
    return test

for row in rows():
    if json.loads(row['stimulus_json'])['operation'] not in UNBOUND:
        setattr(P06ProjectionTests,'test_'+row['case_id'].replace('-','_'),case_test(row))
