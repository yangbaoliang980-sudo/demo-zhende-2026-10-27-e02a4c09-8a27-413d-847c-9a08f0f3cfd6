# P26 Candidate A — 隔离视觉样本

这是 P26 单角色候选视觉草案，不是正式角色注册、生产资源或审定通过的美术资产。

## 先看
1. `docs/P26_delivery_report.md`
2. `docs/character_brief.md`
3. `exports/candidate_a_stand_1024x1536.png`
4. `evidence/candidate_a_key_parts_review.png`
5. `exports/portrait_export_manifest.json`

## 主要源与导出
- `source/candidate_a_master_layers.svg`：可编辑 SVG 矢量主源，10 个命名组。
- `source/candidate_a_layers_interchange.ora`：从 10 个组栅格化生成的 ORA 互通副本；不是原生 Krita 工程。
- `exports/candidate_a_stand_master_2048x3072.png`：完整母版渲染。
- `exports/`：透明立绘、头像、半身审查图、P23 W14/W08 静态裁切、表情变体、小窗缩略试验。
- `docs/portrait_export_manifest.json`：每张导出实际大小、尺寸、SHA-256、alpha 统计、源文件绑定。

## 状态边界
- P04 正式角色原型未收到：身份、姓名、职业、性格、年龄等均不擅自定稿。
- P22 正式 content ID 未收到：本包 asset_id 仅为本地临时标识。
- P13 没有 P26 生产路径映射或写入授权：本包仅存在于独立交付目录，不写入真实工程。
- P37/P25/P30/P35 独立审核/导入/流程签字均未执行。
- 本轮仅一个候选样本；不得扩展三人量产。

## 本地结构检查
解压后运行：
```bash
python -B tools/verify_delivery.py
```
脚本只验证包内清单、PNG 解码/尺寸/alpha、SVG XML、ORA ZIP 结构和哈希，不代替绘图软件打开、艺术审查、许可审核或引擎导入。
