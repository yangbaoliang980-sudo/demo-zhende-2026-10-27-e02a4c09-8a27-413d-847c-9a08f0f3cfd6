# 素材来源与制作记录

- 本轮原创图形由本次会话内手工编写的 SVG 矢量路径、形状和渐变构成；未导入第三方角色图片、贴图、画笔、模型或外部字体。
- PNG 由 CairoSVG 渲染，裁切/缩放/透明合成由 Pillow 处理；工具版本/环境记录见 `tool_environment.json`。
- `candidate_a_master_layers.svg` 是本轮可编辑矢量主源，分为 10 个命名组；每组另行栅格化为同画布 PNG，用于 ORA 互通。
- `candidate_a_layers_interchange.ora` 是由上述分组 PNG 组成的栅格层互通副本，不等于 Krita 原生绘画工程；原生应用打开/修改/重导出均 NOT_RUN。
- 无外部素材不等于已获 P37 许可签字；P37 独立审核 NOT_RUN。
- 不使用生成模型的第三方训练数据声明或外部参考图授权主张；本轮图形从零编写，但仍需 P37 依据发行用途复核记录。
