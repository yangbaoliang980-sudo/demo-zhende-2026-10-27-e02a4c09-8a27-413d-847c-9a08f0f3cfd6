#!/usr/bin/env python3
import hashlib, json, sys, zipfile, xml.etree.ElementTree as ET
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/"delivery_manifest.json"
data=json.loads(manifest.read_text(encoding="utf-8"))
errors=[]
for item in data["files"]:
    p=ROOT/item["relative_path"]
    if not p.is_file():
        errors.append(f"MISSING {item['relative_path']}"); continue
    b=p.read_bytes()
    if len(b)!=item["size_bytes"]: errors.append(f"SIZE {item['relative_path']}")
    if hashlib.sha256(b).hexdigest()!=item["sha256"]: errors.append(f"SHA {item['relative_path']}")
for p in (ROOT/"exports").glob("*.png"):
    try:
        with Image.open(p) as im:
            im.verify()
        with Image.open(p) as im:
            if im.mode!="RGBA": errors.append(f"MODE {p.relative_to(ROOT)} {im.mode}")
            if im.getchannel("A").getextrema()[0]==255 and im.getchannel("A").getextrema()[1]==255:
                errors.append(f"OPAQUE_ONLY {p.relative_to(ROOT)}")
    except Exception as e: errors.append(f"PNG {p.relative_to(ROOT)} {e}")
try:
    ET.parse(ROOT/"source"/"candidate_a_master_layers.svg")
except Exception as e: errors.append(f"SVG {e}")
ora=ROOT/"source"/"candidate_a_layers_interchange.ora"
try:
    with zipfile.ZipFile(ora) as z:
        names=z.namelist()
        if names[0]!="mimetype": errors.append("ORA mimetype not first")
        if z.read("mimetype")!=b"image/openraster": errors.append("ORA mimetype invalid")
        stack=ET.fromstring(z.read("stack.xml"))
        layers=stack.find("stack").findall("layer")
        if len(layers)!=10: errors.append(f"ORA layer count {len(layers)}")
        for layer in layers:
            if layer.attrib["src"] not in names: errors.append(f"ORA missing {layer.attrib['src']}")
        if "mergedimage.png" not in names or "Thumbnails/thumbnail.png" not in names: errors.append("ORA merged/thumbnail missing")
except Exception as e: errors.append(f"ORA {e}")
if errors:
    print("\n".join(errors)); sys.exit(1)
print(f"PASS: {len(data['files'])} manifest files; PNG decode/mode/alpha; SVG XML; ORA structure.")
