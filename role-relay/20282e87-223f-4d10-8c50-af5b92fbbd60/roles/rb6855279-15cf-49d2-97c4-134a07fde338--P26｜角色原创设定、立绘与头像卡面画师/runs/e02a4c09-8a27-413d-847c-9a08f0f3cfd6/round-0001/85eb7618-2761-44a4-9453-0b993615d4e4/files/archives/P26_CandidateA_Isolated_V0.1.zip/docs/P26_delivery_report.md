# P26 交付报告 — 单角色原创视觉候选样本

**任务：** `P26-PRE-S03-SAMPLE-001`  
**版本：** `P26-CANDIDATE-A/0.1.0`  
**风格基线：** `P25-ART-BIBLE/0.1.0`  
**交付状态：** `ISOLATED_VISUAL_DRAFT_DELIVERED / CANONICAL_BINDING_BLOCKED`  
**正式角色资产数：** 0  
**量产许可：** false

## 1. 执行范围与边界

本轮实际生成一个 Candidate A 单角色视觉草案及其矢量源、分层互通副本、透明导出和审查裁切。未创建子角色，未修改真实游戏工程，未执行跨模块整合。

本图不是 P04 已批准角色身份，也不把历史 UI 中的“璃火/千澄/羽铃”等占位示例挪作正式设定。候选代号、文件名和临时 asset_id 仅用于本隔离包内部追踪，不能作为 P22 canonical ID。

本轮未制作三人量产图；遵守 P25 先一人样本审定再扩大范围的门禁。

## 2. 已读取并核验的上游输入

- GitHub 岗位职责仓库：`yangbaoliang980-sudo/juesedemo-2026-10-27-01b55988-26e9-4763-a710-e5ba81986b3c`，检查提交 `8c370d731c323f86ff19642f4cc73f818498f641`。
- V6 岗位职责文件 blob：`5b892ce93a38aa900fcec95d890e57f809a9c562`。P26 明确要求 PREART 后先做单人样本，三人候选扩展需经单人审定；独占设计路径为 `art/characters/source/**` 与 `art/characters/exports/**`，但路径必须先由 P13 映射。
- P25 `style_bible.md`：SHA-256 `b89e7779c11cea6b50a68a7922b2217178655fb8f0226200cc774d09c98d01b4`。
- P23 W14 角色档案线框：SHA-256 `a06c67b85437b0aadf63025d91b53a97c40520eed5088e65442dd4a8a3efd13d`。
- P23 W08 编队线框：SHA-256 `ac7181e6d4f9472c17e523aad52fa2218c5bf52958d484aee27e32d26783205f`。
- P13 路径映射证据：SHA-256 `388113be16ac8cd4aa84e49cf2a563c2c12f738a528a0d81ba434f5ec61b1d6f`。其状态为 `ISOLATED_MAPPING_VERIFIED_TARGET_BLOCKED`；真实游戏仓库/提交/引擎/目标 OS 均为 null，生产写授权 false，且映射中没有 P26 生产路径条目。
- 三个用户上传 relay-materials 外层包的 manifest 逐条大小与 SHA-256 校验均匹配；嵌套 P25/P23/P24 交付包已解压检查。详细证据见 `docs/source_input_receipt.json`。

## 3. 真实缺失的关键输入

| 缺失项 | 当前状态 | 责任方/所需工件 |
|---|---|---|
| 正式角色原型 | BLOCKED | P04 `character_skeleton.json` 或固定版本角色原型及 SHA-256 |
| 正式角色/资产 ID | BLOCKED | P22 canonical `character_id`、各 variant `asset_id` 注册回执 |
| P26 生产路径及白名单 | BLOCKED | P13 对 P26 source/exports 的 actual_path_mapping 与授权 |
| 素材来源独立复核 | NOT_RUN | P37 对本版 SVG/PNG/ORA 的来源/许可回执 |
| 美术正式审定 | NOT_RUN | P25 对本版原稿与裁切逐项审查 |
| 实际引擎导入 | NOT_RUN | P30 同源导入及 runtime_path/import_version 证据 |
| 独立工程流程审查 | NOT_RUN | P35 对本版交付回执和证据链审查 |

因此本轮只能交付**未绑定正式身份的隔离视觉草案**，不能声称 P26 正式样本门禁通过。

## 4. 本轮实体成果

### 可编辑源与分层

- `source/candidate_a_master_layers.svg`：2048×3072 母版尺寸、SVG 矢量组结构；10 个命名组：`00_guides`、`10_sketch`、`20_back_hair`、`30_body_skin`、`40_outfit`、`50_face`、`60_front_hair`、`70_hands_props`、`80_light_fx`、`90_background`。
- `source/candidate_a_layers_interchange.ora`：按上述组逐组栅格化的 ORA 互通副本，含 `mimetype`、`stack.xml`、10 个 layer PNG、`mergedimage.png` 和 thumbnail。
- `source/layers.json`：层名、可见性与源/互通关系。
- `source/*.png`：同画布分组渲染，用于 ORA 互通；不冒充原生绘画软件的笔刷/蒙版工程。

### 导出与审查

- 2048×3072 完整母版渲染。
- 1024×1536 透明立绘审查导出。
- 512×512 独立头像，另附 128×128、64×64 缩略图检查。
- 768×1024 半身审查图（不是手牌插画绑定）。
- 576×360 W14 档案裁切；576×236 W08 编队裁切。
- 156×184 小窗缩略辨识试验（仅视觉研究，不是 P24 敌方素材）。
- 同源平静表情变体。
- 深/浅/棋盘边缘检查图与关键部位联系表。
- `exports/portrait_export_manifest.json` 逐件记录实际文件大小、SHA-256、尺寸、alpha 统计、源文件 SHA 和临时 asset_id。

P23 的 W14/W08 坐标来自静态线框。它们不等于运行时合同；P30 未受理导入，P22 未注册 ID。P24 的 236×174 手牌框没有批准的插画孔位，本轮没有把 3:4 人物图硬塞进手牌框。

## 5. 风格与自检结论

采用 P25 的墨紫、奶白、冷紫阴影与哑金点缀，左上主光、低纹理布料、二维线稿与简化明暗。视觉样本有清楚的角色大轮廓、正面脸部、服装分区与手持小型道具。

**限制：** 本版是可编辑矢量构图草案，不是精修商业立绘。发型体块、手指/握持接点、服装褶皱、头肩结构仍需要画师级深化。缩略图/PNG 技术检查不能替代 P25 审美判断。

本轮机器检查覆盖 SVG XML、PNG 解码/尺寸/alpha、ORA 容器成员、文件哈希与导出—源引用。原生绘图应用打开、切换层、修改眉眼/发色/服装色并重新导出：`NOT_RUN`。不得把 ORA 中栅格化的分组层误称为已验证的 Krita 原生绘画工程。

## 6. 验收状态

| 验收层级 | 状态 | 说明 |
|---|---|---|
| 隔离包静态完整性/哈希检查 | 待本包脚本实跑 | 见 `tools/verify_delivery.py` |
| PNG 实际解码、尺寸、alpha | 作者静态检查 | 见导出清单和复验日志 |
| 原生绘图软件打开/局部编辑重导出 | NOT_RUN | 无应用 UI 证据 |
| P04 角色身份一致性 | BLOCKED | 原型缺失 |
| P22 ID 注册 | BLOCKED | canonical ID 未收到 |
| P25 审美审定 | NOT_RUN | 等待 P25 |
| P37 来源/许可复核 | NOT_RUN | 等待 P37 |
| P30 实际资源导入 | NOT_RUN | 等待 P30 |
| P35 独立流程审查 | NOT_RUN | 等待 P35 |
| 游戏运行/单元/契约/真机/E2E/Anki | NOT_RUN | P26 不负责且未执行 |
| 三人批量制作 | BLOCKED | 单人样本尚未获批，P01 数量记录缺失 |

## 7. 下游交接

- **P04/P22：** 补齐身份原型和正式 ID，决定是否接受本候选视觉方向。
- **P25：** 对本版同源源文件、表情、头肩/手部结构、裁切和材质进行审美复核；P26 按意见修订新版本，不覆盖旧 SHA。
- **P37：** 对本版来源与许可独立签核。
- **P13：** 只有真实工程与 P26 实际路径/白名单明确后，才能考虑生产落位。
- **P30：** 对规定格式、alpha、导入设置、runtime path 和资源引用进行实际导入检查。
- **P35：** 独立审查同版交付证据。

未对 GitHub 仓库写入或修改任何文件；按接力台配置交由本轮附件归档。没有宣称跨岗位集成、游戏内运行或正式发布。
