"""Check packaged original bytes. No network, source edits or acceptance claims."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]


def run():
    receipt = json.loads((ROOT/'source_input_receipt.json').read_text(encoding='utf-8'))
    rows = []; failures = []
    for row in receipt['copied_inputs']:
        p = ROOT/row['package_path']
        if not p.is_file():
            failures.append({'path': row['package_path'], 'error': 'MISSING'}); continue
        raw = p.read_bytes(); digest = hashlib.sha256(raw).hexdigest()
        ok = len(raw) == row['size_bytes'] and digest == row['sha256']
        rows.append({'path': row['package_path'], 'sha256': digest, 'status': 'PASS' if ok else 'FAIL'})
        if not ok: failures.append(rows[-1])
    paths = {'v6_roles.txt': 'upstream/V6/v6_roles.txt',
             'p17_archive_manifest.json': 'evidence/github/p17_archive_manifest.json'}
    for row in receipt['github']['exact_byte_evidence']:
        raw = (ROOT/paths[row['filename']]).read_bytes()
        blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        if blob != row['github_blob_sha1']:
            failures.append({'path': paths[row['filename']], 'error': 'GITHUB_BLOB_MISMATCH'})
    manifest = json.loads((ROOT/paths['p17_archive_manifest.json']).read_text(encoding='utf-8'))
    p17 = next(x for x in manifest['materials']['assets'] if x['name'] == 'P17_CharacterPartyWallet_V0.1.zip')
    if (p17['hash'], p17['size']) != (receipt['github']['p17_archive_sha256'], receipt['github']['p17_archive_size_bytes']):
        failures.append({'error': 'FIXED_P17_ARCHIVE_BINDING_MISMATCH'})
    return {'status': 'PASS' if not failures else 'FAIL', 'copied_inputs_checked': len(rows),
            'github_original_blobs_checked': 2, 'errors': failures, 'files': rows,
            'scope': 'PACKAGED_BYTES_AND_RECEIVED_FIXED_COMMIT_BINDING_NOT_NEW_NETWORK_FETCH'}


if __name__ == '__main__':
    result = run(); print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
