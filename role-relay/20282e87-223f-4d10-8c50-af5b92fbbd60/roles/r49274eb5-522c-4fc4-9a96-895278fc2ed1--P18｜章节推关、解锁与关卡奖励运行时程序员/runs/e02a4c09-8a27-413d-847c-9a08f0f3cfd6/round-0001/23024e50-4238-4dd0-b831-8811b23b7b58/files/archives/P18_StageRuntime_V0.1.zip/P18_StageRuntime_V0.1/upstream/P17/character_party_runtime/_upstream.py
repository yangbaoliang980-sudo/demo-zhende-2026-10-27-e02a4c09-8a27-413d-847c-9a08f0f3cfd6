"""Locate the unmodified P13 isolated contract implementation bundled as evidence."""
from pathlib import Path
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
P13_ROOT = PACKAGE_ROOT / 'sources/P13'
_path = str(P13_ROOT / 'runtime/framework')
if _path not in sys.path:
    sys.path.insert(0, _path)

