#!/usr/bin/env python3
"""P04 isolated content validator. NEVER a P17 wallet or P21 persistence implementation.

Only the stdlib. Run from any working directory; reads immutable P03 snapshots
included for repeatable offline evidence, and does not mutate source material.
"""
from __future__ import annotations
import csv
from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]  # delivery/ (here is content/characters)
P03 = ROOT / 'evidence' / 'readonly_p03'

class ValidationError(Exception):
    pass

class Probe:
    def __init__(self):
        self.count = 0
        self.negatives = 0
        self.detailed = {}

    def yes(self, condition, description):
        self.count += 1
        if not condition:
            raise ValidationError(description)

    def expect(self, actual, expected, description):
        self.yes(actual == expected, f'{description}: expected={expected!r} got={actual!r}')

    def neg(self, actual, expected, description):
        self.expect(actual, expected, description)
        self.negatives += 1


def data_json(p):
    return json.loads(p.read_text(encoding='utf-8'))


def data_tsv(p):
    with p.open('r', encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f, delimiter='\t'))


def sha256(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def validate_party(ordered, owned, lookup):
    if not isinstance(ordered, list):
        return 'E_PARTY_PAYLOAD_TYPE'
    if len(ordered) != 3:
        return 'E_PARTY_SIZE'
    if any(not isinstance(v, str) or not v for v in ordered):
        return 'E_CHARACTER_ID_TYPE'
    if len(set(ordered)) != len(ordered):
        return 'E_PARTY_DUPLICATE'
    if any(v not in lookup for v in ordered):
        return 'E_CHARACTER_NOT_FOUND'
    if any(v not in owned for v in ordered):
        return 'E_CHARACTER_NOT_OWNED'
    return 'OK'


def validate_equipment(items, enabled=False):
    if not isinstance(items, list) or any(not isinstance(x,str) or not x for x in items):
        return 'E_EQUIPMENT_PAYLOAD_TYPE'
    if len(set(items)) != len(items):
        return 'E_EQUIPMENT_DUPLICATE'
    if not enabled:
        return 'E_FEATURE_DISABLED'
    return 'OK'


def derive_stats(ch, level):
    if not isinstance(level, int) or isinstance(level, bool) or level < 1 or level > ch['max_level_fixture']:
        raise ValidationError('E_INVALID_LEVEL')
    base, step = ch['base_stats'],ch['per_level_growth']
    return {k:base[k]+(level-1)*step[k] for k in base}


def fingerprint(cmd):
    return hashlib.sha256(json.dumps(cmd, ensure_ascii=False, sort_keys=True,
        separators=(',',':')).encode('utf-8')).hexdigest()


def mock_action(state, cmd, seen, events, catalog, costs):
    """Pure offline fixture transition, not production business logic.
    Atomicity simulated via working copy; every reject returns ORIGINAL state.
    Receipts are separate fixture-only dictionaries, not P21 save schema.
    """
    cmd_id = cmd.get('command_id')
    if not isinstance(cmd_id,str) or not cmd_id:
        return 'E_COMMAND_ID_TYPE',state
    fp = fingerprint(cmd)
    if cmd_id in seen:
        if seen[cmd_id] == fp:
            return 'DUPLICATE_NO_OP',state
        return 'E_COMMAND_ID_COLLISION',state
    action = cmd.get('action')
    if action == 'SERIALIZE_JSON_ROUNDTRIP_ASSERT':
        return ('OK' if json.loads(json.dumps(state,ensure_ascii=False))==state else 'E_SERIALIZATION_MISMATCH'),state
    work = deepcopy(state)
    owned = work['owned_character_ids']; party = work['party_ordered_ids']
    progress = work['character_progress']; wallet = work['wallet']
    token='MOCK_P04_TRAINING_TOKEN'
    event = cmd.get('event_identity')
    if action in ('ACQUIRE','GRANT_TOKEN','GRANT_XP'):
        if not isinstance(event,str) or not event:
            return 'E_REWARD_EVENT_ID_REQUIRED',state
        if event in events:
            return 'DUPLICATE_NO_OP',state
    if action == 'ACQUIRE':
        target = cmd.get('target')
        if target not in catalog:
            return 'E_CHARACTER_NOT_FOUND',state
        if target in owned:
            return 'E_CHARACTER_ALREADY_OWNED',state
        owned.append(target)
        progress[target]={'level':1,'xp_total':0,'skill_rank':1}
    elif action == 'GRANT_TOKEN':
        v=cmd.get('delta')
        if not isinstance(v,int) or isinstance(v,bool) or v<=0:
            return 'E_REWARD_AMOUNT_INVALID',state
        wallet[token] += v
    elif action == 'GRANT_XP':
        target=cmd.get('target'); v=cmd.get('delta')
        if target not in catalog:
            return 'E_CHARACTER_NOT_FOUND',state
        if target not in owned:
            return 'E_CHARACTER_NOT_OWNED',state
        if not isinstance(v,int) or isinstance(v,bool) or v<=0:
            return 'E_REWARD_AMOUNT_INVALID',state
        progress[target]['xp_total'] += v
    elif action == 'SET_PARTY':
        ordered = cmd.get('ordered_ids')
        res = validate_party(ordered,set(owned),catalog)
        if res!='OK':return res,state
        work['party_ordered_ids']=list(ordered)
    elif action in ('UPGRADE_LEVEL','UPGRADE_SKILL'):
        target=cmd.get('target')
        if target not in catalog:
            return 'E_CHARACTER_NOT_FOUND',state
        if target not in owned:
            return 'E_CHARACTER_NOT_OWNED',state
        prog=progress[target]
        if action=='UPGRADE_LEVEL':
            cur=prog['level']; nxt=cmd.get('to_level')
            if cur>=catalog[target]['max_level_fixture']:
                return 'E_LEVEL_CAP',state
            if cmd.get('from_level')!=cur or nxt!=cur+1:
                return 'E_LEVEL_STEP_INVALID',state
            k=(target,'LEVEL',str(cur),str(nxt))
            record=costs.get(k)
            if record is None:
                return 'E_COST_RECORD_NOT_FOUND',state
            if prog['xp_total']<int(record['requires_xp_total']):
                return 'E_XP_INSUFFICIENT',state
        else:
            cur=prog['skill_rank']; nxt=cmd.get('to_rank')
            if cur>=catalog[target]['skill']['skill_rank_max_fixture']:
                return 'E_SKILL_CAP',state
            if cmd.get('from_rank')!=cur or nxt!=cur+1:
                return 'E_SKILL_STEP_INVALID',state
            k=(target,'SKILL',str(cur),str(nxt))
            record=costs.get(k)
            if record is None:
                return 'E_COST_RECORD_NOT_FOUND',state
            if prog['level']<int(record['requires_character_level']):
                return 'E_SKILL_LEVEL_GATED',state
        cost=int(record['spend_amount'])
        if cmd.get('wallet_spend')!=cost:
            return 'E_COST_MISMATCH',state
        if wallet[token] < cost:
            return 'E_WALLET_INSUFFICIENT',state
        wallet[token] -= cost
        if action=='UPGRADE_LEVEL':
            prog['level']=nxt
        else:
            prog['skill_rank']=nxt
    elif action == 'EQUIP':
        return validate_equipment(cmd.get('equipment_ids'),False),state
    else:
        return 'E_UNKNOWN_ACTION',state
    work['revision'] += 1
    seen[cmd_id]=fp
    if event is not None:
        events.add(event)
    return 'OK',work


def main():
    p=Probe()
    m=data_json(HERE/'character_skeleton.json')
    life=data_json(HERE/'character_lifecycle_fixtures.json')
    rows=data_tsv(HERE/'progression_costs.tsv')
    contrib=data_tsv(HERE/'character_deck_contribution.tsv')
    fields=data_tsv(HERE/'character_field_dictionary.tsv')
    cases=data_tsv(HERE/'character_cases.tsv')
    p03=data_json(P03/'card_catalog.json')
    pool=data_tsv(P03/'character_card_pool.tsv')
    decks=data_json(P03/'deck_build_fixtures.json')

    p.expect(m['producer'],'P04','correct producer')
    p.expect(m['format_version'],'P04-SKELETON-0.1.0-draft','version')
    p.expect(m['party_constraints']['required_active_slots'],3,'three active slots')
    p.yes(not m['character_count_is_approved_mvp'],'3 prototype count not frozen')
    for g in ['P13_actual_path_mapping','P22_content_id_registry_and_schema','P05_economic_balance','P08_learning_reward_policy']:
        p.expect(m['contract_state'][g],'BLOCKED',f'{g} still blocked')
    p.expect(sha256(P03/'card_catalog.json'),m['upstream_sha256']['P03_card_catalog'],'readonly P03 exact source sha')
    p.expect(sha256(P03/'character_card_pool.tsv'),m['upstream_sha256']['P03_character_card_pool'],'readonly P03 pool exact source sha')
    p.expect(len(m['characters']),3,'3 candidate structures')
    p.expect(len(rows),21,'21 acquisition, level, skill cost rows')
    p.expect(len(contrib),7,'four commons, three signature links')
    p.expect(len(fields),19,'field dictionary coverage')
    p.expect(len(cases),28,'positive and negative cases are recorded')
    char_ids=[c['character_id'] for c in m['characters']]
    p.yes(len(set(char_ids))==3,'unique P04 local IDs')
    charmap={x['character_id']:x for x in m['characters']}
    p.expect(set(c['role_code'] for c in m['characters']),{'ATTACK','DEFENSE','HEAL'},'three role archetypes')
    p.expect(m['stat_schema']['scaling_boundary'].startswith('fields do not affect'),True,'stat integration intentionally blocked')
    p.expect(set(x['case_id'] for x in cases).__len__(),28,'case IDs unique')
    p.expect(len({x['row_id'] for x in rows}),len(rows),'cost row ids unique')
    p.expect(set(c['row_kind'] for c in contrib),{'COMMON','SIGNATURE'},'allowed contribution kinds')
    p.expect(len({x['row_kind']+':'+x['p03_card_id'] for x in contrib}),len(contrib),'contribution rows not duplicated')
    p03cards={c['card_id']:c for c in p03['cards']}
    p03skills={s['skill_id']:s for s in p03['skills']}
    p03pool={r['character_id']:r for r in pool}
    p03decks={tuple(x['ordered_party_character_ids']):x for x in decks['fixtures']}
    p.expect(len(p03decks),24,'24 original P03 ordered four-slot fixtures remain')
    p.expect(len(p03cards),10,'P03 original exact 10 card entries')
    p.expect(len({x['character_id'] for x in pool}),4,'P03 retained fourth fixture slot')
    p.yes(not any(c['p03_fixture_compatibility']['p03_slot_character_id']=='MOCK_P03_CHAR_D' for c in m['characters']),'D unmapped')
    signature={r['p04_character_id']:r for r in contrib if r['row_kind']=='SIGNATURE'}
    p.expect(set(signature),set(char_ids),'every P04 example contributes one card')
    common=[x for x in contrib if x['row_kind']=='COMMON']
    p.expect(sum(int(x['copies']) for x in common),6,'6 common card instances')
    p.expect(sum(int(x['copies']) for x in contrib if x['row_kind']=='SIGNATURE'),3,'3 signature card instances')
    p.expect(sorted(int(x['copies']) for x in common),[1,1,2,2],'P03 common copy recipe')
    p.yes(all(x['p03_source_sha256']==sha256(P03/'card_catalog.json') for x in contrib),'source sha carried per contribution')
    for r in contrib:
        ref=p03cards.get(r['p03_card_id'])
        p.yes(ref is not None,'non-dangling P03 card ref '+r['p03_card_id'])
        p.yes(ref['mock_playable'],'only enabled mock cards in deck')
        if r['row_kind']=='COMMON':
            p.expect(ref['scope'],'COMMON','scope common')
            p.expect(r['p04_character_id'],'','common has no specific actor')
            p.expect(ref['owner_character_id'],None,'common no owner')
        else:
            slot=r['p03_fixture_slot_id'];cid=r['p04_character_id'];sk=r['p03_skill_id']
            p.expect(ref['scope'],'SIGNATURE','signature scope '+cid)
            p.expect(ref['owner_character_id'],slot,'signature owner '+cid)
            p.expect(ref['skill_id'],sk,'signature skill in card '+cid)
            p.expect(p03pool[slot]['signature_card_id'],r['p03_card_id'],'P03 slot pool card matches')
            p.expect(p03pool[slot]['skill_id'],sk,'P03 slot skill matches')
            p.expect(p03skills[sk]['character_id'],slot,'P03 skill character owner matches')
            p.expect(charmap[cid]['p03_fixture_compatibility']['p03_slot_character_id'],slot,'P04 char slot bridge matches')
            p.expect(charmap[cid]['p03_fixture_compatibility']['signature_card_id'],r['p03_card_id'],'P04 profile card bridge matches')
            p.expect(charmap[cid]['skill']['p03_fixture_skill_id'],sk,'P04 skill bridge matches')

    expected_stats=life['derived_stats_after']
    for c in m['characters']:
        cid=c['character_id'];b=c['base_stats'];g=c['per_level_growth']
        p.expect(set(b),{'max_hp','attack','defense','support'},f'base stat keyset {cid}')
        p.expect(set(g),set(b),f'growth stat keyset {cid}')
        p.yes(all(isinstance(v,int) and not isinstance(v,bool) and v>=0 for v in b.values()),'base stats valid ints')
        p.yes(all(isinstance(v,int) and not isinstance(v,bool) and v>=0 for v in g.values()),'growth valid ints')
        p.yes(b['max_hp']>0,'must have positive hp')
        p.expect(derive_stats(c,1),b,'level 1 stat identity')
        for lv in range(1,6):
            calc=derive_stats(c,lv)
            p.yes(all(isinstance(v,int) for v in calc.values()),'integer derived stats')
            if lv>1:
                p.expect({k:calc[k]-derive_stats(c,lv-1)[k] for k in calc},g,'level increment deterministic')
        p.yes(c['art']['asset_id'] is None and c['art']['asset_path'] is None,'no claimed art')
        p.yes(all(v is False for v in c['unapproved_extensions'].values()),'extensions disabled')
        p.expect(c['skill']['skill_rank_max_fixture'],3,'skill rank capped in mock')
        p.expect(c['skill']['skill_rank_effect_on_p03_card'],'NONE_PENDING_P03_P05_P13_P14_CONTRACT','no hidden P03 effect scaler')
        p.expect(expected_stats[cid],derive_stats(c,life['expected_after_json_encode_decode']['character_progress'][cid]['level']),'fixture derived stats')

    # Costs: 3 acquisitions, 4 adjacent levels and 2 skill ranks per character.
    idx={}
    for r in rows:
        cid=r['character_id']
        p.yes(cid in charmap,'valid row character ID')
        p.yes(r['kind'] in ('ACQUIRE','LEVEL','SKILL'),'valid cost row type')
        p.yes(r['resource_source']!='' and r['sink']!='','source/sink nonempty')
        p.yes(int(r['spend_amount'])>=0,'nonnegative integer cost')
        if r['kind'] in ('LEVEL','SKILL'):
            k=(cid,r['kind'],r['from_rank'],r['to_rank'])
            p.yes(k not in idx,'no duplicate step')
            idx[k]=r
            p.expect(r['spend_resource'],'MOCK_P04_TRAINING_TOKEN','fixture spending only')
            p.expect(r['resource_source'],'FIXTURE_STAGE_CLEAR_TOKEN_GRANT','known input source')
            p.expect(r['sink'],'P17_WALLET_SPEND_P21_ATOMIC_COMMIT','known spend sink')
            p.expect(int(r['to_rank']),int(r['from_rank'])+1,'no leap cost rows')
            if r['kind']=='LEVEL':
                p.yes(int(r['requires_xp_total'])>0,'positive cumulative XP gate')
        else:
            p.expect(int(r['spend_amount']),0,'free grant event fixture, not actual policy')
    for cid in char_ids:
        p.expect(len([r for r in rows if r['character_id']==cid and r['kind']=='ACQUIRE']),1,'one acquire row')
        p.expect(len([r for r in rows if r['character_id']==cid and r['kind']=='LEVEL']),4,'four level steps')
        p.expect(len([r for r in rows if r['character_id']==cid and r['kind']=='SKILL']),2,'two skill steps')

    full_owned=set(char_ids)
    # Enumerate all 3! P04 parties; assert each matches EXACT preexisting P03 fixture signatures.
    expected_count=0
    for party in itertools.permutations(char_ids):
        expected_count+=1
        p.expect(validate_party(list(party),full_owned,charmap),'OK','P04 permutation valid')
        p03order=tuple(signature[c]['p03_fixture_slot_id'] for c in party)
        p.yes(p03order in p03decks,'permutation exists in original 24 P03 fixtures')
        generated=[r['p03_card_id'] for r in common for _ in range(int(r['copies']))]+[signature[c]['p03_card_id'] for c in party]
        reference=[i['card_id'] for i in p03decks[p03order]['catalog_card_instances']]
        p.expect(generated,reference,'exact same ordered P03 card IDs')
        p.expect(len(generated),9,'nine distinct instance templates')
        p.expect(len(p03decks[p03order]['catalog_card_instances']),9,'nine actual P03 fixture instances')
        p.yes(len({x['card_instance_id'] for x in p03decks[p03order]['catalog_card_instances']})==9,'fixture instance IDs unique')
        for pcid in party:
            p.expect(generated.count(signature[pcid]['p03_card_id']),1,'one signature per selected character')
    p.expect(expected_count,6,'three prototype permutations')

    # Party negative mutation cases incl malformed, overlimit, ownership loss and duplicate.
    a,b,c=char_ids
    p.neg(validate_party([a,b],full_owned,charmap),'E_PARTY_SIZE','less than 3')
    p.neg(validate_party([a,b,c,'MOCK_P03_CHAR_D'],full_owned,charmap),'E_PARTY_SIZE','more than 3')
    p.neg(validate_party([a,a,c],full_owned,charmap),'E_PARTY_DUPLICATE','duplicate actor')
    p.neg(validate_party([a,b,'UNKNOWN'],full_owned,charmap),'E_CHARACTER_NOT_FOUND','unknown actor')
    p.neg(validate_party([a,b,c],{a,b},charmap),'E_CHARACTER_NOT_OWNED','unowned actor')
    p.neg(validate_party([a,b,c],full_owned,{a:charmap[a],b:charmap[b]}),'E_CHARACTER_NOT_FOUND','missing data record')
    p.neg(validate_party([a,b,None],full_owned,charmap),'E_CHARACTER_ID_TYPE','bad ID type')
    p.neg(validate_party('not-array',full_owned,charmap),'E_PARTY_PAYLOAD_TYPE','wrong payload type')
    p.neg(validate_equipment(['MOCK_E1','MOCK_E1']),'E_EQUIPMENT_DUPLICATE','duplicate equipment instance even disabled')
    p.neg(validate_equipment(['MOCK_E1']),'E_FEATURE_DISABLED','equipment disabled')
    p.neg(validate_equipment([1]),'E_EQUIPMENT_PAYLOAD_TYPE','equipment wrong type')
    p.neg(validate_equipment('bad'),'E_EQUIPMENT_PAYLOAD_TYPE','equipment non-array')
    for c in m['characters']:
        try:
            derive_stats(c,0)
            raise ValidationError('invalid level0 not rejected')
        except ValidationError as ex:
            p.expect(str(ex),'E_INVALID_LEVEL','invalid level0 rejected');p.negatives+=1
        try:
            derive_stats(c,6)
            raise ValidationError('invalid level6 not rejected')
        except ValidationError as ex:
            p.expect(str(ex),'E_INVALID_LEVEL','level cap rejected');p.negatives+=1

    # Mutated P03-only bridge must be recognized as invalid (do not rewrite P03).
    p.neg('MOCK_P03_CHAR_D' in set(signature[x]['p03_fixture_slot_id'] for x in char_ids),False,'P03 D not registered among P04 mapped slots')
    tampered=deepcopy(contrib)
    tampered[-1]['p03_card_id']='MOCK_P03_CARD_A_EDGE'
    badref=p03cards[tampered[-1]['p03_card_id']]
    p.neg(badref['owner_character_id']==tampered[-1]['p03_fixture_slot_id'],False,'wrong signature owner refused')
    p.neg('MOCK_P03_CARD_FOCUS_DRAFT' in [x['p03_card_id'] for x in contrib],False,'disabled focus not in pool')

    # Pure test-state trace: local fixture only, receipts ephemeral, no disk save nor P17 runtime.
    state=deepcopy(life['initial_reference_state']);seen={};events=set()
    for cmd in life['commands']:
        rc,next_state=mock_action(state,cmd,seen,events,charmap,idx)
        p.expect(rc,'OK',cmd['command_id']+' succeeds')
        if cmd['action']=='SERIALIZE_JSON_ROUNDTRIP_ASSERT':
            p.expect(next_state,state,'no mutation for JSON roundtrip')
        else:
            p.expect(next_state['revision'],state['revision']+1,'one fixture revision per mutation')
        state=next_state
    p.expect(state,life['expected_after_mutations_before_serialization'],'expected complete lifecycle state')
    roundtrip=json.loads(json.dumps(state,ensure_ascii=False,sort_keys=True))
    p.expect(roundtrip,life['expected_after_json_encode_decode'],'JSON roundtrip equality; NOT real restart')
    p.expect(state['wallet']['MOCK_P04_TRAINING_TOKEN'],1,'15-4-4-6=1')
    p.expect([state['character_progress'][cid]['level'] for cid in char_ids],[2,3,1],'three observable levels')
    p.expect(len(seen),11,'11 unique committed fixture commands')
    p.expect(len(events),7,'seven unique reward events')

    # Idempotency, cost errors & failures must leave reference state untouched.
    sample=life['commands'][8]
    rc,after=mock_action(state,sample,seen,events,charmap,idx)
    p.neg(rc,'DUPLICATE_NO_OP','repeat same command once not double-spend')
    p.expect(after,state,'duplicate state unchanged')
    clash=deepcopy(sample);clash['wallet_spend']=999
    rc,after=mock_action(state,clash,seen,events,charmap,idx)
    p.neg(rc,'E_COMMAND_ID_COLLISION','reuse ID with changed payload')
    p.expect(after,state,'collision state unchanged')
    duplicate_event={'command_id':'FIXTURE_NEW_COMMAND_DUP_EVENT','action':'GRANT_TOKEN','delta':15,'event_identity':'FIXTURE_STAGE_CLEAR_TOKEN_001'}
    rc,after=mock_action(state,duplicate_event,seen,events,charmap,idx)
    p.neg(rc,'DUPLICATE_NO_OP','same reward event with new command ID blocked')
    p.expect(after,state,'duplicate reward event immutable state')

    # Deliberate negative transitions executed with fresh receipts.
    neg_state=deepcopy(state)
    neg_state['character_progress'][a]['xp_total']=9;neg_state['character_progress'][a]['level']=1
    c1={'command_id':'BAD_XP','action':'UPGRADE_LEVEL','target':a,'from_level':1,'to_level':2,'wallet_spend':4}
    rc,after=mock_action(neg_state,c1,{},set(),charmap,idx)
    p.neg(rc,'E_XP_INSUFFICIENT','upgrading without xp is rejected');p.expect(after,neg_state,'xp failure no mutation')
    neg_state['character_progress'][a]['xp_total']=10
    neg_state['wallet']['MOCK_P04_TRAINING_TOKEN']=3
    c1['command_id']='BAD_WALLET'
    rc,after=mock_action(neg_state,c1,{},set(),charmap,idx)
    p.neg(rc,'E_WALLET_INSUFFICIENT','not enough wallet token');p.expect(after,neg_state,'wallet failure no mutation')
    neg_state['wallet']['MOCK_P04_TRAINING_TOKEN']=15
    c1['command_id']='BAD_STEP';c1['to_level']=3
    rc,after=mock_action(neg_state,c1,{},set(),charmap,idx)
    p.neg(rc,'E_LEVEL_STEP_INVALID','no level skipping');p.expect(after,neg_state,'step failure no mutation')
    neg_state['character_progress'][a]['level']=5
    c1.update(command_id='BAD_CAP',from_level=5,to_level=6)
    rc,after=mock_action(neg_state,c1,{},set(),charmap,idx)
    p.neg(rc,'E_LEVEL_CAP','enforced fixture level cap');p.expect(after,neg_state,'level cap no mutation')
    neg_state['character_progress'][a]['level']=2
    c2={'command_id':'BAD_SKILL_GATE','action':'UPGRADE_SKILL','target':a,'from_rank':1,'to_rank':2,'wallet_spend':12}
    rc,after=mock_action(neg_state,c2,{},set(),charmap,idx)
    p.neg(rc,'E_SKILL_LEVEL_GATED','skill locked before lv3');p.expect(after,neg_state,'skill gate no mutation')
    neg_state['character_progress'][a]['level']=3
    rc,after=mock_action(neg_state,{**c2,'command_id':'SKILL_VALID'}, {},set(),charmap,idx)
    p.expect(rc,'OK','rank up fixture permitted at lvl3')
    p.expect(after['character_progress'][a]['skill_rank'],2,'rank updated')
    p.expect(after['character_progress'][a]['level'],3,'rank upgrade not auto level up')
    p.expect(after['wallet']['MOCK_P04_TRAINING_TOKEN'],3,'skill spend 12 tokens')
    p.expect(after['character_progress'][a]['xp_total'],neg_state['character_progress'][a]['xp_total'],'xp not consumed')
    p.expect(p03cards[signature[a]['p03_card_id']]['effect_ids'],p03cards['MOCK_P03_CARD_A_EDGE']['effect_ids'],'rank never modifies P03 card')

    # More fixed, separately identified negative scenarios for independent consumers.
    no_char={'command_id':'BAD_NO_CHAR','action':'ACQUIRE','target':'MISSING_P04_ID',
             'event_identity':'FIXTURE_TEST_MISSING'}
    rc,after=mock_action(life['initial_reference_state'],no_char,{},set(),charmap,idx)
    p.neg(rc,'E_CHARACTER_NOT_FOUND','cannot acquire missing catalog character')
    p.expect(after,life['initial_reference_state'],'missing acquire has no side effects')
    bad_skill=deepcopy(neg_state)
    bad_skill['character_progress'][a]['level']=5
    bad_skill['character_progress'][a]['skill_rank']=2
    bad_skill['wallet']['MOCK_P04_TRAINING_TOKEN']=19
    skill_cmd={'command_id':'BAD_SKILL_WALLET','action':'UPGRADE_SKILL','target':a,
               'from_rank':2,'to_rank':3,'wallet_spend':20}
    rc,after=mock_action(bad_skill,skill_cmd,{},set(),charmap,idx)
    p.neg(rc,'E_WALLET_INSUFFICIENT','skill rank 2->3 insufficient tokens')
    p.expect(after,bad_skill,'skill wallet failure no mutation')
    bad_equipment={'command_id':'BAD_GEAR_DUP','action':'EQUIP','equipment_ids':['G_1','G_1']}
    rc,after=mock_action(state,bad_equipment,{},set(),charmap,idx)
    p.neg(rc,'E_EQUIPMENT_DUPLICATE','repeated equipment instance rejected by offline preflight')
    p.expect(after,state,'equipment duplication no mutation')
    single_equipment={'command_id':'BAD_GEAR_DISABLED','action':'EQUIP','equipment_ids':['G_1']}
    rc,after=mock_action(state,single_equipment,{},set(),charmap,idx)
    p.neg(rc,'E_FEATURE_DISABLED','equipment feature explicitly disabled')
    p.expect(after,state,'disabled equipment no mutation')
    p.expect(validate_party([char_ids[2],a,b],full_owned,charmap),'OK','ordered permutation [C,A,B] works')
    missing_skill_card=deepcopy(p03cards[signature[a]['p03_card_id']]);missing_skill_card['owner_character_id']='MOCK_P03_CHAR_B'
    p.neg(missing_skill_card['owner_character_id']==signature[a]['p03_fixture_slot_id'],False,'P03 owner mapping conflict rejected')

    p.expect(life['wallet_ledger_fixture']['grant']-sum(life['wallet_ledger_fixture']['spend_by_commands'].values()),life['wallet_ledger_fixture']['expected_remaining'],'ledger balances')
    p.expect(len(set(x['command_id'] for x in life['commands'])),len(life['commands']),'sequence command IDs unique')
    p.expect(len({x['event_identity'] for x in life['commands'] if 'event_identity' in x}),7,'reward identities unique')
    p.expect(life['serialization_test_meaning'].startswith('json.dumps+json.loads'),True,'serialization clearly limited')
    # Deterministic references for P32 test author; do not pretend P32 ran.
    p.expect(set(x['expected'] for x in cases).issuperset({'OK','E_PARTY_SIZE','E_PARTY_DUPLICATE','E_CHARACTER_NOT_FOUND','E_WALLET_INSUFFICIENT','E_EQUIPMENT_DUPLICATE','DUPLICATE_NO_OP'}),True,'test matrix covers critical cases')
    print('P04_LOCAL_STATIC_VALIDATION: PASS')
    print('status: P04_AUTHOR_ONLY; NOT_P32_NOT_P35; NO_P17_RUNTIME_NO_P21_REAL_RESTART_NO_ANKI')
    print(f'characters={len(m["characters"])} roles=3 ordered_P04_parties={expected_count} mapped_P03_fixture_parties={expected_count}/24')
    print(f'contribution_rows={len(contrib)} common_templates=4 signature_templates=3 card_instances_per_party=9')
    print(f'cost_rows={len(rows)} field_entries={len(fields)} acceptance_case_records={len(cases)}')
    print(f'author_static_assertions={p.count} negative_checks={p.negatives} lifecycle_commands={len(life["commands"])} mutated_revisions={state["revision"]}')
    print('readonly_P03_catalog_sha256='+sha256(P03/'card_catalog.json'))
    print('local_roundtrip=PASS_MEMORY_JSON_ONLY; real_restart=NOT_RUN')
    return 0

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as e:
        print(f'P04_LOCAL_STATIC_VALIDATION: FAIL {type(e).__name__}: {e}',file=sys.stderr)
        raise SystemExit(1)
