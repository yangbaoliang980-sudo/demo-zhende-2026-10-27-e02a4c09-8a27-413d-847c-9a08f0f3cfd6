"""unittest runner with per-test actual outcomes; no independent sign-off."""
from pathlib import Path
import json, sys, unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class Result(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = []

    def addSuccess(self, test):
        self.rows.append({'test': test.id(), 'status': 'PASS'})
        super().addSuccess(test)

    def addFailure(self, test, err):
        self.rows.append({'test': test.id(), 'status': 'FAIL', 'kind': 'assertion'})
        super().addFailure(test, err)

    def addError(self, test, err):
        self.rows.append({'test': test.id(), 'status': 'FAIL', 'kind': 'error'})
        super().addError(test, err)

    def addSkip(self, test, reason):
        self.rows.append({'test': test.id(), 'status': 'NOT_RUN', 'reason': reason})
        super().addSkip(test, reason)


suite = unittest.defaultTestLoader.discover(str(ROOT/'deck_unit_tests'), pattern='test_*.py', top_level_dir=str(ROOT))
result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
print(json.dumps({'scope': 'P15_AUTHOR_UNIT_AND_ISOLATED_CONTRACT_TESTS', 'tests_run': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'status': 'PASS' if result.wasSuccessful() else 'FAIL', 'tests': result.rows}, indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
