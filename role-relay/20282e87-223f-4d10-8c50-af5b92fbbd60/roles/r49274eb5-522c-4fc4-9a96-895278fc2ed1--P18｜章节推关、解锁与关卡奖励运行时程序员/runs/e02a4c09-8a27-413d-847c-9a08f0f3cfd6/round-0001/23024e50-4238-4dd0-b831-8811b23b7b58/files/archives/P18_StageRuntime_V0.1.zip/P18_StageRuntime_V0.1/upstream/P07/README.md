# P07｜章节推关、关卡配置与掉落交付

**本岗候选实体已完成，状态：LOCAL_CONFIG_DELIVERED / FORMAL_INTEGRATION_BLOCKED。**

任务 `P07-S07-STAGES-001`；内容版本 `P07-STAGES-0.1.0-proposal`；需求锚点 `REQ-010 / REQ-028`；关联 `IC-11 / IC-13`。本次仅进行 P07 独立内容制作与作者验证，没有创建子角色，没有改写游戏工程、P18领赏实现、P21存档事务或敌AI。

## 1. 四项主产物

| 包内相对路径 | 实际字节 | SHA-256 |
|---|---:|---|
| `content/stages/stage_graph.json` | 12,644 | `7bb2dd80ec85fb236240d580380ed406c6673dd3badab32191daf29a6257d7f4` |
| `content/stages/stage_rewards.tsv` | 2,597 | `397a5d02985da3f0f4b769450e29907e1b6da9f4e0b6cfb36e441e4ed8d40827` |
| `design/stages/first_clear_policy.md` | 10,814 | `af618365ca6a875489589dfe20c9ae4be2c11f1569edb0251fc9e0c3eff3be1f` |
| `content/stages/stage_retry_cases.json` | 170,850 | `98e5bbf9097947f7b918da10a89344fd1b7d3ad7a231512dd46bb2855f15c7d8` |

附加实体包括：`content/stages/stage_content_catalog.json`、`stage_table.tsv`；`design/stages/chapter_nodes.mmd/.svg/.png`、`stage_tables.xlsx`、格式说明、来源回执、版本化RFC、实际路径请求、接收文件回执、独立门禁状态矩阵、作者校验器和原始运行日志。Excel只是同一机器表的阅读副本。

逐件完整路径、实际大小、SHA-256、格式/版本、来源输入哈希、接收人和修改白名单见 `design/stages/delivery_manifest.sha256.tsv`。清单不自引用；自身与最终ZIP由包外 `P07_delivery_receipt.json` 固定。任何文件变更都需要重新生成清单与回执。

## 2. 已落成的首章候选

| 顺序 | stage_id | 类型/敌人 | 首通共享代币 | 首通每名入场角色累计 XP | 重复掉落 |
|---|---|---|---:|---:|---|
| 1 | MOCK_P07_STAGE_001 | 普通 / MOCK_P06_ENEMY_001 游离字屑 | 3 | 4 | 停用，0 |
| 2 | MOCK_P07_STAGE_002 | BOSS / MOCK_P06_ENEMY_003 失序校勘者 | 12 | 18 | 停用，0 |

路线：合法三人快照进入普通关 → 权威最终WIN与P21提交 → 解锁BOSS → 权威最终WIN与P21提交 → 本章完成并返回选关。失败可退回或重试；图中只有两关，没有不可达节点，章节完成是明确终点。

精英锁页卫士只留未启用入口说明，分布为普通1 / 精英0 / BOSS1。新增第三关、第二章、剧情或奖励扩展均未获授权。本章没有额外章完成奖励。

P06三阶段Boss图直接引用，不改HP、伤害、阈值或AI。普通样本原适用S03，S07复用需P06接收。全部ID保持 `MOCK_*`，`production_enabled=false`；P22正式ID存在性仍BLOCKED。

## 3. 已写明的关键规则

永久首通键是玩家稳定存档作用域与canonical stage ID，不含battle_id、终局修订号、内容/奖励版本、章节序号或文件名。重复域另用battle/terminal_revision，但同一battle更高修订不能创造第二次奖励，必须过结果守卫与对账。

首通/重复bundle互斥；首通资源、每人XP、进度、首通墓碑、终局回执及解锁必须同事务。结果页按钮只确认/重查，不自行发奖。中断不丢弃已有效的待提交WIN；提交结果未知时禁止开始新一局。

重试创建新battle_id，恢复同局保留旧ID。主动退出要有权威ABORT，拒绝旧attempt迟到WIN。发奖前撤回WIN不发奖励；发奖后撤回保留首通墓碑并标待审，依赖入口与后续新奖励先隔离，不自动负债、降级或重新开放首通。Anki Undo不等于stage撤回。

代币只发共享钱包一次；XP只按入场固定三人名单逐人授予，含阵亡成员。两关同一三人名单首通合计15代币、每人22XP；按P04测试成本最多支持三人各升一次LV2，花12代币余3，XP22不足LV3的25。普通首通3币/4XP尚不足升级，所以BOSS入口不强制LV2。

这些金额和分配仍为未批准测试预算。重复掉落没有P05预算和P08边界，显式停用而非自行承诺永久无掉落。入口/重试0费用、0复习可进入仅是隔离夹具；正式零学习日权益仍受DEC-003阻塞。P05无阶段Boss的旧回合结果不能用于本配置。

## 4. 上游核验与补齐

原上传ZIP 35/35 清单项、嵌套relay 34/34、P01 15/15、P02 14/14、P03 16/16、P04 19/19、P05 19/19、P06 42/42均实际核验，共8个唯一ZIP，CRC通过，194条逐层清单项匹配（不是194个不同源文件）。

P06完整成果ZIP不在原35个附件或给定Git固定提交的文件树中；本次从正文的精确成果链接补齐真实字节，大小168,593，SHA-256为 `0a2912acc81c594bba6fb93bd631ef77c412769adb2ad68f553914a44e1c1ce7`，与交接指定值相同。不能把Git归档中只有正文链接说成源配置已在Git。

V6通过GitHub固定提交 `8c370d731c323f86ff19642f4cc73f818498f641` 读取，实际字节SHA-256 `4008473917142fdf7cdc440ac278e63804bb50e450b9dbce6f598a951e1e782d`，Git blob `682a18f0c33ae24637e67cf19fec33df8142a0f7` 同时匹配。

独立P01决策TSV和P04成长TSV仅有表头的副本未用于决策，采用实际打开并校验的完整内层ZIP。16份实际消费源快照与两份原始封装ZIP均保留为只读证据，下一位可离线递归重算来源；未执行上游内嵌程序。

## 5. 实际执行结果与未执行边界

| 验证层级 | 状态 | 说明 |
|---|---|---|
| 原始来源ZIP、清单、源快照绑定 | PASS | 8 ZIP / 194清单项 / 16快照 |
| P07候选内容静态校验 | PASS | 图、引用、奖励、分域、期望数据一致性 |
| P07校验器作者测试 | PASS，57/57 | 包含53个配置/期望数据变异和2个JSON解析拒绝 |
| 章节图与表格作者目视检查 | PASS | 不等同P25/P33或正式美术审核 |
| 正式前置探针 | BLOCKED | 实际退出3，缺合同/路径/政策/目标环境 |
| P35独立设计审核/SPEC Gate | NOT_RUN | 没有独立回执 |
| P18真实单元、IC-11/13契约、P21持久事务 | NOT_RUN | 没有真实实现与目标环境 |
| P32独测、P33人工、P35独审 | NOT_RUN | 作者不能代签 |
| 游戏真机、Anki E2E、跨模块集成 | NOT_RUN / BLOCKED | 无运行或整合证据 |

**67条用例是期望数据，真实关卡/奖励执行数为0。** 例如ST-026/027覆盖同stage不同battle；ST-031给出两种并发次序；ST-037/039覆盖崩溃和响应丢失；ST-044至048覆盖胜利撤回；ST-065/066说明迁移与旧备份边界。静态通过不证明真实事务幂等或Boss能获胜。

作者原始日志位于 `design/stages/evidence/author_run_002/`，其中 `run_receipt.json`保留实际命令、起止时间、退出码和stdout/stderr哈希。前一轮作者记录也保留，未隐藏失败或伪造独测。

## 6. 下游直接复算

```bash
python design/stages/verification/verify_input_archives.py
python design/stages/verification/validate_stage_content.py
python -m unittest discover -s design/stages/verification -p 'test_*.py' -v
python design/stages/verification/verify_manifest.py
python design/stages/verification/validate_stage_content.py --formal
```

前四项应退出0；最后一项在此版本应输出BLOCKED并退出3。默认只读，不触碰玩家数据。生成新验证日志时请输出到包外，以保持本包固定哈希。

## 7. 接收与剩余责任

P05接奖励和节奏；P06接敌人引用；P18接四项主产物与真实事务要求；P20接地图/锁定/待审状态；P22接ID与Schema；P32接用例、校验器和原始证据。逐件接收哈希在 `design/stages/downstream_handoff.json`，均为PREPARED_NOT_ACKNOWLEDGED。

关键缺项为P13实际路径/DTO/授权、P22正式ID/Schema、P08奖励边界、P01该版本范围接收、P05新Boss/重复预算、P06普通样本S07复用确认、P34目标环境、P18真实运行合同，以及P32/P33/P35独立结果。具体缺文件、版本条件与唯一跟进owner见 `design/stages/interface_rfc_and_blockers.md`。

本包路径是隔离交付相对路径，不是P13实际映射。任何现有工程写入白名单为空；源快照只读。收到正式映射后由各owner消费自己的接口；跨模块合并仍由用户另行指定的EXT-INTEGRATOR承担。
