"""Run the ORIGINAL P13 validator on emitted original-shape DTO samples."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from stage_runtime import FrozenMessage, first_clear_key, load_catalog, p13_view
from stage_runtime.common import validate_dto


def run():
    unique = {}; source_bindings = []
    def walk(value):
        if isinstance(value, dict):
            if 'dto_type' in value:
                validated = validate_dto(value, value['dto_type'])
                unique[validated.sha256] = value['dto_type']
            for child in value.values(): walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    for path in ('examples/lifecycle_execution.json', 'examples/native_p14_contract_execution.json'):
        raw = (ROOT/path).read_bytes()
        source_bindings.append({'path': path, 'sha256': hashlib.sha256(raw).hexdigest()})
        walk(json.loads(raw))
    snap = FrozenMessage.from_value(json.loads((ROOT/'examples/stage_snapshot.json').read_text()))
    projected = p13_view(snap, load_catalog()); walk(projected.value)
    keys = json.loads((ROOT/'first_clear_keys.json').read_text())
    for vector in keys['vectors']:
        assert first_clear_key(vector['scope'], vector['stage_id']) == vector['key_sha256']
    assert len({v['key_sha256'] for v in keys['vectors']}) == len(keys['vectors'])
    return {'status': 'PASS_ORIGINAL_SCHEMA_LOCAL_SAMPLES', 'unique_dto_count': len(unique),
            'by_type': dict(sorted(Counter(unique.values()).items())),
            'validated_dtos': [{'sha256': h, 'dto_type': t} for h,t in sorted(unique.items())],
            'first_clear_vectors_checked': len(keys['vectors']), 'source_bindings': source_bindings,
            'validator': 'upstream/P13/runtime/framework/yltt_framework/contracts.py',
            'validator_sha256': hashlib.sha256((ROOT/'upstream/P13/runtime/framework/yltt_framework/contracts.py').read_bytes()).hexdigest(),
            'proposal_acceptance': 'NOT_RUN', 'P21_durability': 'NOT_RUN'}


if __name__ == '__main__': print(json.dumps(run(), ensure_ascii=False, indent=2))
