"""Read-only gate. A successful isolated run cannot authorize production writes."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
m=json.loads((ROOT/'upstream/P13/architecture/actual_path_mapping.json').read_text())
paths=[x for x in m['mappings'] if x['owner']=='P15']
assert paths and all(x['actual_production_path'] is None and x['write_allowed'] is False for x in paths)
report={'status':'BLOCKED','task_id':'TASK-02-01','production_write_allowlist':[],
    'p13_mapping_status':m['status'],'p15_mapped_paths':paths,
    'missing':['P13 production actual_path_mapping and authorization','P17 genuine hash-bound PartySnapshot',
        'P03/P05 approved deck/fee/hand/entry/common-owner policy','P22 official content IDs and schema',
        'P13/P14 accepted production negative-result and draw-report contract','Target engine/OS evidence',
        'P32 independent tests and P35 independent gate','User-designated EXT-INTEGRATOR'],
    'isolated_runtime_supported':True,'target_runtime':'NOT_RUN'}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(3)
