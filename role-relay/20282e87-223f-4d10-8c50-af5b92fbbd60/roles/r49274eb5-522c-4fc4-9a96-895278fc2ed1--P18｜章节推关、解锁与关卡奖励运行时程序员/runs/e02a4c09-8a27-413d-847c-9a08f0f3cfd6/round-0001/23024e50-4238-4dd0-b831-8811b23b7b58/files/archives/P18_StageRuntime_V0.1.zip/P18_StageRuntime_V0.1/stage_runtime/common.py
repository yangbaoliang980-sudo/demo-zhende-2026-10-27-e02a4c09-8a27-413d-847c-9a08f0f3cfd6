"""P18 pure boundaries; P13's original codec and DTO validator are reused."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
import sys

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
_path = str(PACKAGE_ROOT / 'upstream/P13/runtime/framework')
if _path not in sys.path:
    sys.path.insert(0, _path)
from yltt_framework.codec import (FrozenMessage, ContractError, MAX_INTEGER,
                                  canonical, fingerprint, loads)
from yltt_framework.contracts import validate as validate_dto

VERSION = 'P18-STAGES/0.1.0-isolated'
STATE_VERSION = 'P18-STATE/0.1.0-isolated'
COMMAND_VERSION = 'P18-COMMAND/0.1.0-isolated'
CANDIDATE_VERSION = 'P18-CANDIDATE/0.1.0-isolated'
INTERNAL_VERSION = 'YLTT-INTERNAL/0.1.0-isolated'


class StageError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def need(condition, code):
    if not condition:
        raise StageError(code)


def shape(value, fields, code='E_SHAPE'):
    need(type(value) is dict and set(value) == set(fields.split()), code)


def ident(value, code='E_IDENTIFIER'):
    need(type(value) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}', value) is not None, code)
    return value


def digest(value, code='E_SHA256'):
    need(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, code)
    return value


def integer(value, minimum=0, maximum=MAX_INTEGER, code='E_INTEGER'):
    need(type(value) is int and minimum <= value <= maximum, code)
    return value


def array(value, code='E_ARRAY'):
    need(type(value) is list and len(value) <= 4096, code)


def unique_identifiers(values, code='E_DUPLICATE_ID'):
    array(values)
    for value in values:
        ident(value)
    need(len(values) == len(set(values)), code)


def get_row(rows, field, value):
    return next((x for x in rows if x[field] == value), None)


def first_clear_identity(scope, stage_id):
    return ['STAGE_FIRST_CLEAR', ident(scope), ident(stage_id)]


def first_clear_key(scope, stage_id):
    return fingerprint(first_clear_identity(scope, stage_id))


def repeat_identity(scope, stage_id, battle_id, terminal_revision):
    return ['STAGE_REPEAT_CLEAR', ident(scope), ident(stage_id), ident(battle_id), integer(terminal_revision, 1)]


@dataclass(frozen=True, slots=True)
class PlanResult:
    status: str
    reason: str
    candidate: FrozenMessage | None = None
    receipt: FrozenMessage | None = None

    def value(self):
        return {'status': self.status, 'reason': self.reason,
                'candidate': None if self.candidate is None else self.candidate.value,
                'receipt': None if self.receipt is None else self.receipt.value}

