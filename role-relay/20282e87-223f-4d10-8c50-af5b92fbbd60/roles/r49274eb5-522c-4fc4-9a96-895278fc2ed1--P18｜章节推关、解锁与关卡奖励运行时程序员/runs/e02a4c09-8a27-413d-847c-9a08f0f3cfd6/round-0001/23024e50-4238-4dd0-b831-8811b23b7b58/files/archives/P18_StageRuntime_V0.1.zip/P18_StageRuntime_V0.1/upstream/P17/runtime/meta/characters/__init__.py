"""Character-owned transitions."""
