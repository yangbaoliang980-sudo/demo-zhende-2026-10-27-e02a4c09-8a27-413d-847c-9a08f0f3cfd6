"""P04 level/skill semantics and isolated equipment mechanics."""
from character_party_runtime.common import (keys, require, integer, identifier,
    array, distinct, indexed, checked_add, fingerprint)
from character_party_runtime.content import STATS
from runtime.meta.wallet.rules import spend_character


def owned(state, catalog, cid):
    catalog.character(cid)
    row=next((x for x in state['characters'] if x['character_id']==cid),None)
    require(row is not None,'E_CHARACTER_NOT_OWNED')
    return row


def acquire(state, catalog, cid):
    catalog.character(cid)
    require(all(x['character_id']!=cid for x in state['characters']),'E_CHARACTER_ALREADY_OWNED')
    state['characters'].append({'character_id':cid,'level':1,'xp_total':0,'skill_rank':1,'equipment':[]})
    state['characters'].sort(key=lambda x:x['character_id'])


def grant_xp(state,catalog,cid,amount):
    integer(amount,1)
    c=owned(state,catalog,cid);c['xp_total']=checked_add(c['xp_total'],amount)


def purpose(state,cid,kind,from_rank):
    return fingerprint({'profile_id':state['profile_id'],'character_id':cid,'kind':kind,'from_rank':from_rank})


def upgrade(state,catalog,payload,kind,request_id):
    keys(payload,'character_id from_rank to_rank')
    cid=payload['character_id'];definition=catalog.character(cid);c=owned(state,catalog,cid)
    field='level' if kind=='LEVEL' else 'skill_rank'
    cap=definition['max_level'] if kind=='LEVEL' else definition['skill_max']
    integer(payload['from_rank'],1);integer(payload['to_rank'],1)
    require(payload['from_rank']==c[field],'E_CHARACTER_RANK_CONFLICT')
    require(c[field]<cap,'E_LEVEL_CAP' if kind=='LEVEL' else 'E_SKILL_CAP')
    require(payload['to_rank']==payload['from_rank']+1,'E_LEVEL_STEP_INVALID' if kind=='LEVEL' else 'E_SKILL_STEP_INVALID')
    cost=catalog.cost(cid,kind,c[field])
    require(c['level']>=cost['requires_character_level'],'E_SKILL_LEVEL_GATED' if kind=='SKILL' else 'E_LEVEL_GATED')
    require(c['xp_total']>=cost['requires_xp_total'],'E_XP_INSUFFICIENT')
    spend_character(state['wallet'],cost['resources'],purpose(state,cid,kind,c[field]),request_id)
    c[field]+=1  # No XP debit; skill ranks do not scale P03 cards.


def grant_equipment(state,catalog,items):
    require(catalog.value['equipment_enabled'],'E_FEATURE_DISABLED')
    existing={x['instance_id'] for x in state['equipment_instances']}
    for e in items:
        catalog.equipment(e['definition_id'])
        require(e['instance_id'] not in existing,'E_EQUIPMENT_ALREADY_OWNED')
        existing.add(e['instance_id']);state['equipment_instances'].append(e.copy())
    state['equipment_instances'].sort(key=lambda x:x['instance_id'])


def set_equipment(state,catalog,payload):
    keys(payload,'character_id items')
    array(payload['items'],'E_EQUIPMENT_PAYLOAD')
    for e in payload['items']:
        keys(e,'slot instance_id','E_EQUIPMENT_PAYLOAD');identifier(e['slot']);identifier(e['instance_id'])
    # P04 requires duplicate checks even when the feature is disabled.
    distinct([x['instance_id'] for x in payload['items']],'E_EQUIPMENT_DUPLICATE')
    distinct([x['slot'] for x in payload['items']],'E_EQUIPMENT_SLOT_DUPLICATE')
    require(catalog.value['equipment_enabled'],'E_FEATURE_DISABLED')
    c=owned(state,catalog,payload['character_id'])
    by_instance=indexed(state['equipment_instances'],'instance_id')
    used={e['instance_id'] for x in state['characters'] if x['character_id']!=c['character_id'] for e in x['equipment']}
    for e in payload['items']:
        require(e['instance_id'] in by_instance,'E_EQUIPMENT_NOT_OWNED')
        require(e['instance_id'] not in used,'E_EQUIPMENT_IN_USE')
        definition=catalog.equipment(by_instance[e['instance_id']]['definition_id'])
        require(definition['slot']==e['slot'],'E_EQUIPMENT_SLOT')
        require(c['level']>=definition['required_level'],'E_EQUIPMENT_LEVEL_GATED')
        require(not definition['allowed_roles'] or catalog.character(c['character_id'])['role'] in definition['allowed_roles'],
                'E_EQUIPMENT_ROLE')
    c['equipment']=sorted([e.copy() for e in payload['items']],key=lambda x:x['slot'])


def derived(state,catalog,cid):
    c=owned(state,catalog,cid);d=catalog.character(cid)
    result={s:checked_add(d['base'][s],(c['level']-1)*d['growth'][s]) for s in STATS}
    instances=indexed(state['equipment_instances'],'instance_id')
    for e in c['equipment']:
        definition=catalog.equipment(instances[e['instance_id']]['definition_id'])
        for stat in STATS:result[stat]=checked_add(result[stat],definition['bonuses'][stat])
    return result


def validate_characters(state,catalog):
    array(state['characters']);array(state['equipment_instances'])
    for e in state['equipment_instances']:
        keys(e,'instance_id definition_id');identifier(e['instance_id']);catalog.equipment(e['definition_id'])
    distinct([x['instance_id'] for x in state['equipment_instances']],'E_EQUIPMENT_DUPLICATE')
    ids=[];all_used=[]
    for c in state['characters']:
        keys(c,'character_id level xp_total skill_rank equipment')
        d=catalog.character(c['character_id']);ids.append(c['character_id'])
        integer(c['level'],1,d['max_level']);integer(c['xp_total']);integer(c['skill_rank'],1,d['skill_max'])
        if c['level']>1:
            require(c['xp_total']>=catalog.cost(c['character_id'],'LEVEL',c['level']-1)['requires_xp_total'],'E_XP_INSUFFICIENT')
        if c['skill_rank']>1:
            require(c['level']>=catalog.cost(c['character_id'],'SKILL',c['skill_rank']-1)['requires_character_level'],'E_SKILL_LEVEL_GATED')
        array(c['equipment'])
        for e in c['equipment']:
            keys(e,'slot instance_id');identifier(e['slot']);identifier(e['instance_id']);all_used.append(e['instance_id'])
        distinct([e['slot'] for e in c['equipment']],'E_EQUIPMENT_SLOT_DUPLICATE')
        if c['equipment']:
            require(catalog.value['equipment_enabled'],'E_FEATURE_DISABLED')
            # Reuse the pure validation on a detached state, preserving caller bytes.
            probe={'characters':[dict(x) for x in state['characters']],
                   'equipment_instances':state['equipment_instances']}
            set_equipment(probe,catalog,{'character_id':c['character_id'],'items':c['equipment']})
        derived(state,catalog,c['character_id'])
    distinct(ids,'E_CHARACTER_DUPLICATE');distinct(all_used,'E_EQUIPMENT_IN_USE')

