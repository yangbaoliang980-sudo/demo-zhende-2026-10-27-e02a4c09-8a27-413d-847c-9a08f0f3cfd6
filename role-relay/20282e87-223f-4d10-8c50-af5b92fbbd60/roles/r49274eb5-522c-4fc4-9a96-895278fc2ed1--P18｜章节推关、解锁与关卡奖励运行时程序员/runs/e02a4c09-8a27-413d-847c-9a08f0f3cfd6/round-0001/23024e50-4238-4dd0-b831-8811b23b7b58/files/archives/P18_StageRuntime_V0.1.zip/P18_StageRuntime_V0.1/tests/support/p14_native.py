"""Build a small synthetic combat INPUT; unmodified P14 produces the result.

Enemy HP and card effects are contract fixtures, not P06 balance or boss AI.
No BattleResult is manufactured or edited here.
"""
import importlib.util
import sys
from stage_runtime.common import PACKAGE_ROOT, FrozenMessage, fingerprint, get_row, need

path = str(PACKAGE_ROOT/'upstream/P14')
if path not in sys.path: sys.path.append(path)
from battle_core import BattleCore, Rules, Action, Effect
from battle_core.wire import message as p14_message

_spec = importlib.util.spec_from_file_location('p18_test_original_p14_ports', PACKAGE_ROOT/'upstream/P14/examples/fixture_ports.py')
_ports = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(_ports)


def start_native(h, battle_id='native.battle'):
    payload = h.entry_payload(battle_id=battle_id)
    entry = h.authority.entries[payload['entry_ref']].value
    stage = h.catalog.stage(payload['stage_id']); members = entry['party_snapshot']['members']
    rules = Rules(entry['battle_rules_version'], entry['battle_content_version'],
        'fixture.native-deck', 'ENEMY_EXIT', 0, None, 'UNCAPPED_TEST_ONLY',
        cards=(Action('fixture.native-strike', 'ENEMY', 1, (Effect(0, 'DAMAGE', 1),)),))
    entry['battle_content_sha256'] = rules.frozen().sha256
    h.authority.entries[payload['entry_ref']] = FrozenMessage.from_value(entry)
    h.apply('ENTER', payload)
    a = get_row(h.model.stage.value['attempts'], 'battle_id', battle_id)
    units = [{'unit_id': m['unit_id'], 'definition_id': m['character_id'], 'side': 'PLAYER', 'slot': m['slot'],
              'hp': m['max_hp'], 'max_hp': m['max_hp'], 'shield': 0, 'statuses': []} for m in members]
    units.append({'unit_id': 'fixture.native-enemy', 'definition_id': stage['enemy_refs'][0]['enemy_id'],
                  'side': 'ENEMY', 'slot': 0, 'hp': 1, 'max_hp': 1, 'shield': 0, 'statuses': []})
    snap = p14_message('BattleSnapshot', battle_id=battle_id, revision=0,
        rules_version=rules.rules_version, content_version=rules.content_version, phase='PLAYER_READY',
        turn_number=1, energy=1, units=units, card_instances=[{'instance_id': 'fixture.card',
            'card_id': 'fixture.native-strike', 'owner_unit_id': members[0]['unit_id']}],
        zones={'hand': ['fixture.card'], 'draw': [], 'discard': [], 'exhaust': []},
        rng={'algorithm': 'xorshift32-v1', 'initial_seed': 1, 'state': 1, 'draw_count': 0},
        last_event_seq=0, outcome='ONGOING', boss_states=[])
    deck = _ports.ScriptedDeck(rules.deck_policy_version, [{'command_id': 'native.play', 'energy_delta': -1,
        'moves': [_ports.move('fixture.card', 'hand', 'discard', 0)]}])
    core = BattleCore(p14_message('BattleState', snapshot=snap.value, accepted_commands=[]), rules,
        stage_id=payload['stage_id'], profile_scope=h.scope, deck_planner=deck)
    return core, a


def publish_native(h, core, at):
    # Conversion by bytes handles the two upstream module import namespaces.
    state = core.state().value; result = core.result()
    proof = FrozenMessage.from_value({'schema_version': 'P18-BATTLE-EVIDENCE/0.1.0-proposal',
        'battle_id': at['battle_id'], 'admission_sha256': at['admission_sha256'],
        'snapshot': state['snapshot'], 'result': None if result is None else result.value})
    h.authority.battles[at['battle_id']] = proof
    return None if result is None else FrozenMessage(result.raw)


def finish_native(h, core, at, *, abort=False):
    s = core.state().value['snapshot']
    payload = {'reason_code': 'USER_QUIT'} if abort else {'actor_id': s['units'][0]['unit_id'],
        'card_instance_id': 'fixture.card', 'target_ids': ['fixture.native-enemy']}
    cmd = p14_message('BattleCommand', battle_id=at['battle_id'], command_id='native.abort' if abort else 'native.play',
                      expected_revision=s['revision'], kind='ABORT' if abort else 'PLAY_CARD', payload=payload)
    reply = core.abort(cmd) if abort else core.submit(cmd)
    need(reply.value['result'] == 'COMMITTED' and reply.value['code'] == 'OK', 'E_NATIVE_P14_COMMAND')
    return publish_native(h, core, at), cmd, reply

