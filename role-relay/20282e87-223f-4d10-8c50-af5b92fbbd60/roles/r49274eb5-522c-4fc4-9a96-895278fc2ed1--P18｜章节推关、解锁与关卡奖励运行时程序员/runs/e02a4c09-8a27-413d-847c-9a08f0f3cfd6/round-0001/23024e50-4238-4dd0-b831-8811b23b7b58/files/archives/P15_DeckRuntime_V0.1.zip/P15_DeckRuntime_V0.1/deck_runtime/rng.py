"""P02 xorshift32-v1 and descending Fisher-Yates with modulo selection.

This preserves the upstream deterministic fixture algorithm, including modulo
bias. It is not a cryptographic generator. No clock or global random state.
"""
from dataclasses import asdict, dataclass, replace
from .errors import integer, require
from .wire import MAX_INTEGER

MASK = 0xffffffff


def next_u32(state):
    integer(state, 1, MASK)
    state ^= (state << 13) & MASK
    state ^= state >> 17
    state ^= (state << 5) & MASK
    return state & MASK


def advance(state, count):
    """Verify a saved stream in logarithmic time, even for large draw_count."""
    integer(state, 1, MASK)
    integer(count)
    def apply(matrix, value):
        result = 0
        for bit in range(32):
            if value & (1 << bit):
                result ^= matrix[bit]
        return result
    matrix = tuple(next_u32(1 << bit) for bit in range(32))
    while count:
        if count & 1:
            state = apply(matrix, state)
        count >>= 1
        if count:
            matrix = tuple(apply(matrix, column) for column in matrix)
    return state


@dataclass(frozen=True, slots=True)
class RngState:
    initial_seed: int
    state: int
    draw_count: int
    algorithm: str = 'xorshift32-v1'

    def __post_init__(self):
        integer(self.initial_seed, 1, MASK)
        integer(self.state, 1, MASK)
        integer(self.draw_count)
        require(self.algorithm == 'xorshift32-v1', 'RNG_ALGORITHM_UNSUPPORTED')

    @classmethod
    def seeded(cls, seed):
        return cls(seed, seed, 0)

    @classmethod
    def from_value(cls, value):
        require(type(value) is dict and set(value) == {'initial_seed', 'state', 'draw_count', 'algorithm'}, 'RNG_SHAPE_INVALID')
        result = cls(**value)
        require(advance(result.initial_seed, result.draw_count) == result.state, 'RNG_HISTORY_INVALID')
        return result

    def next(self):
        require(self.draw_count < MAX_INTEGER, 'RNG_COUNT_EXHAUSTED')
        return replace(self, state=next_u32(self.state), draw_count=self.draw_count + 1)

    def value(self):
        return asdict(self)


def shuffle(items, rng):
    require(type(items) is tuple and isinstance(rng, RngState), 'IMMUTABLE_SHUFFLE_INPUT_REQUIRED')
    integer(len(items), 0, 4096)
    require(rng.draw_count + max(len(items) - 1, 0) <= MAX_INTEGER, 'RNG_COUNT_EXHAUSTED')
    values = list(items)
    for index in range(len(values) - 1, 0, -1):
        rng = rng.next()
        choice = rng.state % (index + 1)
        values[index], values[choice] = values[choice], values[index]
    return tuple(values), rng
