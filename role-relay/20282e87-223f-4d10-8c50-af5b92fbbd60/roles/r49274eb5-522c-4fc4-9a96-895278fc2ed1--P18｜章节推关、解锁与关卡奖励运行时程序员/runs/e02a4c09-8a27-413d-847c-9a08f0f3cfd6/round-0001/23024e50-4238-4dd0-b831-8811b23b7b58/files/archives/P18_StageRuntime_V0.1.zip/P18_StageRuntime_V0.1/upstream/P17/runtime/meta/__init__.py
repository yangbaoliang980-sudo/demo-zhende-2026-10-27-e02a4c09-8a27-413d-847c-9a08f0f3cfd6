"""P17-only metadata business rules; no persistence implementation."""
