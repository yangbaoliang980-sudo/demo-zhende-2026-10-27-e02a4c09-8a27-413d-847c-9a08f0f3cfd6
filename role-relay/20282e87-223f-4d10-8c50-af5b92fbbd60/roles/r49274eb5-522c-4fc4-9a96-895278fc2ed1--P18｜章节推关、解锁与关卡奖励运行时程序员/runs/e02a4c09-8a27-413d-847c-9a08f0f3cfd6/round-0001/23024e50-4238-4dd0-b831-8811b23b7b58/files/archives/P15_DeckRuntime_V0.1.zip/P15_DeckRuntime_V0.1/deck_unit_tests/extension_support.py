"""Test-only content extensions with original P03 files left unchanged."""
from dataclasses import replace
import hashlib,json
from deck_runtime import Catalog, CardSpec
from deck_runtime.wire import FrozenMessage,checked
from examples.support import ROOT,inputs,snapshot


def extended():
    context,recipe=inputs(policy_changes={'hand_limit':16})
    base=snapshot(context,recipe,enemy_count=2).value
    raw=(ROOT/'fixtures/extension_cards.fixture.json').read_bytes()
    doc=json.loads(raw)
    extra=[]
    for item in doc['cards']:
        item={**item,'effect_ids':tuple(item['effect_ids']),'effects':FrozenMessage.from_value(item['effects'])}
        extra.append(CardSpec(**item))
    catalog=Catalog(context.catalog.content_version,doc['format'],hashlib.sha256(raw).hexdigest(),context.catalog.cards+tuple(extra))
    context=replace(context,catalog=catalog)
    for n,c in enumerate(extra):
        iid='fixture:extension-'+str(n)
        base['card_instances'].append({'instance_id':iid,'card_id':c.card_id,'owner_unit_id':'hero_a'})
        base['zones']['hand'].append(iid)
    return context,checked(base,'BattleSnapshot')
