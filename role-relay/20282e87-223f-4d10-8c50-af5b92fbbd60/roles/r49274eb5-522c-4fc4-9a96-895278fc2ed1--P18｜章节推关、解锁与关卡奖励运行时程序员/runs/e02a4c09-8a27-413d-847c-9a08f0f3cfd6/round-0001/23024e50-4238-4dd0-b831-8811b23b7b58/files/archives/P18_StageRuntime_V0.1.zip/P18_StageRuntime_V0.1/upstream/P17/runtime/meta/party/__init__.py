"""Party-owned read projections."""
