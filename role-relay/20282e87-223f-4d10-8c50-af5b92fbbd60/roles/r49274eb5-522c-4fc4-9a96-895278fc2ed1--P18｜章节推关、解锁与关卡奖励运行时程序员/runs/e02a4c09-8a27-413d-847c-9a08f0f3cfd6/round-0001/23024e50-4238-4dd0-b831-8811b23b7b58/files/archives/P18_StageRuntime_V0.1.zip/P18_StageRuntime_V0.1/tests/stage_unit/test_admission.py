import unittest
from stage_runtime import FrozenMessage, StagePlanner, ClosedAuthority, progress_view, p13_view
from stage_runtime.common import fingerprint, StageError, validate_dto
from tests.support.harness import Harness, NORMAL, BOSS, changed_catalog


class AdmissionTests(unittest.TestCase):
    def setUp(self): self.h = Harness()

    def rejected(self, payload, reason):
        h = self.h; before = (h.model.stage.raw, h.model.meta.raw)
        req, result = h.plan('ENTER', payload)
        self.assertEqual(result.reason, reason, result.value())
        self.assertIsNone(result.candidate)
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

    def test_normal_entry_does_not_publish_during_plan(self):
        h = self.h; before = h.model.stage
        req, p = h.plan('ENTER', h.entry_payload())
        self.assertEqual(p.reason, 'ADMITTED'); self.assertEqual(h.model.stage, before)
        self.assertIsNone(p.candidate.value['grant'])
        params = p.candidate.value['battle_parameters']
        self.assertEqual(params['admission']['seed'], 1)
        self.assertEqual(params['enemy_refs'][0]['enemy_id'], 'MOCK_P06_ENEMY_001')
        h.model.submit(h.model.prepare(p.candidate)); self.assertEqual(h.balance(), 0)

    def test_locked_boss(self): self.rejected(self.h.entry_payload(BOSS), 'E_LOCKED_STAGE')

    def test_unknown_stage(self): self.rejected(self.h.entry_payload('fixture.unknown'), 'E_UNKNOWN_STAGE')

    def test_disabled_elite_reservation_is_not_stage(self):
        self.rejected(self.h.entry_payload('MOCK_P07_RESERVED_ELITE_ENTRY'), 'E_UNKNOWN_STAGE')

    def test_active_attempt_blocks_second_battle(self):
        self.h.enter(); self.rejected(self.h.entry_payload(battle_id='battle.B'), 'E_ACTIVE_ATTEMPT_EXISTS')

    def test_battle_id_never_reused_after_loss(self):
        self.h.enter(); self.h.settle(outcome='LOSS')
        self.rejected(self.h.entry_payload(), 'E_BATTLE_ID_REUSED')

    def test_valid_first_clear_unlocks_boss_without_level_gate(self):
        h = self.h; h.clear(); h.enter(BOSS, 'battle.B')
        self.assertEqual([c['level'] for c in h.model.meta.value['characters']], [1, 1, 1])
        self.assertEqual(h.model.stage.value['active_battle_id'], 'battle.B')

    def test_missing_entry_evidence(self):
        p = self.h.entry_payload(); self.h.authority.entries.clear()
        self.rejected(p, 'E_ENTRY_AUTHORITY_UNBOUND')

    def test_client_supplied_party_cannot_replace_trusted_reference(self):
        p = self.h.entry_payload(); p['party'] = ['fake1', 'fake2', 'fake3']
        self.rejected(p, 'E_SHAPE')

    def test_entry_other_scope_rejected(self):
        p = self.h.entry_payload(); e = self.h.authority.entries[p['entry_ref']].value
        e['player_save_scope_id'] = 'fixture.other'
        self.h.authority.entries[p['entry_ref']] = FrozenMessage.from_value(e)
        self.rejected(p, 'E_ENTRY_BINDING')

    def test_entry_other_battle_rejected(self):
        p = self.h.entry_payload(); p['battle_id'] = 'battle.other'
        self.rejected(p, 'E_ENTRY_BINDING')

    def test_entry_old_catalog_rejected(self):
        p = self.h.entry_payload(); self.h.switch_catalog(changed_catalog(self.h.catalog))
        self.rejected(p, 'E_ENTRY_BINDING')

    def test_invalid_seed_rejected(self):
        for seed in (0, True, -1, 2**32, '1'):
            with self.subTest(seed=seed):
                p = self.h.entry_payload(); p['seed'] = seed
                self.rejected(p, 'E_INTEGER')

    def test_duplicate_request_same_bytes(self):
        h = self.h; req, candidate, bundle, receipt = h.enter()
        result = h.planner.plan(req, h.model.stage)
        self.assertEqual(result.status, 'DUPLICATE_NO_OP')
        self.assertEqual(h.model.stage.value['revision'], 1)

    def test_request_id_collision(self):
        h = self.h; req, _, _, _ = h.enter()
        r = req.value; r['payload']['seed'] = 2
        self.assertEqual(h.planner.plan(FrozenMessage.from_value(r), h.model.stage).reason, 'E_REQUEST_ID_COLLISION')

    def test_stale_domain_revision(self):
        h = self.h; req = h.request('ENTER', h.entry_payload()); h.enter()
        self.assertEqual(h.planner.plan(req, h.model.stage).reason, 'E_REVISION_CONFLICT')

    def test_default_authority_closed(self):
        h = self.h; p = StagePlanner(h.catalog)
        result = p.plan(h.request('ENTER', h.entry_payload()), h.model.stage)
        self.assertEqual(result.reason, 'E_STORE_AUTHORITY_UNBOUND')

    def test_production_mode_blocked(self):
        with self.assertRaisesRegex(StageError, 'E_PRODUCTION_BOOTSTRAP_BLOCKED'):
            StagePlanner(self.h.catalog, mode='production')

    def test_unknown_operation_cannot_unlock(self):
        h = self.h
        for kind in ('DEBUG_UNLOCK', 'CLAIM_REWARD', 'ANKI_UNDO', 'PHASE_CHANGED', 'ANIMATION_END'):
            with self.subTest(kind=kind):
                result = h.planner.plan(h.request(kind, {}), h.model.stage)
                self.assertEqual(result.reason, 'E_COMMAND_KIND'); self.assertEqual(h.balance(), 0)

    def test_valid_p13_view_and_complete_detailed_view(self):
        h = self.h
        view = p13_view(h.model.stage, h.catalog)
        self.assertEqual(view.value['unlocked_stage_ids'], [NORMAL])
        validate_dto(view.value, 'StageProgressView')
        self.assertFalse(progress_view(h.model.stage, h.catalog).value['chapters'][0]['complete'])

    def test_frozen_candidate_mutation_does_not_change_bytes(self):
        h = self.h; _, r = h.plan('ENTER', h.entry_payload())
        raw = r.candidate.raw; v = r.candidate.value; v['after_state']['revision'] = 99
        self.assertEqual(r.candidate.raw, raw)

