"""P15 local errors. Not new P13 wire reply variants."""
import re
from .wire import MAX_INTEGER


class DeckRejected(ValueError):
    def __init__(self, code):
        if type(code) is not str or re.fullmatch('[A-Z][A-Z0-9_]{0,95}', code) is None:
            raise ValueError('INVALID_REJECTION_CODE')
        self.code = code
        super().__init__(code)


def require(condition, code):
    if not condition:
        raise DeckRejected(code)


def integer(value, low=0, high=MAX_INTEGER):
    require(type(value) is int and low <= value <= high, 'CONFIG_INTEGER_RANGE')


def identifier(value):
    require(type(value) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}', value) is not None, 'CONFIG_IDENTIFIER')


def sha256_text(value):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, 'CONFIG_SOURCE_HASH')
