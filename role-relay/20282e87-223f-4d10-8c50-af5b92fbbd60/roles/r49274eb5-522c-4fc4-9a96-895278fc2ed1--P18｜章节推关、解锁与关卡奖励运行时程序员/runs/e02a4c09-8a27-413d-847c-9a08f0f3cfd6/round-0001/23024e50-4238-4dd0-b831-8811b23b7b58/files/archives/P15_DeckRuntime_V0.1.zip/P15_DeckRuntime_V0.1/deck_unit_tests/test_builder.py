from dataclasses import FrozenInstanceError, replace
import json, unittest
from deck_runtime import build_deck, recipe_from_p03, DeckRejected
from deck_runtime.wire import ContractError, message, checked
from examples.support import ROOT, inputs, CATALOG_PATH, RECIPE_PATH


class BuildTests(unittest.TestCase):
    def test_instance_ids_bound_to_battle(self):
        ctx, recipe = inputs()
        a = build_deck(ctx.party, ctx.catalog, recipe, battle_id='battle:a', seed=1, mode='isolated')
        b = build_deck(ctx.party, ctx.catalog, recipe, battle_id='battle:b', seed=1, mode='isolated')
        self.assertFalse(set(a.deck.draw) & set(b.deck.draw))

    def test_instance_identity_independent_of_shuffle_seed(self):
        ctx, recipe = inputs()
        a = build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')
        b = build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=42, mode='isolated')
        self.assertEqual(a.deck.instances, b.deck.instances)
        self.assertNotEqual(a.deck.rng, b.deck.rng)

    def test_missing_common_owner_mapping_rejected(self):
        with self.assertRaisesRegex(DeckRejected, 'COMMON_CARD_OWNERS_REQUIRED'):
            recipe_from_p03(CATALOG_PATH.read_bytes(), RECIPE_PATH.read_bytes(), common_owner_slots=(), mode='isolated')

    def test_duplicate_party_character_rejected(self):
        with self.assertRaisesRegex(ContractError, 'DUPLICATE_PARTY'):
            inputs(chars=('A', 'A', 'C'))

    def test_party_requires_three_slots(self):
        ctx, recipe = inputs()
        p = ctx.party.value
        p['members'].pop()
        with self.assertRaises(ContractError):
            build_deck(p, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')

    def test_unknown_character_rejected(self):
        ctx, recipe = inputs(chars=('A','B','Z'))
        with self.assertRaisesRegex(DeckRejected, 'PARTY_CHARACTER_UNAVAILABLE'):
            build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')

    def test_production_build_explicitly_blocked(self):
        ctx, recipe = inputs()
        with self.assertRaisesRegex(DeckRejected, 'PRODUCTION_PARTY_UNBOUND'):
            build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='production')

    def test_recipe_catalog_hash_mismatch_rejected(self):
        ctx, recipe = inputs()
        recipe = replace(recipe, catalog_source_sha256='a'*64)
        with self.assertRaisesRegex(DeckRejected, 'RECIPE_CATALOG_MISMATCH'):
            build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')

    def test_build_is_immutable_and_does_not_change_party(self):
        ctx, recipe = inputs()
        before = ctx.party.raw
        a = build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')
        b = build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')
        self.assertEqual(a.deck, b.deck)
        self.assertEqual(a.provenance.raw, b.provenance.raw)
        self.assertEqual(ctx.party.raw, before)
        with self.assertRaises(FrozenInstanceError):
            a.deck.hand = ()
        view = a.deck.value()
        view['zones']['draw'].clear()
        self.assertEqual(len(a.deck.draw), 9)


def build_case(row):
    def test(self):
        chars = tuple(cid.rsplit('_',1)[-1] for cid in row['ordered_party_character_ids'])
        ctx, recipe = inputs(chars=chars)
        result = build_deck(ctx.party, ctx.catalog, recipe, battle_id=ctx.battle_id, seed=1, mode='isolated')
        self.assertEqual([c.card_id for c in result.deck.instances], [c['card_id'] for c in row['catalog_card_instances']])
        self.assertEqual(len(result.deck.instances), row['total_cards'])
        self.assertEqual(len(set(result.deck.draw)), row['total_cards'])
        owners = {m['unit_id']: m['character_id'] for m in ctx.party.value['members']}
        for inst in result.deck.instances:
            spec = ctx.catalog.card(inst.card_id)
            self.assertIn(inst.owner_unit_id, owners)
            if spec.owner_character_id is not None:
                self.assertEqual(owners[inst.owner_unit_id], spec.owner_character_id)
        self.assertEqual(result.deck.hand + result.deck.discard + result.deck.exhaust, ())
    return test


for row in json.loads(RECIPE_PATH.read_text())['fixtures']:
    setattr(BuildTests, 'test_upstream_' + row['fixture_id'], build_case(row))
