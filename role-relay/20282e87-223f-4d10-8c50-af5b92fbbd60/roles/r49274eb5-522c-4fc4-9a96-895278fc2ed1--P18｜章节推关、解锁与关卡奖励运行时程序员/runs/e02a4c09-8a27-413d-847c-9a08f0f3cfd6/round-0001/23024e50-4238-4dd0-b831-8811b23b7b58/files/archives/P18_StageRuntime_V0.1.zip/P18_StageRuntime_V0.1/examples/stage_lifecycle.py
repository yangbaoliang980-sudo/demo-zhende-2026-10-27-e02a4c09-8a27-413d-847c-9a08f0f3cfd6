"""Two-stage lifecycle; P18/P17 real code and an explicitly volatile store."""
from stage_runtime import progress_view, first_clear_identity
from tests.support.harness import Harness, NORMAL, BOSS


def run_demo():
    h = Harness('fixture.demo.save'); events = []
    initial_stage, initial_meta = h.model.stage.value, h.model.meta.value
    _, rejected = h.plan('ENTER', h.entry_payload(BOSS, 'fixture.illegal-skip'))
    assert rejected.reason == 'E_LOCKED_STAGE'

    def remember(out):
        req, candidate, bundle, receipt = out
        events.append({'request': req.value, 'candidate': candidate.value,
                       'bundle': bundle.value, 'receipt': receipt})

    remember(h.enter(NORMAL, 'demo.normal'))
    result = h.result('demo.normal'); remember(h.apply('SETTLE', {'result': result.value}))
    remember(h.enter(BOSS, 'demo.boss.loss'))
    result = h.result('demo.boss.loss', outcome='LOSS'); remember(h.apply('SETTLE', {'result': result.value}))
    remember(h.enter(BOSS, 'demo.boss.retry'))
    result = h.result('demo.boss.retry'); remember(h.apply('SETTLE', {'result': result.value}))
    remember(h.enter(NORMAL, 'demo.normal.repeat'))
    repeated = h.result('demo.normal.repeat'); remember(h.apply('SETTLE', {'result': repeated.value}))
    req, duplicate = h.plan('SETTLE', {'result': repeated.value})
    assert duplicate.status == 'DUPLICATE_NO_OP'
    h.model.reload()
    view = progress_view(h.model.stage, h.catalog)
    assert h.balance() == 15 and h.xp() == [22, 22, 22]
    assert view.value['chapters'][0]['complete']
    summary = {'task_id': 'P18-S07-STAGES-001', 'scope': 'ISOLATED_REAL_P18_P17_WITH_TEST_AUTHORITIES',
        'durable': False, 'tokens': h.balance(), 'xp_each': h.xp(), 'first_clear_count': len(h.model.stage.value['first_clears']),
        'stage_revision': h.model.stage.value['revision'], 'meta_revision': h.model.meta.value['revision'],
        'wallet_revision': h.model.meta.value['wallet_revision'], 'simulated_commits': len(events),
        'chapter_complete': view.value['chapters'][0]['complete'], 'illegal_skip': rejected.reason,
        'repeated_terminal': duplicate.reason, 'stage_sha256': h.model.stage.sha256, 'meta_sha256': h.model.meta.sha256}
    return {'schema_version': 'P18-DEMO-EXECUTION/0.1.0', 'summary': summary,
        'initial_stage': initial_stage, 'initial_meta': initial_meta, 'catalog_sha256': h.catalog.sha256,
        'events': events, 'duplicate_request': req.value, 'duplicate_verdict': duplicate.value(),
        'final_stage': h.model.stage.value, 'final_meta': h.model.meta.value, 'progress_view': view.value,
        'store_fence': h.authority.resolve_store(h.scope).value}


if __name__ == '__main__':
    import json
    print(json.dumps(run_demo(), ensure_ascii=False, indent=2))
