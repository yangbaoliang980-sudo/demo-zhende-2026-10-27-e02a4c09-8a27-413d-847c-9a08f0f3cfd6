"""Capture a real execution, exit code, raw output and exact pre-run sources."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, os, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]


def record(label, argv):
    if not label.replace('_', '').isalnum() or not argv:
        raise ValueError('invalid run arguments')
    out = ROOT / 'evidence/runs' / label
    out.mkdir(parents=True, exist_ok=False)
    selected = []
    for p in sorted(ROOT.rglob('*')):
        rel = p.relative_to(ROOT)
        if not p.is_file() or '__pycache__' in rel.parts or rel.parts[0] == 'evidence':
            continue
        if p.suffix in ('.py', '.json') and 'archives' not in rel.parts:
            selected.append(p)
    rows = []
    with zipfile.ZipFile(out / 'executed_sources.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for p in selected:
            raw = p.read_bytes()
            rel = p.relative_to(ROOT).as_posix()
            rows.append({'relative_path': rel, 'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
            z.writestr(rel, raw)
    (out / 'source_manifest.json').write_text(json.dumps(rows, indent=2) + '\n')
    start = datetime.now(timezone.utc).isoformat()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True, env=env)
    (out / 'stdout.log').write_bytes(proc.stdout)
    (out / 'stderr.log').write_bytes(proc.stderr)
    status = {'label': label, 'command': argv, 'portable_cwd': '.', 'started_utc': start,
        'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': proc.returncode,
        'scope': 'P15_AUTHOR_EXECUTION_NOT_P32_OR_P35',
        'source_snapshot_sha256': hashlib.sha256((out/'executed_sources.zip').read_bytes()).hexdigest(),
        'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest()}
    (out / 'execution.json').write_text(json.dumps(status, indent=2) + '\n')
    print(json.dumps(status, indent=2))
    sys.stdout.flush()
    sys.stdout.buffer.write(proc.stdout)
    sys.stderr.buffer.write(proc.stderr)
    return proc.returncode


if __name__ == '__main__':
    raise SystemExit(record(sys.argv[1], sys.argv[2:]))
