"""Re-plan P15 and re-execute P14 from commands, not from expected candidates."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from examples.support import inputs,core_for
from deck_runtime.wire import canonical,checked

path=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'examples/example_requests.json'
data=json.loads(path.read_text())
context,_=inputs()
initial=checked(data['initial_snapshot'],'BattleSnapshot')
core,planner,_=core_for(context,initial)
for item in data['requests']:
    cmd=checked(item['command'],'BattleCommand')
    assert core.state().sha256==item['before_state_sha256']
    reply=(core.submit_system if cmd.value['kind'].startswith('SYSTEM_') else core.submit)(cmd)
    assert reply.raw==canonical(item['reply'])
    assert core.state().sha256==item['after_state_sha256']
assert core.state().raw==canonical(data['state'])
assert [b.raw for b in core.committed_batches()]==[canonical(b) for b in data['batches']]
assert [d.evidence.raw for d in planner.decisions()]==[canonical(d) for d in data['decisions']]
assert core.export_replay().sha256==data['replay']['sha256']
print(json.dumps({'status':'PASS','scope':'AUTHOR_REPLANNED_P15_UNCHANGED_P14_ISOLATED',
    'request_count':len(data['requests']),'candidate_evidence_count':len(planner.decisions()),
    'final_state_sha256':core.state().sha256,'replay_sha256':core.export_replay().sha256},indent=2))
