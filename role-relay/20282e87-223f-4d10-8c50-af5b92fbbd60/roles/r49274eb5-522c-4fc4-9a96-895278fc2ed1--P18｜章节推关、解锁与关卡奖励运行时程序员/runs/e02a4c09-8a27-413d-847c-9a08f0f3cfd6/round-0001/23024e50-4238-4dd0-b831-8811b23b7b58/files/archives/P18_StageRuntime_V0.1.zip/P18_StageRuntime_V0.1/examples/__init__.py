"""Runnable demonstrations with explicit test authorities, never game bootstrap."""
