"""Verify package bytes, preserved upstream sources and recorded executions.

The manifest excludes itself; its bytes and the enclosing ZIP are bound by the
external delivery_receipt.json. This script is read-only and uses stdlib only.
"""
from pathlib import Path, PurePosixPath
import csv
import hashlib
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = 'delivery_manifest.sha256.tsv'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_path(relative):
    p = PurePosixPath(relative)
    if not relative or p.is_absolute() or '\\' in relative or any(x in ('', '.', '..') for x in relative.split('/')):
        raise ValueError('unsafe package path: ' + repr(relative))
    q = ROOT.joinpath(*p.parts)
    if any(x.is_symlink() for x in (q, *q.parents) if x != ROOT.parent):
        raise ValueError('symlink not permitted: ' + relative)
    return q


def check_bytes(raw, expected, label):
    if len(raw) != int(expected['size_bytes']) or sha(raw) != expected['sha256']:
        raise ValueError('size/SHA-256 mismatch: ' + label)


def verify():
    with (ROOT / MANIFEST).open(encoding='utf-8', newline='') as f:
        rows = list(csv.DictReader(f, delimiter='\t'))
    names = [r['relative_path'] for r in rows]
    if not rows or len(names) != len(set(names)) or MANIFEST in names:
        raise ValueError('empty, duplicated or self-referential manifest')
    for r in rows:
        check_bytes(safe_path(r['relative_path']).read_bytes(), r, r['relative_path'])
        for key in ('format', 'version', 'owner', 'recipients', 'modification_whitelist', 'source_input_hashes'):
            if not r.get(key):
                raise ValueError('missing manifest metadata: ' + key)
        for key in ('recipients', 'modification_whitelist', 'source_input_hashes'):
            if not isinstance(json.loads(r[key]), list):
                raise ValueError('manifest field must be a JSON array: ' + key)
    actual = set()
    for p in ROOT.rglob('*'):
        if p.is_symlink():
            raise ValueError('symlink not permitted: ' + str(p.relative_to(ROOT)))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            actual.add(p.relative_to(ROOT).as_posix())
    if actual != set(names) | {MANIFEST}:
        raise ValueError('unlisted/missing files: ' + repr(sorted(actual ^ (set(names) | {MANIFEST}))))

    receipt = json.loads((ROOT/'evidence/source_input_receipt.json').read_text(encoding='utf-8'))
    for r in receipt['sources']:
        check_bytes(safe_path(r['package_path']).read_bytes(), r, r['package_path'])
        if r['modification_whitelist']:
            raise ValueError('upstream source erroneously writable: ' + r['package_path'])
    preserved = {r['package_path'] for r in receipt['sources']}
    if preserved != {n for n in actual if n.startswith('upstream/')}:
        raise ValueError('source receipt does not enumerate every upstream original')

    p14_members = 0
    with zipfile.ZipFile(ROOT/'upstream/archives/P14_BattleCore_V0.1.zip') as z:
        bad = z.testzip()
        if bad:
            raise ValueError('upstream P14 ZIP CRC failure: ' + bad)
        for n in sorted(preserved):
            if n.startswith('upstream/P14/'):
                member = 'P14_BattleCore_V0.1/' + n[len('upstream/P14/'):]
                if safe_path(n).read_bytes() != z.read(member):
                    raise ValueError('P14 original differs from original ZIP: ' + n)
                p14_members += 1

    execution_count = snapshot_member_count = 0
    for run in sorted((ROOT/'evidence/runs').iterdir()):
        if not run.is_dir():
            raise ValueError('unexpected run file')
        record = json.loads((run/'execution.json').read_text(encoding='utf-8'))
        for filename, field in [('stdout.log','stdout_sha256'), ('stderr.log','stderr_sha256'), ('executed_sources.zip','source_snapshot_sha256')]:
            if sha((run/filename).read_bytes()) != record[field]:
                raise ValueError('recorded execution hash mismatch: ' + run.name + '/' + filename)
        snapshot = json.loads((run/'source_manifest.json').read_text(encoding='utf-8'))
        with zipfile.ZipFile(run/'executed_sources.zip') as z:
            if z.testzip() is not None or len(z.namelist()) != len(set(z.namelist())):
                raise ValueError('recorded source ZIP invalid: ' + run.name)
            if set(z.namelist()) != {r['relative_path'] for r in snapshot}:
                raise ValueError('recorded source members differ: ' + run.name)
            for r in snapshot:
                check_bytes(z.read(r['relative_path']), r, run.name+'/'+r['relative_path'])
                snapshot_member_count += 1
        execution_count += 1

    binding = json.loads((ROOT/'evidence/final_source_binding.json').read_text(encoding='utf-8'))
    for r in binding['files']:
        check_bytes(safe_path(r['relative_path']).read_bytes(), r, r['relative_path'])
        if r['sha256'] != r['tested_sha256']:
            raise ValueError('final source differs from tested source: ' + r['relative_path'])
    return {
        'status':'PASS', 'scope':'P15_AUTHOR_PACKAGE_INTEGRITY_NOT_INDEPENDENT_GATE',
        'manifest_records':len(rows), 'package_files':len(actual),
        'preserved_upstream_files':len(preserved), 'p14_files_equal_original_zip':p14_members,
        'recorded_executions':execution_count, 'execution_snapshot_members':snapshot_member_count,
        'final_test_source_bindings':len(binding['files']),
        'manifest_self_binding':'external delivery_receipt.json',
        'generated_python_cache_files':'ignored', 'production_gate':'BLOCKED',
    }


if __name__ == '__main__':
    try:
        print(json.dumps(verify(), ensure_ascii=False, indent=2))
    except (ValueError, KeyError, OSError, zipfile.BadZipFile) as exc:
        print(json.dumps({'status':'FAIL','error':str(exc)}, ensure_ascii=False, indent=2))
        sys.exit(1)
