from dataclasses import replace
import json, unittest
from deck_runtime import CardInstance, DeckState, RngState, draw_cards, shuffle_draw, discard_hand, consume_card, DeckRejected
from examples.support import ROOT


def deck(*, draw=(), hand=(), discard=(), exhaust=(), seed=1):
    ids = draw + hand + discard + exhaust
    return DeckState(tuple(CardInstance(i, 'fixture:card', 'hero_a') for i in ids), draw, hand, discard, exhaust, RngState.seeded(seed))


def apply_moves(initial, operation):
    # Independent test interpreter of P13's sequential remove-then-insert rule.
    zones = {z:list(initial.value()['zones'][z]) for z in ('draw','hand','discard','exhaust')}
    for m in operation.moves:
        assert m.instance_id in zones[m.from_zone]
        zones[m.from_zone].remove(m.instance_id)
        assert m.to_index <= len(zones[m.to_zone])
        zones[m.to_zone].insert(m.to_index,m.instance_id)
    return zones


class PileTests(unittest.TestCase):
    def assert_projection(self, old, op):
        self.assertEqual(apply_moves(old, op), op.after.value()['zones'])
        self.assertEqual(set(c.instance_id for c in old.instances), set(c.instance_id for c in op.after.instances))

    def test_upstream_F014_exact_pile_and_rng_projection(self):
        data = json.loads((ROOT/'upstream/P02/spec/battle/resolution/battle_replay_fixtures.json').read_text())
        case = next(c for c in data['cases'] if c['fixture_id'] == 'F014')
        s, expected = case['initial_state'], case['expected']['final_state']
        old = deck(discard=tuple(s['zones']['discard']))
        op = draw_cards(old, 1, hand_limit=10, recycle_discard=True)
        for zone in ('draw','hand','discard'):
            self.assertEqual(list(getattr(op.after,zone)), expected['zones'][zone])
        self.assertEqual(op.after.rng.state, expected['random']['state_u32'])
        self.assertEqual(op.after.rng.draw_count, expected['random']['draw_count'])
        self.assertEqual(op.recycled, 1)
        self.assert_projection(old, op)

    def test_both_piles_empty_shortfall_no_fatigue(self):
        old = deck()
        op = draw_cards(old, 5, hand_limit=10, recycle_discard=True)
        self.assertEqual((op.drawn,op.shortfall,op.moves,op.after), (0,5,(),old))

    def test_draws_from_left(self):
        old = deck(draw=('C1','C2','C3'))
        op = draw_cards(old, 2, hand_limit=10, recycle_discard=True)
        self.assertEqual((op.after.hand,op.after.draw), (('C1','C2'),('C3',)))
        self.assertEqual(op.after.rng,old.rng)
        self.assert_projection(old,op)

    def test_recycle_after_finishing_existing_draw(self):
        old=deck(draw=('A',),discard=('C1','C2','C3'))
        op=draw_cards(old,3,hand_limit=10,recycle_discard=True)
        self.assertEqual(op.after.hand,('A','C3','C2'))
        self.assertEqual(op.after.draw,('C1',))
        self.assert_projection(old,op)

    def test_recycle_disabled(self):
        old=deck(discard=('A','B'))
        op=draw_cards(old,2,hand_limit=10,recycle_discard=False)
        self.assertEqual(op.after,old)
        self.assertEqual(op.shortfall,2)

    def test_exhaust_never_recycled(self):
        old=deck(discard=('A',),exhaust=('X','Y'))
        op=draw_cards(old,5,hand_limit=10,recycle_discard=True)
        self.assertEqual((op.after.hand,op.after.exhaust,op.shortfall),(('A',),('X','Y'),4))
        self.assertEqual(op.after.rng,old.rng)

    def test_full_hand_preserves_draw_discard_and_rng(self):
        old=deck(hand=('H',),discard=('A','B'))
        op=draw_cards(old,2,hand_limit=1,recycle_discard=True)
        self.assertEqual(op.after,old)
        self.assertEqual(op.stopped_by,'HAND_LIMIT')

    def test_capacity_stops_without_consuming_extra_cards(self):
        old=deck(draw=('A','B','C'),hand=('H',))
        op=draw_cards(old,3,hand_limit=2,recycle_discard=True)
        self.assertEqual((op.after.hand,op.after.draw,op.shortfall),(('H','A'),('B','C'),2))

    def test_zero_request_does_not_shuffle_discard(self):
        old=deck(discard=('A','B','C'))
        op=draw_cards(old,0,hand_limit=10,recycle_discard=True)
        self.assertEqual(op.after,old)

    def test_discard_hand_appends_in_original_hand_order(self):
        old=deck(draw=('D',),hand=('H2','H1'),discard=('A',),exhaust=('X',))
        op=discard_hand(old)
        self.assertEqual(op.after.discard,('A','H2','H1'))
        self.assertEqual(op.after.hand,())
        self.assert_projection(old,op)

    def test_consume_exhaust_preserves_other_zones(self):
        old=deck(draw=('D',),hand=('H2','H1'),discard=('A',),exhaust=('X',))
        op=consume_card(old,'H1','exhaust')
        self.assertEqual(op.after.exhaust,('X','H1'))
        self.assertEqual(op.after.hand,('H2',))
        self.assertEqual(op.after.discard,old.discard)
        self.assert_projection(old,op)

    def test_double_consume_rejected_without_mutation(self):
        old=deck(hand=('H',))
        first=consume_card(old,'H','discard').after
        with self.assertRaisesRegex(DeckRejected,'CARD_NOT_IN_HAND'):
            consume_card(first,'H','discard')
        self.assertEqual(old.hand,('H',))
        self.assertEqual(first.discard,('H',))

    def test_reorder_same_zone_matches_sequential_move_interpreter(self):
        for n in (0,1,2,3,9,64):
            for seed in (1,2,42,0xffffffff):
                old=deck(draw=tuple('C'+str(i) for i in range(n)),seed=seed)
                op=shuffle_draw(old)
                self.assert_projection(old,op)
                self.assertEqual(op.after.rng.draw_count,max(0,n-1))

    def test_large_draw_shortfall_terminates(self):
        old=deck(draw=('D',),discard=('A','B'),exhaust=('X',))
        op=draw_cards(old,4096,hand_limit=4096,recycle_discard=True)
        self.assertEqual((op.drawn,op.shortfall,op.recycled),(3,4093,1))

    def test_bool_count_rejected(self):
        with self.assertRaises(DeckRejected):
            draw_cards(deck(),True,hand_limit=10,recycle_discard=True)

    def test_duplicate_zones_rejected(self):
        with self.assertRaises(DeckRejected):
            deck(draw=('A',),hand=('A',))

    def test_patch_capacity_rejects_whole_operation(self):
        old=deck(discard=tuple('C'+str(i) for i in range(4096)))
        with self.assertRaisesRegex(DeckRejected,'PATCH_CAPACITY_EXCEEDED'):
            draw_cards(old,4096,hand_limit=4096,recycle_discard=True)
        self.assertEqual(len(old.discard),4096)
        self.assertEqual(old.rng.draw_count,0)
