"""P14's isolated, render-free authoritative battle aggregate.

This is a real in-memory resolver using frozen upstream contracts. It is not a
production game bootstrap, a P15 deck implementation, or a P16 AI implementation.
"""

__version__ = '0.1.0-isolated'

from .core import BattleCore
from .model import Action, BossEdge, Dot, Effect, Reaction, Rules, SourceBinding
from .ports import CandidateRejected, DependencyUnavailable
from .wire import FrozenMessage, message

__all__ = ['BattleCore', 'Action', 'BossEdge', 'Dot', 'Effect', 'Reaction',
           'Rules', 'SourceBinding', 'CandidateRejected', 'DependencyUnavailable',
           'FrozenMessage', 'message']
