"""Validate actual executed messages with the unchanged P13 validator."""
from pathlib import Path
import importlib.util,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from deck_runtime.wire import checked
from examples.support import inputs

data=json.loads((ROOT/'examples/example_requests.json').read_text())
rows=[]
def add(value,name):
    checked(value,name)
    rows.append((value,name))

add(inputs()[0].party,'PartySnapshot')
add(data['initial_snapshot'],'BattleSnapshot')
for item in data['requests']:
    add(item['command'],'BattleCommand')
    add(item['reply'],'BattleReply')
for d in data['decisions']:
    if d['deck_patch'] is not None:add(d['deck_patch'],'DeckPatchCandidate')
for b in data['batches']:
    add(b,'BattleCommitBatch')
    add(b['snapshot'],'BattleSnapshot')
    for event in b['events']:add(event,'BattleEvent')
add(data['state'],'BattleState')
report={'status':'PASS','scope':'P15_AUTHOR_UNCHANGED_P13_VALIDATOR','validated_messages':len(rows)}
if '--jsonschema' in sys.argv:
    if importlib.util.find_spec('jsonschema') is None:
        print(json.dumps({**report,'algorithm_comparison':'NOT_RUN','dependency_gate':'BLOCKED','reason':'jsonschema package not installed in this Python; no network installation attempted'},indent=2))
        raise SystemExit(3)
    import jsonschema
    schema=json.loads((ROOT/'upstream/P13/contracts/internal/internal_dto.schema.json').read_text())
    for value,name in rows:
        if hasattr(value,'value'):value=value.value
        selected={**schema,'oneOf':[{'$ref':'#/$defs/'+name}]}
        jsonschema.Draft202012Validator(selected).validate(value)
    report['algorithm_comparison']='PASS'
print(json.dumps(report,indent=2))
