"""Isolated P18 stage domain. No production store or battle-result producer."""
from .common import (VERSION, FrozenMessage, StageError, PlanResult,
                     first_clear_identity, first_clear_key, repeat_identity)
from .content import Catalog, CatalogSet, load_catalog
from .ports import ClosedAuthority, UnboundP21
from .state import empty_state, validate_state, restore_state
from .service import StagePlanner, command
from .projection import progress_view, p13_view
from .transactions import prepare_atomic, validate_atomic

