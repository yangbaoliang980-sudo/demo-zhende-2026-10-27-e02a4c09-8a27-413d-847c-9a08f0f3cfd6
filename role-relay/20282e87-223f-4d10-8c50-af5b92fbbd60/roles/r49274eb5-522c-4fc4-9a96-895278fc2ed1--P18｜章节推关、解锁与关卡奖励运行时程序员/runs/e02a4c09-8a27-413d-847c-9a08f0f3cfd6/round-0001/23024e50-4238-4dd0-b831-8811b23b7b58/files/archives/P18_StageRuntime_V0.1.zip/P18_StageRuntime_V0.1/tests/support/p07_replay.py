"""P07 expectation adapter v0.1: runs the real P18 and P17 planners.

External battle observations and storage failures are explicit test doubles.
Expected outputs are read only for comparison, never as transition results.
Historical incomplete snapshots and unsupported UI/ID migrations are left
NOT_RUN; this adapter does not manufacture missing durable history.
"""
from stage_runtime import FrozenMessage, progress_view
from stage_runtime.common import fingerprint, get_row
from .harness import Harness, NORMAL, BOSS, changed_catalog
from .memory_model import InjectedFailure, SimulatedCommitUnknown

SELECTED = {1, 2, 3, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 24, 25, 26,
            28, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 55, 56, 57, 59, 61, 62, 67}
LABELS = {'ADMITTED': 'ADMITTED', 'FIRST_CLEAR': 'APPLIED_FIRST_CLEAR',
    'REPEAT_DISABLED': 'REPEAT_DISABLED_NO_AWARD', 'NO_CLEAR': 'CLOSED_NO_CLEAR',
    'FAULTED_NO_CLEAR': 'CLOSED_NO_CLEAR', 'ABORTED_NO_CLEAR': 'ABORTED_NO_CLEAR',
    'REVOKED_PENDING': 'INVALIDATED_PENDING_WIN', 'REVIEW_HOLD': 'REVIEW_HOLD_KEEP_TOMBSTONE',
    'E_LOCKED_STAGE': 'REJECT_LOCKED_STAGE', 'E_UNKNOWN_STAGE': 'REJECT_UNKNOWN_STAGE',
    'E_RESULT_AUTHORITY_UNBOUND': 'REJECT_UNTRUSTED_RESULT', 'E_UNTRUSTED_RESULT': 'REJECT_UNTRUSTED_RESULT',
    'E_RESULT_ADMISSION_BINDING': 'REJECT_ADMISSION_BINDING', 'E_SAVE_SCOPE_MISMATCH': 'REJECT_ADMISSION_BINDING',
    'E_TERMINAL_IDENTITY_COLLISION': 'REJECT_IDENTITY_PAYLOAD_CONFLICT',
    'REUSE_COMMITTED_RECEIPT': 'REUSE_COMMITTED_RECEIPT', 'E_STALE_TERMINAL': 'REJECT_STALE_TERMINAL',
    'E_ABORT_OR_FAULT_TOMBSTONE': 'REJECT_ABORT_TOMBSTONE', 'E_WAIT_FINAL_TERMINAL': 'WAIT_FINAL_TERMINAL',
    'E_COMMIT_UNKNOWN': 'BLOCKED_PENDING_RECONCILIATION',
    'QUARANTINE_MISSING_PINNED_CONTENT': 'QUARANTINE_MISSING_PINNED_CONTENT'}


def replay(case):
    initial = case['initial_state']
    assert initial['stage_progress'] == [], 'Historical fixture is not selected by this adapter'
    h = Harness(initial['player_save_scope_id']); decisions = []; awards = []; execution = []
    initial_view = progress_view(h.model.stage, h.catalog).value
    latest_results = {}; unknown_request = None; clawback = 0; partial_observed = False
    baseline_levels = [c['level'] for c in h.model.meta.value['characters']]
    baseline_foreign_study_revision = 0; foreign_study_revision = baseline_foreign_study_revision

    def run(kind, payload, commit='COMMITTED'):
        nonlocal unknown_request, clawback, partial_observed
        req, out = h.plan(kind, payload)
        row = {'request': req.value, 'plan_status': out.status, 'reason': out.reason,
               'candidate_sha256': None if out.candidate is None else out.candidate.sha256}
        execution.append(row)
        if out.status != 'CANDIDATE': return LABELS[out.reason]
        bundle = h.model.prepare(out.candidate); before = (h.model.stage.raw, h.model.meta.raw)
        before_money = h.balance()
        if commit in ('NOT_YET_COMMITTED', 'CRASH_BEFORE_COMMIT', 'ATOMIC_REJECTED', 'FAIL_DURING_ATOMIC_COMMIT'):
            point = 'after_wallet_prepared' if commit == 'FAIL_DURING_ATOMIC_COMMIT' else 'before_publish'
            try: h.model.submit(bundle, fail_at=point)
            except InjectedFailure: pass
            else: raise AssertionError('fault injection did not execute')
            partial_observed |= before != (h.model.stage.raw, h.model.meta.raw)
            row['simulated_failure'] = point
            return 'PENDING_NO_PUBLICATION'
        if commit == 'UNKNOWN':
            h.authority.bind_store(h.model.stage, 'COMMIT_UNKNOWN')
            row['publication'] = 'UNKNOWN_NOT_ASSERTED_DURABLE_ZERO'
            return 'RECONCILE_UNKNOWN_COMMIT'
        try:
            receipt = h.model.submit(bundle, fail_at='after_publish_unknown' if commit == 'COMMITTED_ACK_LOST' else None)
            row['receipt'] = receipt
        except SimulatedCommitUnknown:
            unknown_request = req.value['request_id']; row['simulated_failure'] = 'after_publish_unknown'
        c = out.candidate.value
        clawback += max(0, before_money - h.balance())
        if c['grant'] is not None:
            g = c['grant']; r = c['request']['payload']['result']; stage = h.catalog.stage(r['stage_id'])
            domain = 'FIRST_CLEAR' if c['decision'] == 'FIRST_CLEAR' else 'REPEAT_CLEAR'
            awards.append({'domain': domain, 'player_save_scope_id': h.scope, 'stage_id': r['stage_id'],
                'battle_id': r['battle_id'], 'terminal_revision': r['terminal_revision'],
                'reward_id': stage['first_reward_id'] if domain == 'FIRST_CLEAR' else stage['repeat_reward_id'],
                'party_character_ids': [x['character_id'] for x in g['xp']],
                'expected_shared_tokens': sum(x['amount'] for x in g['resources']),
                'expected_xp_each_character': g['xp'][0]['amount'] if g['xp'] else 0})
        return 'APPLIED_FIRST_CLEAR_ACK_LOST' if commit == 'COMMITTED_ACK_LOST' else LABELS[out.reason]

    for action in case['actions']:
        op = action['op']; before = (h.model.stage.raw, h.model.meta.raw)
        if op == 'ADMIT':
            assert action['party_character_ids'] == initial['party_character_ids']
            decisions.append(run('ENTER', h.entry_payload(action['stage_id'], action['battle_id'])))
        elif op == 'DELIVER_TERMINAL':
            bid = action['battle_id']; outcome = action['outcome']; rev = action['terminal_revision']
            r = h.result(bid, outcome=outcome, revision=rev)
            if outcome == 'FAULTED':
                decisions.append(run('CLOSE', {'battle_id': bid}, action['commit_outcome'])); continue
            p = h.authority.battles[bid].value
            p['result']['result_id'] = 'fixture.p07.' + fingerprint(action['payload_fingerprint'])
            if action.get('fallen_character_ids'):
                for u in p['snapshot']['units']:
                    if u['definition_id'] in action['fallen_character_ids']: u['hp'] = 0
                p['result']['final_snapshot_sha256'] = fingerprint(p['snapshot'])
            # Incoming malformed binding is independent of the trusted registry.
            incoming = dict(p['result']); incoming['stage_id'] = action['stage_id']; incoming['profile_scope'] = action['player_save_scope_id']
            latest_results[bid] = FrozenMessage.from_value(incoming)
            if action.get('terminal_final') is False: p['result'] = None
            h.authority.battles[bid] = FrozenMessage.from_value(p)
            if action['fixture_authority'] != 'VERIFIED_P14_ADAPTER': h.authority.battles.pop(bid)
            if action.get('admission_content_available') is False:
                h.switch_catalog(changed_catalog(h.catalog), keep_old=False)
            decisions.append(run('SETTLE', {'result': incoming}, action['commit_outcome']))
        elif op == 'AUTHORITATIVE_ABORT':
            h.result(action['battle_id'], outcome='ABORTED', revision=1)
            decisions.append(run('CLOSE', {'battle_id': action['battle_id']}))
        elif op == 'AUTHORITATIVE_REVOKE':
            ref = h.authority.issue_control(h.model.stage, action['battle_id'], latest_results[action['battle_id']], new_revision=action['revision'])
            decisions.append(run('REVOKE', {'control_ref': ref}))
        elif op == 'RESTART_SAME_SAVE_SCOPE':
            if unknown_request: h.model.lookup(unknown_request, resolve_unknown=True)
            h.model.reload()
            decisions.append('RESTORE_PENDING_RESULT' if h.model.stage.value['active_battle_id'] else 'RESTORED_COMMITTED_RECEIPT')
        elif op == 'UI_ACK_REWARD':
            assert h.planner.lookup_terminal(h.model.stage, action['battle_id']) is not None
            decisions.append('REUSE_COMMITTED_RECEIPT')
        elif op in ('RETURN_TO_CHAPTER_SELECT', 'CLOSE_RESULT_UI', 'SKIP_PRESENTATION_ONLY', 'EDIT_PARTY_UI_DRAFT'):
            progress_view(h.model.stage, h.planner.catalog)
            assert before == (h.model.stage.raw, h.model.meta.raw)
            decisions.append({'RETURN_TO_CHAPTER_SELECT': 'RETURNED', 'CLOSE_RESULT_UI': 'RETURNED_KEEPING_RECEIPT',
                'SKIP_PRESENTATION_ONLY': 'NO_GAMEPLAY_MUTATION', 'EDIT_PARTY_UI_DRAFT': 'DRAFT_ONLY'}[op])
        elif op == 'LOAD_NEW_REWARD_VERSION':
            h.switch_catalog(changed_catalog(h.catalog, normal_tokens=99))
            assert before == (h.model.stage.raw, h.model.meta.raw)
            decisions.append('PINNED_ACTIVE_BATTLE_UNCHANGED')
        elif op == 'RESUME_PINNED_BATTLE':
            h.result(action['battle_id'], outcome='ONGOING', phase='PLAYER_READY', revision=0)
            resumed = h.planner.resume(h.model.stage, action['battle_id'])
            assert resumed.value['admission']['battle_id'] == action['battle_id']
            decisions.append('RESUMED_SAME_BATTLE')
        else: raise NotImplementedError(op)
    state = h.model.stage.value; view = progress_view(h.model.stage, h.planner.catalog).value
    actual = {'decisions': decisions, 'award_events': awards,
        'new_first_entitlement_count': len(state['first_clears']),
        'new_repeat_award_count': sum(x['domain'] == 'REPEAT_CLEAR' for x in awards),
        'token_delta_by_save_scope': {h.scope: h.balance()} if h.balance() else {},
        'xp_delta_by_save_scope_and_character': [{'player_save_scope_id': h.scope, 'character_id': c['character_id'],
            'delta': c['xp_total']} for c in h.model.meta.value['characters'] if c['xp_total']],
        'automatic_clawback_tokens': clawback,
        'automatic_character_downgrade': any(c['level'] < old for c, old in zip(h.model.meta.value['characters'], baseline_levels)),
        'study_ledger_delta': foreign_study_revision - baseline_foreign_study_revision,
        'review_required_stage_ids': [s['stage_id'] for s in view['stages'] if s['review_required']]}
    active = get_row(state['attempts'], 'battle_id', state['active_battle_id'])
    queries = {'active_stage_id': None if active is None else active['admission']['stage_id'],
        'active_battle_id': state['active_battle_id'], 'first_entitlement_still_available': not state['first_clears'],
        'chapter_complete': all(c['complete'] for c in view['chapters']),
        'newly_effective_clear_stage_ids': [s['stage_id'] for s in view['stages'] if s['valid_confirmed_clear']],
        'newly_unlocked_stage_ids': [s['stage_id'] for s in view['stages'] if s['unlocked'] and not get_row(initial_view['stages'], 'stage_id', s['stage_id'])['unlocked']],
        'partial_publication_allowed': partial_observed,
        'publication_status': 'UNKNOWN_RECONCILE_REQUIRED' if h.authority.resolve_store(h.scope).value['status'] == 'COMMIT_UNKNOWN' else 'KNOWN_SIMULATION',
        'retained_consumed_first_stage_ids': [fc['stage_id'] for fc in state['first_clears']]}
    for key in case['expected']:
        if key not in actual: actual[key] = queries[key]
    return {'case_id': case['case_id'], 'actual': actual, 'expected': case['expected'],
            'status': 'PASS' if actual == case['expected'] else 'FAIL',
            'execution': execution, 'final_stage_sha256': h.model.stage.sha256, 'final_meta_sha256': h.model.meta.sha256,
            'scope': 'P18_P17_REAL_CODE_WITH_SYNTHETIC_AUTHORITY_AND_VOLATILE_STORE', 'durable': False}
