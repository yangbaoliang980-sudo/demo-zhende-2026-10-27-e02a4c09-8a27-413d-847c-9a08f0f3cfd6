"""Immutable stage snapshots and strict reload fences. No filesystem writes."""
from .common import (FrozenMessage, STATE_VERSION, need, shape, ident, integer,
    digest, array, unique_identifiers, fingerprint, first_clear_key, first_clear_identity,
    repeat_identity, validate_dto, get_row)

ATTEMPT_STATUSES = ('ACTIVE', 'SETTLED', 'ABORTED', 'FAULTED', 'REVOKED', 'QUARANTINED', 'REVIEW_REQUIRED')
DECISIONS = ('FIRST_CLEAR', 'REPEAT_CLEAR', 'REPEAT_DISABLED', 'NO_CLEAR')


def empty_state(catalog, *, player_save_scope_id, store_instance, continuity_ref):
    for v in (player_save_scope_id, store_instance, continuity_ref): ident(v)
    return FrozenMessage.from_value({'schema_version': STATE_VERSION,
        'player_save_scope_id': player_save_scope_id, 'store_instance': store_instance,
        'continuity_ref': continuity_ref, 'revision': 0, 'active_battle_id': None,
        'stages': [{'stage_id': s['stage_id'], 'confirmed_win_battles': [], 'review_required': False}
                   for s in sorted(catalog.value['stages'], key=lambda x: x['stage_id'])],
        'attempts': [], 'first_clears': [], 'controls': [], 'quarantines': [], 'operations': []})


def validate_admission(a):
    shape(a, 'player_save_scope_id battle_id stage_id chapter_id catalog_sha256 entry_ref entry_sha256 party_snapshot party_sha256 battle_rules_version battle_content_version battle_content_sha256 seed stage_config_sha256 reward_config_sha256 enemy_content_sha256 boss_graph_sha256 prerequisites')
    for k in ('player_save_scope_id', 'battle_id', 'stage_id', 'chapter_id', 'entry_ref', 'battle_rules_version', 'battle_content_version'): ident(a[k])
    for k in ('catalog_sha256', 'entry_sha256', 'party_sha256', 'battle_content_sha256', 'stage_config_sha256', 'reward_config_sha256', 'enemy_content_sha256', 'boss_graph_sha256'): digest(a[k])
    integer(a['seed'], 1, 2**32 - 1)
    party = validate_dto(a['party_snapshot'], 'PartySnapshot')
    need(party.sha256 == a['party_sha256'], 'E_PARTY_HASH')
    unique_identifiers([m['character_id'] for m in party.value['members']], 'E_PARTY_DUPLICATE')
    array(a['prerequisites'])
    for p in a['prerequisites']:
        shape(p, 'stage_id clear_receipt_ref first_clear_key')
        ident(p['stage_id']); ident(p['clear_receipt_ref']); digest(p['first_clear_key'])
        need(p['first_clear_key'] == first_clear_key(a['player_save_scope_id'], p['stage_id']), 'E_PREREQUISITE_KEY')
    unique_identifiers([p['stage_id'] for p in a['prerequisites']])


def validate_state(message, catalog):
    need(type(message) is FrozenMessage, 'E_STATE_TYPE')
    d = message.value
    shape(d, 'schema_version player_save_scope_id store_instance continuity_ref revision active_battle_id stages attempts first_clears controls quarantines operations')
    need(d['schema_version'] == STATE_VERSION, 'E_STATE_VERSION')
    for k in ('player_save_scope_id', 'store_instance', 'continuity_ref'): ident(d[k])
    integer(d['revision'])
    for k in ('stages', 'attempts', 'first_clears', 'controls', 'quarantines', 'operations'): array(d[k])
    if d['active_battle_id'] is not None: ident(d['active_battle_id'])
    for s in d['stages']:
        shape(s, 'stage_id confirmed_win_battles review_required')
        ident(s['stage_id']); unique_identifiers(s['confirmed_win_battles'])
        need(type(s['review_required']) is bool, 'E_REVIEW_FLAG')
    unique_identifiers([s['stage_id'] for s in d['stages']])
    need({s['stage_id'] for s in d['stages']} == {s['stage_id'] for s in catalog.value['stages']}, 'E_CONTENT_MIGRATION_REQUIRED')
    for at in d['attempts']:
        shape(at, 'battle_id admission admission_sha256 status high_revision terminal closure')
        ident(at['battle_id']); validate_admission(at['admission']); digest(at['admission_sha256'])
        a = at['admission']
        need(a['player_save_scope_id'] == d['player_save_scope_id'] and a['battle_id'] == at['battle_id'], 'E_ADMISSION_BINDING')
        need(a['stage_id'] in {s['stage_id'] for s in d['stages']}, 'E_UNKNOWN_STAGE')
        need(fingerprint(a) == at['admission_sha256'], 'E_ADMISSION_HASH')
        need(at['status'] in ATTEMPT_STATUSES, 'E_ATTEMPT_STATUS'); integer(at['high_revision'])
        if at['terminal'] is not None:
            t = at['terminal']
            shape(t, 'result result_sha256 decision receipt_ref grant_ref reward_identity')
            result = validate_dto(t['result'], 'BattleResult'); digest(t['result_sha256'])
            need(result.sha256 == t['result_sha256'], 'E_RESULT_HASH')
            r = result.value
            need((r['battle_id'], r['stage_id'], r['profile_scope']) == (at['battle_id'], a['stage_id'], d['player_save_scope_id']), 'E_TERMINAL_BINDING')
            need((r['rules_version'], r['content_version']) == (a['battle_rules_version'], a['battle_content_version']), 'E_TERMINAL_VERSION')
            need(at['high_revision'] >= r['terminal_revision'], 'E_TERMINAL_HIGH_WATER')
            need(t['decision'] in DECISIONS, 'E_DECISION'); ident(t['receipt_ref'])
            if t['grant_ref'] is not None: ident(t['grant_ref'])
            need((r['outcome'] != 'WIN') == (t['decision'] == 'NO_CLEAR'), 'E_DECISION_OUTCOME')
            expected_identity = (None if t['decision'] == 'NO_CLEAR' else
                first_clear_identity(d['player_save_scope_id'], a['stage_id']) if t['decision'] == 'FIRST_CLEAR' else
                repeat_identity(d['player_save_scope_id'], a['stage_id'], at['battle_id'], r['terminal_revision']))
            need(t['reward_identity'] == expected_identity, 'E_REWARD_IDENTITY')
        if at['closure'] is not None:
            shape(at['closure'], 'kind evidence_sha256 revision evidence')
            need(at['closure']['kind'] in ('ABORTED', 'FAULTED', 'REVOKED'), 'E_CLOSURE_KIND')
            digest(at['closure']['evidence_sha256']); integer(at['closure']['revision'], 1, at['high_revision'])
            need(fingerprint(at['closure']['evidence']) == at['closure']['evidence_sha256'], 'E_CLOSURE_HASH')
        if at['status'] == 'ACTIVE': need(at['terminal'] is None and at['closure'] is None, 'E_ACTIVE_TERMINAL')
        if at['status'] == 'SETTLED': need(at['terminal'] is not None and at['closure'] is None, 'E_SETTLEMENT_MISSING')
        if at['status'] in ('ABORTED', 'FAULTED', 'REVOKED'): need(at['closure'] is not None, 'E_CLOSURE_MISSING')
    unique_identifiers([x['battle_id'] for x in d['attempts']], 'E_BATTLE_ID_REUSED')
    active = [a['battle_id'] for a in d['attempts'] if a['status'] in ('ACTIVE', 'QUARANTINED')]
    need(active == ([] if d['active_battle_id'] is None else [d['active_battle_id']]), 'E_ACTIVE_ATTEMPT_SET')
    attempts = {x['battle_id']: x for x in d['attempts']}
    expected_wins = {s['stage_id']: [] for s in d['stages']}
    for at in d['attempts']:
        if at['terminal'] and at['terminal']['result']['outcome'] == 'WIN':
            expected_wins[at['admission']['stage_id']].append(at['battle_id'])
    for s in d['stages']:
        need(sorted(s['confirmed_win_battles']) == sorted(expected_wins[s['stage_id']]), 'E_CLEAR_RECEIPT_SET')
    for fc in d['first_clears']:
        shape(fc, 'key stage_id battle_id result_sha256 receipt_ref')
        digest(fc['key']); ident(fc['stage_id']); ident(fc['battle_id']); digest(fc['result_sha256']); ident(fc['receipt_ref'])
        need(fc['key'] == first_clear_key(d['player_save_scope_id'], fc['stage_id']), 'E_FIRST_CLEAR_KEY')
        at = attempts.get(fc['battle_id'])
        need(at is not None and at['terminal'] is not None, 'E_FIRST_CLEAR_RECEIPT')
        t = at['terminal']
        need((at['admission']['stage_id'], t['result_sha256'], t['receipt_ref'], t['decision']) ==
             (fc['stage_id'], fc['result_sha256'], fc['receipt_ref'], 'FIRST_CLEAR'), 'E_FIRST_CLEAR_BINDING')
    unique_identifiers([fc['key'] for fc in d['first_clears']], 'E_FIRST_CLEAR_DUPLICATE')
    need({fc['battle_id'] for fc in d['first_clears']} == {a['battle_id'] for a in d['attempts'] if a['terminal'] and a['terminal']['decision'] == 'FIRST_CLEAR'}, 'E_FIRST_CLEAR_SET')
    for c in d['controls']:
        shape(c, 'control_ref evidence_sha256 evidence decision')
        ident(c['control_ref']); digest(c['evidence_sha256']); need(fingerprint(c['evidence']) == c['evidence_sha256'], 'E_CONTROL_HASH')
        need(c['decision'] in ('REVOKED_PENDING', 'REVIEW_HOLD'), 'E_CONTROL_DECISION')
    unique_identifiers([c['control_ref'] for c in d['controls']], 'E_CONTROL_DUPLICATE')
    for q in d['quarantines']:
        shape(q, 'battle_id reason evidence_sha256 evidence')
        ident(q['battle_id']); ident(q['reason']); digest(q['evidence_sha256'])
        need(fingerprint(q['evidence']) == q['evidence_sha256'], 'E_QUARANTINE_HASH')
    for i, op in enumerate(d['operations'], 1):
        shape(op, 'request_id request_sha256 committed_revision')
        ident(op['request_id']); digest(op['request_sha256']); integer(op['committed_revision'], 1)
        need(op['committed_revision'] == i, 'E_REVISION_HISTORY')
    unique_identifiers([op['request_id'] for op in d['operations']], 'E_REQUEST_DUPLICATE')
    need(d['revision'] == len(d['operations']), 'E_REVISION_HISTORY')
    return d


def check_store_fence(snapshot, authority):
    d = snapshot.value
    proof = authority.resolve_store(d['player_save_scope_id'])
    need(type(proof) is FrozenMessage, 'E_STORE_AUTHORITY_UNBOUND')
    p = proof.value
    shape(p, 'schema_version player_save_scope_id store_instance continuity_ref revision state_sha256 status')
    need(p['schema_version'] == 'P18-STORE-FENCE/0.1.0-proposal', 'E_STORE_FENCE_VERSION')
    for k in ('player_save_scope_id', 'store_instance', 'continuity_ref'): ident(p[k])
    integer(p['revision']); digest(p['state_sha256'])
    need(p['status'] in ('CONSISTENT', 'COMMIT_UNKNOWN', 'RECONCILIATION_REQUIRED'), 'E_STORE_STATUS')
    need(p['status'] == 'CONSISTENT', 'E_COMMIT_UNKNOWN' if p['status'] == 'COMMIT_UNKNOWN' else 'E_RESTORE_RECONCILIATION_REQUIRED')
    need((p['player_save_scope_id'], p['store_instance'], p['continuity_ref']) ==
         (d['player_save_scope_id'], d['store_instance'], d['continuity_ref']), 'E_CONTINUITY_FENCE')
    need(p['revision'] == d['revision'] and p['state_sha256'] == snapshot.sha256, 'E_STORE_HEAD_MISMATCH')
    return proof


def restore_state(raw, catalog, authority):
    """P21 must supply a read fence external to the restored backup itself."""
    restored = FrozenMessage(raw)
    validate_state(restored, catalog)
    check_store_fence(restored, authority)
    return restored

