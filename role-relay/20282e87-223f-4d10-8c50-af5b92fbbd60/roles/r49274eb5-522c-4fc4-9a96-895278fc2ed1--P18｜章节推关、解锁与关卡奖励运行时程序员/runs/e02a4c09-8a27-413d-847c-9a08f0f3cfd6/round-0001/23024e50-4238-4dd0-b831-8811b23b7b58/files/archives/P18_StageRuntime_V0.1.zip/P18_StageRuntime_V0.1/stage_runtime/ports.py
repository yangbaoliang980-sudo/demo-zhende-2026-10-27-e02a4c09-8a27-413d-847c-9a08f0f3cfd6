"""Versioned proposals, not an implementation of P21 or an authentication flag."""
from typing import Protocol
from .common import FrozenMessage, StageError


class AuthorityPort(Protocol):
    """Trusted composition supplies a coherent read under P21's lock/CAS.

    Data supplied by UI/network must never be installed as an authority port.
    All four methods are read-only. Production ownership is P13/P14/P17/P21.
    """
    def resolve_store(self, scope: str) -> FrozenMessage | None: ...
    def resolve_entry(self, reference: str) -> FrozenMessage | None: ...
    def resolve_battle(self, battle_id: str) -> FrozenMessage | None: ...
    def resolve_control(self, reference: str) -> FrozenMessage | None: ...


class ClosedAuthority:
    def resolve_store(self, scope): return None
    def resolve_entry(self, reference): return None
    def resolve_battle(self, battle_id): return None
    def resolve_control(self, reference): return None


class WalletPort(Protocol):
    """P17 alone computes character XP and wallet/source changes."""
    def propose(self, grant: FrozenMessage, snapshot: FrozenMessage) -> FrozenMessage: ...
    def validate(self, grant: FrozenMessage, candidate: FrozenMessage,
                 snapshot: FrozenMessage) -> None: ...


class UnboundP21:
    def submit(self, bundle):
        raise StageError('E_P21_NOT_BOUND_NO_STATE_COMMITTED')

