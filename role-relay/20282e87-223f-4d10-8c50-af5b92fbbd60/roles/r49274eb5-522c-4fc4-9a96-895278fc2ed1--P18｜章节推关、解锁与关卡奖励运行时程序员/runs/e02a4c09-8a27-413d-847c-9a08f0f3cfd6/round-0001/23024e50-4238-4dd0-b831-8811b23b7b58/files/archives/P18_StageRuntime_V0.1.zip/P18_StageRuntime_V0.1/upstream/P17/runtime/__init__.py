"""Isolated P17 package; not a mapped game-engine directory."""
