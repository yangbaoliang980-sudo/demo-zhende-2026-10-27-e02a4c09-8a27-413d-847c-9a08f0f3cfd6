"""Only an isolated CLI demonstration; all receipts explicitly durable=false."""
import json
from examples.stage_lifecycle import run_demo
print(json.dumps(run_demo()['summary'], ensure_ascii=False, sort_keys=True, indent=2))
