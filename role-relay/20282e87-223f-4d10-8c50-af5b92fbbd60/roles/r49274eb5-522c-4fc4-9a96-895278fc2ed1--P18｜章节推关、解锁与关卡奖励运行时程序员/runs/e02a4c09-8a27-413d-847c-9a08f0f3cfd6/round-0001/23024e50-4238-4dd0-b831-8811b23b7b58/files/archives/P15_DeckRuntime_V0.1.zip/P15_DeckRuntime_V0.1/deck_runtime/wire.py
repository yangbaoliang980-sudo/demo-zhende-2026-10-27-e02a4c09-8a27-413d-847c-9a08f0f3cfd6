"""P13's original codec and DTO validator, imported without changing its bytes."""
from upstream.P13.runtime.framework.yltt_framework import CONTRACT_VERSION
from upstream.P13.runtime.framework.yltt_framework.codec import (
    ContractError, FrozenMessage, MAX_INTEGER, canonical, fingerprint,
)
from upstream.P13.runtime.framework.yltt_framework.contracts import validate


def checked(value, dto_type):
    if isinstance(value, FrozenMessage):
        value = value.value
    elif type(value) is bytes:
        value = FrozenMessage(value).value
    return validate(value, dto_type)


def message(dto_type, **fields):
    return checked(dict(contract_version=CONTRACT_VERSION, dto_type=dto_type, **fields), dto_type)
