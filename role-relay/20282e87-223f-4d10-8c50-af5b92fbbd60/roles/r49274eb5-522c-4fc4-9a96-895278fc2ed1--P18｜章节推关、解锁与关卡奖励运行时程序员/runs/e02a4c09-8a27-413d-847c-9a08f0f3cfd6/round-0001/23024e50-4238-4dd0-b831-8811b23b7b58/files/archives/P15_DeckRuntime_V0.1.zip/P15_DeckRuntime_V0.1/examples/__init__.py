"""Isolated author fixtures; no game bootstrap or real P17/P16 producer."""
