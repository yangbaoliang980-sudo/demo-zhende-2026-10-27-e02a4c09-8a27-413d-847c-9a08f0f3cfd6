import unittest
from stage_runtime import FrozenMessage
from tests.support.harness import Harness, BOSS
from tests.support.p14_native import start_native, finish_native, publish_native


class NativeContractTests(unittest.TestCase):
    def test_unmodified_p14_result_consumed_with_unmodified_p17(self):
        h = Harness(); core, at = start_native(h)
        result, command, reply = finish_native(h, core, at)
        self.assertEqual(result.raw, core.result().raw)
        self.assertEqual(result.value['final_snapshot_sha256'], core.snapshot(at['battle_id']).sha256)
        h.apply('SETTLE', {'result': result.value})
        self.assertEqual(h.balance(), 3); self.assertEqual(h.xp(), [4, 4, 4])
        self.assertTrue(h.stage_view(BOSS)['unlocked'])
        _, p = h.plan('SETTLE', {'result': result.value}); self.assertEqual(p.status, 'DUPLICATE_NO_OP')

    def test_unmodified_p14_abort_has_no_battle_result(self):
        h = Harness(); core, at = start_native(h)
        result, _, _ = finish_native(h, core, at, abort=True)
        self.assertIsNone(core.result()); self.assertIsNone(result)
        h.apply('CLOSE', {'battle_id': at['battle_id']})
        self.assertEqual(h.balance(), 0); self.assertFalse(h.stage_view(BOSS)['unlocked'])

    def test_native_resume_uses_original_battle_snapshot(self):
        h = Harness(); core, at = start_native(h); publish_native(h, core, at)
        resume = h.planner.resume(h.model.stage, at['battle_id'])
        self.assertEqual(resume.value['battle_snapshot'], core.snapshot(at['battle_id']).value)
        result, _, _ = finish_native(h, core, at); h.apply('SETTLE', {'result': result.value})
        self.assertEqual(h.balance(), 3)

    def test_p14_and_p18_retries_do_not_add_rewards(self):
        h = Harness(); core, at = start_native(h); r, cmd, _ = finish_native(h, core, at)
        h.apply('SETTLE', {'result': r.value}); old = (h.model.stage.raw, h.model.meta.raw)
        reply = core.submit(cmd)
        self.assertEqual(reply.value['result'], 'DUPLICATE_NO_OP')
        self.assertEqual(core.result().raw, r.raw)
        _, p = h.plan('SETTLE', {'result': r.value}); self.assertEqual(p.status, 'DUPLICATE_NO_OP')
        self.assertEqual(old, (h.model.stage.raw, h.model.meta.raw))

