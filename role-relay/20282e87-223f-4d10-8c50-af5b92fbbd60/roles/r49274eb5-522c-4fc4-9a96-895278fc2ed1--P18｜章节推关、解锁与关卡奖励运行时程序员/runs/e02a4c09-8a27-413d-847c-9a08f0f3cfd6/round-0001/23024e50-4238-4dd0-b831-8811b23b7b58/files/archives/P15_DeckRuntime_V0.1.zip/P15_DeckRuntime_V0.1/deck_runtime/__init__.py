"""P15 pure deck construction and card validation; isolated delivery only."""
__version__ = '0.1.0-isolated'

from .builder import DeckBuildCandidate, DeckRecipe, build_deck, recipe_from_p03
from .commands import DeckPlanner
from .content import CardSpec, Catalog, DeckPolicy, PlannerContext, compile_p03
from .deck import CardInstance, DeckOperation, DeckState, consume_card, discard_hand, draw_cards, shuffle_draw
from .errors import DeckRejected
from .planner import Decision, plan
from .rng import RngState, shuffle

__all__ = ['DeckBuildCandidate', 'DeckRecipe', 'build_deck', 'recipe_from_p03', 'DeckPlanner',
    'CardSpec', 'Catalog', 'DeckPolicy', 'PlannerContext', 'compile_p03', 'CardInstance',
    'DeckOperation', 'DeckState', 'consume_card', 'discard_hand', 'draw_cards', 'shuffle_draw',
    'DeckRejected', 'Decision', 'plan', 'RngState', 'shuffle']
