from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import unittest
from deck_runtime import DeckPlanner,DeckRejected,plan
from deck_runtime.wire import checked
from examples.support import inputs,snapshot,command,rules_for
from deck_runtime.p14_adapter import P14DeckAdapter
from upstream.P14.battle_core.ports import CandidateRejected


class CommandTests(unittest.TestCase):
    def setUp(self):
        self.ctx,r=inputs();self.s=snapshot(self.ctx,r);self.c=command(self.s)

    def test_pure_recompute_identical_candidate_bytes(self):
        a=plan(self.c,self.s,self.ctx);b=plan(self.c,self.s,self.ctx)
        self.assertEqual(a.evidence.raw,b.evidence.raw)
        self.assertEqual(a.candidate.raw,b.candidate.raw)

    def test_same_request_returns_original_evidence_before_revision_check(self):
        planner=DeckPlanner(self.ctx)
        old=planner.evaluate(self.c,self.s)
        later=self.s.value;later['revision']=3;later['energy']=0;later['phase']='ENEMY_READY'
        again=planner.evaluate(self.c,checked(later,'BattleSnapshot'))
        self.assertEqual(old.evidence.raw,again.evidence.raw)
        self.assertEqual(again.candidate.value['expected_revision'],0)

    def test_rejected_request_keeps_same_rejection_after_balance_changes(self):
        planner=DeckPlanner(self.ctx)
        poor=self.s.value;poor['energy']=0
        first=planner.evaluate(self.c,checked(poor,'BattleSnapshot'))
        again=planner.evaluate(self.c,self.s)
        self.assertEqual(first.code,'ENERGY_INSUFFICIENT')
        self.assertEqual(first.evidence.raw,again.evidence.raw)
        self.assertIsNone(again.candidate)

    def test_id_collision_for_changed_revision(self):
        planner=DeckPlanner(self.ctx);planner.evaluate(self.c,self.s)
        changed=self.c.value;changed['expected_revision']=1
        collision=planner.evaluate(changed,self.s)
        self.assertEqual(collision.code,'COMMAND_ID_COLLISION')
        self.assertIsNone(collision.candidate)

    def test_id_collision_for_changed_targets_is_stable(self):
        planner=DeckPlanner(self.ctx);first=planner.evaluate(self.c,self.s)
        changed=self.c.value;changed['payload']['target_ids']=['hero_b']
        one=planner.evaluate(changed,self.s)
        later=self.s.value;later['revision']=1
        two=planner.evaluate(changed,later)
        self.assertEqual(one.code,'COMMAND_ID_COLLISION')
        self.assertEqual(one.evidence.raw,two.evidence.raw)
        self.assertEqual(planner.evaluate(self.c,self.s).evidence.raw,first.evidence.raw)

    def test_memory_cache_not_a_commit_receipt(self):
        planner=DeckPlanner(self.ctx)
        result=planner.evaluate(self.c,self.s)
        self.assertEqual(result.evidence.value['status'],'CANDIDATE')
        self.assertEqual(self.s.value['energy'],3)
        self.assertEqual(self.s.value['revision'],0)
        self.assertNotIn('accepted_commands',result.evidence.value)

    def test_concurrent_24_identical_proposals_share_bytes(self):
        planner=DeckPlanner(self.ctx)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:planner.evaluate(self.c,self.s),range(24)))
        self.assertEqual(len({d.evidence.raw for d in results}),1)
        self.assertEqual(len(planner.decisions()),1)

    def test_cache_capacity_never_evicts_old_identity(self):
        planner=DeckPlanner(self.ctx,capacity=1);first=planner.evaluate(self.c,self.s)
        new=self.c.value;new['command_id']='new:request'
        with self.assertRaisesRegex(DeckRejected,'DECISION_CACHE_CAPACITY'):
            planner.evaluate(new,self.s)
        self.assertEqual(planner.evaluate(self.c,self.s).evidence.raw,first.evidence.raw)

    def test_returned_copies_cannot_mutate_cached_decision(self):
        planner=DeckPlanner(self.ctx);first=planner.evaluate(self.c,self.s)
        value=first.evidence.value;value['deck_patch']['energy_delta']=-999
        patch=first.candidate.value;patch['moves'].clear()
        self.assertEqual(planner.evaluate(self.c,self.s).evidence.raw,first.evidence.raw)
        self.assertEqual(first.candidate.value['energy_delta'],-1)

    def test_changed_context_cannot_reuse_prior_evidence(self):
        first=plan(self.c,self.s,self.ctx)
        context=replace(self.ctx,policy=replace(self.ctx.policy,version='fixture:other'))
        with self.assertRaisesRegex(DeckRejected,'PRIOR_CONTEXT_MISMATCH'):
            plan(self.c,self.s,context,prior=first)

    def test_adapter_refuses_cached_candidate_against_new_basis(self):
        adapter=P14DeckAdapter(DeckPlanner(self.ctx),rules_for(self.ctx),rejection_type=CandidateRejected)
        adapter.propose(self.c,self.s)
        changed=self.s.value;changed['energy']=2
        with self.assertRaisesRegex(CandidateRejected,'CACHED_CANDIDATE_BASIS_CHANGED'):
            adapter.propose(self.c,changed)
