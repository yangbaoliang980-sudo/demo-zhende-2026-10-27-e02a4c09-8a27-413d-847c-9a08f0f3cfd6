"""Frozen P15 projections. Content/balance and public DTO ownership stay upstream."""
from dataclasses import asdict, dataclass
import hashlib
from .errors import identifier, integer, require, sha256_text
from .wire import FrozenMessage, checked, fingerprint


@dataclass(frozen=True, slots=True)
class CardSpec:
    card_id: str
    cost: int
    target_side: str
    target_count: int
    owner_character_id: str | None
    after_play_zone: str
    playable: bool
    effect_ids: tuple[str, ...]
    effects: FrozenMessage

    def __post_init__(self):
        identifier(self.card_id)
        integer(self.cost)
        integer(self.target_count, 1, 4096)
        require(self.target_side in ('PLAYER', 'ENEMY'), 'TARGET_SIDE_UNSUPPORTED')
        if self.owner_character_id is not None:
            identifier(self.owner_character_id)
        require(self.after_play_zone in ('discard', 'exhaust'), 'AFTER_PLAY_ZONE_UNSUPPORTED')
        require(type(self.playable) is bool, 'CONFIG_PLAYABLE_BOOLEAN')
        require(type(self.effect_ids) is tuple and len(set(self.effect_ids)) == len(self.effect_ids), 'EFFECT_REFERENCES_INVALID')
        for eid in self.effect_ids:
            identifier(eid)
        require(isinstance(self.effects, FrozenMessage), 'IMMUTABLE_EFFECT_REFERENCES_REQUIRED')
        effects = self.effects.value
        require(type(effects) is list and tuple(e['effect_id'] for e in effects) == self.effect_ids, 'EFFECT_REFERENCES_INVALID')
        for effect in effects:
            integer(effect['amount'])
            require(effect['target_side'] == self.target_side, 'EFFECT_TARGET_MISMATCH')
            if self.playable:
                require(effect['effect_code'] in ('DAMAGE', 'SHIELD', 'HEAL', 'STATUS'), 'EFFECT_NOT_APPROVED_FOR_FIXTURE')
                if effect['effect_code'] == 'STATUS':
                    require(effect.get('status_kind') == 'DOT' and effect.get('tick_at') == 'OWNER_TURN_ENTER', 'STATUS_RULE_UNDEFINED')
                    identifier(effect['status_id'])
                    integer(effect['remaining_owner_turns'], 1)

    def value(self):
        return {'card_id': self.card_id, 'cost': self.cost, 'target_side': self.target_side,
                'target_count': self.target_count, 'owner_character_id': self.owner_character_id,
                'after_play_zone': self.after_play_zone, 'playable': self.playable,
                'effect_ids': list(self.effect_ids), 'effects': self.effects.value}


@dataclass(frozen=True, slots=True)
class Catalog:
    content_version: str
    source_version: str
    source_sha256: str
    cards: tuple[CardSpec, ...]

    def __post_init__(self):
        identifier(self.content_version)
        identifier(self.source_version)
        sha256_text(self.source_sha256)
        require(type(self.cards) is tuple and all(isinstance(c, CardSpec) for c in self.cards), 'IMMUTABLE_CATALOG_REQUIRED')
        require(len({c.card_id for c in self.cards}) == len(self.cards), 'DUPLICATE_CARD_DEFINITION')
        integer(len(self.cards), 1, 4096)

    def frozen(self):
        return FrozenMessage.from_value({'content_version': self.content_version, 'source_version': self.source_version,
            'source_sha256': self.source_sha256, 'cards': [c.value() for c in self.cards]})

    def card(self, card_id):
        found = next((c for c in self.cards if c.card_id == card_id), None)
        require(found is not None, 'CONTENT_UNAVAILABLE')
        return found


def compile_p03(raw, *, content_version, mode):
    require(mode == 'isolated', 'PRODUCTION_CONTENT_UNBOUND')
    require(type(raw) is bytes, 'ORIGINAL_CATALOG_BYTES_REQUIRED')
    data = FrozenMessage(raw).value
    require(data['format_version'] == 'P03-CARDS-0.1.0-draft' and data['release_status'] == 'ISOLATED_TEST_ONLY_NOT_APPROVED_FOR_RUNTIME', 'CATALOG_VERSION_UNSUPPORTED')
    effects = {e['effect_id']: e for e in data['effects']}
    require(len(effects) == len(data['effects']), 'DUPLICATE_EFFECT_DEFINITION')
    cards = []
    for c in data['cards']:
        t = c['target_rule']
        require(c['cost']['resource'] == 'BATTLE_ENERGY', 'COST_RESOURCE_UNSUPPORTED')
        require(t['selector'] == 'EXPLICIT_SINGLE' and t['target_count'] == 1 and t['living_only'] is True, 'TARGET_RULE_UNSUPPORTED')
        require(all(e in effects for e in c['effect_ids']), 'DANGLING_EFFECT_REFERENCE')
        require(c['trigger_code'] == 'ON_PLAY', 'TRIGGER_RULE_UNSUPPORTED')
        require(c['scope'] in ('COMMON', 'SIGNATURE', 'PROPOSED_COMMON'), 'CARD_SCOPE_UNSUPPORTED')
        require((c['scope'] == 'SIGNATURE') == (c['owner_character_id'] is not None), 'CARD_SCOPE_OWNER_MISMATCH')
        cards.append(CardSpec(c['card_id'], c['cost']['amount'], t['side'], t['target_count'],
            c['owner_character_id'], c['zone_after_play'].lower(), c['mock_playable'], tuple(c['effect_ids']),
            FrozenMessage.from_value([effects[e] for e in c['effect_ids']])))
    return Catalog(content_version, data['format_version'], hashlib.sha256(raw).hexdigest(), tuple(cards))


@dataclass(frozen=True, slots=True)
class DeckPolicy:
    version: str
    rules_version: str
    content_version: str
    initial_draw: int
    turn_draw: int
    hand_limit: int
    shuffle_initial: bool
    recycle_discard: bool
    end_turn: str
    entry_energy_mode: str
    entry_energy: int
    energy_cap: int

    def __post_init__(self):
        for v in (self.version, self.rules_version, self.content_version):
            identifier(v)
        require(self.rules_version == 'P02-BATTLE-0.1.0-draft', 'RULES_VERSION_UNSUPPORTED')
        for n in (self.initial_draw, self.turn_draw, self.hand_limit):
            integer(n, 0, 4096)
        for b in (self.shuffle_initial, self.recycle_discard):
            require(type(b) is bool, 'CONFIG_POLICY_BOOLEAN')
        require(self.end_turn in ('KEEP', 'DISCARD_ALL'), 'END_TURN_POLICY_UNSUPPORTED')
        require(self.entry_energy_mode in ('KEEP', 'SET', 'ADD_CAPPED'), 'ENERGY_POLICY_UNSUPPORTED')
        integer(self.entry_energy)
        integer(self.energy_cap)
        require(self.entry_energy <= self.energy_cap, 'ENERGY_POLICY_BOUNDS')
        require(self.entry_energy_mode != 'KEEP' or self.entry_energy == 0, 'UNUSED_ENERGY_CONFIG')

    def frozen(self):
        return FrozenMessage.from_value(asdict(self))


@dataclass(frozen=True, slots=True)
class PlannerContext:
    battle_id: str
    catalog: Catalog
    policy: DeckPolicy
    party: FrozenMessage
    mode: str

    def __post_init__(self):
        require(self.mode == 'isolated', 'PRODUCTION_DEPENDENCIES_UNBOUND')
        identifier(self.battle_id)
        require(isinstance(self.catalog, Catalog) and isinstance(self.policy, DeckPolicy), 'IMMUTABLE_CONTEXT_REQUIRED')
        require(isinstance(self.party, FrozenMessage), 'IMMUTABLE_PARTY_REQUIRED')
        checked(self.party, 'PartySnapshot')
        require(self.catalog.content_version == self.policy.content_version == self.party.value['content_version'], 'CONTENT_VERSION_MISMATCH')

    @property
    def sha256(self):
        return fingerprint({'battle_id': self.battle_id, 'catalog_sha256': self.catalog.frozen().sha256,
            'policy_sha256': self.policy.frozen().sha256, 'party_sha256': self.party.sha256, 'mode': self.mode})
