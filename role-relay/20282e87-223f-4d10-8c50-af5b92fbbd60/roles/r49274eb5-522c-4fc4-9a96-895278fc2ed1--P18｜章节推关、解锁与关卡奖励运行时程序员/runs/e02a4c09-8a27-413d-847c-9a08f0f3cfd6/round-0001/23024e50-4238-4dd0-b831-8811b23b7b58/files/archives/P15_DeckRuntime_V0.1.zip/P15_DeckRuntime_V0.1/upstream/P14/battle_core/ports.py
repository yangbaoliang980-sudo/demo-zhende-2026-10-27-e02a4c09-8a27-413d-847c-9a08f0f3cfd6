"""Only trusted composition supplies these pure candidates; no role flag grants it."""
from typing import Protocol
from .wire import FrozenMessage


class CandidateRejected(ValueError):
    """Isolated Python adapter's negative verdict; not a new P13 wire DTO.

    P13-RFC request in this delivery asks for a versioned negative reply shape.
    """
    def __init__(self, code):
        import re
        if not isinstance(code, str) or not re.fullmatch('[A-Z][A-Z0-9_]{0,95}', code):
            raise ValueError('INVALID_REJECTION_CODE')
        self.code = code
        super().__init__(code)


class DependencyUnavailable(RuntimeError):
    pass


class DeckPlanner(Protocol):
    def propose(self, command: FrozenMessage, snapshot: FrozenMessage) -> FrozenMessage: ...


class EnemyPlanner(Protocol):
    def propose(self, snapshot: FrozenMessage) -> FrozenMessage: ...


class SafetyFault(RuntimeError):
    """Requires gameplay rollback followed by a separate safety-only commit."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)
