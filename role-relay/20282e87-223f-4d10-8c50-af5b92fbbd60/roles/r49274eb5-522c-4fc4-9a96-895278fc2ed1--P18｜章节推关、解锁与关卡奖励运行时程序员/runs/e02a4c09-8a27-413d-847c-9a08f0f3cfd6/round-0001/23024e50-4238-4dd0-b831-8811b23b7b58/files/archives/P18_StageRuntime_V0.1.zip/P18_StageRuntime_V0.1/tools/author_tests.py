"""Run author tests; emits every actual outcome, never independent acceptance."""
import json
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class EvidenceResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs); self.rows = []; self.started = {}
    def startTest(self, test):
        self.started[test.id()] = time.monotonic(); super().startTest(test)
    def _row(self, test, status):
        self.rows.append({'test_id': test.id(), 'status': status})
    def addSuccess(self, test): super().addSuccess(test); self._row(test, 'PASS')
    def addError(self, test, err): super().addError(test, err); self._row(test, 'ERROR')
    def addFailure(self, test, err): super().addFailure(test, err); self._row(test, 'FAIL')
    def addSkip(self, test, reason): super().addSkip(test, reason); self._row(test, 'NOT_RUN')
    def addSubTest(self, test, subtest, err):
        super().addSubTest(test, subtest, err)
        if err is not None: self._row(subtest, 'FAIL_SUBTEST')


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.discover(str(ROOT/'tests/stage_unit'), pattern='test_*.py', top_level_dir=str(ROOT))
    result = unittest.TextTestRunner(verbosity=2, resultclass=EvidenceResult).run(suite)
    print(json.dumps({'layer': 'AUTHOR_UNIT_AND_ISOLATED_CONTRACT_TESTS',
        'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors),
        'skipped': len(result.skipped), 'successful': result.wasSuccessful(), 'results': result.rows,
        'P32': 'NOT_RUN', 'P33': 'NOT_RUN', 'P35': 'NOT_RUN', 'P21_durable': 'NOT_RUN'}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)

