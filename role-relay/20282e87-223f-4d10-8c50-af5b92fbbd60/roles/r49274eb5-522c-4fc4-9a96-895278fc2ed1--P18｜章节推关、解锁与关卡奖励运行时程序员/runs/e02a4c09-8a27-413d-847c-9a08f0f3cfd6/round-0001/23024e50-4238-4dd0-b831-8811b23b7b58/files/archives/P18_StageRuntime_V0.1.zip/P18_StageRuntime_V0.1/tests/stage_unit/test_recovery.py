import unittest
from stage_runtime import FrozenMessage, restore_state, p13_view, StageError, ClosedAuthority
from stage_runtime.common import fingerprint
from tests.support.harness import Harness, NORMAL, BOSS
from tests.support.memory_model import InjectedFailure, SimulatedCommitUnknown


class RecoveryTests(unittest.TestCase):
    def setUp(self): self.h = Harness()

    def test_authoritative_abort_then_new_battle(self):
        h = self.h; h.enter(); h.result(outcome='ABORTED')
        _, c, _, _ = h.apply('CLOSE', {'battle_id': 'battle.A'})
        self.assertEqual(c.value['decision'], 'ABORTED_NO_CLEAR'); self.assertEqual(h.balance(), 0)
        h.enter(NORMAL, 'battle.B')

    def test_faulted_snapshot_closes_without_result(self):
        h = self.h; h.enter(); self.assertIsNone(h.result(outcome='FAULTED'))
        h.apply('CLOSE', {'battle_id': 'battle.A'})
        self.assertEqual(h.balance(), 0); self.assertFalse(h.stage_view(BOSS)['unlocked'])

    def test_cannot_turn_active_battle_into_ui_abort(self):
        h = self.h; h.enter(); h.result(outcome='ONGOING', phase='PLAYER_READY')
        _, p = h.plan('CLOSE', {'battle_id': 'battle.A'})
        self.assertEqual(p.reason, 'E_AUTHORITATIVE_CLOSURE_REQUIRED')

    def test_cannot_close_existing_win_to_avoid_settlement(self):
        h = self.h; h.enter(); h.result()
        _, p = h.plan('CLOSE', {'battle_id': 'battle.A'})
        self.assertEqual(p.reason, 'E_AUTHORITATIVE_CLOSURE_REQUIRED')

    def test_abort_tombstone_blocks_late_win(self):
        h = self.h; h.enter(); h.result(outcome='ABORTED')
        h.apply('CLOSE', {'battle_id': 'battle.A'}); r = h.result(revision=3)
        _, p = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(p.reason, 'E_ABORT_OR_FAULT_TOMBSTONE'); self.assertEqual(h.balance(), 0)

    def test_duplicate_close_noop(self):
        h = self.h; h.enter(); h.result(outcome='ABORTED'); h.apply('CLOSE', {'battle_id': 'battle.A'})
        _, p = h.plan('CLOSE', {'battle_id': 'battle.A'})
        self.assertEqual(p.reason, 'REUSE_CLOSURE_RECEIPT')

    def test_pause_resume_same_pinned_battle(self):
        h = self.h; h.enter(); h.result(outcome='ONGOING', phase='PLAYER_READY')
        before = h.model.stage.raw; resumed = h.planner.resume(h.model.stage, 'battle.A')
        self.assertEqual(resumed.value['admission']['battle_id'], 'battle.A')
        self.assertEqual(before, h.model.stage.raw); h.settle(); self.assertEqual(h.balance(), 3)

    def test_resume_finished_battle_routes_to_settlement(self):
        h = self.h; h.enter(); h.result()
        with self.assertRaisesRegex(StageError, 'E_TERMINAL_REQUIRES_SETTLEMENT'):
            h.planner.resume(h.model.stage, 'battle.A')

    def test_memory_reload_preserves_stage_and_receipts(self):
        h = self.h; r, _ = h.clear(); before = (h.model.stage.raw, h.model.meta.raw)
        h.model.reload(); self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))
        _, p = h.plan('SETTLE', {'result': r.value}); self.assertEqual(p.status, 'DUPLICATE_NO_OP')
        self.assertEqual(h.balance(), 3)

    def test_older_snapshot_rejected_by_retained_head(self):
        h = self.h; old = h.model.stage; h.clear()
        with self.assertRaisesRegex(StageError, 'E_STORE_HEAD_MISMATCH'):
            restore_state(old.raw, h.catalog, h.authority)

    def test_missing_external_continuity_cannot_prove_backup(self):
        h = self.h; h.clear()
        with self.assertRaisesRegex(StageError, 'E_STORE_AUTHORITY_UNBOUND'):
            restore_state(h.model.stage.raw, h.catalog, ClosedAuthority())

    def test_explicit_restore_reconciliation_blocks(self):
        h = self.h; h.authority.bind_store(h.model.stage, 'RECONCILIATION_REQUIRED')
        _, p = h.plan('ENTER', h.entry_payload())
        self.assertEqual(p.reason, 'E_RESTORE_RECONCILIATION_REQUIRED')

    def test_renaming_storage_file_does_not_change_key(self):
        h = self.h; h.clear(); first = h.model.stage.value['first_clears'][0]['key']
        # No filesystem path or device ID is present in the serialized identity.
        raw = bytes(h.model.stage.raw); restored = restore_state(raw, h.catalog, h.authority)
        self.assertEqual(restored.value['first_clears'][0]['key'], first)
        h.clear(NORMAL, 'battle.B'); self.assertEqual(h.balance(), 3)

    def test_revoke_before_award_invalidates_pending_win(self):
        h = self.h; h.enter(); r = h.result(); _, p = h.plan('SETTLE', {'result': r.value})
        held = h.model.prepare(p.candidate)
        h.revoke('battle.A', r)
        self.assertEqual(h.balance(), 0); self.assertFalse(h.stage_view(BOSS)['unlocked'])
        self.assertEqual(h.model.stage.value['first_clears'], [])
        _, again = h.plan('SETTLE', {'result': r.value}); self.assertEqual(again.reason, 'E_STALE_TERMINAL')
        with self.assertRaises(StageError): h.model.submit(held)
        h.clear(NORMAL, 'battle.B'); self.assertEqual(h.balance(), 3)

    def test_revoke_after_award_keeps_first_clear_tombstone(self):
        h = self.h; r, _ = h.clear(); before_meta = h.model.meta.raw
        h.revoke('battle.A', r)
        self.assertEqual(h.model.meta.raw, before_meta); self.assertEqual(h.balance(), 3)
        v = h.stage_view(NORMAL)
        self.assertTrue(v['first_clear_consumed']); self.assertFalse(v['valid_confirmed_clear'])
        self.assertTrue(v['review_required']); self.assertFalse(h.stage_view(BOSS)['unlocked'])

    def test_prerequisite_under_review_blocks_boss_entry(self):
        h = self.h; r, _ = h.clear(); h.revoke('battle.A', r)
        _, p = h.plan('ENTER', h.entry_payload(BOSS, 'battle.B'))
        self.assertEqual(p.reason, 'E_PREREQUISITE_UNDER_REVIEW')

    def test_prerequisite_revoked_while_boss_inflight_quarantines_award(self):
        h = self.h; normal, _ = h.clear(); h.enter(BOSS, 'battle.B')
        h.revoke('battle.A', normal); result = h.result('battle.B')
        _, c, _, _ = h.apply('SETTLE', {'result': result.value})
        self.assertEqual(c.value['decision'], 'QUARANTINE_PREREQUISITE_REVOKED')
        self.assertEqual(h.balance(), 3); self.assertEqual(h.xp(), [4, 4, 4])
        self.assertFalse(h.stage_view(BOSS)['first_clear_consumed'])

    def test_untrusted_revocation_no_freeze(self):
        h = self.h; h.clear(); before = h.model.stage.raw
        _, p = h.plan('REVOKE', {'control_ref': 'fixture.fake'})
        self.assertEqual(p.reason, 'E_CONTROL_AUTHORITY_UNBOUND'); self.assertEqual(before, h.model.stage.raw)

    def test_repeated_revocation_is_noop(self):
        h = self.h; r, _ = h.clear(); h.revoke('battle.A', r)
        before = (h.model.stage.raw, h.model.meta.raw)
        _, p = h.plan('REVOKE', {'control_ref': 'fixture.revoke'})
        self.assertEqual(p.reason, 'REUSE_REVIEW_RECEIPT')
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

    def test_revoke_receipt_id_collision(self):
        h = self.h; r, _ = h.clear(); h.revoke('battle.A', r)
        c = h.authority.controls['fixture.revoke'].value; c['new_revision'] += 1
        h.authority.controls['fixture.revoke'] = FrozenMessage.from_value(c)
        _, p = h.plan('REVOKE', {'control_ref': 'fixture.revoke'})
        self.assertEqual(p.reason, 'E_CONTROL_ID_COLLISION')

    def test_legacy_view_rejects_lossy_review_projection(self):
        h = self.h; r, _ = h.clear(); h.revoke('battle.A', r)
        with self.assertRaisesRegex(StageError, 'E_EXTENDED_PROGRESS_VIEW_REQUIRED'):
            p13_view(h.model.stage, h.catalog)

    def test_readonly_reward_query_does_not_claim(self):
        h = self.h; h.clear(); before = (h.model.stage.raw, h.model.meta.raw)
        receipt = h.planner.lookup_terminal(h.model.stage, 'battle.A')
        self.assertEqual(receipt.value['decision'], 'FIRST_CLEAR')
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

