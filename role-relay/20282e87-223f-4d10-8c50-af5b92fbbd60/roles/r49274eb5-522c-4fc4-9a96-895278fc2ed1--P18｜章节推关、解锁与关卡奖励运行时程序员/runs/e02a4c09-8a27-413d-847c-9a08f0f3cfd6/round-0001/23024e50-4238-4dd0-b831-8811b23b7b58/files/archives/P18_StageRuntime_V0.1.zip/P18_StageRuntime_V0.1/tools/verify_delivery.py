"""Verify manifest size, hashes and exact file set without changing the package."""
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT/'tools'))
from check_sources import run as check_sources


def run():
    manifest = json.loads((ROOT/'delivery_manifest.json').read_text(encoding='utf-8'))
    errors = []; expected = {'delivery_manifest.json'}
    for row in manifest['files']:
        rel = row['relative_path']; expected.add(rel); p = ROOT/rel
        if not p.is_file(): errors.append({'path': rel, 'error': 'MISSING'}); continue
        raw = p.read_bytes()
        if len(raw) != row['size_bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            errors.append({'path': rel, 'error': 'HASH_OR_SIZE_MISMATCH'})
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual != expected:
        errors.append({'error': 'FILE_SET_MISMATCH', 'missing': sorted(expected-actual), 'extra': sorted(actual-expected)})
    sources = check_sources()
    errors.extend(sources['errors'])
    return {'status': 'PASS' if not errors else 'FAIL', 'files_checked': len(manifest['files']),
            'manifest_self_hash': hashlib.sha256((ROOT/'delivery_manifest.json').read_bytes()).hexdigest(),
            'source_files_checked': sources['copied_inputs_checked'], 'errors': errors,
            'note': 'Manifest self and ZIP bound by external P18_delivery_receipt.json; no circular hash.'}


if __name__ == '__main__':
    report = run(); print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['status'] == 'PASS' else 1)
