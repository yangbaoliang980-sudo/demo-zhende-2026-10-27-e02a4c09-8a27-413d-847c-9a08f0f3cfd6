import json
import subprocess
import sys
import unittest
from stage_runtime.common import PACKAGE_ROOT
from tests.support.harness import Harness, BOSS


class ProcessReloadTests(unittest.TestCase):
    def test_child_process_preserves_scope_chapter_and_first_clear(self):
        h = Harness(); h.clear(); h.clear(BOSS, 'battle.B')
        data = {'snapshot': h.model.stage.value, 'fixture_fence': h.authority.resolve_store(h.scope).value}
        p = subprocess.run([sys.executable, '-B', str(PACKAGE_ROOT/'tools/reload_from_stdin.py')],
            input=json.dumps(data).encode(), capture_output=True)
        self.assertEqual(p.returncode, 0, p.stderr.decode()); result = json.loads(p.stdout)
        self.assertEqual(result['sha256'], h.model.stage.sha256)
        self.assertTrue(result['view']['chapters'][0]['complete'])
        self.assertEqual(len([s for s in result['view']['stages'] if s['first_clear_consumed']]), 2)
