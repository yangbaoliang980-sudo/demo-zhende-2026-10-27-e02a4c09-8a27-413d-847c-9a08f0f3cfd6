"""Test composition only: real P15 + unchanged P14; P17/P16 remain fixtures."""
from dataclasses import replace
import json
from pathlib import Path
from deck_runtime import (
    Catalog, DeckPlanner, DeckPolicy, PlannerContext, build_deck, compile_p03, recipe_from_p03,
)
from deck_runtime.p14_adapter import P14DeckAdapter
from deck_runtime.wire import FrozenMessage, checked, message
from upstream.P14.battle_core import BattleCore, Action, Effect, Dot, Rules, SourceBinding, CandidateRejected

ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / 'upstream/P03/content/cards/card_catalog.json'
RECIPE_PATH = ROOT / 'upstream/P03/content/cards/deck_build_fixtures.json'


def inputs(*, battle_id='fixture:P15-battle', chars=('A', 'B', 'C'), policy_changes=None, catalog=None):
    config = json.loads((ROOT / 'fixtures/deck_policy.fixture.json').read_text())
    policy = DeckPolicy(**{**config['policy'], **(policy_changes or {})})
    if catalog is None:
        catalog = compile_p03(CATALOG_PATH.read_bytes(), content_version=policy.content_version, mode='isolated')
    party = message('PartySnapshot', party_id='fixture:P15-party', revision=0, content_version=policy.content_version,
        members=[{'unit_id': 'hero_' + char.lower(), 'character_id': 'MOCK_P03_CHAR_' + char,
                  'slot': i, 'max_hp': 10, 'attack': 1, 'defense': 0} for i, char in enumerate(chars)])
    context = PlannerContext(battle_id, catalog, policy, party, 'isolated')
    recipe = recipe_from_p03(CATALOG_PATH.read_bytes(), RECIPE_PATH.read_bytes(),
                            common_owner_slots=tuple(config['common_owner_slots']), mode='isolated')
    return context, recipe


def snapshot(context, recipe, *, ready=True, seed=1, enemy_hp=100, enemy_count=1):
    built = build_deck(context.party, context.catalog, recipe, battle_id=context.battle_id, seed=seed, mode='isolated')
    d = built.deck.value()
    if ready:
        d['zones']['hand'], d['zones']['draw'] = d['zones']['draw'], []
    units = [{'unit_id': m['unit_id'], 'definition_id': m['character_id'], 'side': 'PLAYER',
              'slot': m['slot'], 'hp': m['max_hp'], 'max_hp': m['max_hp'], 'shield': 0, 'statuses': []}
             for m in context.party.value['members']]
    units += [{'unit_id': 'enemy' + str(i + 1), 'definition_id': 'fixture:enemy', 'side': 'ENEMY',
               'slot': i, 'hp': enemy_hp, 'max_hp': enemy_hp, 'shield': 0, 'statuses': []} for i in range(enemy_count)]
    return message('BattleSnapshot', battle_id=context.battle_id, revision=0,
        rules_version=context.policy.rules_version, content_version=context.policy.content_version,
        phase='PLAYER_READY' if ready else 'CREATED', turn_number=1 if ready else 0,
        energy=3 if ready else 0, units=units, **d, last_event_seq=0, outcome='ONGOING', boss_states=[])


def command(snap, *, request_id='fixture:play-1', kind='PLAY_CARD', card_id='MOCK_P03_CARD_STRIKE',
            instance_id=None, actor_id=None, targets=None):
    s = snap.value if isinstance(snap, FrozenMessage) else snap
    payload = {}
    if kind == 'PLAY_CARD':
        inst = next(i for i in s['card_instances'] if
            (i['instance_id'] == instance_id if instance_id is not None else i['card_id'] == card_id))
        payload = {'actor_id': actor_id or inst['owner_unit_id'], 'card_instance_id': inst['instance_id'],
                   'target_ids': ['enemy1'] if targets is None else targets}
    return message('BattleCommand', battle_id=s['battle_id'], command_id=request_id,
                   expected_revision=s['revision'], kind=kind, payload=payload)


def rules_for(context, *, shield_cap=None, shield_overflow='UNCAPPED_TEST_ONLY'):
    cards, dots = [], {}
    for c in context.catalog.cards:
        if not c.playable:
            continue
        effects = []
        for index, e in enumerate(c.effects.value):
            if e['effect_code'] == 'STATUS':
                dots[e['status_id']] = Dot(e['status_id'], e['amount'], e['remaining_owner_turns'])
                effects.append(Effect(index, 'STATUS', status_id=e['status_id']))
            else:
                effects.append(Effect(index, e['effect_code'], e['amount']))
        cards.append(Action(c.card_id, c.target_side, c.target_count, tuple(effects),
                            owner_definition_id=c.owner_character_id, after_play_zone=c.after_play_zone))
    return Rules(context.policy.rules_version, context.policy.content_version, context.policy.version,
        'ENEMY_EXIT', context.policy.turn_draw, shield_cap, shield_overflow, cards=tuple(cards),
        skills=(Action('fixture:enemy-fixed-hit', 'PLAYER', 1, (Effect(0, 'DAMAGE', 1),)),),
        statuses=tuple(dots.values()), source_bindings=(SourceBinding('P03-catalog', context.catalog.source_version, context.catalog.source_sha256),))


class ScriptedEnemy:
    """Explicit fixed target/skill test input, not P16 AI or production content."""
    def __init__(self, target):
        self.target = target

    def propose(self, basis):
        s = basis.value
        return message('EnemyIntent', battle_id=s['battle_id'], expected_revision=s['revision'],
            content_version=s['content_version'], intent_id='fixture:fixed-enemy-intent', actor_id='enemy1',
            skill_id='fixture:enemy-fixed-hit', target_ids=[self.target], no_valid_target='REJECT')


def core_for(context, snap, *, interrupt=None, rules=None, provider=None):
    rules = rules or rules_for(context)
    planner = DeckPlanner(context)
    adapter = P14DeckAdapter(planner, rules, rejection_type=CandidateRejected) if provider is None else provider
    core = BattleCore(message('BattleState', snapshot=snap.value, accepted_commands=[]), rules,
        stage_id='fixture:stage', profile_scope='fixture:profile', deck_planner=adapter,
        enemy_planner=ScriptedEnemy(context.party.value['members'][0]['unit_id']), test_interrupt=interrupt)
    return core, planner, adapter
