"""Pure boundary helpers. No file writes, clock, random generator or store."""
from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Protocol
from . import _upstream  # noqa: F401
from yltt_framework.codec import (ContractError, FrozenMessage, canonical,
                                  fingerprint, loads, MAX_INTEGER)

VERSION = 'P17-META/0.1.0-isolated'
STATE_VERSION = 'P17-STATE/0.1.0-isolated'
COMMAND_VERSION = 'P17-COMMAND/0.1.0-isolated'
GRANT_VERSION = 'P17-GRANT-INPUT/0.1.0-proposal'
QUOTE_VERSION = 'P17-COST-INPUT/0.1.0-proposal'
CANDIDATE_VERSION = 'P17-CANDIDATE/0.1.0-isolated'
INTERNAL_VERSION = 'YLTT-INTERNAL/0.1.0-isolated'


class DomainError(ValueError):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def require(condition, code):
    if not condition:
        raise DomainError(code)


def keys(value, expected, code='E_SHAPE'):
    require(type(value) is dict and set(value) == set(expected.split()), code)


def integer(value, minimum=0, maximum=MAX_INTEGER, code='E_INTEGER'):
    require(type(value) is int and minimum <= value <= maximum, code)
    return value


def identifier(value, code='E_IDENTIFIER'):
    require(type(value) is str and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}', value)
            is not None, code)
    return value


def sha(value, code='E_SHA256'):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None, code)
    return value


def array(value, code='E_ARRAY'):
    require(type(value) is list and len(value) <= 4096, code)
    return value


def distinct(values, code):
    require(len(values) == len(set(values)), code)


def indexed(rows, field):
    return {row[field]: row for row in rows}


def checked_add(a, b):
    return integer(a+b, code='E_INTEGER_OVERFLOW')


def resource_rows(rows, *, allow_empty=False):
    array(rows)
    require(bool(rows) or allow_empty, 'E_EMPTY_COST')
    for row in rows:
        keys(row, 'resource_id amount')
        identifier(row['resource_id'])
        integer(row['amount'], 1)
    distinct([r['resource_id'] for r in rows], 'E_RESOURCE_DUPLICATE')
    return sorted(rows, key=lambda x: x['resource_id'])


class EvidencePort(Protocol):
    """Trusted composition input, NOT data authenticated by an issuer string.

    Actual P11/P18 implementations must resolve and validate eligibility,
    policy and durable causal references. P17 does not decide them.
    """
    def resolve_grant(self, ref: str) -> FrozenMessage | None: ...
    def resolve_quote(self, ref: str) -> FrozenMessage | None: ...
    def resolve_reversal(self, ref: str) -> FrozenMessage | None: ...


class ClosedEvidence:
    def resolve_grant(self, ref): return None
    def resolve_quote(self, ref): return None
    def resolve_reversal(self, ref): return None


@dataclass(frozen=True, slots=True)
class PlanResult:
    status: str
    reason: str
    candidate: FrozenMessage | None = None
    original_revision: int | None = None

    def value(self):
        return {'status': self.status, 'reason': self.reason,
                'candidate': None if self.candidate is None else self.candidate.value,
                'original_revision': self.original_revision}

