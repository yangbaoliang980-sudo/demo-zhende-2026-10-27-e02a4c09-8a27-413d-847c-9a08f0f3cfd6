"""P18 author tests, never a P32 or P35 acceptance receipt."""
