import copy
import json
import unittest
from stage_runtime import (FrozenMessage, StageError, Catalog, load_catalog, empty_state,
                           validate_state, first_clear_key, progress_view)
from stage_runtime.common import ContractError, fingerprint
from tests.support.harness import Harness, NORMAL, BOSS


class BoundaryTests(unittest.TestCase):
    def test_graph_cycle_rejected(self):
        d = load_catalog().value; d['stages'][0]['prerequisites'] = [BOSS]
        with self.assertRaisesRegex(StageError, 'E_STAGE_GRAPH_CYCLE'): Catalog(FrozenMessage.from_value(d))

    def test_unknown_prerequisite_rejected(self):
        d = load_catalog().value; d['stages'][1]['prerequisites'] = ['missing.stage']
        with self.assertRaisesRegex(StageError, 'E_PREREQUISITE_REFERENCE'): Catalog(FrozenMessage.from_value(d))

    def test_unapproved_alias_rejected(self):
        d = load_catalog().value; d['stages'][0]['canonical_stage_id'] = 'renamed.stage'
        with self.assertRaisesRegex(StageError, 'E_ALIAS_MIGRATION_UNBOUND'): Catalog(FrozenMessage.from_value(d))

    def test_duplicate_stage_id_rejected(self):
        d = load_catalog().value; d['stages'].append(d['stages'][0])
        with self.assertRaisesRegex(StageError, 'E_DUPLICATE_ID'): Catalog(FrozenMessage.from_value(d))

    def test_nonzero_disabled_repeat_rejected(self):
        d = load_catalog().value; d['stages'][0]['repeat']['tokens'] = 1
        with self.assertRaisesRegex(StageError, 'E_DISABLED_REPEAT_NONZERO'): Catalog(FrozenMessage.from_value(d))

    def test_chapter_completion_cannot_reference_another_chapter(self):
        d = load_catalog().value; d['chapters'][0]['completion_stage_ids'] = ['missing.stage']
        with self.assertRaisesRegex(StageError, 'E_CHAPTER_BOUNDARY'): Catalog(FrozenMessage.from_value(d))

    def test_no_implicit_next_chapter(self):
        d = load_catalog().value; d['chapters'][0]['next_chapter_id'] = 'unapproved.chapter'
        with self.assertRaisesRegex(StageError, 'E_CHAPTER_EXPANSION_UNAPPROVED'): Catalog(FrozenMessage.from_value(d))

    def test_synthetic_disjoint_chapter_not_cleared_by_first_chapter(self):
        d = load_catalog().value; d['scope'] = 'SYNTHETIC_TEST_ONLY'
        other = copy.deepcopy(d['stages'][0]); other['stage_id'] = other['canonical_stage_id'] = 'fixture.stage.other'
        other['chapter_id'] = 'fixture.chapter.other'; d['stages'].append(other)
        d['chapters'].append({'chapter_id': 'fixture.chapter.other', 'entry_stage_ids': [other['stage_id']],
            'completion_stage_ids': [other['stage_id']], 'next_chapter_id': None})
        h = Harness(catalog=Catalog(FrozenMessage.from_value(d))); h.clear(); h.clear(BOSS, 'battle.B')
        chapters = progress_view(h.model.stage, h.catalog).value['chapters']
        self.assertEqual([c['complete'] for c in chapters], [True, False])

    def test_unknown_persisted_stage_requires_migration(self):
        h = Harness(); s = h.model.stage.value; s['stages'].append({'stage_id': 'unregistered', 'confirmed_win_battles': [], 'review_required': False})
        with self.assertRaisesRegex(StageError, 'E_CONTENT_MIGRATION_REQUIRED'): validate_state(FrozenMessage.from_value(s), h.catalog)

    def test_first_clear_cannot_exist_without_terminal_receipt(self):
        h = Harness(); d = h.model.stage.value
        d['first_clears'].append({'key': first_clear_key(h.scope, NORMAL), 'stage_id': NORMAL,
            'battle_id': 'fake.battle', 'result_sha256': '0'*64, 'receipt_ref': 'fake.receipt'})
        with self.assertRaisesRegex(StageError, 'E_FIRST_CLEAR_RECEIPT'): validate_state(FrozenMessage.from_value(d), h.catalog)

    def test_bool_is_not_revision_integer(self):
        h = Harness(); d = h.model.stage.value; d['revision'] = True
        with self.assertRaisesRegex(StageError, 'E_INTEGER'): validate_state(FrozenMessage.from_value(d), h.catalog)

    def test_empty_and_overlong_scope_rejected(self):
        c = load_catalog()
        for scope in ('', 'x'*129, [], None, True):
            with self.subTest(scope=scope):
                with self.assertRaises(StageError): empty_state(c, player_save_scope_id=scope, store_instance='s', continuity_ref='c')

    def test_duplicate_json_key_rejected(self):
        with self.assertRaisesRegex(ContractError, 'DUPLICATE_JSON_KEY'): FrozenMessage(b'{"x":1,"x":2}')

    def test_float_and_nonfinite_rejected(self):
        for raw in (b'{"x":1.5}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.subTest(raw=raw):
                with self.assertRaises(ContractError): FrozenMessage(raw)

    def test_malformed_commands_return_explicit_rejections(self):
        h = Harness(); r = h.request('ENTER', h.entry_payload()).value
        mutations = [('kind', []), ('request_id', {}), ('expected_revision', True),
                     ('payload', None), ('catalog_sha256', 'BAD'), ('player_save_scope_id', ''), ('schema_version', 7)]
        for field, bad in mutations:
            with self.subTest(field=field):
                x = copy.deepcopy(r); x[field] = bad
                out = h.planner.plan(FrozenMessage.from_value(x), h.model.stage)
                self.assertIn(out.status, ('REJECTED', 'BLOCKED')); self.assertIsNone(out.candidate)

    def test_malformed_nested_payload_rejected_without_python_exception(self):
        h = Harness()
        for kind, payload in [('ENTER', {'stage_id': [], 'battle_id': 'b', 'entry_ref': 'r', 'seed': 1}),
                              ('SETTLE', {'result': []}), ('CLOSE', {'battle_id': {}}), ('REVOKE', {'control_ref': []})]:
            with self.subTest(kind=kind):
                _, out = h.plan(kind, payload); self.assertEqual(out.status, 'REJECTED')

    def test_tampered_admission_hash_rejected_on_reload(self):
        h = Harness(); h.enter(); d = h.model.stage.value; d['attempts'][0]['admission']['seed'] = 2
        with self.assertRaisesRegex(StageError, 'E_ADMISSION_HASH'): validate_state(FrozenMessage.from_value(d), h.catalog)

    def test_snapshot_encoding_limit_fails_closed(self):
        with self.assertRaisesRegex(ContractError, 'FRAME_SIZE_OR_TYPE'):
            FrozenMessage.from_value({'data': 'x' * 1048576})

    def test_admitted_fallen_member_still_receives_xp(self):
        h = Harness(); h.enter(); r = h.result(); proof = h.authority.battles['battle.A'].value
        proof['snapshot']['units'][0]['hp'] = 0
        proof['result']['final_snapshot_sha256'] = fingerprint(proof['snapshot'])
        h.authority.battles['battle.A'] = FrozenMessage.from_value(proof)
        h.apply('SETTLE', {'result': proof['result']})
        self.assertEqual(h.xp(), [4, 4, 4])

    def test_terminal_bool_revision_rejected(self):
        h = Harness(); h.enter(); r = h.result().value; r['terminal_revision'] = True
        _, out = h.plan('SETTLE', {'result': r})
        self.assertTrue(out.reason.startswith('E_CONTRACT:')); self.assertEqual(h.balance(), 0)

    def test_inflight_snapshot_final_without_result_waits(self):
        h = Harness(); h.enter(); r = h.result(); p = h.authority.battles['battle.A'].value; p['result'] = None
        h.authority.battles['battle.A'] = FrozenMessage.from_value(p)
        _, out = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(out.reason, 'E_WAIT_FINAL_TERMINAL'); self.assertEqual(h.balance(), 0)
