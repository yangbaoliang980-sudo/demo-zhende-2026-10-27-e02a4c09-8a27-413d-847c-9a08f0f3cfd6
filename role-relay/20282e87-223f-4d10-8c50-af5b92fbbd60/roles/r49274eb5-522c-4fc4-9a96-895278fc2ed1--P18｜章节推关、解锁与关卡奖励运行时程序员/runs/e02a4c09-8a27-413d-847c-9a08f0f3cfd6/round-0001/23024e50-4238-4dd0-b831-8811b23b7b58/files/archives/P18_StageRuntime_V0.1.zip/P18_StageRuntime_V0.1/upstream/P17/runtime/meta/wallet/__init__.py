"""P17 wallet business rules. Only immutable candidates leave this package."""
