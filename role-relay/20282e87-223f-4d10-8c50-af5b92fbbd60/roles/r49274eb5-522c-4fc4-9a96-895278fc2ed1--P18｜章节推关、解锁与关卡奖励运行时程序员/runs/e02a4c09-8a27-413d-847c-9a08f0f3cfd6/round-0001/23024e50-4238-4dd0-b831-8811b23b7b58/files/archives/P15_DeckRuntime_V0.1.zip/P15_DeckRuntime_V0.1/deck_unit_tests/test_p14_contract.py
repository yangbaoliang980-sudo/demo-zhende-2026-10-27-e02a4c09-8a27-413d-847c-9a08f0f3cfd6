from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
import os,subprocess,sys,unittest
from deck_runtime import DeckPlanner,DeckRejected,plan
from deck_runtime.p14_adapter import P14DeckAdapter,verify_p14_rules
from deck_runtime.wire import checked,message
from upstream.P14.battle_core import BattleCore,CandidateRejected
from examples.support import ROOT,inputs,snapshot,command,core_for,rules_for
from .extension_support import extended


class Interrupted(BaseException):
    pass


class P14ContractTests(unittest.TestCase):
    def setUp(self):
        self.ctx,recipe=inputs();self.s=snapshot(self.ctx,recipe)
        self.core,self.planner,self.adapter=core_for(self.ctx,self.s)

    def test_one_commit_contains_fee_card_and_effect(self):
        c=command(self.s);before=self.core.state().raw
        p=self.adapter.propose(c,self.s)
        self.assertEqual(before,self.core.state().raw)
        r=self.core.submit(c).value
        self.assertEqual((r['result'],r['code']),('COMMITTED','OK'))
        s=r['commit']['snapshot'];events=r['commit']['events']
        self.assertEqual((s['revision'],s['energy']),(1,2))
        self.assertEqual(next(u['hp'] for u in s['units'] if u['unit_id']=='enemy1'),96)
        self.assertIn(c.value['payload']['card_instance_id'],s['zones']['discard'])
        types=[e['event_type'] for e in events]
        self.assertLess(types.index('ENERGY_SPENT'),types.index('CARD_MOVED'))
        self.assertLess(types.index('CARD_MOVED'),types.index('DAMAGE_APPLIED'))
        self.assertEqual(len(self.core.state().value['accepted_commands']),1)
        self.assertEqual(sum(e['data'].get('amount',0) for e in events if e['event_type']=='ENERGY_SPENT'),1)

    def test_double_click_same_id_does_not_call_provider_again(self):
        delegate=self.adapter
        class Counted:
            calls=0
            def propose(self,command,basis):
                self.calls+=1
                return delegate.propose(command,basis)
        provider=Counted()
        core,_,_=core_for(self.ctx,self.s,provider=provider)
        c=command(self.s);core.submit(c);before=core.state().raw
        self.assertEqual(provider.calls,1)
        r=core.submit(c).value
        self.assertEqual(r['result'],'DUPLICATE_NO_OP')
        self.assertIsNone(r['commit'])
        self.assertEqual(before,core.state().raw)
        self.assertEqual(provider.calls,1)
        self.assertEqual(len(core.committed_batches()),1)

    def test_collision_before_stale_revision_does_not_charge(self):
        c=command(self.s);self.core.submit(c);before=self.core.state().raw
        changed=c.value;changed['payload']['target_ids']=['hero_b']
        r=self.core.submit(changed).value
        self.assertEqual(r['code'],'COMMAND_ID_COLLISION')
        self.assertEqual(before,self.core.state().raw)

    def test_new_id_same_spent_instance_does_not_charge(self):
        c=command(self.s);self.core.submit(c);before=self.core.state().raw
        new=c.value;new.update(command_id='new:id',expected_revision=1)
        r=self.core.submit(new).value
        self.assertEqual(r['code'],'CARD_NOT_IN_HAND')
        self.assertEqual(before,self.core.state().raw)

    def test_two_distinct_commands_same_revision_commit_once(self):
        a=command(self.s)
        b=command(self.s,request_id='second:request',card_id='MOCK_P03_CARD_BARRIER',targets=['hero_a'])
        self.core.submit(a);before=self.core.state().raw
        self.assertEqual(self.core.submit(b).value['code'],'REVISION_CONFLICT')
        self.assertEqual(before,self.core.state().raw)

    def test_concurrent_24_clicks_commit_and_charge_once(self):
        c=command(self.s)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results=list(pool.map(lambda _:self.core.submit(c).value,range(24)))
        self.assertEqual(sum(r['result']=='COMMITTED' for r in results),1)
        self.assertEqual(sum(r['result']=='DUPLICATE_NO_OP' for r in results),23)
        self.assertEqual(self.core.state().value['snapshot']['energy'],2)
        self.assertEqual(len(self.core.committed_batches()),1)

    def test_insufficient_energy_refuses_without_receipt_or_state_change(self):
        s=self.s.value;s['energy']=0;s=checked(s,'BattleSnapshot')
        core,planner,_=core_for(self.ctx,s);c=command(s);before=core.state().raw
        one=core.submit(c);evidence=planner.decisions()[0].evidence.raw
        two=core.submit(c)
        self.assertEqual(one.value['code'],'ENERGY_INSUFFICIENT')
        self.assertEqual(one.raw,two.raw)
        self.assertEqual(core.state().raw,before)
        self.assertEqual(planner.decisions()[0].evidence.raw,evidence)
        self.assertEqual(core.committed_batches(),())

    def test_p14_effect_rejection_rolls_back_accepted_candidate(self):
        rules=rules_for(self.ctx,shield_cap=1,shield_overflow='REJECT')
        core,planner,_=core_for(self.ctx,self.s,rules=rules)
        c=command(self.s,card_id='MOCK_P03_CARD_BARRIER',targets=['hero_a']);before=core.state().raw
        one=core.submit(c);two=core.submit(c)
        self.assertEqual(one.value['code'],'SHIELD_CAP_EXCEEDED')
        self.assertEqual(one.raw,two.raw)
        self.assertEqual(core.state().raw,before)
        self.assertEqual(planner.decisions()[0].code,'OK')

    def test_public_state_remains_old_at_all_precommit_checkpoints(self):
        observed=[]
        core,_,_=core_for(self.ctx,self.s,interrupt=lambda stage:observed.append((stage,core.state().raw)))
        before=core.state().raw
        self.assertEqual(core.submit(command(self.s)).value['code'],'OK')
        self.assertEqual({stage for stage,_ in observed},{'after_deck_patch','after_resolution','before_publish'})
        self.assertTrue(all(raw==before for _,raw in observed))

    def test_restart_p15_cache_still_relies_on_p14_accepted_receipt(self):
        c=command(self.s);self.core.submit(c)
        restored=BattleCore(self.core.state(),rules_for(self.ctx),stage_id='fixture:stage',profile_scope='fixture:profile',
            deck_planner=P14DeckAdapter(DeckPlanner(self.ctx),rules_for(self.ctx),rejection_type=CandidateRejected))
        before=restored.state().raw
        self.assertEqual(restored.submit(c).value['result'],'DUPLICATE_NO_OP')
        self.assertEqual(restored.state().raw,before)

    def test_p14_draw_reporting_mismatch_fails_before_binding(self):
        context=replace(self.ctx,policy=replace(self.ctx.policy,initial_draw=3))
        with self.assertRaisesRegex(DeckRejected,'P14_ENTRY_DRAW_REPORT_UNBOUND'):
            P14DeckAdapter(DeckPlanner(context),rules_for(context),rejection_type=CandidateRejected)

    def test_p14_effect_definition_mismatch_fails_binding(self):
        rules=rules_for(self.ctx)
        action=rules.cards[0]
        changed=replace(action,effects=(replace(action.effects[0],amount=99),))
        rules=replace(rules,cards=(changed,)+rules.cards[1:])
        with self.assertRaisesRegex(DeckRejected,'P14_EFFECT_BINDING_MISMATCH'):
            P14DeckAdapter(DeckPlanner(self.ctx),rules,rejection_type=CandidateRejected)

    def test_original_p14_import_namespace_receives_its_own_rejection_class(self):
        proc=subprocess.run([sys.executable,'-B','tools/probe_p14_module_identity.py'],cwd=ROOT,
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stdout+proc.stderr)

    def test_multi_target_order_and_exhaust_paid_once(self):
        ctx,s=extended();core,planner,adapter=core_for(ctx,s)
        c=command(s,card_id='fixture:multi-exhaust',targets=['enemy2','enemy1'])
        evidence=plan(c,s,ctx)
        self.assertEqual(evidence.action_intent.value['target_ids'],['enemy2','enemy1'])
        r=core.submit(c).value;events=r['commit']['events']
        self.assertEqual(r['code'],'OK')
        self.assertEqual([e['data']['target_unit_id'] for e in events if e['event_type']=='DAMAGE_APPLIED'],['enemy2','enemy1'])
        self.assertEqual(sum(e['data']['amount'] for e in events if e['event_type']=='ENERGY_SPENT'),2)
        self.assertIn(c.value['payload']['card_instance_id'],r['commit']['snapshot']['zones']['exhaust'])

    def test_multi_target_one_invalid_rejects_entire_play(self):
        ctx,s=extended();raw=s.value;raw['units'][4]['hp']=0;s=checked(raw,'BattleSnapshot')
        core,_,_=core_for(ctx,s);before=core.state().raw
        c=command(s,card_id='fixture:multi-exhaust',targets=['enemy1','enemy2'])
        self.assertEqual(plan(c,s,ctx).code,'TARGET_INVALID')
        self.assertEqual(core.submit(c).value['code'],'TARGET_INVALID')
        self.assertEqual(core.state().raw,before)

    def test_zero_cost_still_consumes_once(self):
        ctx,s=extended();raw=s.value;raw['energy']=0;s=checked(raw,'BattleSnapshot')
        core,_,_=core_for(ctx,s)
        c=command(s,card_id='fixture:free-card');r=core.submit(c).value
        self.assertEqual(r['code'],'OK')
        self.assertEqual(r['commit']['snapshot']['energy'],0)
        self.assertEqual([e['data']['amount'] for e in r['commit']['events'] if e['event_type']=='ENERGY_SPENT'],[0])
        self.assertEqual(core.submit(c).value['result'],'DUPLICATE_NO_OP')


def interruption_case(stage, starting=False):
    def test(self):
        ctx,recipe=inputs();s=snapshot(ctx,recipe,ready=not starting)
        armed=[True]
        def interrupt(point):
            if point==stage and armed[0]:
                armed[0]=False
                raise Interrupted(point)
        core,planner,_=core_for(ctx,s,interrupt=interrupt)
        c=command(s,kind='SYSTEM_START' if starting else 'PLAY_CARD')
        call=core.submit_system if starting else core.submit
        before=core.state().raw
        with self.assertRaises(Interrupted):
            call(c)
        self.assertEqual(core.state().raw,before)
        self.assertEqual(core.committed_batches(),())
        evidence=planner.decisions()[0].evidence.raw
        reply=call(c).value
        self.assertEqual((reply['result'],reply['code']),('COMMITTED','OK'))
        self.assertEqual(planner.decisions()[0].evidence.raw,evidence)
        self.assertEqual(len(core.committed_batches()),1)
        if starting:
            self.assertEqual(core.state().value['snapshot']['rng']['draw_count'],8)
        else:
            self.assertEqual(core.state().value['snapshot']['energy'],2)
    return test


for stage in ('after_deck_patch','after_resolution','before_publish'):
    setattr(P14ContractTests,'test_interrupted_'+stage+'_retry',interruption_case(stage))
setattr(P14ContractTests,'test_shuffle_interrupted_retry_same_rng',interruption_case('after_deck_patch',starting=True))


class EntryBasisTests(unittest.TestCase):
    def test_empty_deck_reports_shortfall_without_hp_or_extra_rng(self):
        ctx,recipe=inputs();raw=snapshot(ctx,recipe,ready=False).value
        raw['card_instances']=[];raw['zones']={z:[] for z in ('draw','hand','discard','exhaust')}
        s=checked(raw,'BattleSnapshot');core,planner,_=core_for(ctx,s)
        r=core.submit_system(command(s,kind='SYSTEM_START')).value
        self.assertEqual(r['code'],'OK')
        self.assertEqual(r['commit']['snapshot']['units'],s.value['units'])
        self.assertEqual(r['commit']['snapshot']['rng'],s.value['rng'])
        self.assertEqual([e['data'] for e in r['commit']['events'] if e['event_type']=='DRAW_SHORTFALL'],[{'requested':5,'drawn':0}])
        self.assertEqual(planner.decisions()[0].evidence.value['draw_report']['shortfall'],5)

    def test_hand_capacity_shortfall_matches_p14_actual_movement_count(self):
        ctx,recipe=inputs(policy_changes={'hand_limit':2})
        s=snapshot(ctx,recipe,ready=False);core,planner,_=core_for(ctx,s)
        r=core.submit_system(command(s,kind='SYSTEM_START')).value
        self.assertEqual(r['code'],'OK')
        self.assertEqual(len(r['commit']['snapshot']['zones']['hand']),2)
        self.assertEqual(len(r['commit']['snapshot']['zones']['draw']),7)
        self.assertEqual([e['data'] for e in r['commit']['events'] if e['event_type']=='DRAW_SHORTFALL'],[{'requested':5,'drawn':2}])
        self.assertEqual(planner.decisions()[0].evidence.value['draw_report']['stopped_by'],'HAND_LIMIT')

    def fixture(self, terminal=False):
        ctx,recipe=inputs();raw=snapshot(ctx,recipe,ready=False).value
        raw.update(phase='PLAYER_TURN_PENDING',turn_number=2)
        raw['units'][0]['statuses']=[{'status_instance_id':'status:dot','status_id':'MOCK_P03_STATUS_BURN',
            'source_unit_id':'enemy1','stacks':1,'remaining_triggers':1,'insert_order':0}]
        if terminal:
            raw['units'][0]['hp']=2;raw['units'][1]['hp']=0;raw['units'][2]['hp']=0
        return ctx,checked(raw,'BattleSnapshot')

    def test_real_post_dot_private_basis_bound_by_exact_hash(self):
        ctx,s=self.fixture();planner=DeckPlanner(ctx);adapter=P14DeckAdapter(planner,rules_for(ctx),rejection_type=CandidateRejected);seen=[]
        class Capture:
            def propose(self,cmd,basis):
                seen.append(basis)
                return adapter.propose(cmd,basis)
        core,_,_=core_for(ctx,s,provider=Capture())
        r=core.submit_system(command(s,kind='SYSTEM_ENTER_PLAYER_TURN')).value
        self.assertEqual(r['code'],'OK')
        self.assertEqual(seen[0].value['units'][0]['hp'],8)
        self.assertEqual(seen[0].value['revision'],0)
        self.assertNotEqual(seen[0].sha256,s.sha256)
        self.assertEqual(planner.decisions()[0].candidate.value['snapshot_sha256'],seen[0].sha256)
        self.assertEqual(r['commit']['snapshot']['energy'],3)

    def test_terminal_dot_never_calls_p15(self):
        ctx,s=self.fixture(terminal=True)
        core,planner,_=core_for(ctx,s)
        r=core.submit_system(command(s,kind='SYSTEM_ENTER_PLAYER_TURN')).value
        self.assertEqual(r['code'],'OK')
        self.assertEqual(r['commit']['snapshot']['outcome'],'LOSS')
        self.assertEqual(planner.decisions(),())
        self.assertEqual(r['commit']['snapshot']['energy'],0)

    def test_candidate_rejection_rolls_back_post_dot_changes(self):
        ctx,s=self.fixture();ctx=replace(ctx,policy=replace(ctx.policy,entry_energy=1,energy_cap=1))
        raw=s.value;raw['energy']=2;s=checked(raw,'BattleSnapshot')
        core,planner,_=core_for(ctx,s);before=core.state().raw
        r=core.submit_system(command(s,kind='SYSTEM_ENTER_PLAYER_TURN')).value
        self.assertEqual(r['code'],'ENERGY_POLICY_BOUNDS')
        self.assertEqual(planner.decisions()[0].code,'ENERGY_POLICY_BOUNDS')
        self.assertEqual(core.state().raw,before)
