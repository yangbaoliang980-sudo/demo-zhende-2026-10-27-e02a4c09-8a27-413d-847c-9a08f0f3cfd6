"""Serialization and invariants only; obtaining/storing bytes is P21's job."""
from .common import (STATE_VERSION, COMMAND_VERSION, FrozenMessage, require, keys,
    integer, identifier, sha, array, distinct, fingerprint, indexed)
from runtime.meta.wallet.rules import empty_wallet,validate_wallet,grant_value,source_ref
from runtime.meta.characters.rules import validate_characters,purpose
from runtime.meta.party.projection import validate_party


def empty_state(catalog, *, profile_id='fixture:player', store_instance='fixture:store-1',
                continuity_ref='fixture:continuity-1'):
    for value in (profile_id,store_instance,continuity_ref):identifier(value)
    return FrozenMessage.from_value({'schema_version':STATE_VERSION,'profile_id':profile_id,
        'store_instance':store_instance,'continuity_ref':continuity_ref,'content_sha256':catalog.sha256,
        'revision':0,'wallet_revision':0,'characters':[],'party_slots':[None,None,None],
        'equipment_instances':[],'wallet':empty_wallet(),'entitlements':[],'operations':[]})


def validate_state(message,catalog):
    require(type(message) is FrozenMessage,'E_SNAPSHOT_TYPE')
    d=message.value
    keys(d,'schema_version profile_id store_instance continuity_ref content_sha256 revision wallet_revision characters party_slots equipment_instances wallet entitlements operations')
    require(d['schema_version']==STATE_VERSION,'E_STATE_VERSION')
    for k in ('profile_id','store_instance','continuity_ref'):identifier(d[k])
    sha(d['content_sha256']);require(d['content_sha256']==catalog.sha256,'E_CONTENT_CONFLICT')
    integer(d['revision']);integer(d['wallet_revision'],0,d['revision'])
    validate_wallet(d['wallet'],d['revision']);validate_characters(d,catalog)
    require(type(d['party_slots']) is list and len(d['party_slots'])==3,'E_PARTY_SIZE')
    if d['party_slots'] != [None,None,None]:
        validate_party(d['party_slots'],{c['character_id'] for c in d['characters']},catalog)
    array(d['entitlements']);array(d['operations'])
    expected_lots={};expected_chars=[];expected_xp={};expected_gear=[]
    for e in d['entitlements']:
        keys(e,'key semantic_sha256 status grant')
        sha(e['key']);sha(e['semantic_sha256'])
        g,key,semantic=grant_value(FrozenMessage.from_value(e['grant']),d['profile_id'])
        require((key,semantic)==(e['key'],e['semantic_sha256']),'E_ENTITLEMENT_BINDING')
        require(e['status'] in ('ACTIVE','REVOKED'),'E_ENTITLEMENT_STATUS')
        require(e['status']=='ACTIVE' or g['source_kind']=='STUDY','E_NONSTUDY_REVOKE')
        expected_chars+=g['characters'];expected_gear+=g['equipment']
        for xp in g['xp']:expected_xp[xp['character_id']]=expected_xp.get(xp['character_id'],0)+xp['amount']
        for r in g['resources']:
            lid=fingerprint({'source_key':key,'resource_id':r['resource_id']})
            expected_lots[lid]=(r['amount'],source_ref(g,key),e['status'])
    distinct([x['key'] for x in d['entitlements']],'E_ENTITLEMENT_DUPLICATE')
    require(set(expected_lots)=={x['lot_id'] for x in d['wallet']['lots']},'E_GRANT_LOT_SET')
    for l in d['wallet']['lots']:
        quantity,source,status=expected_lots[l['lot_id']]
        require((l['quantity'],l['source'])==(quantity,source),'E_GRANT_LOT_BINDING')
        require(l['revoked']==(quantity if status=='REVOKED' else 0),'E_GRANT_REVERSAL_BINDING')
    distinct(expected_chars,'E_CHARACTER_GRANT_DUPLICATE')
    require(set(expected_chars)=={c['character_id'] for c in d['characters']},'E_CHARACTER_GRANT_SET')
    require(set(expected_xp)<=set(expected_chars),'E_XP_CHARACTER_NOT_OWNED')
    require(sorted(expected_gear,key=lambda x:x['instance_id'])==d['equipment_instances'],'E_EQUIPMENT_GRANT_SET')
    for c in d['characters']:
        require(c['xp_total']==expected_xp.get(c['character_id'],0),'E_XP_GRANT_SUM')
        for kind,limit in [('LEVEL',c['level']),('SKILL',c['skill_rank'])]:
            for rank in range(1,limit):
                sk=fingerprint({'owner':'P17','purpose_key':purpose(d,c['character_id'],kind,rank)})
                rec=next((x for x in d['wallet']['consumptions'] if x['spend_key']==sk),None)
                costs=catalog.cost(c['character_id'],kind,rank)['resources']
                require(rec is not None and rec['cost_sha256']==fingerprint(costs),'E_GROWTH_COST_RECEIPT')
                paid={}
                for a in rec['allocations']:paid[a['resource_id']]=paid.get(a['resource_id'],0)+a['amount']
                require(paid=={x['resource_id']:x['amount'] for x in costs},'E_GROWTH_PAYMENT')
    for r in d['operations']:
        keys(r,'request_id request_sha256 committed_revision')
        identifier(r['request_id']);sha(r['request_sha256']);integer(r['committed_revision'],1,d['revision'])
    distinct([r['request_id'] for r in d['operations']],'E_RECEIPT_DUPLICATE')
    require(sorted(r['committed_revision'] for r in d['operations'])==list(range(1,d['revision']+1)),
            'E_RECEIPT_REVISION_HISTORY')
    return d


def restore_state(raw,catalog,*,expected_sha256,expected_store_instance,expected_continuity_ref):
    """Expected values must come from P21's consistent authoritative read.

    A matching hash is an integrity check, never evidence of persistence or
    authenticity by itself. No backup continuity is inferred here.
    """
    sha(expected_sha256);identifier(expected_store_instance);identifier(expected_continuity_ref)
    msg=FrozenMessage(raw)
    require(msg.sha256==expected_sha256,'E_RELOAD_HASH')
    d=validate_state(msg,catalog)
    require(d['store_instance']==expected_store_instance,'E_STORE_INSTANCE')
    require(d['continuity_ref']==expected_continuity_ref,'E_CONTINUITY_FENCE')
    return msg
