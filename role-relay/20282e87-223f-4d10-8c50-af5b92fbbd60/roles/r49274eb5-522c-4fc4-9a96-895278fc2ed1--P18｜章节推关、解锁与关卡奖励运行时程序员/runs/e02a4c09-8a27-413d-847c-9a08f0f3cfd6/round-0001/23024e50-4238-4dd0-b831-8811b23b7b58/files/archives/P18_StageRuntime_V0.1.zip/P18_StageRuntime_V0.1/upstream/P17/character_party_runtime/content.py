"""Read-only content adapter; P04 and P05 bytes remain unchanged."""
from __future__ import annotations
import csv
import hashlib
import io
from dataclasses import dataclass
from .common import (FrozenMessage, array, distinct, identifier, integer, keys,
                     require, loads, fingerprint, resource_rows)
from ._upstream import PACKAGE_ROOT

STATS = ('max_hp', 'attack', 'defense', 'support')


@dataclass(frozen=True, slots=True)
class Catalog:
    document: FrozenMessage

    def __post_init__(self):
        require(type(self.document) is FrozenMessage,'E_CATALOG_TYPE')
        d = self.document.value
        keys(d, 'schema_version content_version characters costs equipment_enabled equipment source_hashes')
        require(d['schema_version'] == 'P17-CATALOG/0.1.0-isolated', 'E_CATALOG_VERSION')
        identifier(d['content_version'])
        require(type(d['equipment_enabled']) is bool, 'E_FEATURE_FLAG')
        array(d['characters']); array(d['costs']); array(d['equipment'])
        for c in d['characters']:
            keys(c, 'character_id role max_level base growth skill_id skill_max p03_character_id signature_card_id')
            identifier(c['character_id'])
            identifier(c['role']); integer(c['max_level'], 1, 1000)
            integer(c['skill_max'], 1, 1000)
            for k in ('skill_id', 'p03_character_id', 'signature_card_id'): identifier(c[k])
            for k in ('base', 'growth'):
                keys(c[k], ' '.join(STATS))
                for stat in STATS: integer(c[k][stat], 1 if k == 'base' and stat == 'max_hp' else 0)
        distinct([x['character_id'] for x in d['characters']], 'E_CONTENT_DUPLICATE')
        ids = {x['character_id'] for x in d['characters']}
        cost_keys = []
        for row in d['costs']:
            keys(row, 'character_id kind from_rank to_rank requires_character_level requires_xp_total resources')
            require(row['character_id'] in ids, 'E_COST_CHARACTER')
            require(row['kind'] in ('LEVEL','SKILL'), 'E_COST_KIND')
            integer(row['from_rank'],1); integer(row['to_rank'],2)
            require(row['to_rank']==row['from_rank']+1, 'E_COST_STEP')
            integer(row['requires_character_level'],1); integer(row['requires_xp_total'])
            resource_rows(row['resources'])
            cost_keys.append((row['character_id'],row['kind'],row['from_rank']))
        distinct(cost_keys, 'E_COST_DUPLICATE')
        for c in d['characters']:
            for kind, limit in [('LEVEL',c['max_level']),('SKILL',c['skill_max'])]:
                require({x[2] for x in cost_keys if x[:2]==(c['character_id'],kind)} == set(range(1,limit)),
                        'E_COST_COVERAGE')
        for e in d['equipment']:
            keys(e, 'definition_id slot required_level bonuses allowed_roles')
            identifier(e['definition_id'])
            identifier(e['slot']); integer(e['required_level'],1)
            keys(e['bonuses'], ' '.join(STATS))
            for v in e['bonuses'].values(): integer(v)
            array(e['allowed_roles'])
            for v in e['allowed_roles']: identifier(v)
            distinct(e['allowed_roles'], 'E_EQUIPMENT_ROLE_DUPLICATE')
        distinct([x['definition_id'] for x in d['equipment']], 'E_EQUIPMENT_DEFINITION_DUPLICATE')
        require(d['equipment_enabled'] or not d['equipment'], 'E_DISABLED_CONTENT_PRESENT')

    @property
    def sha256(self): return self.document.sha256

    @property
    def value(self): return self.document.value

    def character(self, character_id):
        identifier(character_id, 'E_CHARACTER_ID_TYPE')
        c = next((x for x in self.value['characters'] if x['character_id']==character_id),None)
        require(c is not None, 'E_CHARACTER_NOT_FOUND')
        return c

    def cost(self, character_id, kind, from_rank):
        row = next((x for x in self.value['costs'] if
                    (x['character_id'],x['kind'],x['from_rank'])==(character_id,kind,from_rank)),None)
        require(row is not None, 'E_COST_NOT_CONFIGURED')
        return row

    def equipment(self, definition_id):
        row = next((x for x in self.value['equipment'] if x['definition_id']==definition_id),None)
        require(row is not None,'E_EQUIPMENT_DEFINITION_UNKNOWN')
        return row


def load_catalog(*, equipment_test_fixture=False):
    """Fixture loader only. Never an approved production-content bootstrap."""
    base = PACKAGE_ROOT / 'sources/P04/content/characters'
    raw = (base/'character_skeleton.json').read_bytes()
    raw_costs = (base/'progression_costs.tsv').read_bytes()
    p04 = loads(raw)
    require(p04['release_status']=='ISOLATED_TEST_ONLY_NOT_APPROVED_FOR_RUNTIME', 'E_SOURCE_RELEASE')
    chars=[]
    for c in p04['characters']:
        chars.append({'character_id':c['character_id'], 'role':c['role_code'],
                      'max_level':c['max_level_fixture'], 'base':c['base_stats'],
                      'growth':c['per_level_growth'], 'skill_id':c['skill']['local_skill_id'],
                      'skill_max':c['skill']['skill_rank_max_fixture'],
                      'p03_character_id':c['p03_fixture_compatibility']['p03_slot_character_id'],
                      'signature_card_id':c['p03_fixture_compatibility']['signature_card_id']})
    costs=[]
    for c in csv.DictReader(io.StringIO(raw_costs.decode('utf-8')), delimiter='\t'):
        if c['kind'] == 'ACQUIRE': continue
        costs.append({'character_id':c['character_id'], 'kind':c['kind'],
                      **{k:int(c[k]) for k in ('from_rank','to_rank','requires_character_level','requires_xp_total')},
                      'resources':[{'resource_id':c['spend_resource'],'amount':int(c['spend_amount'])}]})
    sources=[{'name':'P04_character_skeleton','sha256':hashlib.sha256(raw).hexdigest()},
             {'name':'P04_progression_costs','sha256':hashlib.sha256(raw_costs).hexdigest()}]
    gear=[]
    if equipment_test_fixture:
        raw_gear=(PACKAGE_ROOT/'fixtures/equipment_test_only.json').read_bytes()
        doc=loads(raw_gear)
        require(doc['scope']=='SYNTHETIC_TEST_ONLY_NOT_DEC009_APPROVAL', 'E_EQUIPMENT_SCOPE')
        gear=doc['definitions']
        sources.append({'name':'P17_equipment_fixture','sha256':hashlib.sha256(raw_gear).hexdigest()})
    return Catalog(FrozenMessage.from_value({'schema_version':'P17-CATALOG/0.1.0-isolated',
        'content_version':'P17-CONTENT/0.1.0-test-only','characters':chars,'costs':costs,
        'equipment_enabled':equipment_test_fixture,'equipment':gear,'source_hashes':sources}))

