"""Real P15 candidate execution against unchanged P14 in a test composition."""
import json
from .support import inputs, snapshot, core_for, command
from deck_runtime.wire import checked, fingerprint
from upstream.P14.battle_core.replay import replay


def run_demo():
    context, recipe = inputs()
    initial = snapshot(context, recipe, ready=False)
    core, planner, adapter = core_for(context, initial)
    history = []

    def submit(cmd, expected='COMMITTED'):
        before = core.state().sha256
        reply = (core.submit_system if cmd.value['kind'].startswith('SYSTEM_') else core.submit)(cmd)
        assert reply.value['result'] == expected, reply.value
        history.append({'command': cmd.value, 'reply': reply.value, 'before_state_sha256': before,
                        'after_state_sha256': core.state().sha256})
        return reply

    submit(command(initial, request_id='demo:start', kind='SYSTEM_START'))
    for round_index in range(3):
        s = core.snapshot(context.battle_id)
        raw = s.value
        playable = [i for i in raw['card_instances'] if i['instance_id'] in raw['zones']['hand']
                    and context.catalog.card(i['card_id']).effects.value[0]['effect_code'] != 'STATUS'
                    and context.catalog.card(i['card_id']).cost <= raw['energy']]
        chosen = playable[0]
        spec = context.catalog.card(chosen['card_id'])
        targets = ['enemy1'] if spec.target_side == 'ENEMY' else [chosen['owner_unit_id']]
        bad = command(s, request_id=f'demo:bad:{round_index}', instance_id=chosen['instance_id'], targets=['missing-target'])
        submit(bad, 'REJECTED')
        assert history[-1]['before_state_sha256'] == history[-1]['after_state_sha256']
        good = command(s, request_id=f'demo:play:{round_index}', instance_id=chosen['instance_id'], targets=targets)
        # Candidate generation alone must not change P14 state.
        before = core.state().raw
        adapter.propose(good, s)
        assert core.state().raw == before
        submit(good)
        submit(good, 'DUPLICATE_NO_OP')
        assert history[-1]['before_state_sha256'] == history[-1]['after_state_sha256']
        end = command(core.snapshot(context.battle_id), request_id=f'demo:end:{round_index}', kind='END_TURN')
        submit(end)
        enemy = command(core.snapshot(context.battle_id), request_id=f'demo:enemy:{round_index}', kind='SYSTEM_ENEMY_ACTION')
        submit(enemy)
        if round_index < 2:
            enter = command(core.snapshot(context.battle_id), request_id=f'demo:enter:{round_index}', kind='SYSTEM_ENTER_PLAYER_TURN')
            submit(enter)
    bundle = core.export_replay()
    again = replay(bundle)
    assert again.state().raw == core.state().raw
    assert tuple(b.raw for b in again.committed_batches()) == tuple(b.raw for b in core.committed_batches())
    decisions = [d.evidence.value for d in planner.decisions()]
    batches = [b.value for b in core.committed_batches()]
    summary = {'scope': 'AUTHOR_ISOLATED_CONTRACT_EXECUTION_REAL_P15_UNCHANGED_P14_FIXTURE_P17_AND_P16',
        'commits': len(batches), 'revision': core.state().value['snapshot']['revision'],
        'rejected_requests': sum(x['reply']['result'] == 'REJECTED' for x in history),
        'duplicate_no_ops': sum(x['reply']['result'] == 'DUPLICATE_NO_OP' for x in history),
        'energy_spent_events': sum(e['event_type'] == 'ENERGY_SPENT' for b in batches for e in b['events']),
        'recycle_count': sum(d['draw_report']['recycled'] for d in decisions if d['draw_report']),
        'rng_draw_count': core.state().value['snapshot']['rng']['draw_count'],
        'final_state_sha256': core.state().sha256, 'replay_sha256': bundle.sha256,
        'full_game_integration': 'NOT_RUN', 'real_p17_party': 'BLOCKED', 'P32_P35_independent': 'NOT_RUN'}
    return {'summary': summary, 'initial_snapshot': initial.value, 'requests': history,
            'decisions': decisions, 'state': core.state().value, 'batches': batches, 'replay': bundle.value()}


if __name__ == '__main__':
    print(json.dumps(run_demo()['summary'], ensure_ascii=False, indent=2))
