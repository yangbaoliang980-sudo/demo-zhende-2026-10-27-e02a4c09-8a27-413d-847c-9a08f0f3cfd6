"""Stage domain author verification."""
