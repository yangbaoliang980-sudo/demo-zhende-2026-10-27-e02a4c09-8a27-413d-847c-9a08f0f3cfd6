"""Single-lock memory model, explicitly NOT P21 and NOT durable storage."""
from threading import RLock
from stage_runtime import FrozenMessage, PlanResult, prepare_atomic, validate_atomic, restore_state
from stage_runtime.common import need


class InjectedFailure(RuntimeError): pass
class SimulatedCommitUnknown(RuntimeError): pass


class AtomicMemoryModel:
    origin = 'P18_AUTHOR_MEMORY_MODEL_NOT_P21'
    durable = False

    def __init__(self, planner, stage, meta, wallet_port):
        self.planner = planner; self.wallet_port = wallet_port
        self._record = (stage, meta, ())
        self.lock = RLock()
        self.planner.authority.bind_store(stage)

    @property
    def stage(self):
        with self.lock: return self._record[0]

    @property
    def meta(self):
        with self.lock: return self._record[1]

    @property
    def receipts(self):
        with self.lock: return self._record[2]

    def prepare(self, candidate):
        with self.lock:
            return prepare_atomic(self.planner, candidate, self.stage, self.meta, self.wallet_port)

    def submit(self, bundle, *, fail_at=None):
        with self.lock:
            if fail_at == 'before_validation': raise InjectedFailure(fail_at)
            stage, meta, receipts = self._record
            checked = validate_atomic(bundle, self.planner, stage, meta, self.wallet_port)
            if checked.status == 'DUPLICATE_NO_OP':
                return {'status': 'DUPLICATE_NO_OP', 'durable': False, 'origin': self.origin}
            body = bundle.value['body']; sc = body['stage_candidate']; mc = body['wallet_character_candidate']
            staged_stage = FrozenMessage.from_value(sc['after_state'])
            if fail_at == 'after_stage_prepared': raise InjectedFailure(fail_at)
            staged_meta = meta if mc is None else FrozenMessage.from_value(mc['after_state'])
            if fail_at in ('after_wallet_prepared', 'before_publish'): raise InjectedFailure(fail_at)
            receipt = FrozenMessage.from_value({'status': 'COMMITTED_SIMULATION',
                'transaction_id': bundle.value['p13_projection']['transaction_id'],
                'request_id': sc['request']['request_id'], 'request_sha256': sc['request_sha256'],
                'bundle_sha256': bundle.sha256, 'stage_sha256': staged_stage.sha256,
                'meta_sha256': staged_meta.sha256, 'revision': staged_stage.value['revision'],
                'decision': sc['decision'], 'durable': False, 'origin': self.origin})
            # One record reference publishes both domains and the model receipt.
            self._record = (staged_stage, staged_meta, receipts + (receipt,))
            self.planner.authority.bind_store(staged_stage, 'COMMIT_UNKNOWN' if fail_at == 'after_publish_unknown' else 'CONSISTENT')
            if fail_at == 'after_publish_unknown': raise SimulatedCommitUnknown(fail_at)
            return receipt.value

    def lookup(self, request_id, *, resolve_unknown=False):
        with self.lock:
            receipt = next((r for r in self.receipts if r.value['request_id'] == request_id), None)
            if resolve_unknown and receipt is not None:
                self.planner.authority.bind_store(self.stage)
            return {'status': 'COMMITTED_SIMULATION' if receipt else 'ABSENT_SIMULATION',
                    'receipt': None if receipt is None else receipt.value, 'durable': False, 'origin': self.origin}

    def reload(self):
        with self.lock:
            stage = restore_state(self.stage.raw, self.planner.catalog, self.planner.authority)
            self._record = (stage, FrozenMessage(self.meta.raw), self.receipts)
            return stage
