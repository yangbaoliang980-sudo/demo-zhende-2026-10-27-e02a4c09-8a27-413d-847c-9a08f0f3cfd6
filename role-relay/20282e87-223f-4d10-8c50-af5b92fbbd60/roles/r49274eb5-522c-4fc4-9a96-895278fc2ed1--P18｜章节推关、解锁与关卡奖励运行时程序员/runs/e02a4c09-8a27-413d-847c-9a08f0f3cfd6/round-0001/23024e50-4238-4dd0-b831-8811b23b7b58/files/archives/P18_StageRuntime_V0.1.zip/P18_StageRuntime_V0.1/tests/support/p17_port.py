"""Contract-test binding to UNMODIFIED P17 code. Not a production integrator."""
import sys
from stage_runtime.common import PACKAGE_ROOT, FrozenMessage, fingerprint, need, StageError

_p = str(PACKAGE_ROOT / 'upstream/P17')
if _p not in sys.path: sys.path.append(_p)
from character_party_runtime import MetaPlanner, load_catalog, empty_state, command
from character_party_runtime.common import DomainError

CHARS = ['MOCK_P04_CHAR_001', 'MOCK_P04_CHAR_002', 'MOCK_P04_CHAR_003']
TOKEN = 'MOCK_P04_TRAINING_TOKEN'


class SingleGrant:
    def __init__(self, grant): self.grant = grant
    def resolve_grant(self, ref): return self.grant if ref == self.grant.value['grant_ref'] else None
    def resolve_quote(self, ref): return None
    def resolve_reversal(self, ref): return None


class P17ContractPort:
    def __init__(self): self.catalog = load_catalog()

    def _planner(self, grant): return MetaPlanner(self.catalog, SingleGrant(grant))

    def propose(self, grant, snapshot):
        planner = self._planner(grant)
        req = command(snapshot, 'p18.meta.' + fingerprint(grant.value['grant_ref']),
                      'APPLY_GRANT', {'grant_ref': grant.value['grant_ref']})
        result = planner.plan(req, snapshot)
        need(result.status == 'CANDIDATE', 'E_P17:' + result.reason)
        return FrozenMessage(result.candidate.raw)

    def validate(self, grant, candidate, snapshot):
        try:
            result = self._planner(grant).validate_for_commit(candidate, snapshot)
            need(result.status == 'CANDIDATE', 'E_P17_DUPLICATE_WITHOUT_STAGE_RECEIPT')
        except DomainError as exc:
            raise StageError('E_P17:' + exc.code) from exc

    def party(self, snapshot): return MetaPlanner(self.catalog).party_snapshot(snapshot)

    def balances(self, snapshot): return MetaPlanner(self.catalog).wallet_snapshot(snapshot).value['balances']

    def bootstrap(self, scope, store, continuity):
        """Test-only owned characters; no stage completion or monetary reward."""
        state = empty_state(self.catalog, profile_id=scope, store_instance=store, continuity_ref=continuity)
        grant = FrozenMessage.from_value({'schema_version': 'P17-GRANT-INPUT/0.1.0-proposal',
            'grant_ref': 'fixture.bootstrap', 'issuer': 'P18', 'profile_id': scope,
            'source_kind': 'STAGE_REPEAT', 'identity': {'campaign_id': 'fixture.bootstrap',
                'stage_id': 'fixture.not-a-player-stage', 'battle_id': 'fixture.bootstrap'},
            'eligibility_ref': 'fixture.bootstrap-only', 'policy_version': 'fixture.bootstrap',
            'policy_sha256': fingerprint('TEST_ONLY_OWNED_CHARACTERS'), 'resources': [],
            'characters': CHARS, 'xp': [], 'equipment': []})
        state = FrozenMessage.from_value(self.propose(grant, state).value['after_state'])
        req = command(state, 'fixture.set-party', 'SET_PARTY', {'ordered_character_ids': CHARS})
        result = MetaPlanner(self.catalog).plan(req, state)
        need(result.status == 'CANDIDATE', result.reason)
        return FrozenMessage.from_value(result.candidate.value['after_state'])

