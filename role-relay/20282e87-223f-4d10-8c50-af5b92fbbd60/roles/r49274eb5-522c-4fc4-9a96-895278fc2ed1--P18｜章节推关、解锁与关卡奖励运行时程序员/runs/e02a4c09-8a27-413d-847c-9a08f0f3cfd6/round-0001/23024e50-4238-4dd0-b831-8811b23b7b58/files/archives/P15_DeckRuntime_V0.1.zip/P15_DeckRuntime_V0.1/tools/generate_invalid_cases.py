"""Create explicit negative input fixtures. Expected codes are authored oracles."""
from pathlib import Path
import copy, json, sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from examples.support import inputs, snapshot, command

context, recipe = inputs()
base = snapshot(context, recipe).value
cmd = command(base).value
cases = []

def add(name, code, change, *, schema=False):
    s, c = copy.deepcopy(base), copy.deepcopy(cmd)
    change(s, c)
    cases.append({'case_id': 'INV-'+str(len(cases)+1).zfill(3), 'name': name, 'snapshot': s, 'command': c,
        'expected': {'kind': 'CONTRACT_ERROR' if schema else 'REJECTED', 'code': code,
                     'authoritative_change': False, 'candidate': None}})

add('insufficient_energy', 'ENERGY_INSUFFICIENT', lambda s,c:s.update(energy=0))
add('unknown_actor', 'ACTOR_INVALID', lambda s,c:c['payload'].update(actor_id='missing'))
add('enemy_actor', 'ACTOR_INVALID', lambda s,c:c['payload'].update(actor_id='enemy1'))
add('dead_actor', 'ACTOR_INVALID', lambda s,c:s['units'][0].update(hp=0))
add('instance_belongs_to_other_hero', 'CARD_OWNER_INVALID', lambda s,c:c['payload'].update(actor_id='hero_b'))
add('missing_instance', 'CARD_NOT_IN_HAND', lambda s,c:c['payload'].update(card_instance_id='missing'))
def moved(s,c,zone):
    iid=c['payload']['card_instance_id'];s['zones']['hand'].remove(iid);s['zones'][zone].append(iid)
add('already_discarded', 'CARD_NOT_IN_HAND', lambda s,c:moved(s,c,'discard'))
add('already_exhausted', 'CARD_NOT_IN_HAND', lambda s,c:moved(s,c,'exhaust'))
add('enemy_turn', 'PHASE_INVALID', lambda s,c:s.update(phase='ENEMY_READY'))
add('stale_revision', 'REVISION_CONFLICT', lambda s,c:s.update(revision=1))
add('wrong_battle', 'BATTLE_ID_MISMATCH', lambda s,c:c.update(battle_id='fixture:other'))
add('missing_target', 'TARGET_INVALID', lambda s,c:c['payload'].update(target_ids=['missing']))
add('dead_target', 'TARGET_INVALID', lambda s,c:s['units'][3].update(hp=0))
add('friendly_target_for_attack', 'TARGET_INVALID', lambda s,c:c['payload'].update(target_ids=['hero_a']))
add('too_many_targets', 'TARGET_INVALID', lambda s,c:c['payload'].update(target_ids=['enemy1','hero_a']))
add('no_targets', None, lambda s,c:c['payload'].update(target_ids=[]), schema=True)
add('duplicate_targets', 'DUPLICATE_TARGET', lambda s,c:c['payload'].update(target_ids=['enemy1','enemy1']), schema=True)
add('self_reported_cost', None, lambda s,c:c['payload'].update(cost=0), schema=True)
add('self_reported_hp', None, lambda s,c:c['payload'].update(hp=100), schema=True)
add('bool_revision', None, lambda s,c:c.update(expected_revision=True), schema=True)
add('negative_energy_snapshot', None, lambda s,c:s.update(energy=-1), schema=True)
add('same_instance_two_zones', 'CARD_IN_MULTIPLE_ZONES', lambda s,c:s['zones']['discard'].append(c['payload']['card_instance_id']), schema=True)
add('wrong_content_version', 'CONTENT_VERSION_MISMATCH', lambda s,c:s.update(content_version='fixture:unknown'))
add('wrong_rules_version', 'RULES_VERSION_MISMATCH', lambda s,c:s.update(rules_version='fixture:unknown'))
add('disabled_buff', 'CONTENT_DISABLED', lambda s,c:s['card_instances'][0].update(card_id='MOCK_P03_CARD_FOCUS_DRAFT'))
add('disabled_debuff', 'CONTENT_DISABLED', lambda s,c:s['card_instances'][0].update(card_id='MOCK_P03_CARD_FEEBLE_DRAFT'))
add('unknown_card_definition', 'CONTENT_UNAVAILABLE', lambda s,c:s['card_instances'][0].update(card_id='fixture:missing'))
add('unsupported_contract_version', 'UNSUPPORTED_CONTRACT_VERSION', lambda s,c:c.update(contract_version='future:version'), schema=True)
add('card_owned_by_enemy', 'CARD_OWNER_INVALID', lambda s,c:s['card_instances'][0].update(owner_unit_id='enemy1'))
add('non_string_target', None, lambda s,c:c['payload'].update(target_ids=[1]), schema=True)
add('invalid_rng_history', 'RNG_HISTORY_INVALID', lambda s,c:s['rng'].update(state=2))
add('zero_seed', None, lambda s,c:s['rng'].update(initial_seed=0,state=0), schema=True)
add('closed_battle', 'ALREADY_CLOSED', lambda s,c:s.update(phase='TERMINAL',outcome='WIN'))
add('aborted_battle', 'ALREADY_CLOSED', lambda s,c:s.update(phase='ABORTED',outcome='ABORTED'))
add('extra_request_id_wire_field', None, lambda s,c:c.update(request_id=c['command_id']), schema=True)
add('party_definition_changed', 'PARTY_SNAPSHOT_MISMATCH', lambda s,c:s['units'][0].update(definition_id='fixture:unknown'))
add('signature_instance_forged_owner', 'CARD_OWNER_INVALID', lambda s,c:s['card_instances'][6].update(owner_unit_id='hero_b'))
add('unowned_system_command', 'COMMAND_NOT_OWNED_BY_P15', lambda s,c:c.update(kind='SYSTEM_ENEMY_ACTION',payload={}))
(ROOT/'invalid_play_cases.json').write_text(json.dumps({'format':'P15-INVALID-PLAYS/0.1.0-isolated',
    'scope':'AUTHOR_FIXTURE_INPUTS_AND_EXPECTATIONS_NOT_EXECUTION_LOG', 'context_sha256':context.sha256,
    'cases':cases},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'generated_cases':len(cases),'path':'invalid_play_cases.json'}))
