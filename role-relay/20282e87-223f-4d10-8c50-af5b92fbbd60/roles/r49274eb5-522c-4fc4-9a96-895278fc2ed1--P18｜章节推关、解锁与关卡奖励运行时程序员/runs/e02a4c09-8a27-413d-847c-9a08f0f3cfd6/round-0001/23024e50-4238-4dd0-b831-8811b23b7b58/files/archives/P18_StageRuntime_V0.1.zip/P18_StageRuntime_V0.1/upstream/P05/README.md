# 《言灵旅团》P05｜战斗数值与学习经济离线交付 V0.1

**角色**：P05 战斗数值与学习资源经济平衡师  
**任务**：`TASK-P05-S01-S03-S05-LOCAL-001`  
**参数/模拟版本**：`P05-BALANCE-0.1.0-provisional`  
**随机种子**：`20261028`  
**交付性质**：`LOCAL_MOCK_SIMULATION_DELIVERED / FORMAL_GAME_INTEGRATION_BLOCKED`  
**本地实测范围**：Python 标准库离线模拟、字节级固定种子复算、作者单元测试。P32/P35、P14 真实游戏、P08/P11 真实 Anki、P21 持久化 E2E 均未运行。

## 优先下载与打开

从本次答复下载 `P05_S01_Balance_Delivery_V0.1.zip`，完整解压；**不要只下载 CSV 而漏掉 P02/P03/P04 的只读固定输入**。目录结构保持不变。

## 四项强制交付

| 逻辑相对路径（隔离交付） | 实体文件 | 用途 |
|---|---|---|
| `content/balance/balance_parameters.tsv` | 89 条数值记录 | 含 P03/P04 原数值引用与 P05 未签候选、来源哈希、owner/版本和边界 |
| `analysis/simulations/fixed_seed_simulation.py` | 可执行 Python 标准库源码 | 固定 seed、原始文件 hash 校验、战斗/收益模拟、敏感性/反例 |
| `analysis/simulations/simulation_results.csv` | 44 条模拟结果 | 普通/精英/BOSS长战、不同策略和角色等级、零/仅Again/大量学习、重放、Undo、盾堆积、伤害/费用敏感性 |
| `design/balance/reward_abuse_cases.md` | 文字反例及 owner 矩阵 | 重放、异指纹、错误作答激励、撤销与已消费、极端刷取和费用堆叠 |

## 其他直接可接收工件

| 文件 | 说明 |
|---|---|
| `design/balance/balance_report.md` | 关键数值结论、资源预算、敏感性与更改建议（不改上游） |
| `design/balance/card_adjustment_candidates.tsv` | 两费专属卡等效调整 RFC 候选，记录 P03 原哈希 |
| `design/balance/interface_rfc_blockers.md` | IC-04/06/11、P06/P08/P13/P18/P22 缺项及责任分派 |
| `content/balance/character_growth_projection.tsv` | P04 三人 Lv1–Lv5 原成长公式逐级展开，未加伤害缩放 |
| `content/balance/stage_resource_budget.tsv` | 0～多个普通/精英/BOSS 假想首通预算（P18 未签） |
| `analysis/simulations/test_fixed_seed_simulation.py` | 33 项作者单测，未冒充 P32 独立测试 |
| `evidence/readonly_upstream/` | 六份 P01/P02/P03/P04 原始字节快照，仅供复算，不可当正式内容 |
| `evidence/source_input_receipt.tsv` | 全部 30 个上传附件、4 内层 ZIP/manifest、6 原字节源与缺失源的状态 |
| `evidence/validation.log` | 本次已实际执行的命令输出、exit code、解释器版本 |
| `evidence/delivery_manifest.sha256.tsv` | 逐文件精确字节、SHA-256、源输入哈希、下游接收岗位和修改白名单（不包括自身） |

## 执行/独立重算（Python 3.10+）

在**解压根目录**执行，不依赖任何 Anki 客户端、Unity、第三方库或网络：

```bash
python analysis/simulations/fixed_seed_simulation.py --seed 20261028 --verify
python -m unittest discover -s analysis/simulations -p "test_*.py" -v
```

`--verify` 不改文件，逐字节核对当前模拟输出；若 SHA/source 发生漂移或 CSV 不一致则退出非零。重建模拟 CSV 需显式执行：

```bash
python analysis/simulations/fixed_seed_simulation.py --seed 20261028
```

默认重建**只写解压后的 P05 本地输出 CSV**；若需要别的结果文件可指定 `--output /some/path/p05.csv`，但须自行标注新种子、新输出哈希，不能套用本包固定结果验收。

## 审查与缺项

- **不可当正式数值**：P01 未批准角色/卡/敌数；P03 10 张测试卡内 8 激活 2 禁用，P04 3 角色是结构 Mock；P06 正式敌/BOSS、P18 正式关卡资源未到场；学习四键、Undo、无学习日策略为 `DEC-001/002/003` 未批准。
- **不可当战斗引擎代码**：模拟器自行采用 3 能量/4 抽牌/5 手牌、纯合成单敌人、无 BOSS 阶段和有限 AI。P14 的 `BattleState`、幂等事务、P15 抽弃牌与 P06 行动意图不在本包内。
- **不可当 Anki 真实数据**：本包 `RID_*` 是纯合成事件 ID，模拟的 `trusted` 布尔不是已验证身份；`shadow_net` 不是钱包余额，也不存在真实发奖。
- **权限边界**：允许编辑/交付的 P05 逻辑范围 `design/balance/**`、`content/balance/**`、`analysis/simulations/**`；`evidence/**` 为只读证据/包级元数据。正式仓库写入需要 P13 `actual_path_mapping.json`、白名单和授权。已保持 GitHub 原工程无修改，不擅自代行 EXT-INTEGRATOR。
- **审查状态**：本地作者单测和固定种子复算 PASS；P32 独测及 P35 独审 NOT_RUN；真实游戏/Anki 和跨岗契约 BLOCKED/NOT_RUN（详见报告与 blockers）。

## 下游接力顺序

P02/P03/P04/P06/P08/P14 读取 `balance_report.md`、`balance_parameters.tsv`、`card_adjustment_candidates.tsv`、`reward_abuse_cases.md` 并决定是否走 RFC；P13/P22 冻结 DTO 和 ID 后才能导入正式工程；P32 先检查 `evidence/validation.log` 并独立复算，P35 最后签门禁；P39 在真实原型中测体验。所有变更须保留上游 SHA、base SHA 和 owner。**禁止直接合并这个 Mock 模拟器当战斗引擎实现。**
