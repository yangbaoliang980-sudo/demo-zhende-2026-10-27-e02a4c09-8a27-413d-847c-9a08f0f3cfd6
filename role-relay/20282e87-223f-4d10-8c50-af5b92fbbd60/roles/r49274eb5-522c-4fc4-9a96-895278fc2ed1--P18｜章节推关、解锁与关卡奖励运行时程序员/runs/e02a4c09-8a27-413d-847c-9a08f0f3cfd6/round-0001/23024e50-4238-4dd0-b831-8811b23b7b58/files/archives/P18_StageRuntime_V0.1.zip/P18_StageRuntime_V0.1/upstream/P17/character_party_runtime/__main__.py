"""Small explicitly isolated demo entry point."""
import json
from examples.lifecycle_demo import run_demo

result=run_demo()
print(json.dumps({k:result[k] for k in ('scope','production_commit','durable','final_state_sha256','summary')},ensure_ascii=False,indent=2))
