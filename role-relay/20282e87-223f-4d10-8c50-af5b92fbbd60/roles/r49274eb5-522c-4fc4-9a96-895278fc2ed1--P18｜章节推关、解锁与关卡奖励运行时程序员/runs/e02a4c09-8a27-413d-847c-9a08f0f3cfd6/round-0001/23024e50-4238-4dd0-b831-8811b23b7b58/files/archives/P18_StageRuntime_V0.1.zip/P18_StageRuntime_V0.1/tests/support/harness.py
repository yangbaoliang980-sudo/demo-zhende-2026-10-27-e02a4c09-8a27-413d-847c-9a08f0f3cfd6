"""Reusable author fixture. Models P21 only in volatile memory."""
from stage_runtime import (FrozenMessage, StagePlanner, load_catalog, empty_state,
                           command, progress_view, Catalog)
from stage_runtime.common import get_row
from .authority import FixtureAuthority
from .p17_port import P17ContractPort, CHARS, TOKEN
from .memory_model import AtomicMemoryModel

NORMAL = 'MOCK_P07_STAGE_001'
BOSS = 'MOCK_P07_STAGE_002'
SCOPE = 'fixture.save.A'


class Harness:
    def __init__(self, scope=SCOPE, catalog=None):
        self.catalog = catalog or load_catalog(); self.authority = FixtureAuthority()
        self.wallet = P17ContractPort(); self.scope = scope; self.seq = 0
        stage = empty_state(self.catalog, player_save_scope_id=scope,
                            store_instance='fixture.store', continuity_ref='fixture.continuity')
        self.planner = StagePlanner(self.catalog, self.authority)
        meta = self.wallet.bootstrap(scope, 'fixture.store', 'fixture.continuity')
        self.model = AtomicMemoryModel(self.planner, stage, meta, self.wallet)

    def request(self, kind, payload, *, snapshot=None, request_id=None):
        self.seq += 1
        return command(snapshot or self.model.stage, self.planner.catalog,
                       request_id or 'req.' + str(self.seq), kind, payload)

    def plan(self, kind, payload, **kwargs):
        req = self.request(kind, payload, **kwargs)
        return req, self.planner.plan(req, self.model.stage)

    def apply(self, kind, payload, **kwargs):
        req, result = self.plan(kind, payload, **kwargs)
        if result.status != 'CANDIDATE':
            raise AssertionError(result.value())
        bundle = self.model.prepare(result.candidate)
        receipt = self.model.submit(bundle)
        return req, result.candidate, bundle, receipt

    def entry_payload(self, stage_id=NORMAL, battle_id='battle.A', *, ref=None, seed=1):
        ref = self.authority.issue_entry(self.planner.catalog, self.model.stage,
            self.model.meta, self.wallet, stage_id, battle_id, ref)
        return {'stage_id': stage_id, 'battle_id': battle_id, 'entry_ref': ref, 'seed': seed}

    def enter(self, stage_id=NORMAL, battle_id='battle.A', **kwargs):
        return self.apply('ENTER', self.entry_payload(stage_id, battle_id, **kwargs))

    def result(self, battle_id='battle.A', **kwargs):
        at = get_row(self.model.stage.value['attempts'], 'battle_id', battle_id)
        catalog = self.planner.catalogs.resolve(at['admission']['catalog_sha256']) or self.catalog
        return self.authority.issue_battle(self.model.stage, catalog, battle_id, **kwargs)

    def settle(self, battle_id='battle.A', **kwargs):
        r = self.result(battle_id, **kwargs)
        return r, self.apply('SETTLE', {'result': r.value})

    def clear(self, stage_id=NORMAL, battle_id='battle.A'):
        self.enter(stage_id, battle_id)
        return self.settle(battle_id)

    def revoke(self, battle_id, result, ref='fixture.revoke'):
        ref = self.authority.issue_control(self.model.stage, battle_id, result, ref=ref)
        return self.apply('REVOKE', {'control_ref': ref})

    def balance(self):
        rows = self.wallet.balances(self.model.meta)
        return next((r['available'] for r in rows if r['resource_id'] == TOKEN), 0)

    def xp(self):
        return [x['xp_total'] for x in self.model.meta.value['characters']]

    def stage_view(self, stage_id):
        return get_row(progress_view(self.model.stage, self.planner.catalog).value['stages'], 'stage_id', stage_id)

    def switch_catalog(self, catalog, *, keep_old=True):
        self.planner = StagePlanner(catalog, self.authority, historical=(self.catalog,) if keep_old else ())
        self.model.planner = self.planner


def changed_catalog(catalog, *, version='fixture.new-content', normal_tokens=None, normal_xp=None, repeat_tokens=None):
    d = catalog.value
    d['scope'] = 'SYNTHETIC_TEST_ONLY'; d['content_version'] = version
    stage = get_row(d['stages'], 'stage_id', NORMAL)
    if normal_tokens is not None: stage['first']['tokens'] = normal_tokens
    if normal_xp is not None: stage['first']['xp_each'] = normal_xp
    if repeat_tokens is not None:
        stage['repeat_enabled'] = True; stage['repeat']['tokens'] = repeat_tokens
    return Catalog(FrozenMessage.from_value(d))
