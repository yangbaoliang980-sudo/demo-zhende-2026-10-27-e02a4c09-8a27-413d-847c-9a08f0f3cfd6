"""Explicitly synthetic external authorities and a non-durable memory model."""
