"""Synthetic registries. Fabricated outcomes exist ONLY in author fixtures.

The runtime never imports this file. P14 native contract tests replace these
fixture outcomes with results produced by the unmodified actual P14 core.
"""
from stage_runtime.common import FrozenMessage, fingerprint, get_row, validate_dto, need


class FixtureAuthority:
    origin = 'P18_TEST_REGISTRY_NOT_PRODUCTION_AUTHORITY'

    def __init__(self):
        self.stores = {}; self.entries = {}; self.battles = {}; self.controls = {}

    def resolve_store(self, scope): return self.stores.get(scope)
    def resolve_entry(self, ref): return self.entries.get(ref)
    def resolve_battle(self, battle): return self.battles.get(battle)
    def resolve_control(self, ref): return self.controls.get(ref)

    def bind_store(self, snapshot, status='CONSISTENT'):
        s = snapshot.value
        self.stores[s['player_save_scope_id']] = FrozenMessage.from_value({
            'schema_version': 'P18-STORE-FENCE/0.1.0-proposal',
            **{k: s[k] for k in ('player_save_scope_id', 'store_instance', 'continuity_ref', 'revision')},
            'state_sha256': snapshot.sha256, 'status': status})

    def issue_entry(self, catalog, snapshot, meta, wallet_port, stage_id, battle_id, ref=None):
        s = snapshot.value
        ref = ref or 'entry.' + fingerprint([s['player_save_scope_id'], battle_id])
        party = wallet_port.party(meta)  # P17 checks ownership before exporting.
        self.entries[ref] = FrozenMessage.from_value({'schema_version': 'P18-ENTRY-EVIDENCE/0.1.0-proposal',
            'entry_ref': ref, **{k: s[k] for k in ('player_save_scope_id', 'store_instance', 'continuity_ref')},
            'stage_id': stage_id, 'battle_id': battle_id, 'catalog_sha256': catalog.sha256,
            'party_snapshot': party.value, 'party_source_sha256': meta.sha256,
            'battle_rules_version': 'P02-BATTLE-0.1.0-draft',
            'battle_content_version': 'fixture:P18-battle-v1',
            'battle_content_sha256': fingerprint('SYNTHETIC_COMBAT_INPUTS_NOT_P06_BALANCE')})
        return ref

    def issue_battle(self, snapshot, catalog, battle_id, *, outcome='WIN', revision=2, seed=None, phase=None):
        state = snapshot.value
        at = get_row(state['attempts'], 'battle_id', battle_id); need(at is not None, 'E_FIXTURE_ADMISSION')
        a = at['admission']; stage = catalog.stage(a['stage_id'])
        actual_phase = phase or ('TERMINAL' if outcome in ('WIN', 'LOSS', 'DRAW') else outcome)
        members = a['party_snapshot']['members']
        units = [{'unit_id': m['unit_id'], 'definition_id': m['character_id'], 'side': 'PLAYER', 'slot': m['slot'],
                  'hp': 0 if outcome in ('LOSS', 'DRAW') else m['max_hp'], 'max_hp': m['max_hp'],
                  'shield': 0, 'statuses': []} for m in members]
        for ref in stage['enemy_refs']:
            for n in range(ref['count']):
                units.append({'unit_id': 'fixture.enemy.' + str(len(units)), 'definition_id': ref['enemy_id'],
                    'side': 'ENEMY', 'slot': len(units)-len(members), 'hp': 0 if outcome in ('WIN', 'DRAW') else 1,
                    'max_hp': 1, 'shield': 0, 'statuses': []})
        seed = a['seed'] if seed is None else seed
        s = validate_dto({'contract_version': 'YLTT-INTERNAL/0.1.0-isolated', 'dto_type': 'BattleSnapshot',
            'battle_id': battle_id, 'revision': revision, 'rules_version': a['battle_rules_version'],
            'content_version': a['battle_content_version'], 'phase': actual_phase, 'turn_number': 1,
            'energy': 0, 'units': units, 'card_instances': [],
            'zones': {'hand': [], 'draw': [], 'discard': [], 'exhaust': []},
            'rng': {'algorithm': 'xorshift32-v1', 'initial_seed': seed, 'state': seed, 'draw_count': 0},
            'last_event_seq': revision+1, 'outcome': outcome if actual_phase == 'TERMINAL' else ('ABORTED' if actual_phase == 'ABORTED' else 'FAULTED' if actual_phase == 'FAULTED' else 'ONGOING'),
            'boss_states': []}, 'BattleSnapshot')
        result = None
        if actual_phase == 'TERMINAL':
            result = validate_dto({'contract_version': 'YLTT-INTERNAL/0.1.0-isolated', 'dto_type': 'BattleResult',
                'result_id': 'fixture.result.' + fingerprint([battle_id, revision, s.sha256]),
                'battle_id': battle_id, 'terminal_revision': revision, 'terminal_event_seq': revision,
                'outcome': outcome, 'stage_id': a['stage_id'], 'profile_scope': a['player_save_scope_id'],
                'rules_version': a['battle_rules_version'], 'content_version': a['battle_content_version'],
                'final_snapshot_sha256': s.sha256, 'replay_input_sha256': fingerprint('SYNTHETIC_NOT_P14_REPLAY')}, 'BattleResult')
        proof = FrozenMessage.from_value({'schema_version': 'P18-BATTLE-EVIDENCE/0.1.0-proposal',
            'battle_id': battle_id, 'admission_sha256': at['admission_sha256'],
            'snapshot': s.value, 'result': None if result is None else result.value})
        self.battles[battle_id] = proof
        return result

    def issue_control(self, snapshot, battle_id, result, *, ref='fixture.revoke', new_revision=None):
        s = snapshot.value; at = get_row(s['attempts'], 'battle_id', battle_id)
        p = FrozenMessage.from_value({'schema_version': 'P18-REVOCATION-EVIDENCE/0.1.0-proposal',
            'control_ref': ref, 'player_save_scope_id': s['player_save_scope_id'],
            'battle_id': battle_id, 'admission_sha256': at['admission_sha256'],
            'superseded_result': result.value, 'new_revision': new_revision or result.value['terminal_revision']+1})
        self.controls[ref] = p
        return ref

