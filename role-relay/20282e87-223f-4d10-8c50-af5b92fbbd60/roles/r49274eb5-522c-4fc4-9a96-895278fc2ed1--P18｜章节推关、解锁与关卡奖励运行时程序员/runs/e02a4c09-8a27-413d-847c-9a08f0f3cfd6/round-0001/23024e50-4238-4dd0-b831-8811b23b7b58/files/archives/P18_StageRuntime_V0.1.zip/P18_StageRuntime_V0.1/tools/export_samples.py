"""Write reviewable demonstration artifacts. This tool is not runtime storage."""
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from examples.stage_lifecycle import run_demo
from stage_runtime import first_clear_key, first_clear_identity, repeat_identity, load_catalog
from tests.support.harness import Harness, NORMAL, BOSS
from tests.support.p14_native import start_native, finish_native
from tests.support.p07_replay import SELECTED


def write(path, value):
    target = ROOT/path; target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return {'path': path, 'size_bytes': target.stat().st_size, 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}


def main():
    demo = run_demo(); written = []
    written.append(write('examples/lifecycle_execution.json', demo))
    written.append(write('examples/demo_summary.json', demo['summary']))
    written.append(write('examples/stage_snapshot.json', demo['final_stage']))
    written.append(write('examples/stage_progress_view.json', demo['progress_view']))
    written.append(write('examples/joint_transaction.json', demo['events'][1]['bundle']))
    catalog = load_catalog()
    keys = {'schema_version': 'P18-FIRST-CLEAR-KEYS/0.1.0', 'lifetime': 'STABLE_PLAYER_SAVE_SCOPE_AND_CANONICAL_STAGE',
        'identity_encoding': 'P13 canonical UTF-8 JSON array', 'hash': 'SHA-256',
        'excluded': ['battle_id', 'terminal_revision', 'chapter_id', 'content_version', 'reward_version', 'filename', 'device_id', 'store_instance'],
        'p17_projection_status': 'PROPOSAL_NOT_ACCEPTED',
        'p17_projection': {'profile_id': 'player_save_scope_id', 'campaign_id': 'YLTT_STAGE_SCOPE',
            'stage_id': 'canonical_stage_id', 'scope_constraint': 'P17 profile_id must equal stable save scope for this isolated adapter'},
        'vectors': [{'scope': scope, 'stage_id': stage, 'logical_identity': first_clear_identity(scope, stage),
                     'key_sha256': first_clear_key(scope, stage)} for scope in ('fixture.save.A', 'fixture.save.B') for stage in (NORMAL, BOSS)],
        'repeat_vectors': [repeat_identity('fixture.save.A', NORMAL, 'battle.A', 2), repeat_identity('fixture.save.A', NORMAL, 'battle.B', 2)],
        'default_repeat_enabled': False, 'same_battle_higher_revision': 'RECONCILE_ONLY_NO_NEW_AWARD'}
    written.append(write('first_clear_keys.json', keys))
    source = ROOT/'upstream/P07/content/stages/stage_retry_cases.json'
    original = json.loads(source.read_text(encoding='utf-8'))
    written.append(write('stage_progress_fixtures.json', {'schema_version': 'P18-PROGRESS-FIXTURES/0.1.0',
        'source_file': str(source.relative_to(ROOT)), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'expected_case_owner': 'P07', 'cases_are_expected_not_execution_results': True,
        'direct_adapter_selected_case_ids': ['P07-ST-'+str(i).zfill(3) for i in sorted(SELECTED)],
        'execution_evidence': 'p07_projection_results.json',
        'upstream_cases': original['cases'], 'runtime_catalog': catalog.value}))
    h = Harness('fixture.native.save'); core, at = start_native(h)
    result, cmd, reply = finish_native(h, core, at)
    req, candidate, bundle, receipt = h.apply('SETTLE', {'result': result.value})
    written.append(write('examples/native_p14_contract_execution.json', {
        'scope': 'UNMODIFIED_P14_RESULT_UNMODIFIED_P17_CANDIDATE_TEST_STORE_ONLY', 'durable': False,
        'p14_command': cmd.value, 'p14_reply': reply.value, 'p14_result': result.value,
        'p14_result_raw_sha256': result.sha256, 'p14_final_snapshot': core.snapshot(at['battle_id']).value,
        'p18_request': req.value, 'p18_candidate': candidate.value, 'joint_bundle': bundle.value,
        'simulated_receipt': receipt, 'wallet_balance': h.balance(), 'xp_each': h.xp()}))
    print(json.dumps({'generated': written, 'demo_summary': demo['summary']}, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
