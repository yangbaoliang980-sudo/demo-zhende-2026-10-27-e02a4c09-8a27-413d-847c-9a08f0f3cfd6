from dataclasses import replace
import json, unittest
from deck_runtime import plan, DeckPolicy, DeckRejected
from deck_runtime.wire import ContractError, canonical, checked
from examples.support import ROOT, inputs, snapshot, command, CATALOG_PATH


class ValidationTests(unittest.TestCase):
    def test_valid_card_returns_bound_candidate_and_reference_only_intent(self):
        ctx,recipe=inputs()
        s=snapshot(ctx,recipe);c=command(s)
        before=s.raw
        decision=plan(c,s,ctx)
        self.assertEqual(decision.code,'OK')
        self.assertEqual(s.raw,before)
        p=decision.candidate.value
        self.assertEqual(p['energy_delta'],-1)
        self.assertEqual(p['command_sha256'],c.sha256)
        self.assertEqual(p['snapshot_sha256'],s.sha256)
        self.assertEqual(p['rng_after'],p['rng_before'])
        self.assertEqual(p['moves'][0]['from_zone'],'hand')
        self.assertEqual(p['moves'][0]['to_zone'],'discard')
        i=decision.action_intent.value
        self.assertEqual(i['target_ids'],c.value['payload']['target_ids'])
        self.assertEqual(i['deck_candidate_sha256'],decision.candidate.sha256)
        self.assertFalse(i['wire_submission'])
        self.assertNotIn('hp',i)

    def test_end_turn_keep_is_explicit_noop(self):
        ctx,recipe=inputs(policy_changes={'end_turn':'KEEP'})
        s=snapshot(ctx,recipe)
        p=plan(command(s,kind='END_TURN'),s,ctx).candidate.value
        self.assertEqual(p['moves'],[])
        self.assertEqual(p['energy_delta'],0)

    def test_end_turn_discards_all_without_energy_change(self):
        ctx,recipe=inputs();s=snapshot(ctx,recipe)
        p=plan(command(s,kind='END_TURN'),s,ctx).candidate.value
        self.assertEqual(len(p['moves']),9)
        self.assertEqual(p['energy_delta'],0)
        self.assertTrue(all(m['to_zone']=='discard' for m in p['moves']))

    def test_add_energy_capped_and_returned_only_as_candidate(self):
        ctx,recipe=inputs(policy_changes={'entry_energy_mode':'ADD_CAPPED','entry_energy':2})
        raw=snapshot(ctx,recipe,ready=False).value;raw['energy']=2
        s=checked(raw,'BattleSnapshot')
        d=plan(command(s,kind='SYSTEM_START'),s,ctx)
        self.assertEqual(d.candidate.value['energy_delta'],1)
        self.assertEqual(s.value['energy'],2)

    def test_keep_energy_never_grants_resources(self):
        ctx,recipe=inputs(policy_changes={'entry_energy_mode':'KEEP','entry_energy':0})
        s=snapshot(ctx,recipe,ready=False)
        self.assertEqual(plan(command(s,kind='SYSTEM_START'),s,ctx).candidate.value['energy_delta'],0)

    def test_status_reapplication_rejected(self):
        ctx,recipe=inputs();raw=snapshot(ctx,recipe).value
        raw['units'][3]['statuses']=[{'status_instance_id':'status:test','status_id':'MOCK_P03_STATUS_BURN',
            'source_unit_id':'hero_a','stacks':1,'remaining_triggers':1,'insert_order':0}]
        s=checked(raw,'BattleSnapshot');c=command(s,card_id='MOCK_P03_CARD_EMBER')
        self.assertEqual(plan(c,s,ctx).code,'STATUS_REAPPLY_UNDEFINED')

    def test_no_default_production_mode(self):
        ctx,recipe=inputs()
        with self.assertRaisesRegex(DeckRejected,'PRODUCTION_DEPENDENCIES_UNBOUND'):
            replace(ctx,mode='production')

    def test_boolean_and_negative_cost_config_rejected(self):
        ctx,_=inputs()
        for cost in (True,-1,1.5,2**53):
            with self.assertRaises(DeckRejected):
                replace(ctx.catalog.cards[0],cost=cost)

    def test_deck_patch_schema_is_exact_p13_definition_projection(self):
        full=json.loads((ROOT/'upstream/P13/contracts/internal/internal_dto.schema.json').read_text())
        own=json.loads((ROOT/'deck_patch_schema.json').read_text())
        for name in ('DeckPatchCandidate','Move','Rng'):
            self.assertEqual(own['$defs'][name],full['$defs'][name])


def invalid_case(row):
    def test(self):
        ctx,_=inputs()
        s,c=row['snapshot'],row['command']
        # json.dumps preserves malformed semantic inputs that canonical() may refuse.
        before=json.dumps([s,c],sort_keys=True)
        if row['expected']['kind']=='CONTRACT_ERROR':
            with self.assertRaises(ContractError) as error:
                plan(c,s,ctx)
            if row['expected']['code'] is not None:
                self.assertEqual(str(error.exception),row['expected']['code'])
        else:
            result=plan(c,s,ctx)
            self.assertEqual(result.code,row['expected']['code'])
            self.assertIsNone(result.candidate)
            self.assertIsNone(result.action_intent)
        self.assertEqual(json.dumps([s,c],sort_keys=True),before)
    return test


for row in json.loads((ROOT/'invalid_play_cases.json').read_text())['cases']:
    setattr(ValidationTests,'test_'+row['case_id'].replace('-','_')+'_'+row['name'],invalid_case(row))


def valid_upstream_card(row):
    def test(self):
        chars=('A','B','D') if row['owner_character_id']=='MOCK_P03_CHAR_D' else ('A','B','C')
        ctx,recipe=inputs(chars=chars);s=snapshot(ctx,recipe)
        target='enemy1' if row['target_rule']['side']=='ENEMY' else 'hero_a'
        c=command(s,card_id=row['card_id'],targets=[target])
        d=plan(c,s,ctx)
        self.assertEqual(d.code,'OK')
        self.assertEqual(d.candidate.value['energy_delta'],-row['cost']['amount'])
        self.assertEqual(d.action_intent.value['effect_ids'],row['effect_ids'])
    return test


for row in json.loads(CATALOG_PATH.read_text())['cards']:
    if row['mock_playable']:
        setattr(ValidationTests,'test_P03_'+row['card_id'],valid_upstream_card(row))
