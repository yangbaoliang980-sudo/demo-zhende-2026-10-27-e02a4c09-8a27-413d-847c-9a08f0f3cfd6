"""Evidence writer used only by authors/tests, outside stage_runtime."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def sha(b): return hashlib.sha256(b).hexdigest()


def record(name, command):
    out = ROOT/'evidence/runs'/name
    out.mkdir(parents=True, exist_ok=False)
    sources = [p for p in ROOT.rglob('*') if p.is_file() and p.suffix in ('.py', '.json', '.tsv', '.txt')
               and p.relative_to(ROOT).parts[0] in ('stage_runtime', 'tests', 'tools', 'upstream', 'examples')
               and '__pycache__' not in p.parts]
    bindings = []
    with zipfile.ZipFile(out/'executed_sources.zip', 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(sources):
            b = p.read_bytes(); rel = str(p.relative_to(ROOT))
            z.writestr(rel, b); bindings.append({'path': rel, 'size_bytes': len(b), 'sha256': sha(b)})
    started = datetime.now(timezone.utc).isoformat(); clock = time.monotonic()
    result = subprocess.run(command, cwd=ROOT, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
    (out/'stdout.log').write_bytes(result.stdout); (out/'stderr.log').write_bytes(result.stderr)
    rec = {'name': name, 'command': command, 'cwd': str(ROOT), 'started_utc': started,
           'ended_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': round(time.monotonic()-clock, 6),
           'exit_code': result.returncode, 'python': sys.version, 'platform': platform.platform(),
           'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr),
           'executed_sources_zip_sha256': sha((out/'executed_sources.zip').read_bytes()), 'source_bindings': bindings}
    (out/'run_receipt.json').write_text(json.dumps(rec, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'run': name, 'exit_code': result.returncode, 'evidence_dir': str(out),
                      'stdout_tail': result.stdout.decode(errors='replace')[-2000:],
                      'stderr_tail': result.stderr.decode(errors='replace')[-6000:]}, ensure_ascii=False, indent=2))
    return result.returncode


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('name'); parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args(); raise SystemExit(record(args.name, args.command))
