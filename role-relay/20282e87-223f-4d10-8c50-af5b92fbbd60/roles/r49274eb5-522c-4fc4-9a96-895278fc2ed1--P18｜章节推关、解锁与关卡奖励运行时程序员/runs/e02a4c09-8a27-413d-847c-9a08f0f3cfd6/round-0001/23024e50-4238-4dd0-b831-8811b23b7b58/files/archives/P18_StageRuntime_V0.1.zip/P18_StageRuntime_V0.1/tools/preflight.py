"""Fail closed: this delivery is deliberately an isolated candidate, not deployable."""
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from stage_runtime import load_catalog


def run():
    mapping_path = ROOT/'upstream/P13/architecture/actual_path_mapping.json'
    mapping = json.loads(mapping_path.read_text(encoding='utf-8'))
    rows = [r for r in mapping['mappings'] if r['owner'] == 'P18']
    catalog = load_catalog()
    blockers = [
        {'id': 'P18-B01', 'owner': 'P13', 'condition': 'P18 actual production paths and write whitelist',
         'observed': rows, 'status': 'BLOCKED' if any(not r['write_allowed'] or r['actual_production_path'] is None for r in rows) else 'REQUIRES_INDEPENDENT_REVIEW'},
        {'id': 'P18-B02', 'owner': 'P21', 'condition': 'Accepted durable atomic store, receipt lookup and external restore fence',
         'observed': 'UnboundP21 rejects; tests/support/AtomicMemoryModel is durable=false', 'status': 'BLOCKED'},
        {'id': 'P18-B03', 'owner': 'P13/P17/P21', 'condition': 'Stable save-scope to P17 profile mapping and joint envelope accepted',
         'observed': 'P18 proposal only; no owner acceptance', 'status': 'BLOCKED'},
        {'id': 'P18-B04', 'owner': 'P13/P14/P21', 'condition': 'Authoritative entry, terminal and revocation resolution under same transaction fence',
         'observed': 'Test ports only; production default ClosedAuthority', 'status': 'BLOCKED'},
        {'id': 'P18-B05', 'owner': 'P05/P07/P01', 'condition': 'Approved content and rewards',
         'observed': {'content_version': catalog.value['content_version'], 'production_enabled': catalog.value['production_enabled']}, 'status': 'BLOCKED'},
        {'id': 'P18-B06', 'owner': 'P22/P13', 'condition': 'Canonical content IDs and approved alias/migration table',
         'observed': 'MOCK IDs; alias and added-stage migration rejected', 'status': 'BLOCKED'},
        {'id': 'P18-B07', 'owner': 'P34', 'condition': 'Actual engine, project and target machine evidence',
         'observed': 'P13 target_environment_requirements contains null target/source fields', 'status': 'BLOCKED'},
        {'id': 'P18-B08', 'owner': 'P32/P33/P35', 'condition': 'Independent acceptance at this exact package hash',
         'observed': 'NOT_RUN', 'status': 'BLOCKED'}]
    return {'task_id': 'P18-S07-STAGES-001', 'status': 'BLOCKED', 'intended_exit_code': 3,
            'production_writable': False, 'mapping_sha256': hashlib.sha256(mapping_path.read_bytes()).hexdigest(),
            'blockers': blockers, 'isolation': 'stage_runtime supports only mode=isolated'}


if __name__ == '__main__':
    print(json.dumps(run(), ensure_ascii=False, indent=2)); raise SystemExit(3)
