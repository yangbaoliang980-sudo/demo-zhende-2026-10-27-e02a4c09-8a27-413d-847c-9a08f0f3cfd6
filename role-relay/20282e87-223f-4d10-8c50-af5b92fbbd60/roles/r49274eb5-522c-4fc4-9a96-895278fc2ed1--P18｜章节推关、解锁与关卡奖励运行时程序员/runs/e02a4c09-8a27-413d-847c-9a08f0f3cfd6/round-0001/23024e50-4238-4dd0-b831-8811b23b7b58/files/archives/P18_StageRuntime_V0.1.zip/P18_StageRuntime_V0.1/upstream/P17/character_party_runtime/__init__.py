"""P17-META/0.1.0-isolated: immutable candidates, no physical persistence.

Lazy public exports keep the wallet, character and party modules independently
importable; importing a low-level helper must not eagerly import the planner.
"""
from importlib import import_module

_EXPORTS={
    'Catalog':'content','load_catalog':'content',
    'DomainError':'common','FrozenMessage':'common','PlanResult':'common','VERSION':'common',
    'empty_state':'state','restore_state':'state','validate_state':'state',
    'MetaPlanner':'service','command':'service','atomic_proposal':'service','UnboundP21':'service'}
__all__=list(_EXPORTS)


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError(name)
    value=getattr(import_module('.'+_EXPORTS[name],__name__),name)
    globals()[name]=value
    return value
