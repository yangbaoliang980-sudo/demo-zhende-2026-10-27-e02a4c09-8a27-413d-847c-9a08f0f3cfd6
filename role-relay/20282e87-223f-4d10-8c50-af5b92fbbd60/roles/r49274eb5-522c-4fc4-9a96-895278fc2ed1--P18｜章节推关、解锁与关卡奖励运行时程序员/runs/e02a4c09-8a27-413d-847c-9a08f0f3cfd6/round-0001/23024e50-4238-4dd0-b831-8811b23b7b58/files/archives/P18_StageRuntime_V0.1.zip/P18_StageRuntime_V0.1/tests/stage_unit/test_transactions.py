from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
import unittest
from stage_runtime import FrozenMessage, StageError, UnboundP21, prepare_atomic
from stage_runtime.common import fingerprint, validate_dto, MAX_INTEGER
from tests.support.harness import Harness, NORMAL, BOSS, changed_catalog
from tests.support.memory_model import InjectedFailure, SimulatedCommitUnknown


class TransactionTests(unittest.TestCase):
    def setUp(self): self.h = Harness()

    def pending(self, h=None):
        h = h or self.h; h.enter(); result = h.result()
        req, p = h.plan('SETTLE', {'result': result.value})
        return req, p.candidate, h.model.prepare(p.candidate), result

    def test_p13_projection_with_actual_p17_wallet_candidate(self):
        h = self.h; _, _, b, _ = self.pending()
        p = validate_dto(b.value['p13_projection'], 'AtomicCommitProposal').value
        self.assertEqual(p['transaction_kind'], 'STAGE_PROGRESS_WALLET')
        self.assertEqual(p['wallet_candidate']['changes'][0]['available_delta'], 3)
        self.assertEqual(b.value['body']['wallet_character_candidate']['required_counterpart_owner'], 'P18')

    def test_no_p17_port_blocks_monetary_candidate(self):
        h = self.h; _, c, _, _ = self.pending()
        with self.assertRaisesRegex(StageError, 'E_P17_PORT_UNBOUND'):
            prepare_atomic(h.planner, c, h.model.stage)
        self.assertEqual(h.balance(), 0)

    def test_production_store_remains_unbound(self):
        _, _, b, _ = self.pending()
        with self.assertRaisesRegex(StageError, 'E_P21_NOT_BOUND_NO_STATE_COMMITTED'):
            UnboundP21().submit(b)
        self.assertEqual(self.h.balance(), 0)

    def test_failures_never_publish_half_stage_or_wallet(self):
        for point in ('before_validation', 'after_stage_prepared', 'after_wallet_prepared', 'before_publish'):
            with self.subTest(point=point):
                h = Harness(); _, _, b, _ = self.pending(h); before = (h.model.stage.raw, h.model.meta.raw, h.model.receipts)
                with self.assertRaises(InjectedFailure): h.model.submit(b, fail_at=point)
                self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw, h.model.receipts))
                self.assertFalse(h.stage_view(BOSS)['unlocked']); self.assertEqual(h.balance(), 0)
                h.model.submit(b); self.assertEqual(h.balance(), 3)

    def test_ack_lost_requires_lookup_before_new_attempt(self):
        h = self.h; req, c, b, r = self.pending()
        with self.assertRaises(SimulatedCommitUnknown): h.model.submit(b, fail_at='after_publish_unknown')
        self.assertEqual(h.balance(), 3)
        _, p = h.plan('ENTER', h.entry_payload(BOSS, 'battle.B'))
        self.assertEqual(p.reason, 'E_COMMIT_UNKNOWN')
        receipt = h.model.lookup(req.value['request_id'], resolve_unknown=True)
        self.assertFalse(receipt['durable'])
        self.assertEqual(h.planner.plan(req, h.model.stage).status, 'DUPLICATE_NO_OP')
        h.enter(BOSS, 'battle.B'); self.assertEqual(h.balance(), 3)

    def test_noncommit_unknown_blocks_retry_award(self):
        h = self.h; _, _, b, r = self.pending()
        h.authority.bind_store(h.model.stage, 'COMMIT_UNKNOWN')
        _, p = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(p.reason, 'E_COMMIT_UNKNOWN'); self.assertEqual(h.balance(), 0)

    def test_source_authority_changes_before_commit(self):
        h = self.h; _, _, b, _ = self.pending(); before = (h.model.stage.raw, h.model.meta.raw)
        h.result(revision=3)
        with self.assertRaisesRegex(StageError, 'E_STALE_TERMINAL'): h.model.submit(b)
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

    def test_candidate_tampering_rejected_after_rehash(self):
        h = self.h; _, c, _, _ = self.pending()
        v = c.value; v['after_state']['first_clears'] = []; v['after_sha256'] = fingerprint(v['after_state'])
        with self.assertRaisesRegex(StageError, 'E_CANDIDATE_RECOMPUTE_MISMATCH'):
            h.model.prepare(FrozenMessage.from_value(v))
        self.assertEqual(h.balance(), 0)

    def test_bundle_wallet_tampering_rejected_after_rehash(self):
        h = self.h; _, _, b, _ = self.pending(); v = b.value
        v['body']['wallet_character_candidate']['wallet_delta']['changes'][0]['available_delta'] = 999
        v['body_sha256'] = fingerprint(v['body']); v['p13_projection']['domain_candidate_sha256'] = v['body_sha256']
        with self.assertRaisesRegex(StageError, 'E_JOINT_RECOMPUTE_MISMATCH'):
            h.model.submit(FrozenMessage.from_value(v))
        self.assertEqual(h.balance(), 0)

    def test_bundle_cannot_claim_durable_before_commit(self):
        _, _, b, _ = self.pending(); v = b.value; v['durable'] = True
        with self.assertRaisesRegex(StageError, 'E_FALSE_DURABLE_CLAIM'):
            self.h.model.submit(FrozenMessage.from_value(v))

    def test_same_result_multiple_requests_cas_only_one(self):
        h = self.h; _, _, b, r = self.pending()
        _, p2 = h.plan('SETTLE', {'result': r.value}); b2 = h.model.prepare(p2.candidate)
        h.model.submit(b)
        with self.assertRaisesRegex(StageError, 'E_REVISION_CONFLICT'): h.model.submit(b2)
        _, duplicate = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(duplicate.status, 'DUPLICATE_NO_OP'); self.assertEqual(h.balance(), 3)

    def test_concurrent_duplicate_delivery_one_publish(self):
        h = self.h; _, _, b, _ = self.pending(); gate = Barrier(6)
        def work(_): gate.wait(); return h.model.submit(b)['status']
        with ThreadPoolExecutor(max_workers=6) as pool: outcomes = list(pool.map(work, range(6)))
        self.assertEqual(outcomes.count('COMMITTED_SIMULATION'), 1)
        self.assertEqual(outcomes.count('DUPLICATE_NO_OP'), 5)
        self.assertEqual(h.balance(), 3); self.assertEqual(len(h.model.receipts), 2)

    def test_concurrent_different_battle_entries_then_two_wins_only_one_first(self):
        h = self.h; bundles = {}
        for battle in ('battle.A', 'battle.B'):
            _, p = h.plan('ENTER', h.entry_payload(battle_id=battle)); bundles[battle] = h.model.prepare(p.candidate)
        gate = Barrier(2)
        def work(battle):
            gate.wait()
            try: h.model.submit(bundles[battle]); return battle, 'COMMITTED'
            except StageError as e: return battle, e.code
        with ThreadPoolExecutor(max_workers=2) as pool: results = dict(pool.map(work, bundles))
        winner = next(k for k, v in results.items() if v == 'COMMITTED')
        loser = next(k for k, v in results.items() if v != 'COMMITTED')
        self.assertEqual(results[loser], 'E_REVISION_CONFLICT')
        h.settle(winner); h.clear(NORMAL, loser)
        self.assertEqual(h.balance(), 3); self.assertEqual(len(h.model.stage.value['first_clears']), 1)
        self.assertEqual(len(h.model.stage.value['attempts']), 2)

    def test_real_p17_overflow_rejects_whole_joint_transaction(self):
        h = self.h; h.clear(); d = changed_catalog(h.catalog).value
        next(s for s in d['stages'] if s['stage_id'] == BOSS)['first']['tokens'] = MAX_INTEGER
        from stage_runtime import Catalog
        h.switch_catalog(Catalog(FrozenMessage.from_value(d))); h.enter(BOSS, 'battle.B'); r = h.result('battle.B')
        _, p = h.plan('SETTLE', {'result': r.value}); before = (h.model.stage.raw, h.model.meta.raw)
        with self.assertRaisesRegex(StageError, 'E_P17:'): h.model.prepare(p.candidate)
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw)); self.assertEqual(h.balance(), 3)

    def test_same_save_scope_not_store_instance_defines_first_clear_key(self):
        h = self.h; h.clear(); fc = h.model.stage.value['first_clears'][0]
        from stage_runtime import first_clear_key
        self.assertEqual(fc['key'], first_clear_key(h.scope, NORMAL))
        self.assertNotIn('store', str(fc))
