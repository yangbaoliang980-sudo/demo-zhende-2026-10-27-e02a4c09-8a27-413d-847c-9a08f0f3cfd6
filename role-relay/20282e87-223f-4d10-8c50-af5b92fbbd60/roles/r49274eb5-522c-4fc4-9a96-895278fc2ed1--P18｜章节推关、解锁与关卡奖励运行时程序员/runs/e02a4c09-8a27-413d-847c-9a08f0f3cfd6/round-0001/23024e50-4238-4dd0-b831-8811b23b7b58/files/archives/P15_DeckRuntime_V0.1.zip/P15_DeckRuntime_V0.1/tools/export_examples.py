from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from examples.demo import run_demo
from deck_runtime.wire import canonical

result=run_demo()
(ROOT/'examples/example_requests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(ROOT/'examples/demo_summary.json').write_text(json.dumps(result['summary'],ensure_ascii=False,indent=2)+'\n')
(ROOT/'examples/final_battle_state.json').write_bytes(canonical(result['state']))
(ROOT/'examples/p14_recorded_replay.json').write_bytes(canonical(result['replay']))
print(json.dumps(result['summary'],ensure_ascii=False,indent=2))
