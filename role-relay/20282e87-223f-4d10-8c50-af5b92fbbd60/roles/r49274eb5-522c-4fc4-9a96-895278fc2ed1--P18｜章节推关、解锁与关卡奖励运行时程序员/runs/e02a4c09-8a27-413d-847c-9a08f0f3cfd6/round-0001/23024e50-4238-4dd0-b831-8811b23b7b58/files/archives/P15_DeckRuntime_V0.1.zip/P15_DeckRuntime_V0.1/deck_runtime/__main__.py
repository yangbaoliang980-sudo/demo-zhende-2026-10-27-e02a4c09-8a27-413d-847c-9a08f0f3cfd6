"""Run the explicitly isolated author example."""
import json
from examples.demo import run_demo

print(json.dumps(run_demo()['summary'], ensure_ascii=False, indent=2))
