import json
import os
from pathlib import Path
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
rows = []
for seed in ('1', '17', '98765'):
    p = subprocess.run([sys.executable, '-B', '-m', 'stage_runtime'], cwd=ROOT,
        env={**os.environ, 'PYTHONHASHSEED': seed, 'PYTHONDONTWRITEBYTECODE': '1'}, capture_output=True)
    assert p.returncode == 0, p.stderr.decode()
    rows.append({'pythonhashseed': seed, 'result': json.loads(p.stdout)})
assert all(r['result'] == rows[0]['result'] for r in rows), 'PROCESS_DETERMINISM_MISMATCH'
print(json.dumps({'status': 'PASS_AUTHOR_CROSS_PROCESS', 'runs': rows}, ensure_ascii=False, indent=2))
