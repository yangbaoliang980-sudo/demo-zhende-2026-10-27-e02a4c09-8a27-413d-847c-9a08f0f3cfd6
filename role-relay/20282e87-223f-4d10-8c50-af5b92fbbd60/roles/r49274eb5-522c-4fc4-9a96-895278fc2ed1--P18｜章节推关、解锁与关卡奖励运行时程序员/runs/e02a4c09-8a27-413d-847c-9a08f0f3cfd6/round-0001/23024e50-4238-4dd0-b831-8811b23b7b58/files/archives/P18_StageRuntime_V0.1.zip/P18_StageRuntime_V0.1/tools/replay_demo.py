import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from examples.stage_lifecycle import run_demo

actual = run_demo(); expected = json.loads((ROOT/'examples/lifecycle_execution.json').read_text(encoding='utf-8'))
assert actual == expected, 'DEMO_REPLAY_MISMATCH'
print(json.dumps({'status': 'PASS_AUTHOR_REPLAY', 'durable': False, 'summary': actual['summary']}, ensure_ascii=False, indent=2))
