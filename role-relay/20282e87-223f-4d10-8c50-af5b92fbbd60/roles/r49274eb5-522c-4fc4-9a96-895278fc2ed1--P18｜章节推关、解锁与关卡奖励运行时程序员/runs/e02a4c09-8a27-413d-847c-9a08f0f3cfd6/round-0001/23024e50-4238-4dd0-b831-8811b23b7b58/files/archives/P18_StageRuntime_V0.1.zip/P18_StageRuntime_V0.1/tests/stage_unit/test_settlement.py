import unittest
from stage_runtime import FrozenMessage, first_clear_key, first_clear_identity, repeat_identity, progress_view
from stage_runtime.common import fingerprint
from tests.support.harness import Harness, NORMAL, BOSS, changed_catalog


class SettlementTests(unittest.TestCase):
    def setUp(self): self.h = Harness()

    def reject(self, value, reason):
        h = self.h; before = (h.model.stage.raw, h.model.meta.raw)
        _, p = h.plan('SETTLE', {'result': value})
        self.assertEqual(p.reason, reason, p.value()); self.assertIsNone(p.candidate)
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

    def test_first_clear_shared_tokens_and_three_xp(self):
        h = self.h; h.clear()
        self.assertEqual(h.balance(), 3); self.assertEqual(h.xp(), [4, 4, 4])
        self.assertEqual(len(h.model.stage.value['first_clears']), 1)
        self.assertTrue(h.stage_view(BOSS)['unlocked'])

    def test_full_two_stage_chapter(self):
        h = self.h; h.clear(); h.clear(BOSS, 'battle.B')
        self.assertEqual(h.balance(), 15); self.assertEqual(h.xp(), [22, 22, 22])
        v = progress_view(h.model.stage, h.catalog).value
        self.assertTrue(v['chapters'][0]['complete']); self.assertIsNone(v['chapters'][0]['next_chapter_id'])
        self.assertEqual(len(v['stages']), 2); self.assertEqual(len(h.model.stage.value['first_clears']), 2)

    def test_same_message_same_request_noop(self):
        h = self.h; r, (req, c, b, _) = h.clear(); before = (h.model.stage.raw, h.model.meta.raw)
        p = h.planner.plan(req, h.model.stage)
        self.assertEqual(p.status, 'DUPLICATE_NO_OP')
        self.assertEqual(before, (h.model.stage.raw, h.model.meta.raw))

    def test_same_message_new_request_reuses_terminal_receipt(self):
        h = self.h; r, _ = h.clear()
        req, p = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(p.reason, 'REUSE_COMMITTED_RECEIPT'); self.assertEqual(h.balance(), 3)

    def test_different_battle_same_stage_first_clear_only_once(self):
        h = self.h; h.clear(); r, (_, c, _, _) = h.clear(NORMAL, 'battle.B')
        self.assertEqual(c.value['decision'], 'REPEAT_DISABLED'); self.assertIsNone(c.value['grant'])
        self.assertEqual(h.balance(), 3); self.assertEqual(h.xp(), [4, 4, 4])
        self.assertEqual(len(h.model.stage.value['first_clears']), 1)

    def test_boss_replay_no_extra_chapter_reward(self):
        h = self.h; h.clear(); h.clear(BOSS, 'battle.B'); h.clear(BOSS, 'battle.C')
        self.assertEqual(h.balance(), 15); self.assertEqual(h.xp(), [22, 22, 22])

    def test_nonwinning_outcomes_no_clear(self):
        for outcome in ('LOSS', 'DRAW'):
            with self.subTest(outcome=outcome):
                h = Harness(); h.enter(); r, (_, c, _, _) = h.settle(outcome=outcome)
                self.assertEqual(c.value['decision'], 'NO_CLEAR'); self.assertEqual(h.balance(), 0)
                self.assertEqual(h.xp(), [0, 0, 0]); self.assertFalse(h.stage_view(BOSS)['unlocked'])

    def test_failure_then_retry_can_first_clear(self):
        h = self.h; h.enter(); h.settle(outcome='LOSS'); h.clear(NORMAL, 'battle.B')
        self.assertEqual(h.balance(), 3)

    def test_failure_does_not_erase_prior_clear(self):
        h = self.h; h.clear(); h.enter(NORMAL, 'battle.B'); h.settle('battle.B', outcome='LOSS')
        self.assertEqual(h.balance(), 3); self.assertTrue(h.stage_view(NORMAL)['valid_confirmed_clear'])

    def test_result_with_no_admission(self):
        other = Harness(); other.enter(); r = other.result()
        self.reject(r.value, 'E_MISSING_ADMISSION')

    def test_stage_mismatch(self):
        h = self.h; h.enter(); r = h.result().value; r['stage_id'] = BOSS
        self.reject(r, 'E_RESULT_ADMISSION_BINDING')

    def test_scope_mismatch(self):
        h = self.h; h.enter(); r = h.result().value; r['profile_scope'] = 'fixture.other'
        self.reject(r, 'E_SAVE_SCOPE_MISMATCH')

    def test_content_version_mismatch(self):
        h = self.h; h.enter(); r = h.result().value; r['content_version'] = 'fixture.other'
        self.reject(r, 'E_RESULT_ADMISSION_BINDING')

    def test_source_text_is_not_authority(self):
        h = self.h; h.enter(); r = h.result().value; h.authority.battles.clear()
        self.reject(r, 'E_RESULT_AUTHORITY_UNBOUND')
        r['source'] = 'P14'; _, p = h.plan('SETTLE', {'result': r})
        self.assertTrue(p.reason.startswith('E_CONTRACT:'))

    def test_forged_result_hash(self):
        h = self.h; h.enter(); r = h.result().value; r['result_id'] = 'fixture.forged'
        self.reject(r, 'E_UNTRUSTED_RESULT')

    def test_old_revision(self):
        h = self.h; h.enter(); old = h.result(revision=2); h.result(revision=3)
        self.reject(old.value, 'E_STALE_TERMINAL')

    def test_future_revision(self):
        h = self.h; h.enter(); r = h.result().value; r['terminal_revision'] = 3
        self.reject(r, 'E_FUTURE_TERMINAL')

    def test_identity_collision_after_commit(self):
        h = self.h; r, _ = h.clear(); v = r.value; v['result_id'] = 'fixture.conflict'
        self.reject(v, 'E_TERMINAL_IDENTITY_COLLISION')

    def test_higher_revision_after_commit_review_no_new_reward(self):
        h = self.h; h.clear(); r = h.result(revision=3)
        _, c, _, _ = h.apply('SETTLE', {'result': r.value})
        self.assertEqual(c.value['decision'], 'RECONCILE_REVISION_NO_NEW_AWARD')
        self.assertTrue(h.stage_view(NORMAL)['review_required']); self.assertEqual(h.balance(), 3)
        self.assertEqual(h.xp(), [4, 4, 4]); self.assertEqual(len(h.model.stage.value['first_clears']), 1)

    def test_final_snapshot_hash_mismatch(self):
        h = self.h; h.enter(); r = h.result(); p = h.authority.battles['battle.A'].value
        p['snapshot']['units'][0]['hp'] -= 1
        h.authority.battles['battle.A'] = FrozenMessage.from_value(p)
        self.reject(r.value, 'E_FINAL_SNAPSHOT_HASH')

    def test_seed_binding(self):
        h = self.h; h.enter(); r = h.result(seed=2)
        self.reject(r.value, 'E_BATTLE_SEED_BINDING')

    def test_party_binding(self):
        h = self.h; h.enter(); r = h.result(); p = h.authority.battles['battle.A'].value
        p['snapshot']['units'][0]['unit_id'] = 'fixture.foreign'
        h.authority.battles['battle.A'] = FrozenMessage.from_value(p)
        self.reject(r.value, 'E_BATTLE_PARTY_BINDING')

    def test_two_save_scopes_each_have_own_first_clear(self):
        a, b = self.h, Harness('fixture.save.B'); a.clear(); b.clear()
        self.assertEqual((a.balance(), b.balance()), (3, 3))
        self.assertNotEqual(a.model.stage.value['first_clears'][0]['key'], b.model.stage.value['first_clears'][0]['key'])

    def test_first_key_excludes_battle_and_version(self):
        k = first_clear_key('scope.A', NORMAL)
        self.assertEqual(k, fingerprint(['STAGE_FIRST_CLEAR', 'scope.A', NORMAL]))
        self.assertEqual(first_clear_identity('scope.A', NORMAL), ['STAGE_FIRST_CLEAR', 'scope.A', NORMAL])
        self.assertNotEqual(k, first_clear_key('scope.B', NORMAL))
        self.assertNotEqual(repeat_identity('scope.A', NORMAL, 'battle.A', 2), repeat_identity('scope.A', NORMAL, 'battle.B', 2))

    def test_version_update_does_not_reset_first_key(self):
        h = self.h; h.clear(); key = h.model.stage.value['first_clears'][0]['key']
        h.switch_catalog(changed_catalog(h.catalog, normal_tokens=99)); h.clear(NORMAL, 'battle.B')
        self.assertEqual(h.balance(), 3); self.assertEqual(key, h.model.stage.value['first_clears'][0]['key'])

    def test_inflight_uses_admitted_budget(self):
        h = self.h; h.enter(); h.switch_catalog(changed_catalog(h.catalog, normal_tokens=99, normal_xp=99))
        h.settle(); self.assertEqual(h.balance(), 3); self.assertEqual(h.xp(), [4, 4, 4])

    def test_missing_pinned_content_quarantines(self):
        h = self.h; h.enter(); r = h.result()
        h.switch_catalog(changed_catalog(h.catalog), keep_old=False)
        _, c, _, _ = h.apply('SETTLE', {'result': r.value})
        self.assertEqual(c.value['decision'], 'QUARANTINE_MISSING_PINNED_CONTENT')
        self.assertEqual(h.balance(), 0); self.assertFalse(h.stage_view(BOSS)['unlocked'])
        self.assertEqual(h.model.stage.value['active_battle_id'], 'battle.A')

    def test_repeated_quarantine_is_noop(self):
        h = self.h; h.enter(); r = h.result(); h.switch_catalog(changed_catalog(h.catalog), keep_old=False)
        h.apply('SETTLE', {'result': r.value}); _, p = h.plan('SETTLE', {'result': r.value})
        self.assertEqual(p.reason, 'REUSE_QUARANTINE_RECORD'); self.assertEqual(h.balance(), 0)

    def test_repeat_enabled_only_in_synthetic_catalog(self):
        c = changed_catalog(self.h.catalog, repeat_tokens=2); h = Harness(catalog=c)
        h.clear(); h.clear(NORMAL, 'battle.B'); h.clear(NORMAL, 'battle.C')
        self.assertEqual(h.balance(), 7); self.assertEqual(h.xp(), [4, 4, 4])
        self.assertEqual(len(h.model.stage.value['first_clears']), 1)
        self.assertFalse(self.h.catalog.stage(NORMAL)['repeat_enabled'])

    def test_party_ui_draft_cannot_change_xp_recipients(self):
        h = self.h; h.enter(); entry = next(iter(h.authority.entries.values())).value
        entry['party_snapshot']['members'][0]['character_id'] = 'fixture.ui-only'
        # Replacing the later entry registry does not rewrite a committed admission.
        h.authority.entries[entry['entry_ref']] = FrozenMessage.from_value(entry)
        h.settle(); self.assertEqual(h.xp(), [4, 4, 4])
