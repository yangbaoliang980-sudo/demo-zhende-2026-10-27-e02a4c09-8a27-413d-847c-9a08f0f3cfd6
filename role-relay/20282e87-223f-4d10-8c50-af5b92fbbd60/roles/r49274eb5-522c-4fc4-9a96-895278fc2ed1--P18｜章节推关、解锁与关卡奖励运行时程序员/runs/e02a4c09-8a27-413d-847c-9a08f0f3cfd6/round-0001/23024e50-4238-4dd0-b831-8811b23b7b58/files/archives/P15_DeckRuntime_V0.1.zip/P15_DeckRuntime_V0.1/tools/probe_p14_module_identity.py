"""Exercise the original P14 public package name instead of the vendored name."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'upstream/P14'))
import battle_core as p14_owner
from examples.support import inputs,snapshot,rules_for,command
from deck_runtime import DeckPlanner
from deck_runtime.p14_adapter import P14DeckAdapter
from deck_runtime.wire import checked,message

context,recipe=inputs();raw=snapshot(context,recipe).value;raw['energy']=0
basis=checked(raw,'BattleSnapshot')
rules=p14_owner.Rules.from_value(rules_for(context).frozen().value)
adapter=P14DeckAdapter(DeckPlanner(context),rules,rejection_type=p14_owner.CandidateRejected)
core=p14_owner.BattleCore(message('BattleState',snapshot=basis.value,accepted_commands=[]),rules,
    stage_id='fixture:stage',profile_scope='fixture:profile',deck_planner=adapter)
before=core.state().raw
reply=core.submit(command(basis)).value
ok=reply['result']=='REJECTED' and reply['code']=='ENERGY_INSUFFICIENT' and core.state().raw==before
print(json.dumps({'status':'PASS' if ok else 'FAIL','scope':'AUTHOR_ALTERNATE_P14_IMPORT_IDENTITY',
    'p14_module':p14_owner.__name__,'reply_result':reply['result'],'reply_code':reply['code'],
    'authoritative_state_unchanged':core.state().raw==before,'energy_after':core.state().value['snapshot']['energy']},indent=2))
raise SystemExit(0 if ok else 1)
