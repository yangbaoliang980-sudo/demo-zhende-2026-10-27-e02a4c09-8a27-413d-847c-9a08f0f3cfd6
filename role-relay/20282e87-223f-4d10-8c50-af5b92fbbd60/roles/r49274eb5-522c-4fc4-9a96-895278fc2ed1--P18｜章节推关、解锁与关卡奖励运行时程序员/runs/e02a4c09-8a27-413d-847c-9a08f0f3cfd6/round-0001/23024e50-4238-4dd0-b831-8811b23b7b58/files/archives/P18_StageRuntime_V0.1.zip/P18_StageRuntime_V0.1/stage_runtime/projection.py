"""Read-only P20 views. Unlocks are derived only from a committed snapshot."""
from .common import (FrozenMessage, INTERNAL_VERSION, need, get_row, validate_dto)
from .state import validate_state


def effective_clear(state, catalog, stage_id):
    row = get_row(state['stages'], 'stage_id', stage_id)
    if row is None or row['review_required'] or not row['confirmed_win_battles']:
        return False
    return all(effective_clear(state, catalog, p) for p in catalog.stage(stage_id)['prerequisites'])


def eligible(state, catalog, stage_id):
    stage = catalog.stage(stage_id)
    row = get_row(state['stages'], 'stage_id', stage_id)
    need(not row['review_required'], 'E_STAGE_UNDER_REVIEW')
    for pre in stage['prerequisites']:
        pr = get_row(state['stages'], 'stage_id', pre)
        need(not pr['review_required'], 'E_PREREQUISITE_UNDER_REVIEW')
        need(effective_clear(state, catalog, pre), 'E_LOCKED_STAGE')
    return stage


def progress_view(snapshot, catalog):
    s = validate_state(snapshot, catalog)
    active = get_row(s['attempts'], 'battle_id', s['active_battle_id'])
    rows = []
    for stage in sorted(catalog.value['stages'], key=lambda x: x['stage_id']):
        sid = stage['stage_id']; row = get_row(s['stages'], 'stage_id', sid)
        unlocked = not row['review_required'] and all(effective_clear(s, catalog, p) for p in stage['prerequisites'])
        cleared = effective_clear(s, catalog, sid)
        status = 'CLEARED' if cleared else ('AVAILABLE' if unlocked else 'LOCKED')
        if row['review_required']: status = 'REVIEW_REQUIRED'
        if active and active['admission']['stage_id'] == sid:
            status = 'PENDING_RECONCILIATION' if active['status'] == 'QUARANTINED' else 'IN_PROGRESS'
        rows.append({'stage_id': sid, 'chapter_id': stage['chapter_id'], 'status': status,
                     'unlocked': unlocked, 'valid_confirmed_clear': cleared,
                     'first_clear_consumed': any(fc['stage_id'] == sid for fc in s['first_clears']),
                     'review_required': row['review_required']})
    chapters = [{'chapter_id': c['chapter_id'],
                 'complete': all(effective_clear(s, catalog, sid) for sid in c['completion_stage_ids']),
                 'next_chapter_id': c['next_chapter_id']} for c in catalog.value['chapters']]
    return FrozenMessage.from_value({'schema_version': 'P18-PROGRESS-VIEW/0.1.0-proposal',
        'player_save_scope_id': s['player_save_scope_id'], 'revision': s['revision'],
        'content_version': catalog.value['content_version'], 'active_battle_id': s['active_battle_id'],
        'stages': rows, 'chapters': chapters, 'source_snapshot_sha256': snapshot.sha256})


def p13_view(snapshot, catalog):
    view = progress_view(snapshot, catalog).value
    need(not any(r['status'] in ('REVIEW_REQUIRED', 'PENDING_RECONCILIATION') for r in view['stages']), 'E_EXTENDED_PROGRESS_VIEW_REQUIRED')
    return validate_dto({'contract_version': INTERNAL_VERSION, 'dto_type': 'StageProgressView',
        'profile_id': view['player_save_scope_id'], 'revision': view['revision'],
        'content_version': view['content_version'],
        'unlocked_stage_ids': [r['stage_id'] for r in view['stages'] if r['unlocked']],
        'first_clear_stage_ids': [r['stage_id'] for r in view['stages'] if r['first_clear_consumed']]}, 'StageProgressView')
