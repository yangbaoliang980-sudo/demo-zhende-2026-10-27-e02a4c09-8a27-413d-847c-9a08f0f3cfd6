"""Child-process decode test. Supplied fence is a fixture, not real P21 proof."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from stage_runtime import FrozenMessage, load_catalog, restore_state, progress_view, ClosedAuthority


class SuppliedFence(ClosedAuthority):
    def __init__(self, fence): self.fence = fence
    def resolve_store(self, scope): return self.fence


if __name__ == '__main__':
    incoming = json.load(sys.stdin)
    fence = SuppliedFence(FrozenMessage.from_value(incoming['fixture_fence']))
    snapshot = restore_state(FrozenMessage.from_value(incoming['snapshot']).raw, load_catalog(), fence)
    print(json.dumps({'sha256': snapshot.sha256, 'view': progress_view(snapshot, load_catalog()).value,
                      'scope': 'CHILD_PROCESS_SUPPLIED_BYTES_NOT_DURABLE_RESTART'}, ensure_ascii=False))
