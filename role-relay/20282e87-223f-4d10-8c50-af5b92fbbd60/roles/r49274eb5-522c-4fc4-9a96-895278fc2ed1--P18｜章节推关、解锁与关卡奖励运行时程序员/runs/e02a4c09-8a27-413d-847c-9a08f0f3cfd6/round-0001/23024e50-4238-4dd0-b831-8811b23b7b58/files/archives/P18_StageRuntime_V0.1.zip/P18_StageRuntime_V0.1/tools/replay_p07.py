"""Compare selected ORIGINAL P07 expectations with actual planner execution."""
import hashlib
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT))
from tests.support.p07_replay import replay, SELECTED


def run():
    path = ROOT/'upstream/P07/content/stages/stage_retry_cases.json'
    source = json.loads(path.read_text(encoding='utf-8')); results = []
    for i, case in enumerate(source['cases'], 1):
        if i not in SELECTED:
            results.append({'case_id': case['case_id'], 'status': 'NOT_RUN',
                'reason': 'Full original historical/UI/alias scenario not adapted; see separately named author tests. No pass inferred.'})
            continue
        try: results.append(replay(case))
        except Exception as exc:
            import traceback
            results.append({'case_id': case['case_id'], 'status': 'ERROR', 'error': repr(exc), 'traceback': traceback.format_exc()})
    return {'schema_version': 'P18-P07-REPLAY/0.1.0', 'source_path': str(path.relative_to(ROOT)),
        'source_file_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'total_source_cases': len(source['cases']),
        'executed': len(SELECTED), 'pass': sum(r['status'] == 'PASS' for r in results),
        'fail': sum(r['status'] in ('FAIL', 'ERROR') for r in results),
        'not_run': sum(r['status'] == 'NOT_RUN' for r in results), 'results': results,
        'P21_durability': 'NOT_RUN', 'P32_independent': 'NOT_RUN'}


if __name__ == '__main__':
    report = run(); print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report['fail'] == 0 else 1)
