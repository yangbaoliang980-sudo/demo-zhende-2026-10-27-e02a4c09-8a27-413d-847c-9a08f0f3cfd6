"""Read-only P07/P05/P06 projection. No content table is edited here."""
from __future__ import annotations
import csv
import hashlib
import io
import json
from dataclasses import dataclass
from .common import (PACKAGE_ROOT, FrozenMessage, need, shape, ident, integer,
                     array, unique_identifiers, digest, get_row)


@dataclass(frozen=True, slots=True)
class Catalog:
    document: FrozenMessage

    def __post_init__(self):
        need(type(self.document) is FrozenMessage, 'E_CATALOG_TYPE')
        d = self.document.value
        shape(d, 'schema_version content_version production_enabled source_hashes chapters stages party_size scope')
        need(d['schema_version'] == 'P18-CATALOG/0.1.0-isolated', 'E_CONTENT_VERSION')
        need(d['production_enabled'] is False, 'E_PRODUCTION_CONTENT_BLOCKED')
        need(d['scope'] in ('P07_UNCHANGED_CANDIDATE', 'SYNTHETIC_TEST_ONLY'), 'E_CONTENT_SCOPE')
        need(d['party_size'] == 3 and type(d['party_size']) is int, 'E_PARTY_SIZE')
        ident(d['content_version']); array(d['source_hashes'])
        for row in d['source_hashes']:
            shape(row, 'source_id sha256'); ident(row['source_id']); digest(row['sha256'])
        unique_identifiers([x['source_id'] for x in d['source_hashes']])
        array(d['chapters']); array(d['stages'])
        need(bool(d['chapters']) and bool(d['stages']), 'E_EMPTY_CONTENT')
        for c in d['chapters']:
            shape(c, 'chapter_id entry_stage_ids completion_stage_ids next_chapter_id')
            ident(c['chapter_id']); unique_identifiers(c['entry_stage_ids']); unique_identifiers(c['completion_stage_ids'])
            need(c['entry_stage_ids'] and c['completion_stage_ids'], 'E_CHAPTER_BOUNDARY')
            need(c['next_chapter_id'] is None, 'E_CHAPTER_EXPANSION_UNAPPROVED')
        unique_identifiers([x['chapter_id'] for x in d['chapters']])
        for s in d['stages']:
            shape(s, 'stage_id canonical_stage_id chapter_id prerequisites enemy_refs boss_graph_id first_reward_id repeat_reward_id first repeat repeat_enabled')
            for k in ('stage_id', 'canonical_stage_id', 'chapter_id', 'first_reward_id', 'repeat_reward_id'):
                ident(s[k])
            need(s['stage_id'] == s['canonical_stage_id'], 'E_ALIAS_MIGRATION_UNBOUND')
            unique_identifiers(s['prerequisites'])
            array(s['enemy_refs']); need(bool(s['enemy_refs']), 'E_ENEMY_REFERENCE')
            for e in s['enemy_refs']:
                shape(e, 'enemy_id count'); ident(e['enemy_id']); integer(e['count'], 1, 32)
            unique_identifiers([e['enemy_id'] for e in s['enemy_refs']])
            if s['boss_graph_id'] is not None: ident(s['boss_graph_id'])
            need(type(s['repeat_enabled']) is bool, 'E_REPEAT_FLAG')
            for domain in ('first', 'repeat'):
                shape(s[domain], 'resource_id tokens xp_each')
                ident(s[domain]['resource_id']); integer(s[domain]['tokens']); integer(s[domain]['xp_each'])
            need(s['repeat_enabled'] or s['repeat']['tokens'] == s['repeat']['xp_each'] == 0, 'E_DISABLED_REPEAT_NONZERO')
        ids = [s['stage_id'] for s in d['stages']]
        unique_identifiers(ids)
        chapter_ids = [c['chapter_id'] for c in d['chapters']]
        need(all(s['chapter_id'] in chapter_ids for s in d['stages']), 'E_CHAPTER_REFERENCE')
        for s in d['stages']:
            need(set(s['prerequisites']) <= set(ids), 'E_PREREQUISITE_REFERENCE')
        # Reject cycles, including self cycles. Ordering is deterministic.
        visited, active = set(), set()
        def walk(sid):
            need(sid not in active, 'E_STAGE_GRAPH_CYCLE')
            if sid in visited: return
            active.add(sid)
            for pre in get_row(d['stages'], 'stage_id', sid)['prerequisites']: walk(pre)
            active.remove(sid); visited.add(sid)
        for sid in sorted(ids): walk(sid)
        for c in d['chapters']:
            owned = {s['stage_id'] for s in d['stages'] if s['chapter_id'] == c['chapter_id']}
            need(set(c['entry_stage_ids'] + c['completion_stage_ids']) <= owned, 'E_CHAPTER_BOUNDARY')
        roots = {s['stage_id'] for s in d['stages'] if not s['prerequisites']}
        declared = {sid for c in d['chapters'] for sid in c['entry_stage_ids']}
        need(roots <= declared, 'E_UNDECLARED_ROOT')

    @property
    def sha256(self): return self.document.sha256

    @property
    def value(self): return self.document.value

    def stage(self, stage_id):
        ident(stage_id)
        s = get_row(self.value['stages'], 'stage_id', stage_id)
        need(s is not None, 'E_UNKNOWN_STAGE')
        return s

    def source_hash(self, source_id):
        row = get_row(self.value['source_hashes'], 'source_id', source_id)
        need(row is not None, 'E_CONTENT_SOURCE_UNBOUND')
        return row['sha256']


@dataclass(frozen=True, slots=True)
class CatalogSet:
    current: Catalog
    historical: tuple[Catalog, ...] = ()

    def resolve(self, sha256):
        for c in (self.current,) + self.historical:
            if c.sha256 == sha256: return c
        return None


def load_catalog(root=PACKAGE_ROOT):
    """Only the received, disabled P07 candidate is a built-in fixture."""
    base = root / 'upstream'
    paths = {'P07_GRAPH': base/'P07/content/stages/stage_graph.json',
             'P07_REWARDS': base/'P07/content/stages/stage_rewards.tsv',
             'P07_CATALOG': base/'P07/content/stages/stage_content_catalog.json',
             'P05_BUDGET': base/'P05/content/balance/balance_parameters.tsv',
             'P06_ENEMIES': base/'P06/content/enemies/enemy_specs.json',
             'P06_BOSS': base/'P06/content/enemies/boss_phase_graph.json'}
    raw = {k: p.read_bytes() for k, p in paths.items()}
    hashes = {k: hashlib.sha256(v).hexdigest() for k, v in raw.items()}
    g = json.loads(raw['P07_GRAPH']); cat = json.loads(raw['P07_CATALOG'])
    enemies = json.loads(raw['P06_ENEMIES']); boss = json.loads(raw['P06_BOSS'])
    need(g['production_enabled'] is cat['production_enabled'] is False, 'E_PRODUCTION_CONTENT_BLOCKED')
    need(g['format_version'] == 'P07-STAGE-GRAPH/0.1.0-proposal', 'E_SOURCE_FORMAT')
    need(g['content_version'] == cat['content_version'], 'E_CONTENT_BINDING')
    need(g['source_hashes']['SRC-P05-PARAM'] == hashes['P05_BUDGET'], 'E_BUDGET_SOURCE_HASH')
    need(g['source_hashes']['SRC-P06-SPEC'] == hashes['P06_ENEMIES'], 'E_ENEMY_SOURCE_HASH')
    need(g['source_hashes']['SRC-P06-BOSS'] == hashes['P06_BOSS'], 'E_BOSS_SOURCE_HASH')
    need(g['admission']['fixture_entry_cost'] == g['retry_policy']['retry_cost_fixture'] == 0, 'E_COST_CONTRACT_UNBOUND')
    need(g['reward_policy']['first_clear_identity']['fields'] == ['player_save_scope_id', 'stage_id'], 'E_FIRST_KEY_POLICY')
    need(g['reward_policy']['repeat_identity']['enabled'] is False, 'E_REPEAT_BUDGET_UNBOUND')
    need(g['chapter']['chapter_completion_reward_id'] is None, 'E_CHAPTER_REWARD_UNBOUND')
    need(g['reward_policy']['bundles_mutually_exclusive'] is True, 'E_REWARD_SELECTION')
    need(g['reward_policy']['rng_draws'] == 0, 'E_RANDOM_DROP_POLICY_UNBOUND')
    rows = list(csv.DictReader(io.StringIO(raw['P07_REWARDS'].decode()), delimiter='\t'))
    budget = {r['parameter_id']: r for r in csv.DictReader(io.StringIO(raw['P05_BUDGET'].decode()), delimiter='\t')}
    enemy_ids = {x['enemy_id'] for x in enemies['enemies']}
    graph_ids = {boss['graph_id']}
    stages = []
    for s in g['stages']:
        need(s['candidate_enabled'] is True and s['production_enabled'] is False, 'E_SOURCE_FEATURE_FLAG')
        need(s['unlock_rule']['type'] == 'ALL_OF_CONFIRMED_CLEARS', 'E_UNLOCK_RULE_UNSUPPORTED')
        need(s['enemy_stat_overrides'] == {}, 'E_ENEMY_OVERRIDE_UNSUPPORTED')
        need(all(e['enemy_id'] in enemy_ids and e['source_sha256'] == hashes['P06_ENEMIES'] for e in s['enemy_refs']), 'E_UNRESOLVED_CONTENT_ID')
        need(s['boss_phase_graph_id'] is None or s['boss_phase_graph_id'] in graph_ids, 'E_UNRESOLVED_CONTENT_ID')
        rewards = {}
        for domain, field in [('FIRST_CLEAR', 'first'), ('REPEAT_CLEAR', 'repeat')]:
            rr = [r for r in rows if r['stage_id'] == s['stage_id'] and r['reward_domain'] == domain]
            need(len(rr) == 2 and {r['grant_kind'] for r in rr} == {'SHARED_TOKEN', 'CHARACTER_XP'}, 'E_REWARD_ROWS')
            values = {}
            for r in rr:
                need(r['reward_id'] == s['reward_ids'][domain] and r['content_version'] == g['content_version'], 'E_REWARD_BINDING')
                need(r['production_enabled'] == 'false', 'E_PRODUCTION_CONTENT_BLOCKED')
                qty = int(r['quantity']); integer(qty)
                if domain == 'FIRST_CLEAR':
                    need(r['enabled_in_candidate'] == 'true' and int(r['probability_ppm']) == 1000000, 'E_REWARD_POLICY')
                    need(r['source_sha256'] == hashes['P05_BUDGET'], 'E_BUDGET_SOURCE_HASH')
                    need(r['source_parameter_id'] in budget and qty == int(budget[r['source_parameter_id']]['value']), 'E_BUDGET_VALUE')
                else:
                    need(r['enabled_in_candidate'] == 'false' and qty == int(r['probability_ppm']) == 0, 'E_REPEAT_BUDGET_UNBOUND')
                values[r['grant_kind']] = r
            token, xp = values['SHARED_TOKEN'], values['CHARACTER_XP']
            need(token['recipient_scope'] == 'SHARED_WALLET' and xp['recipient_scope'] == 'ADMISSION_PARTY_EACH_CHARACTER', 'E_RECIPIENT_POLICY')
            rewards[field] = {'resource_id': token['resource_id'], 'tokens': int(token['quantity']), 'xp_each': int(xp['quantity'])}
        stages.append({'stage_id': s['stage_id'], 'canonical_stage_id': s['canonical_stage_id'],
            'chapter_id': s['chapter_id'], 'prerequisites': s['unlock_rule']['requires_stage_ids'],
            'enemy_refs': [{'enemy_id': e['enemy_id'], 'count': e['count']} for e in s['enemy_refs']],
            'boss_graph_id': s['boss_phase_graph_id'], 'first_reward_id': s['reward_ids']['FIRST_CLEAR'],
            'repeat_reward_id': s['reward_ids']['REPEAT_CLEAR'], **rewards, 'repeat_enabled': False})
    need(len(rows) == 4 * len(stages), 'E_EXTRA_REWARD_ROWS')
    need(set(cat['stage_ids']) == {s['stage_id'] for s in stages}, 'E_CATALOG_STAGE_SET')
    return Catalog(FrozenMessage.from_value({'schema_version': 'P18-CATALOG/0.1.0-isolated',
        'content_version': g['content_version'], 'production_enabled': False, 'scope': 'P07_UNCHANGED_CANDIDATE',
        'source_hashes': [{'source_id': k, 'sha256': v} for k, v in sorted(hashes.items())],
        'party_size': 3, 'stages': stages,
        'chapters': [{k: g['chapter'][k] for k in ('chapter_id', 'entry_stage_ids', 'completion_stage_ids', 'next_chapter_id')}]}))
