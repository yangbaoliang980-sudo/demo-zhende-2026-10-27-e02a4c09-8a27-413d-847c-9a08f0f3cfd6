"""Run an actual command, preserving bytes, exit status and source hashes."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, subprocess, time, zipfile

ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--timeout',type=int,default=90)
    p.add_argument('command',nargs=argparse.REMAINDER);args=p.parse_args()
    cmd=args.command[1:] if args.command and args.command[0]=='--' else args.command
    target=ROOT/'evidence/runs'/args.name;target.mkdir(parents=True,exist_ok=False)
    entries=[]
    paths=[]
    for d in ['ui','tests','tools','upstream']:
        paths += sorted((ROOT/d).rglob('*'))
    paths += [ROOT/'package.json',ROOT/'run_ui.py']
    for f in paths:
        if f.is_file() and f.suffix not in {'.pyc','.png','.zip'}:
            entries.append({'path':str(f.relative_to(ROOT)),'size_bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
    (target/'source_hashes.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # Preserve the small authored tree per run; upstream immutable bytes are
    # already included once in the main delivery and bound by SHA-256 above.
    with zipfile.ZipFile(target/'executed_p19_sources.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in paths:
            if f.is_file() and 'upstream' not in f.relative_to(ROOT).parts and f.suffix not in {'.pyc','.png','.zip'}:
                z.write(f,f.relative_to(ROOT))
    started=datetime.now(timezone.utc).isoformat();t=time.monotonic()
    result=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=args.timeout)
    for name,data in [('stdout.log',result.stdout),('stderr.log',result.stderr)]: (target/name).write_bytes(data)
    receipt={'argv':cmd,'cwd':'.','started_at_utc':started,'finished_at_utc':datetime.now(timezone.utc).isoformat(),
        'duration_seconds':round(time.monotonic()-t,6),'exit_code':result.returncode,
        'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest(),
        'source_binding':'source_hashes.json','executed_sources':'executed_p19_sources.zip'}
    (target/'run_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'run':args.name,'exit_code':result.returncode,'stdout_tail':result.stdout.decode(errors='replace')[-3000:],
                      'stderr_tail':result.stderr.decode(errors='replace')[-3000:]},ensure_ascii=False))
    raise SystemExit(result.returncode)
if __name__=='__main__':main()
