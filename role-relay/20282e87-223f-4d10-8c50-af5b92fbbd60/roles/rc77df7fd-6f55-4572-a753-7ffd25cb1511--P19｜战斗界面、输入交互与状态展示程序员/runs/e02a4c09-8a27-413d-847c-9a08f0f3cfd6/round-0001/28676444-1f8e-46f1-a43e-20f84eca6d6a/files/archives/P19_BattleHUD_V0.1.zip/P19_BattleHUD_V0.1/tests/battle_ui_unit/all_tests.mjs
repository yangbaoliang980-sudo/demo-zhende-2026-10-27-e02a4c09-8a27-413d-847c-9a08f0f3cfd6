// Direct entry avoids the host runtime's file-isolation reporter hiding cases.
import './wire.test.mjs';
import './commands.test.mjs';
import './binding.test.mjs';
import './presentation.test.mjs';
