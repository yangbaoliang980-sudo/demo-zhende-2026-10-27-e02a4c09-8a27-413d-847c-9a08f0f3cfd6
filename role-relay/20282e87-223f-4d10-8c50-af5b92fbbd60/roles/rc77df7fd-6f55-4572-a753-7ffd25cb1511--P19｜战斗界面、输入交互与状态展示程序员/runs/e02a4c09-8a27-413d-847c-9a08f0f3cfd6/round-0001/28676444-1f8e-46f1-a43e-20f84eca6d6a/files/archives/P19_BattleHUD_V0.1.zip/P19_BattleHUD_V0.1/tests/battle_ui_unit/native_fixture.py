"""P19 author contract fixture; unchanged P14/P15, scripted P16/P17 inputs.

This module is TEST infrastructure. It is not a game composition root, production
host, AI, or replacement for P15 affordability rules. All effects/costs/legality
are delegated to the preserved owner modules. No upstream bytes are edited.
"""
from pathlib import Path
import importlib.util
import itertools
import json
import sys
import threading

ROOT = Path(__file__).resolve().parents[2]
for entry in (ROOT, ROOT/'upstream/P15', ROOT/'upstream/P16'):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

spec = importlib.util.spec_from_file_location('p19_preserved_p15_support', ROOT/'upstream/P15/examples/support.py')
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
from deck_runtime.planner import plan
from deck_runtime.wire import checked, fingerprint, message


class NativeFixture:
    """One in-memory battle, one fixture window. No save or Anki connection."""
    def __init__(self, battle_id='fixture:P19-battle'):
        self.lock = threading.RLock()
        self.context, self.recipe = support.inputs(battle_id=battle_id)
        # Explicit fixture HP: does not change original rule/configuration files.
        initial = support.snapshot(self.context, self.recipe, ready=False, seed=2, enemy_hp=18)
        self.core, self.planner, _ = support.core_for(self.context, initial)
        self.history = []
        self.user_submissions = []
        self._system('SYSTEM_START')
        self.catalog = json.loads(support.CATALOG_PATH.read_text(encoding='utf-8'))
        self.cards = {c['card_id']: c for c in self.catalog['cards']}
        self.effects = {e['effect_id']: e for e in self.catalog['effects']}

    def _system(self, kind):
        s = self.core.snapshot(self.context.battle_id)
        c = support.command(s, request_id=f'fixture:host:{kind}:{s.value["revision"]}', kind=kind)
        r = self.core.submit_system(c)
        if r.value['result'] != 'COMMITTED':
            raise RuntimeError(r.value['code'])
        self.history.append({'channel':'TRUSTED_TEST_HOST', 'command':c.value, 'reply':r.value})

    def submit(self, raw):
        c = checked(raw, 'BattleCommand')
        if c.value['kind'] not in ('PLAY_CARD', 'END_TURN'):
            raise ValueError('TEST_HTTP_USER_COMMAND_ONLY')
        with self.lock:
            before = self.core.state().sha256
            reply = self.core.submit(c)
            self.user_submissions.append(c.value)
            self.history.append({'channel':'UI_USER_COMMAND', 'command':c.value, 'reply':reply.value,
                                 'before_sha256':before,'after_sha256':self.core.state().sha256})
            # Scripted scheduling belongs ONLY to this isolated test fixture.
            # UI cannot invoke system commands, choose AI, or drive this clock.
            if reply.value['result'] == 'COMMITTED':
                s = self.core.snapshot(self.context.battle_id).value
                if s['phase'] == 'ENEMY_READY':
                    self._system('SYSTEM_ENEMY_ACTION')
                if self.core.snapshot(self.context.battle_id).value['phase'] == 'PLAYER_TURN_PENDING':
                    self._system('SYSTEM_ENTER_PLAYER_TURN')
            return reply.value

    def read(self):
        with self.lock:
            snap = self.core.snapshot(self.context.battle_id)
            s = snap.value
            views = []
            for iid in s['zones']['hand']:
                inst = next(c for c in s['card_instances'] if c['instance_id'] == iid)
                definition = self.context.catalog.card(inst['card_id'])
                raw = self.cards[inst['card_id']]
                allowed, codes = [], []
                # Ask original P15 for each possible target set. No local rule
                # duplicates affordability, target side, status, or ownership.
                for targets in itertools.combinations([u['unit_id'] for u in s['units']], definition.target_count):
                    cmd = support.command(snap, request_id='fixture:readonly-preview', instance_id=iid, targets=list(targets))
                    decision = plan(cmd, snap, self.context)
                    if decision.code == 'OK':
                        allowed.append(list(targets))
                    else:
                        codes.append(decision.code)
                reason = 'OK' if allowed else next((c for c in codes if c not in ('TARGET_INVALID',)), 'TARGET_INVALID')
                labels = {'DAMAGE':'基础伤害','SHIELD':'护盾','HEAL':'恢复','STATUS':'状态基础量'}
                description = '；'.join(f'{labels[e["effect_code"]]} {e["amount"]}' for e in
                                        [self.effects[eid] for eid in raw['effect_ids']])
                views.append({'instance_id':iid,'actor_id':inst['owner_unit_id'],'name':raw['display_name'],
                    'category':raw['category'],'cost':definition.cost,'description':description,
                    'enabled':bool(allowed),'reason_code':reason,'allowed_target_sets':allowed})
            intents = []
            if s['outcome'] == 'ONGOING':
                intents.append({'actor_id':'enemy1','expected_revision':s['revision'],
                    'target_ids':['hero_a'],'provenance':'SCRIPTED_TEST_ONLY','label':'固定攻击',
                    'skill_id':'fixture:enemy-fixed-hit','base_amount':1,'hit_count':1,
                    'damage_label':'BASE_DAMAGE_NOT_HP_LOSS'})
            context = {'format':'P19-HUD-CONTEXT/0.1.0-proposal','source_kind':'ISOLATED_FIXTURE_ONLY',
                'battle_id':s['battle_id'],'revision':s['revision'],'snapshot_sha256':snap.sha256,
                'cards':views,'intents':intents,
                'unit_labels':[{'unit_id':u['unit_id'],'name':name} for u,name in zip(s['units'],
                    ['锋刃位 A','守护位 B','治愈位 C','演练敌方'])]}
            return {'format':'P19-HUD-FRAME/0.1.0-proposal','snapshot':s,'context':context,
                    'recent_batches':[b.value for b in self.core.committed_batches()[-8:]],
                    'scope':'ISOLATED_CONTRACT_FIXTURE_REAL_P14_P15_SCRIPTED_P16_P17'}

    def diagnostics(self):
        with self.lock:
            return {'submissions':len(self.user_submissions), 'user_commands':self.user_submissions,
                    'commits':len(self.core.committed_batches()), 'snapshot':self.core.snapshot(self.context.battle_id).value,
                    'state_sha256':self.core.state().sha256,'durable':False,'fixture_only':True}


def p16_preview_fixture():
    """Consume original P16 candidate without pretending P14 committed intent."""
    from enemy_ai import bundled_catalog, publish_intent
    from upstream.P16.examples.fixture_inputs import snapshot, context
    snap = snapshot(battle_phase='PLAYER_READY')
    decision = publish_intent(snap, context(snap), bundled_catalog())
    v = decision.view.value
    a = v['action']
    c = {'format':'P19-HUD-CONTEXT/0.1.0-proposal','source_kind':'ISOLATED_FIXTURE_ONLY',
         'battle_id':snap.value['battle_id'],'revision':snap.value['revision'],'snapshot_sha256':snap.sha256,
         'cards':[], 'intents':[{'actor_id':v['actor_id'],'expected_revision':v['expected_revision'],
             'target_ids':a['target_ids'],'provenance':'P16_PREVIEW_CANDIDATE_ONLY',
             'label':a['kind'],'skill_id':a['skill_id'],'base_amount':a['base_amount_per_hit'],
             'hit_count':a['hit_count'],'damage_label':v['damage_label']}]}
    return {'format':'P19-HUD-FRAME/0.1.0-proposal','snapshot':snap.value,'context':c,
            'p16_original_view':v,'p16_announcement':decision.announcement.value,
            'scope':'P16_CANDIDATE_CONSUMPTION_NOT_OWNER_COMMIT'}
