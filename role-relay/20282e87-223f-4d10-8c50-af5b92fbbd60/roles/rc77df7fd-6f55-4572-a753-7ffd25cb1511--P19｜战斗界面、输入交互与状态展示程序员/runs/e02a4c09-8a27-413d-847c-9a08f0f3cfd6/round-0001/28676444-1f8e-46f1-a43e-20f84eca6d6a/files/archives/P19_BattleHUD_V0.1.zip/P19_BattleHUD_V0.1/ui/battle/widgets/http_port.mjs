import {ViewError,parseWireJson} from './wire.mjs';
export class FixtureHttpPort {
  constructor(token) {this.token=token;}
  async request(path,options={}) {
    const response=await fetch(path,{cache:'no-store',...options});
    const value=parseWireJson(await response.text());
    if (!response.ok) throw new ViewError(value.code || 'TRANSPORT_REJECTED');
    return value;
  }
  read() {return this.request('/api/frame');}
  submit(command) {return this.request('/api/command',{method:'POST',headers:{'Content-Type':'application/json',
    'X-P19-Fixture-Token':this.token},body:JSON.stringify(command)});}
}
