"""Build P19 handoff metadata from real package bytes; intermediate author tool."""
from pathlib import Path
import csv
import hashlib
import json
import shutil

ROOT = Path('/workspace/scratch/1ccaa470742e/P19_BattleHUD_V0.1')
WORK = ROOT.parent / 'p19_work'
TASK = 'P19-S03-HUD-001'
VERSION = 'P19-HUD/0.1.0-isolated'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(rel):
    p=ROOT/rel
    return {'path':rel,'size_bytes':p.stat().st_size,'sha256':digest(p)}
def put(rel,obj):
    p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def base(fmt):
    return {'format':fmt+'/0.1.0','task_id':TASK,'delivery_version':VERSION,'owner':'P19'}

MAPPING='upstream/P13/architecture/actual_path_mapping.json'
SCHEMA='upstream/P13/contracts/internal/internal_dto.schema.json'
P14='upstream/P14/battle_core/core.py'
P15='upstream/P15/deck_runtime/planner.py'
P16='upstream/P16/enemy_intent_schema.json'
V6='upstream/V6/v6_roles.txt'
REQ='upstream/P01/requirements_traceability.tsv'
mapping=json.loads((ROOT/MAPPING).read_text())
source=json.loads((ROOT/'source_input_receipt.json').read_text())
source['fixed_references']=[
 {'repository':'yangbaoliang980-sudo/juesedemo-2026-10-27-01b55988-26e9-4763-a710-e5ba81986b3c','commit':'8c370d731c323f86ff19642f4cc73f818498f641','tree_evidence':'evidence/intake/github_0_tree.json','role_text':ref(V6)},
 {'repository':'yangbaoliang980-sudo/demo-zhende-2026-10-27-e02a4c09-8a27-413d-847c-9a08f0f3cfd6','commit':'671c72e6cb0599953c7052b2f090ec9aa3a388de','tree_evidence':'evidence/intake/github_1_tree.json','archive_binding':'evidence/intake/github_archive_binding.json'}]
source['input_versions']={'P01':'P01-REQ-V0.1','P13_shared_dto':'YLTT-INTERNAL/0.1.0-isolated','P13_path_mapping':mapping['schema_version'],'P14':'P14-BATTLE-CORE/0.1.0-isolated','P15':'P15-DECK-RUNTIME/0.1.0-isolated','P16':'P16-ENEMY-AI/0.1.0-isolated','P18':'P18-STAGES/0.1.0-isolated'}
source['upstream_file_count']=len(source['upstream_files'])
source['verification_scope']='All received ZIP bytes were extracted and checked; relevant P19 inputs were read. This is not a claim that every expanded source file was semantically reviewed.'
source['unreceived_critical_inputs']=['P13 production path authorization and actual game base commit','P23 approved interaction draft/anchors','P24 formal UI asset files with source/license receipts','P29 accepted driver implementation','P13/P14 committed intent view','P13/P15 official card affordance display view','P34 target engine/OS/device evidence']
put('source_input_receipt.json',source)

put('actual_path_request.json',{
 **base('P19-ACTUAL-PATH-REQUEST'),'status':'PREPARED_NOT_SUBMITTED','base_mapping':ref(MAPPING),
 'production_write_authorized':False,'actual_game_repository':None,'actual_game_commit':None,
 'observed_P19_mappings':[m for m in mapping['mappings'] if m['owner']=='P19'],
 'isolated_work_authority':'Current user task explicitly permits isolated prototype development and requires concrete P19 deliverables. This authorizes a new separate package only; it does not fill or override P13 production mapping.',
 'isolated_root':'P19_BattleHUD_V0.1','new_authored_namespaces':['ui/battle/screens/**','ui/battle/widgets/**','tests/battle_ui_unit/**','tools/**','package-local launchers and handoff metadata'],
 'readonly_namespaces':['upstream/**','evidence/**','ui/battle/widgets/fonts/LICENSE','ui/battle/widgets/fonts/package.json','ui/battle/widgets/fonts/*.woff2'],
 'request_to':'P13','requested_evidence':['actual repository and fixed base commit','actual paths for all three P19 exclusive namespaces','explicit owner/write authorization','do_not_touch and merge conflict rules','target engine and OS evidence'],
 'merge_policy':'No overwrite or cross-module merge. Future conflicting changes must retain both base SHAs and a versioned ChangeRequest; only user-appointed EXT-INTEGRATOR performs final integration.'})

bindings=[]
def binding(id,selector,field,authority,owner,rule,fallback,refs):
    bindings.append({'id':id,'view_selector':selector,'source_field':field,'authority':authority,'source_owner':owner,'render_rule':rule,'missing_or_invalid_behavior':fallback,'source_input_hashes':[ref(p) for p in refs]})
binding('HP','#party/#enemies .hp-label; [role=progressbar]; .hp-fill','BattleSnapshot.units[*].hp/max_hp','AUTHORITATIVE_SNAPSHOT','P14','Same accepted snapshot supplies text, aria-valuenow/max and scaleX(hp/max_hp). Never animate or subtract final numeric values in P19.','Invalid snapshot rejected; last confirmed state visibly stale and actions locked.',[SCHEMA,P14])
binding('SHIELD','.shield-label','BattleSnapshot.units[*].shield','AUTHORITATIVE_SNAPSHOT','P14','Render exact integer; historical SHIELD_CHANGED is text-only.','Never derive shield from event deltas.',[SCHEMA,P14])
binding('ENERGY','#energy','BattleSnapshot.energy','AUTHORITATIVE_SNAPSHOT','P14','Render exact committed remaining energy; do not subtract card cost locally.','Display — before first valid snapshot; lock new actions.',[SCHEMA,P14])
binding('HAND','#hand; #hand-count','BattleSnapshot.zones.hand; card_instances','AUTHORITATIVE_SNAPSHOT','P14/P15','Render hand order and length from snapshot; preserve owner_unit_id for command actor.','Missing display context: keep card ID and unknown cost, disable selection.',[SCHEMA,P14,P15])
binding('PILES','#pile-counts','BattleSnapshot.zones.draw/discard/exhaust','AUTHORITATIVE_SNAPSHOT','P14/P15','Render array lengths from same snapshot.','No optimistic pile movement.',[SCHEMA,P14,P15])
binding('PARTY','#party','BattleSnapshot.units[side=PLAYER].slot/unit_id/hp','AUTHORITATIVE_SNAPSHOT','P14','Sort by slot; render actual unit data; A/B/C are explicitly temporary portraits.','Do not invent absent units or claim formal art.',[SCHEMA,P14])
binding('ENEMY','#enemies','BattleSnapshot.units[side=ENEMY]; boss_states','AUTHORITATIVE_SNAPSHOT','P14','Render card containers, state pills and committed current_phase_id; enemy artwork is explicitly placeholder.','Do not infer phase by own HP threshold rules.',[SCHEMA,P14])
binding('STATUS','.status-list','BattleSnapshot.units[*].statuses[*].status_id/stacks/remaining_triggers','AUTHORITATIVE_SNAPSHOT','P14','Render ID, stack count, remaining trigger count as text.','No local ticking or status expiration.',[SCHEMA,P14])
binding('TURN','#turn-label; #phase-label; #outcome','BattleSnapshot.turn_number/phase/outcome','AUTHORITATIVE_SNAPSHOT','P14','Render committed phase/outcome. Terminal/aborted/faulted lock play and end-turn.','No UI-side victory determination.',[SCHEMA,P14])
binding('CARD_DISPLAY','.card-cost/.card-name/.card-desc; targetable units','Context.cards[*] bound to battle_id/revision/snapshot_sha256','ISOLATED_OWNER_QUERY_PROPOSAL','P13/P15','Fixture asks original P15 planner for legality/target sets; renderer only displays. Context is not added to closed P13 DTO.','Drop context atomically; disable play; display waiting text.',[SCHEMA,P15,'upstream/P15/handoff/P15_API.md'])
binding('INTENT','.enemy-intent','Context.intents[*] bound to battle_id/revision/snapshot_sha256/expected_revision','TEST_SCRIPT_OR_UNCOMMITTED_P16_CANDIDATE','P13/P14/P16','Show explicit provenance, targets, base_amount and hit_count. Label base amount as NOT actual HP loss. No production-authoritative intent claim.','Drop stale/invalid context and old intent; display 意图尚未同步. Production gate BLOCKED.',[SCHEMA,P16,'upstream/P16/P16_API.md'])
binding('ACTUAL_DAMAGE','#battle-log','BattleCommitBatch.events[event_type=DAMAGE_APPLIED].data.hp_loss/absorbed','HISTORICAL_COMMITTED_EVENT_FACT_ONLY','P14','Static text remains readable without audio/animation; it never drives current HP.','Bad history binding discarded; current snapshot remains visible.',[SCHEMA,'upstream/P14/battle_event_samples.json'])
binding('INPUT','#play; #end-turn; .hand-card; target buttons','Snapshot.phase + local connection/stale/suspended/pending + validated Context','LOCAL_VIEW_STATE_AND_AUTHORITATIVE_PHASE','P19/P14/P15','Only PLAY_CARD/END_TURN Commands with original expected_revision; 350ms same signature debounce and synchronous pending lock.','UNKNOWN preserves exact original command; lock new actions.',[SCHEMA,P14,P15])
binding('ERROR','#error-message; #connection-banner; #retry','BattleReply.code/result + local transport/view validation errors','OWNER_REPLY_OR_LOCAL_TRANSPORT_STATUS','P19/P14','Text alert and state banner, independent of audio. Reconnection clears resolved transient active error, retains history.','No unverified success; retry same ID only.',[SCHEMA,P14])
binding('PRESENTATION','#motion-mode; #skip-motion; public bridge anchors','Committed BattleCommitBatch + current numeric viewport anchors','PRESENTATION_ONLY','P19 bridge / P29 future driver','Bind snapshot first; missing/skipped/gap/throwing/hung animation cannot block input or change final fields.','Cancel epoch and retain full static terminal state.',[SCHEMA,V6])
put('battle_hud_state_binding.json',{**base('P19-HUD-BINDING'),'shared_dto_version':'YLTT-INTERNAL/0.1.0-isolated','local_context_version':'P19-HUD-CONTEXT/0.1.0-proposal','formal_acceptance':'PREPARED_NOT_ACCEPTED','snapshot_is_sole_source_for_terminal_numeric_state':True,'intent_production_status':'BLOCKED_MISSING_COMMITTED_VIEW','bindings':bindings})

rows=[
 ['CONNECTING','no valid snapshot','disabled','disabled','disabled','enabled','hidden','initial status','等待快照；numeric —','NOT applicable'],
 ['PLAYER_READY_NO_SELECTION','valid snapshot+context','enabled per owner affordance','disabled','enabled','enabled','hidden','unchanged','选择卡牌与目标','original button semantics'],
 ['CARD_SELECTED','valid owner card','enabled per owner','disabled until exact target set','enabled','enabled','hidden','selected card or stable key','描边及文字提示目标','Esc clears selection'],
 ['TARGETS_COMPLETE','allowed_target_sets match','enabled per owner','enabled','enabled','enabled','hidden','selected target','确认出牌文字','owner target order preserved'],
 ['INSUFFICIENT_ENERGY','owner enabled=false reason','disabled for affected card','disabled for it','enabled if PLAYER_READY','enabled','hidden','skip disabled buttons','费用不足+visible cost','no local cost recomputation'],
 ['SENDING','pending state SENDING','disabled','disabled','disabled','disabled','hidden','status fallback if removed','等待操作结果','synchronous lock'],
 ['UNKNOWN','pending state UNKNOWN','disabled','disabled','disabled','enabled','enabled unless suspended','query button available','结果未知+same command ID held','repeat query while SENDING ignored'],
 ['DISCONNECTED','read failed; last snapshot stale','disabled','disabled','disabled','enabled','only if pending UNKNOWN','stable/fallback status','连接中断；旧状态明确标识','no speculative rollback'],
 ['CONTEXT_MISSING_OR_STALE','valid snapshot; no valid context','disabled','disabled','enabled only if ready without other locks','enabled','as pending state','status','卡牌待同步；意图尚未同步','valid HP always refreshes'],
 ['BACKGROUND','visibility hidden','disabled','disabled','disabled','as pending state','disabled','selection cleared','后台/恢复重新同步','cancel presentation epoch'],
 ['RESUMING','visible; fresh read pending','disabled','disabled','disabled','as pending state','only after visible+UNKNOWN','status','同步中','old async read cannot unlock'],
 ['ENEMY_OR_TRANSITION','phase not PLAYER_READY','disabled','disabled','disabled','enabled if not SENDING','as pending state','status','敌方回合或等待下一回合','UI emits no SYSTEM command'],
 ['TERMINAL_ABORTED_FAULTED','snapshot closed phase/outcome','disabled','disabled','disabled','enabled if not SENDING','as pending state','status','明确胜负/中止/异常+final values','never decide outcome from HP locally'],
 ['OWNER_REJECTED','BattleReply.REJECTED then successful read','per latest state','per latest selection; usually cleared','per latest state','enabled','hidden after known reply','status if replaced','owner error code text','no damage/energy mutation'],
 ['REDUCED_NONE_FAST_SKIP','any snapshot state','unchanged','unchanged','unchanged','unchanged','unchanged','preserved','完整数值与记录始终可见','only P29 mode/cancel changes'],
 ['KEY_REPEAT','Enter/Space repeat=true','no new gesture','no second command','no second command','same native controls','same native controls','preserved','same visible status','keydown prevents repeated activation'],
]
with (ROOT/'control_state_table.tsv').open('w',encoding='utf-8',newline='') as f:
 w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['state','condition','cards_targets','play','end_turn','refresh','retry','focus','text_without_audio','notes']);w.writerows(rows)

blockers=[
 ('BLK-P19-001',['P13'],'PRODUCTION_PATH_MAPPING',['actual repository','fixed base commit','three actual P19 paths','write whitelist'],[MAPPING],'All 3 P19 actual paths null; write_allowed=false. New isolated work does not authorize production writes.'),
 ('BLK-P19-002',['P13','P34'],'TARGET_ENGINE_AND_DEVICE',['engine version/project','OS and architecture','target device and input environment','reproducible build entry'],[MAPPING,'upstream/P13/architecture/target_environment_requirements.json'],'Browser author environment is observed; no authorized target engine or Windows device evidence received.'),
 ('BLK-P19-003',['P23'],'APPROVED_INTERACTION_AND_ANCHORS',['fixed interaction draft','target resolution/scaling','anchor IDs and positions','review acceptance'],[V6],'P19 prototype layout/anchors implemented for review; upstream P23 acceptance absent.'),
 ('BLK-P19-004',['P24','P25','P37'],'FORMAL_UI_ASSETS',['portrait/card/frame/icon assets','editable sources as applicable','asset manifest/hash/license','style/compliance acceptance'],[V6],'A/B/C portraits and numbered enemy are explicit placeholders; font license preserved, independent review NOT_RUN.'),
 ('BLK-P19-005',['P29','P23'],'ANIMATION_DRIVER',['accepted presentation adapter version','driver implementation','cancel/epoch tests','anchor acceptance'],[V6,SCHEMA],'Public bridge and static fallback complete; no real hit/card-motion controller received.'),
 ('BLK-P19-006',['P13','P15'],'CARD_DISPLAY_AND_AFFORDANCE_VIEW',['versioned read-only card view','cost/legality/targets bound to snapshot','owner acceptance'],[SCHEMA,P15],'Original snapshot has no card cost or affordance fields. Isolated sidecar is not a production DTO.'),
 ('BLK-P19-007',['P13','P14','P16'],'COMMITTED_INTENT_VIEW',['authoritatively committed enemy intent','same snapshot revision/hash binding','cancel/phase/retarget semantics'],[SCHEMA,P16],'P16 preview is requires_owner_commit candidate. Formal intent/snapshot consistency cannot be signed off.'),
 ('BLK-P19-008',['P13','P14','P21'],'PERSISTENT_UNKNOWN_COMMAND_RECOVERY',['authoritative result lookup','retention and replay guarantee','restart continuity/pending command handling'],[SCHEMA,P14],'Same-page retry validated; browser reload or host process restart is not durable recovery.'),
 ('BLK-P19-009',['P01','P22','P34'],'RELEASE_INPUT_BASELINE',['approved S03/MVP scope','formal content versions and budget','actual integration activation'],['upstream/P01/requirements_baseline_v6.txt',REQ],'Upstream isolated content is test data. Initial roster/enemy/card counts are not promoted to approved scope.'),
 ('BLK-P19-010',['P32','P33','P35','USER/EXT-INTEGRATOR'],'INDEPENDENT_ACCEPTANCE_AND_INTEGRATION',['P32 independent results','P33 target manual evidence','P35 independent gate','user-appointed integrator'],[V6],'P19 author checks cannot substitute independent acceptance or authorize final integration.')]
put('blockers.json',{**base('P19-BLOCKERS'),'overall':'PRODUCTION_INTEGRATION_BLOCKED','items':[{'id':id,'status':'BLOCKED','responsible_owners':owners,'gate':gate,'missing_artifacts':missing,'observed_evidence':[ref(p) for p in refs],'reason':reason,'independent_work_completed':'P19 isolated source, state binding, defensive input handling, static fallback, reproducible author tests and receipts'} for id,owners,gate,missing,refs,reason in blockers]})

rfcs=[
 ('RFC-P19-001',['P13'],'Actual path and engine host binding',[MAPPING],['Map screens/widgets/tests to actual repo/base commit','Provide read-only snapshot+command host API and version'],'No formal source is overwritten. P19 prototype remains isolated.'),
 ('RFC-P19-002',['P13','P15'],'Read-only card display and affordance projection',[SCHEMA,P15,'upstream/P15/handoff/P15_API.md'],['Owner provides exact display cost, enabled/reason and ordered allowed_target_sets','Bind to battle/revision/snapshot hash and content version','Keep candidate fee changes exclusively in P15 and commits exclusively in P14'],'Context proposal exists only outside closed shared DTO; no live rule reimplementation.'),
 ('RFC-P19-003',['P13','P14','P16'],'Committed enemy intent projection',[SCHEMA,P16,'upstream/P16/P16_API.md'],['Expose owner-committed intent, cancellation/phase revision and target identity','Agree lifecycle when entry damage, death or Boss phase invalidates preview','Distinguish base amount from resolved actual HP loss'],'P19 currently shows labeled script/candidate intent only; authoritative intent acceptance BLOCKED.'),
 ('RFC-P19-004',['P23','P29','P13'],'Presentation bridge and anchor acceptance',[V6,SCHEMA],['Accept numeric rect anchors and frozen event envelope version','Keep P19 final numeric fields outside driver control','Provide epoch cancellation and nonblocking driver evidence'],'No received P23/P29 artifact base exists; base refs are V6/shared events, not invented owner acceptance.'),
 ('RFC-P19-005',['P13','P14','P21'],'Unknown-command query and restart recovery',[SCHEMA,P14],['Specify query/retry same-ID semantics across process restarts','Define durable result retention and monotonic state continuity','Provide recovery evidence before enabling formal persisted pending input'],'Current pending command is page memory only; unknown status blocks new input.')]
put('interface_rfcs.json',{**base('P19-INTERFACE-RFCS'),'status':'PREPARED_NOT_SUBMITTED','items':[{'rfc_id':id,'rfc_version':'0.1.0-proposal','owners':owners,'title':title,'base_sources':[ref(p) for p in refs],'requested_contract_decisions':decisions,'compatibility_and_scope':scope,'status':'PREPARED_NOT_SUBMITTED','related_interfaces':['IC-08','IC-12','IC-21','IC-23'],'owner_acceptance':None} for id,owners,title,refs,decisions,scope in rfcs]})

put('contract_acceptance.json',{**base('P19-CONTRACT-ACCEPTANCE'),'entries':[
 {'contract':'YLTT-INTERNAL/0.1.0-isolated','consumer':'P19','source':ref(SCHEMA),'consumption_status':'PASS_AUTHOR_CONTRACT_TESTS','producer_files_modified':False,'formal_production_acceptance':'NOT_RUN','evidence':'evidence/runs/author_all_final/'},
 {'contract':'P14/P15 original isolated runtime','consumer':'P19 author fixture','consumption_status':'PASS_AUTHOR_18_CASES','production_integration':'BLOCKED','evidence':'evidence/runs/author_all_final/'},
 {'contract':'P16-INTENT-VIEW/0.1.0-proposal','consumer':'P19 isolated candidate display','source':ref(P16),'consumption_status':'PASS_AUTHOR_CANDIDATE_TEST_ONLY','authoritative_intent':'BLOCKED','continuous_AI_integration':'NOT_RUN'},
 {'contract':'P19-HUD-CONTEXT/0.1.0-proposal','consumer':'P19 isolated renderer','status':'PREPARED_NOT_ACCEPTED','accepting_owners':['P13','P14','P15','P16'],'restricted_source_kind':'ISOLATED_FIXTURE_ONLY'},
 {'contract':'P19-PRESENTATION/0.1.0-proposal','consumer':'P29 future driver','status':'PREPARED_NOT_ACCEPTED','P19_bridge_and_fallback':'PASS_AUTHOR_TESTS','P29_real_driver':'NOT_RUN'},
 {'contract':'P23 UX anchors / P24 art / P13 production path','status':'BLOCKED','owner_acceptance':None}]})

actual_browser=json.loads((ROOT/'evidence/browser_final/browser_results.json').read_text())
put('verification_status.json',{**base('P19-VERIFICATION'),'overall':'ISOLATED_UI_DELIVERED_PRODUCTION_INTEGRATION_BLOCKED','counting_rule':'98 JS cases, 18 Python cases, and 23 browser scenario checks are distinct reporting layers; repeated runs are not added as new functionality coverage.','layers':[
 {'layer':'P19_AUTHOR_DESIGN_REVIEW','status':'COMPLETED_AUTHOR_REVIEW','independent':False,'evidence':['README.md','P19_API.md','presentation_adapter_spec.md','blockers.json']},
 {'layer':'P19_JAVASCRIPT_UNIT','status':'PASS','passed':98,'failed':0,'skipped':0,'independent':False,'run':'evidence/runs/author_all_final/run_receipt.json','stdout':'evidence/runs/author_all_final/stdout.log'},
 {'layer':'P19_NATIVE_P13_P14_P15_P16_CONTRACT','status':'PASS','passed':18,'failed':0,'skipped':0,'independent':False,'scope':'Unmodified producer code in isolated test composition; P16 candidate only.','run':'evidence/runs/author_all_final/run_receipt.json','stderr':'evidence/runs/author_all_final/stderr.log'},
 {'layer':'P19_LINUX_CHROMIUM_COMPONENT','status':'PASS','passed':actual_browser['passed'],'failed':actual_browser['failed'],'independent':False,'browser':actual_browser['browser_version'],'evidence':'evidence/browser_final/browser_results.json','scope':'Actual browser DOM/HTTP + original isolated core, not full-game E2E.'},
 {'layer':'FORMAL_PRODUCTION_PREFLIGHT','status':'BLOCKED','expected_exit_code':3,'evidence':'evidence/runs/preflight_final/'},
 *[{'layer':layer,'status':'NOT_RUN','independent':True,'reason':'Responsible owner has not supplied or executed this gate in this handoff.'} for layer in ['P23_UX_ACCEPTANCE','P25_STYLE_REVIEW','P32_INDEPENDENT_AUTOMATION','P33_MANUAL_TARGET_ACCEPTANCE','P35_INDEPENDENT_EVIDENCE_GATE','P37_COMPLIANCE_REVIEW']],
 *[{'layer':layer,'status':'NOT_RUN','reason':reason} for layer,reason in [('TARGET_ENGINE','No actual engine project/target mapping received.'),('TARGET_WINDOWS','Actual run environment was Linux.'),('REAL_P29_ANIMATION','No real driver implementation received.'),('CONTINUOUS_P16_AI','Only independent original candidate consumption tested.'),('TRUE_ANKI_REVIEW','Outside P19 task and no Anki desktop tested.'),('FULL_GAME_E2E','No authorized cross-module integration performed.'),('PRODUCTION_RELEASE','No release or production integration authorized/performed.')]]})

defects=[
 {'id':'DEF-P19-001','owner':'P19','kind':'FIXTURE','initial':'FAIL','evidence':'evidence/runs/fixture_seed_failure/','symptom':'StopIteration when selecting ATTACK from seed=1 initial hand.','root_cause':'Author fixture assumed a type present in a random initial hand.','fix':'Explicit seed=2 with verified attack/defense sample; upstream content and rules unchanged.','retest':'evidence/runs/fixture_generation_001/; evidence/runs/author_all_final/; evidence/browser_final/','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-002','owner':'P19','kind':'TEST_IMPORT','initial':'FAIL','evidence':'evidence/runs/author_js_001/','symptom':'Four test modules could not import the widget path.','root_cause':'One excessive parent directory in relative imports.','fix':'Correct P19 test-only paths to ../../ui/battle/.','retest':'evidence/runs/author_all_final/','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-003','owner':'P19','kind':'REPORTING','initial':'EVIDENCE_GRANULARITY_INSUFFICIENT','evidence':'evidence/runs/author_js_002/','symptom':'Node isolated reporter exposed only file-level results.','root_cause':'Observed runner/reporting mode hid individual cases.','fix':'Direct node:test import aggregator; case-level final report is retained.','retest':'evidence/runs/author_all_final/','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-004','owner':'P19','kind':'LAYOUT','initial':'FAIL','evidence':'evidence/browser_001/browser_results.json','symptom':'390px viewport document horizontally overflowed.','root_cause':'Grid children/log content retained intrinsic min widths.','fix':'min-width:0, bounded scroll and wrapping; compact primary desktop controls.','retest':'evidence/browser_final/browser_results.json','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-005','owner':'P19','kind':'TEST_ORACLE','initial':'FAIL','evidence':'evidence/browser_002/browser_results.json','symptom':'Console error oracle counted deliberately injected HTTP 503/503/400 as unexpected.','root_cause':'Negative scenarios not classified separately in test assertion.','fix':'Assert exact intentional path/status sequence and reject all other errors; retain raw console messages.','retest':'evidence/browser_final/browser_results.json','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-006','owner':'P19','kind':'STATE_PRESENTATION','initial':'AUTHOR_OBSERVED','evidence':'evidence/browser_003/P19_HUD_1280.png','symptom':'Resolved disconnect left an active red error after reconnection.','root_cause':'Successful read did not clear transient connection error field.','fix':'Clear only resolved transient active errors; retain readable historical records.','retest':'evidence/runs/author_all_final/; evidence/browser_final/browser_results.json','resolution':'AUTHOR_FIXED'},
 {'id':'DEF-P19-007','owner':'P19','kind':'FONT_DISPLAY','initial':'AUTHOR_OBSERVED','evidence':'evidence/environment/; evidence/dependencies/font_receipt.json','symptom':'Environment had no usable CJK font; early glyph display was missing.','root_cause':'Generic system font fallback was insufficient.','fix':'Bundle exact licensed Noto subset/font files; use explicit local font.','retest':'evidence/browser_final/P19_HUD_initial.png','resolution':'AUTHOR_FIXED'},
]
for d in defects:d['independent_closure']='NOT_RUN';d['source_preservation']='Historical run receipts/source snapshots are preserved where the original run was captured.'
put('defect_log.json',{**base('P19-DEFECT-LOG'),'items':defects,'escalation_policy':'If the same issue undergoes two rework rounds without new evidence, escalate to P01; this handoff retains distinct observed evidence and fixes, no independent closure asserted.'})

reqs={r['requirement_id']:r for r in csv.DictReader((ROOT/REQ).open(encoding='utf-8'),delimiter='\t')}
scope={
 'REQ-003':('P19_IMPLEMENTED_AUTHOR_TESTED','Actual source/test files and byte receipts; independent gate NOT_RUN.'),
 'REQ-005':('P19_VIEW_IMPLEMENTED','Three slots display owner data, no P17 growth/team-rule implementation.'),
 'REQ-006':('P19_COMMAND_VIEW_IMPLEMENTED','Displays owner cards and sends PLAY_CARD/END_TURN only.'),
 'REQ-007':('P19_CONTAINER_IMPLEMENTED_ART_BLOCKED','Enemy card containers and snapshot HP; no formal artwork.'),
 'REQ-008':('P19_STATIC_BINDING_IMPLEMENTED_P29_BLOCKED','Actual damage text/final HP and bridge complete; real motion/hit controller NOT_RUN.'),
 'REQ-009':('CANDIDATE_DISPLAY_ONLY_PRODUCTION_BLOCKED','P16 preview consumption tested; committed intent/continuous AI not integrated.'),
 'REQ-013':('SCOPE_RESPECTED','No 3D/PvP/skeletal/open world module authored.'),
 'REQ-016':('ISOLATION_EXPLICIT','Versioned fixture sidecar and original owner code; no production claim.'),
 'REQ-023':('P19_COMPONENT_TESTED_FULL_VERTICAL_SLICE_BLOCKED','Browser component with test host runs; official S03 multi-role integration absent.'),
 'REQ-024':('P19_IMPLEMENTED_AUTHOR_TESTED','Skipping/losing presentation never computes or changes battle results.'),
 'REQ-029':('EXT_INTEGRATION_NOT_PERFORMED','No final source merge or deployment.'),
 'REQ-030':('STATUS_DISCLOSED','PASS only actual author runs; BLOCKED/NOT_RUN retained.'),
 'REQ-032':('P19_HANDOFF_PREPARED','Source hashes/versions, files, docs and pending downstream receipts.'),
 'REQ-035':('P19_UI_SOURCE_DELIVERED','Executable UI plus state binding mapping.'),
 'REQ-036':('P19_SOURCE_AND_TESTS_DELIVERED','Actual JS/Python code and executable tests.'),
 'REQ-038':('NO_FULL_GAME_COMPLETION_CLAIM','Independent gates, Anki, real engine/full-game E2E NOT_RUN.')}
put('task_traceability.json',{**base('P19-TASK-TRACEABILITY'),'baseline':ref(REQ),'role_basis':ref(V6),'stage':'S03 minimum HUD; S08 formal UI integration BLOCKED','interfaces':['IC-08','IC-12','IC-21','IC-23'],'requirements':[{'requirement_id':id,'original_requirement':reqs[id]['normalized_requirement'],'original_owner':reqs[id]['implementation_owner'],'P19_scope_status':state,'P19_evidence_scope':desc,'evidence':['battle_hud_state_binding.json','verification_status.json','evidence/runs/author_all_final/','evidence/browser_final/']} for id,(state,desc) in scope.items()]})

# Preserve the environment failures and installation records as their original bytes.
for name in ['browser_install.log','browser_install_retry.log','browser_npm_install.log','chromium_npm_error.log','font_npm_error.log','font_npm_install.log']:
 p=WORK/name
 if p.is_file(): shutil.copyfile(p,ROOT/'evidence/environment'/name)

# Bind the final tested runtime sources without treating later documentation as executed code.
checks=[]
for run in ['author_all_final','browser_final']:
 recorded=json.loads((ROOT/f'evidence/runs/{run}/source_hashes.json').read_text())
 mismatches=[]
 for row in recorded:
  p=ROOT/row['path']
  if not p.is_file() or p.stat().st_size!=row['size_bytes'] or digest(p)!=row['sha256']:mismatches.append(row['path'])
 checks.append({'run':run,'recorded_file_count':len(recorded),'status':'PASS' if not mismatches else 'FAIL','mismatches':mismatches,'binding':ref(f'evidence/runs/{run}/source_hashes.json')})
 assert not mismatches,(run,mismatches)
put('evidence/final_source_binding.json',{'format':'P19-FINAL-SOURCE-BINDING/0.1.0','scope':'Compare all files recorded in final test runs to final package. Later handoff documents and packaging tools were not falsely counted as tested UI code.','checks':checks})

print(json.dumps({'generated':'metadata','upstream_files':len(source['upstream_files']),'bindings':len(bindings),'blockers':len(blockers),'rfcs':len(rfcs),'defects':len(defects),'runtime_source_checks':checks},ensure_ascii=False,indent=2))
