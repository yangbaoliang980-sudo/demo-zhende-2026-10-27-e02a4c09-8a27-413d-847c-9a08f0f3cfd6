"""Loopback-only P19 author test host. No installation or production mutation."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import json
import mimetypes
import secrets
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).parent))
from native_fixture import NativeFixture

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def send(self, status, data, mime='application/json; charset=utf-8'):
        raw = data if isinstance(data, bytes) else json.dumps(data,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'")
        self.end_headers()
        try: self.wfile.write(raw)
        except (BrokenPipeError,ConnectionResetError): pass

    def trusted_request(self, mutation=False):
        allowed = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
        if self.headers.get('Host') not in allowed:
            self.send(403,{'code':'HOST_REJECTED'}); return False
        origin = self.headers.get('Origin')
        if origin and origin not in {f'http://{h}' for h in allowed}:
            self.send(403,{'code':'ORIGIN_REJECTED'}); return False
        if mutation and self.headers.get('X-P19-Fixture-Token') != self.server.token:
            self.send(403,{'code':'FIXTURE_TOKEN_REQUIRED'}); return False
        return True

    def do_GET(self):
        if not self.trusted_request():return
        path = urlsplit(self.path).path
        if path == '/api/bootstrap':
            self.send(200,{'token':self.server.token,'mode':'isolated','scope':'AUTHOR_CONTRACT_FIXTURE'});return
        if path == '/api/frame': self.send(200,self.server.fixture.read());return
        if path == '/api/diagnostics': self.send(200,self.server.fixture.diagnostics());return
        if path == '/api/schema':
            self.send(200,(ROOT/'upstream/P13/contracts/internal/internal_dto.schema.json').read_bytes());return
        rel = 'ui/battle/screens/index.html' if path == '/' else path.lstrip('/')
        target = (ROOT/rel).resolve()
        allowed_root = (ROOT/'ui/battle').resolve()
        if not target.is_relative_to(allowed_root) or not target.is_file():
            self.send(404,{'code':'NOT_FOUND'});return
        mime={'.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8',
              '.html':'text/html; charset=utf-8'}.get(target.suffix,mimetypes.guess_type(str(target))[0] or 'application/octet-stream')
        self.send(200,target.read_bytes(),mime)

    def do_POST(self):
        if not self.trusted_request(mutation=True):return
        if urlsplit(self.path).path != '/api/command': self.send(404,{'code':'NOT_FOUND'});return
        if self.headers.get('Content-Type','').split(';')[0] != 'application/json':
            self.send(415,{'code':'JSON_REQUIRED'});return
        try:
            size=int(self.headers.get('Content-Length','0'))
            if not 0 < size <= 1048576: raise ValueError('FRAME_SIZE_LIMIT')
            from upstream.P13.runtime.framework.yltt_framework.codec import loads
            raw=loads(self.rfile.read(size))
            reply=self.server.fixture.submit(raw)
        except (ValueError,TypeError,KeyError) as exc:
            self.send(400,{'code':str(exc)[:160]});return
        self.send(200,reply)

def create_server(port=0):
    server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
    server.daemon_threads=True
    server.fixture=NativeFixture()
    server.token=secrets.token_urlsafe(32)
    return server

def main():
    parser=argparse.ArgumentParser(description='P19 isolated UI contract fixture, no persistent game state')
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    server=create_server(args.port)
    print(json.dumps({'status':'READY','url':f'http://127.0.0.1:{server.server_port}',
                      'scope':'P19_ISOLATED_AUTHOR_TEST_HOST','durable':False}),flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == '__main__': main()
