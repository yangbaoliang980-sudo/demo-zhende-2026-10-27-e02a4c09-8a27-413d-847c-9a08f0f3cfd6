"""Generate P19 test inputs by actually executing unchanged owner code."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
from native_fixture import NativeFixture, p16_preview_fixture, support

ROOT=Path(__file__).resolve().parents[2]

def build():
    f=NativeFixture()
    initial=f.read()
    attack=next(c for c in initial['context']['cards'] if c['category']=='ATTACK' and c['enabled'])
    command=support.command(initial['snapshot'],request_id='fixture:p19:play',instance_id=attack['instance_id'],targets=attack['allowed_target_sets'][0]).value
    before=f.core.state().sha256
    reply=f.submit(command)
    after=f.read()
    after_play_state=f.core.state().sha256
    repeated=f.submit(command)
    duplicate_after=f.core.state().sha256
    bad=support.command(after['snapshot'],request_id='fixture:p19:invalid',kind='END_TURN').value
    bad['expected_revision']=0
    rejected=f.submit(bad)
    end=support.command(after['snapshot'],request_id='fixture:p19:end',kind='END_TURN').value
    end_reply=f.submit(end)
    next_turn=f.read()
    return {'format':'P19-NATIVE-FIXTURES/0.1.0','scope':'ORIGINAL_P14_P15_WITH_SCRIPTED_P16_P17',
        'initial':initial,'play_command':command,'play_reply':reply,'after_play':after,
        'duplicate_reply':repeated,'invalid_command':bad,'rejected_reply':rejected,
        'end_command':end,'end_reply':end_reply,'next_turn':next_turn,
        'p16_preview':p16_preview_fixture(),
        'execution':{'before_sha256':before,'after_play_sha256':duplicate_after,
                     'duplicate_state_unchanged':after_play_state==duplicate_after,
                     'history':f.history}}

def fingerprint_snapshot(s):
    from upstream.P13.runtime.framework.yltt_framework.codec import fingerprint
    return fingerprint(s)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=Path(__file__).parent/'fixtures/native_frames.json')
    args=parser.parse_args()
    result=build()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'path':str(args.output),'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'play':result['play_reply']['result'],'duplicate':result['duplicate_reply']['result'],
        'invalid':result['rejected_reply']['result'],'next_turn':result['next_turn']['snapshot']['turn_number']}))

if __name__=='__main__':main()
