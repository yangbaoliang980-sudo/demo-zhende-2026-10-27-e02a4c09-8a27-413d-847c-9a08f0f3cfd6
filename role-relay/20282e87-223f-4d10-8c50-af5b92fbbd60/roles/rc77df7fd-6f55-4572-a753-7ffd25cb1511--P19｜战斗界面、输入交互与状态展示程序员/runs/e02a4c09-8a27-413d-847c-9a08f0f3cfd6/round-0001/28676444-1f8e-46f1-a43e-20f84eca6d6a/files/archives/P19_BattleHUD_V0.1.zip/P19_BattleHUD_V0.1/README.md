# P19｜战斗界面、输入交互与状态展示

任务：`P19-S03-HUD-001`  
交付：`P19-HUD/0.1.0-isolated`  
状态：**ISOLATED_UI_DELIVERED / PRODUCTION_INTEGRATION_BLOCKED**

这是可运行的 P19 界面组件、状态绑定与测试包。三人头像位、敌方卡面容器、手牌、费用、HP/护盾、状态、敌方意图占位/测试预告、错误提示、结束回合及无动效降级均有实际源码。正式美术和 P29 命中动画尚未提供，文字占位始终明确显示。

## 1. 立即运行

完整解压进入本目录，使用 Python 3.12：

```bash
python -B run_ui.py
```

看到 `READY` 后，在本机浏览器打开 `http://127.0.0.1:8765`。Windows 可双击 `start_ui.cmd`；Windows 启动脚本本轮未在 Windows 执行。端口被占用时使用 `python -B run_ui.py --port 8766`，按输出 URL 打开。

运行界面只需要 Python 标准库和支持 ES Modules/Web Crypto 的现代浏览器。中文字体随包离线提供，无 CDN、登录、音频或联网游戏依赖。Node 仅用于作者测试。不要直接双击 `index.html`：该界面需要本地验证台提供只读快照和命令端口。

操作：选择手牌 → 选择描边标记的敌方或队友 → 确认出牌。结束回合后由测试 host 调用系统调度；UI 不发送系统命令。Tab/Enter 操作原生按钮，Esc 清除选择。关闭/减少/标准/快进设置不会修改规则。当前未安装 P29 驱动，各模式均可回退到静态终态。

测试 host 只有一场内存战斗。多个标签页会读取同一场景，旧 revision 的命令由 P14 拒绝。重新演练请停止后重新启动程序；没有持久存档或 Anki 收益写入。

## 2. 验证台中哪些是真实代码

| 部分 | 本包实际使用 | 限制 |
| --- | --- | --- |
| UI 控制、绑定、渲染 | 本轮 P19 实际源码 | 是本岗隔离组件 |
| BattleSnapshot / Command / Reply | 原 P13 `YLTT-INTERNAL/0.1.0-isolated` | 未修改 DTO |
| HP、护盾、费用提交与终局 | 未修改的 P14 原代码 | 仅在作者测试 host 中装配 |
| 费用和目标合法性 | 未修改的 P15 `plan` / DeckPlanner / P14DeckAdapter | 原 P03/P15 测试配置，未批准为生产数值 |
| 三人身份、初始内容 | 上游 P15/P03 测试输入 | 不证明 P17 正式编队接入 |
| 连续敌方行动 | 原 P15 support 的固定脚本 | 不是已集成的 P16 连续 AI |
| P16 意图消费 | 独立调用原 P16 `publish_intent`，比对原 view/targets | 仍是预告候选，未由 P14 提交 |
| 动效 | P19 公共桥及空驱动降级 | 无撞击/闪白/震动控制器；P29 实现 NOT_RUN |
| 美术 | A/B/C 文字头像及编号敌方容器 | 未收到 P24 正式 UI 资源，不是角色原画交付 |

`tests/battle_ui_unit/native_fixture.py` 与 `fixture_host.py` 是**作者契约测试夹具**，不可作为正式游戏 composition root 合并。没有改动上游文件、提交 GitHub 写入、整合到引擎或执行发布。

## 3. 实际验证

```bash
python -B battle_command_tests.py
python -B tools/verify_delivery.py
python -B tools/preflight.py
```

作者测试入口分别执行 **98 项 JavaScript 单元测试**和 **18 项 Python 原代码契约测试**。当前实际运行环境是 Python 3.12.14、Node 24.22.1、Linux Chromium 153.0.8010.0。原始日志、执行源码快照和源文件哈希在 `evidence/runs/author_all_final/`。

真实浏览器执行了 **23 项检查**，记录在 `evidence/browser_final/browser_results.json`。内容包含：数值与原快照对照、双击、实际伤害文本、护盾事件、回合推进、丢响应后原 ID 重试、断线锁定与恢复、系统命令拒绝、窗口布局和终局。3 次 HTTP 错误是主动注入的负例（2 次 503、1 次 400），已逐项记录；非预期页面异常为 0。

终局场景实际达到 `WIN`、revision 13、turn 3；9 次用户端口提交含 1 次完全相同的重试，P14 共提交 13 个批次（含 host 系统命令）。我方三人 HP 均为 10，敌方 HP 为 0。结果属于测试内容的原代码契约执行，不属于整游戏 E2E。

`preflight.py` 预期返回 **exit 3 / BLOCKED**。它验证正式依赖仍未满足，这不是运行界面失败。P23 设计受理、P25 风格、P32 独测、P33 人工、P35 独审、P37 合规、目标引擎、Windows 和真实 Anki 全部按未执行状态登记。

## 4. 文件入口

| 文件/目录 | 用途 |
| --- | --- |
| `ui/battle/screens/` | 页面、布局、启动装配 |
| `ui/battle/widgets/hud_controller.mjs` | 只发用户命令、防抖、未知结果与恢复 |
| `ui/battle/widgets/hud_renderer.mjs` | 快照终态、目标选择、只读记录 |
| `ui/battle/widgets/wire.mjs` | 原 schema 消费、严格 JSON 解析、规范化哈希 |
| `ui/battle/widgets/presentation_adapter.mjs` | P29 公共表现桥，终态不依赖回调 |
| `battle_hud_state_binding.json` | 字段来源、权威级别、缺项与降级 |
| `control_state_table.tsv` | 控件启用/禁用与焦点规则 |
| `presentation_adapter_spec.md` | P19/P29 接口与边界 |
| `P19_API.md` | Frame、Context、Command 和响应流程 |
| `battle_command_tests.py` | 作者单元/契约测试入口 |
| `tests/battle_ui_unit/browser_tests.mjs` | 可复跑的真实浏览器检查 |
| `integration_handoff.md` | 下一位接收与正式接线门禁 |
| `source_input_receipt.json` | 已收到输入、版本、路径与哈希 |
| `delivery_manifest.json` | 逐文件大小、SHA-256、接收人、修改白名单 |
| `blockers.json` / `interface_rfcs.json` | 未具备的正式依赖与待受理接口变更 |
| `evidence/` | 原始成功/失败记录、截图、环境与 GitHub 绑定 |

## 5. 已确认的正式接入缺口

P13 的三条 P19 路径均为 `actual_production_path=null`、`write_allowed=false`。真实引擎工程、实际基准提交和目标机器也未冻结。P23 交互稿/锚点、P24 素材、P29 驱动未收到。

原 `BattleSnapshot` 没有卡牌费用/可操作性及已提交意图字段。P19 没有给原 DTO 增字段，而是使用单独、可丢弃、明确绑定 battle/revision/snapshot SHA 的 `P19-HUD-CONTEXT/0.1.0-proposal`。它只能用于本隔离包；生产端口受理仍由 P13/P14/P15/P16 负责。上下文无效时仍显示合法快照的完整终态，但不显示旧意图、不允许根据缺失数据出牌。

最终整合仍等待用户指定的 EXT-INTEGRATOR。本交付是其可接收的源码与证据，不是整合完成声明。
