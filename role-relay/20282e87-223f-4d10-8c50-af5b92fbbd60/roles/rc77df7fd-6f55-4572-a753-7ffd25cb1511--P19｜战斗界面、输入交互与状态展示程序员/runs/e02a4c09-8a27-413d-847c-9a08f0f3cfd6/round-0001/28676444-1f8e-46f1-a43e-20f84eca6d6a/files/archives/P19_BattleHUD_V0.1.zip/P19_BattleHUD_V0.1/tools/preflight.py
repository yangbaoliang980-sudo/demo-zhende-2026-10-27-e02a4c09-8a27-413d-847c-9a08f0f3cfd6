"""Read-only formal integration gate. A BLOCKED result exits with code 3."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    mapping_path = ROOT / 'upstream/P13/architecture/actual_path_mapping.json'
    mapping = json.loads(mapping_path.read_text(encoding='utf-8'))
    blockers = json.loads((ROOT / 'blockers.json').read_text(encoding='utf-8'))
    p19 = [m for m in mapping['mappings'] if m['owner'] == 'P19']
    expected = {'ui/battle/screens/**', 'ui/battle/widgets/**', 'tests/battle_ui_unit/**'}
    mapped = (
        {m['design_path'] for m in p19} == expected
        and all(m['actual_production_path'] and m['write_allowed'] is True for m in p19)
        and mapping['production_write_authorized'] is True
    )
    target = all(mapping.get(k) for k in (
        'actual_game_repository', 'actual_game_commit', 'actual_engine',
        'target_os', 'target_architecture'
    ))
    open_items = [b for b in blockers['items'] if b['status'] == 'BLOCKED']
    checks = [
        {'check': 'P13_ACTUAL_PATH_AUTHORIZATION', 'status': 'PASS' if mapped else 'BLOCKED',
         'observed_mappings': p19},
        {'check': 'P13_TARGET_BASELINE', 'status': 'PASS' if target else 'BLOCKED',
         'observed': {k: mapping.get(k) for k in (
             'actual_game_repository', 'actual_game_commit', 'actual_engine',
             'target_os', 'target_architecture')}},
        {'check': 'DECLARED_OWNER_ACCEPTANCE_DEPENDENCIES',
         'status': 'PASS' if not open_items else 'BLOCKED',
         'open_blockers': [{'id': b['id'], 'owners': b['responsible_owners'],
                            'missing_artifacts': b['missing_artifacts']} for b in open_items]},
    ]
    blocked = any(c['status'] == 'BLOCKED' for c in checks)
    print(json.dumps({
        'format': 'P19-PREFLIGHT/0.1.0',
        'scope': 'FORMAL_PRODUCTION_INTEGRATION_ONLY',
        'status': 'BLOCKED' if blocked else 'READY_FOR_INDEPENDENT_REVIEW',
        'mapping_sha256': hashlib.sha256(mapping_path.read_bytes()).hexdigest(),
        'checks': checks,
        'note': 'Isolated UI may run. This check cannot authorize writes, sign independent acceptance, or appoint an integrator.'
    }, ensure_ascii=False, indent=2))
    return 3 if blocked else 0


if __name__ == '__main__':
    raise SystemExit(main())
