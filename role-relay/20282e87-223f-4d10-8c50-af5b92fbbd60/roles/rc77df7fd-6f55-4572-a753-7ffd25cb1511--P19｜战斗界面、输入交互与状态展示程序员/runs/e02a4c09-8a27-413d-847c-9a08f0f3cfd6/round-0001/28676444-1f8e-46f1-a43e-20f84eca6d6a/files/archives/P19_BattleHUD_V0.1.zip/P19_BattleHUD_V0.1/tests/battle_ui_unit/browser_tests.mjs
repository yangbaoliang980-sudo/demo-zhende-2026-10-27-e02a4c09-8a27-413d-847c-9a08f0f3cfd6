/** Actual browser author tests. Uses DOM, HTTP and native unmodified owners. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url);
const root=fileURLToPath(new URL('../..',import.meta.url));
const modulePath=process.env.P19_PLAYWRIGHT_MODULE || 'playwright';
const {chromium}=require(modulePath);
const out=path.resolve(process.argv[2] || path.join(root,'evidence/browser'));
fs.mkdirSync(out,{recursive:true});
const checks=[],screenshots=[],consoleErrors=[],httpFailures=[];let server,browser,url;
function record(name,details={}){checks.push({name,status:'PASS',...details});}
async function start(){
  server=spawn(process.env.P19_PYTHON || 'python',['-B','run_ui.py','--port','0'],{cwd:root,stdio:['ignore','pipe','pipe']});
  const stderr=[];server.stderr.on('data',b=>stderr.push(b));
  url=await new Promise((resolve,reject)=>{let buffer='';const timer=setTimeout(()=>reject(Error('HOST_START_TIMEOUT')),15000);
    server.once('exit',code=>{clearTimeout(timer);reject(Error(`HOST_EXIT ${code}: ${Buffer.concat(stderr)}`));});
    server.stdout.on('data',b=>{buffer+=b;const line=buffer.split('\n')[0];try{const v=JSON.parse(line);if(v.url){clearTimeout(timer);resolve(v.url);}}catch{}});
  });
  browser=await chromium.launch({headless:true,...(process.env.P19_BROWSER_EXECUTABLE?{executablePath:process.env.P19_BROWSER_EXECUTABLE,args:['--no-sandbox','--disable-dev-shm-usage']}:{} )});
}
async function diagnostic(page){return page.evaluate(async()=>await (await fetch('/api/diagnostics')).json());}
async function waitReady(page){await page.waitForFunction(()=>document.getElementById('connection-banner').textContent.startsWith('状态已同步'));}
async function assertBound(page,name){
  const data=await diagnostic(page);const dom=await page.evaluate(()=>({energy:Number(document.getElementById('energy').textContent),
    units:[...document.querySelectorAll('[data-unit-id]')].map(e=>({id:e.dataset.unitId,hp:Number(e.dataset.hp),shield:Number(e.dataset.shield),
      hpText:e.querySelector('.hp-label').textContent,aria:e.querySelector('[role=progressbar]').getAttribute('aria-valuenow')})),
    hand:[...document.querySelectorAll('[data-card-id]')].map(e=>e.dataset.cardId)}));
  assert.equal(dom.energy,data.snapshot.energy);
  assert.deepEqual(dom.hand,data.snapshot.zones.hand);
  for(const u of data.snapshot.units){const d=dom.units.find(x=>x.id===u.unit_id);assert.ok(d);assert.equal(d.hp,u.hp);assert.equal(d.shield,u.shield);assert.equal(Number(d.aria),u.hp);assert.equal(d.hpText,`HP ${u.hp} / ${u.max_hp}`);}
  record(name,{revision:data.snapshot.revision,energy:dom.energy,unit_values:dom.units});return data;
}
async function shot(page,name){await page.evaluate(()=>document.fonts.ready);const filename=name+'.png';await page.screenshot({path:path.join(out,filename),fullPage:true});screenshots.push(filename);}
try{
  await start();
  const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
  page.on('pageerror',e=>consoleErrors.push(String(e)));page.on('console',m=>{if(m.type()==='error')consoleErrors.push(m.text());});
  page.on('response',r=>{if(r.status()>=400)httpFailures.push({path:new URL(r.url()).pathname,status:r.status()});});
  await page.goto(url);await waitReady(page);await page.evaluate(()=>document.fonts.ready);
  await assertBound(page,'initial HP shield energy and hand match native snapshot');
  assert.equal(await page.locator('#party [data-unit-id]').count(),3);assert.equal(await page.locator('.enemy-card').count(),1);
  assert.ok((await page.locator('.enemy-intent').textContent()).includes('脚本测试预告'));
  assert.equal(await page.locator('#motion-mode').inputValue(),'reduced');record('three party slots enemy intent and system reduced motion rendered');
  await shot(page,'P19_HUD_initial');
  const before=await diagnostic(page);
  await page.locator('.hand-card[data-category=ATTACK]:enabled').first().click();
  assert.equal(await page.locator('[data-unit-id=hero_a]').isDisabled(),true);
  await page.locator('[data-unit-id=enemy1]').click();
  await page.locator('#play').evaluate(e=>{e.click();e.click();});
  await waitReady(page);
  const after=await assertBound(page,'double click retains one real P14 HP and cost result');
  assert.equal(after.submissions-before.submissions,1);record('double click sends exactly one HTTP command',{delta:after.submissions-before.submissions});
  assert.ok((await page.locator('#battle-log').textContent()).includes('实际伤害'));record('actual damage remains readable with audio and animation absent');
  await shot(page,'P19_HUD_after_attack');
  const rev=after.snapshot.revision;
  for(const mode of ['normal','fast','none','reduced']){await page.selectOption('#motion-mode',mode);await page.click('#skip-motion');}
  const unchanged=await diagnostic(page);assert.equal(unchanged.snapshot.revision,rev);assert.equal(unchanged.state_sha256,after.state_sha256);record('effect modes and skip do not change native battle state');
  // Settle a defend card to exercise real SHIELD_CHANGED and exact HUD binding.
  const defense=page.locator('.hand-card[data-category=DEFENSE]:enabled').first();
  if(await defense.count()){
    await defense.click();await page.locator('[data-unit-id=hero_a]').click();await page.click('#play');await waitReady(page);
    await assertBound(page,'shield value after native defend command matches snapshot');
    assert.ok((await page.locator('#battle-log').textContent()).includes('护盾结算'));record('original SHIELD_CHANGED event visible in static history');
  }else throw Error('TEST_FIXTURE_MISSING_DEFEND');
  const beforeEnd=await diagnostic(page);await page.click('#end-turn');await waitReady(page);
  const afterEnd=await assertBound(page,'end-turn enemy action and new turn final HP match snapshot');
  assert.equal(afterEnd.snapshot.turn_number,beforeEnd.snapshot.turn_number+1);assert.equal(afterEnd.submissions-beforeEnd.submissions,1);
  assert.ok(afterEnd.user_commands.every(c=>['PLAY_CARD','END_TURN'].includes(c.kind)));record('UI never emits system commands');
  // Lost command response after server commit: the user retries the SAME id.
  const available=page.locator('.hand-card:enabled').first();await available.click();await page.locator('[data-unit-id]:enabled').first().click();
  let lost=true;
  await page.route('**/api/command',async route=>{if(lost){lost=false;await route.fetch();await route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({code:'REPLY_LOST_TEST'})});}else await route.continue();});
  await page.click('#play');await page.waitForFunction(()=>!document.getElementById('retry').hidden);
  const committedOnce=await diagnostic(page);assert.equal(await page.locator('#end-turn').isDisabled(),true);
  await page.click('#retry');await waitReady(page);const afterRetry=await assertBound(page,'lost response recovery binds full latest snapshot');
  assert.equal(afterRetry.state_sha256,committedOnce.state_sha256);assert.deepEqual(afterRetry.user_commands.at(-1),afterRetry.user_commands.at(-2));
  record('response loss retries exact command without second native commit');await page.unroute('**/api/command');
  // Disconnect frame reads; last confirmed values remain visible and locked.
  await page.route('**/api/frame',route=>route.fulfill({status:503,contentType:'application/json',body:JSON.stringify({code:'CONNECTION_LOST'})}));
  await page.click('#refresh');await page.waitForFunction(()=>document.getElementById('connection-banner').textContent.startsWith('连接中断'));
  assert.equal(await page.locator('#play').isDisabled(),true);assert.equal(await page.locator('#end-turn').isDisabled(),true);record('disconnect exposes stale state and locks new input');await shot(page,'P19_HUD_disconnected');
  await page.unroute('**/api/frame');await page.click('#refresh');await waitReady(page);await assertBound(page,'reconnect restores current state');
  assert.equal(await page.locator('#error-message').isVisible(),false);record('successful reconnection clears active error message');
  // Duplicate-id and system-command endpoint defense is evaluated against native state.
  const safety=await page.evaluate(async()=>{
    const b=await (await fetch('/api/bootstrap')).json(),before=await (await fetch('/api/diagnostics')).json();
    const c={contract_version:'YLTT-INTERNAL/0.1.0-isolated',dto_type:'BattleCommand',battle_id:before.snapshot.battle_id,command_id:'fixture:illegal-system',expected_revision:before.snapshot.revision,kind:'SYSTEM_ENEMY_ACTION',payload:{}};
    const r=await fetch('/api/command',{method:'POST',headers:{'Content-Type':'application/json','X-P19-Fixture-Token':b.token},body:JSON.stringify(c)});
    const after=await (await fetch('/api/diagnostics')).json();return {status:r.status,before:before.state_sha256,after:after.state_sha256};
  });assert.equal(safety.status,400);assert.equal(safety.before,safety.after);record('HTTP test host rejects injected system command');
  for(const [width,height] of [[1280,800],[960,720],[390,844]]){
    await page.setViewportSize({width,height});await page.evaluate(()=>document.fonts.ready);
    const bounds=await page.evaluate(()=>({scroll:document.documentElement.scrollWidth,client:document.documentElement.clientWidth,
      invalid:[...document.querySelectorAll('button')].filter(e=>!e.hidden&&getComputedStyle(e).display!=='none'&&e.getBoundingClientRect().width<24).map(e=>e.id)}));
    assert.ok(bounds.scroll<=bounds.client+1,JSON.stringify(bounds));assert.deepEqual(bounds.invalid,[]);record(`responsive layout ${width}x${height} has no document horizontal overflow`,bounds);
    if(width===1280){await page.evaluate(()=>window.scrollTo(0,0));const box=await page.locator('#end-turn').boundingBox();assert.ok(box.y+box.height<=height,'PRIMARY_COMMAND_BELOW_DESKTOP_VIEWPORT');record('primary action visible without scrolling at 1280x800',{end_button:box});}
    if(width===1280||width===390)await shot(page,`P19_HUD_${width}`);
  }
  await page.setViewportSize({width:1440,height:1000});
  // Win through legal visible UI choices, with deterministic fixture AI.
  for(let n=0;n<50;n++){
    const d=await diagnostic(page);if(d.snapshot.outcome!=='ONGOING')break;
    const a=page.locator('.hand-card[data-category=ATTACK]:enabled').first();
    if(await a.count()){await a.click();await page.locator('[data-unit-id=enemy1]').click();await page.click('#play');}
    else await page.click('#end-turn');
    await waitReady(page);
  }
  const final=await assertBound(page,'terminal state and HP derive from authoritative snapshot');
  assert.equal(final.snapshot.outcome,'WIN');assert.equal(await page.locator('#play').isDisabled(),true);assert.equal(await page.locator('#end-turn').isDisabled(),true);
  assert.equal(await page.locator('#outcome').textContent(),'战斗胜利');record('native terminal WIN visible and controls locked');await shot(page,'P19_HUD_victory');
  const expectedHttp=[{path:'/api/command',status:503},{path:'/api/frame',status:503},{path:'/api/command',status:400}];
  assert.deepEqual(httpFailures,expectedHttp);
  const intentional=consoleErrors.filter(e=>/^Failed to load resource: the server responded with a status of (503|400) /.test(e));
  assert.equal(intentional.length,3);assert.deepEqual(consoleErrors.filter(e=>!intentional.includes(e)),[]);
  record('no unexpected browser errors; three intentional HTTP rejection tests accounted for',{intentional_http_failures:httpFailures});
  fs.writeFileSync(path.join(out,'browser_results.json'),JSON.stringify({scope:'AUTHOR_LINUX_CHROMIUM_ISOLATED_UI_NOT_WINDOWS_OR_FULL_GAME_E2E',browser_version:browser.version(),
    passed:checks.length,failed:0,checks,screenshots,console_errors:consoleErrors,intentional_http_failures:httpFailures,final_diagnostics:final},null,2)+'\n');
  console.log(JSON.stringify({passed:checks.length,failed:0,browser:browser.version(),out,screenshots}));
}catch(e){
  checks.push({name:'execution_failure',status:'FAIL',error:String(e),stack:e.stack});
  fs.writeFileSync(path.join(out,'browser_results.json'),JSON.stringify({passed:checks.filter(x=>x.status==='PASS').length,failed:1,checks,screenshots,console_errors:consoleErrors},null,2)+'\n');
  console.error(e);process.exitCode=1;
}finally{if(browser)await browser.close();if(server)server.kill('SIGTERM');}
