"""Read supplied archives recursively, preserving bytes and tracing every member."""
from pathlib import Path, PurePosixPath
import hashlib, json, zipfile, stat

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'p19_work' / 'intake'
OUT.mkdir(parents=True, exist_ok=True)
archives, members, checks, errors, edges = {}, [], [], [], []
sha = lambda b: hashlib.sha256(b).hexdigest()

def visit(path, source):
    data = path.read_bytes()
    h = sha(data)
    edges.append({'source': source, 'sha256': h, 'size_bytes': len(data)})
    if h in archives:
        return
    dest = OUT / h[:16]
    dest.mkdir(exist_ok=True)
    record = {'sha256': h, 'size_bytes': len(data), 'source': source,
              'directory': str(dest.relative_to(ROOT)), 'crc': 'PASS'}
    archives[h] = record
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None:
            raise ValueError('CRC failure: ' + source)
        seen = set()
        for info in z.infolist():
            p = PurePosixPath(info.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in info.filename or stat.S_ISLNK(info.external_attr >> 16):
                raise ValueError('unsafe member: ' + info.filename)
            if info.is_dir():
                continue
            if info.filename in seen:
                raise ValueError('duplicate member: ' + info.filename)
            seen.add(info.filename)
            blob = z.read(info)
            target = dest / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(blob)
            members.append({'archive_sha256': h, 'member': info.filename,
                            'path': str(target.relative_to(ROOT)), 'size_bytes': len(blob), 'sha256': sha(blob)})
        record['file_count'] = len(seen)
        if 'manifest.json' in seen:
            m = json.loads(z.read('manifest.json'))
            if m.get('purpose', '').startswith('Original relay attachments'):
                for f in m['files']:
                    b = z.read(f['path'])
                    ok = len(b) == f['size'] and sha(b) == f['sha256']
                    checks.append({'archive_sha256': h, 'path': f['path'], 'original_name': f.get('originalName'),
                                   'size_bytes': len(b), 'sha256': sha(b), 'status': 'PASS' if ok else 'FAIL'})
                    if not ok:
                        errors.append(checks[-1])
        for name in sorted(seen):
            if name.lower().endswith('.zip'):
                visit(dest / name, h + '!/' + name)

uploads=[]
for path in sorted((ROOT/'upload').glob('*.zip')):
    uploads.append({'path': str(path.relative_to(ROOT)), 'size_bytes': path.stat().st_size,
                    'sha256': sha(path.read_bytes())})
    visit(path, str(path.relative_to(ROOT)))
result = {'uploads': uploads, 'archives': list(archives.values()), 'archive_edges': edges,
          'members': members, 'relay_manifest_checks': checks, 'errors': errors}
(ROOT/'p19_work/intake_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'uploads':len(uploads),'unique_archives':len(archives),'members':len(members),
                  'relay_checks':len(checks),'errors':len(errors)},ensure_ascii=False))
for a in archives.values():
    if any(x in a['source'].split('!/')[-1] for x in ['P13_','P14_','P15_','P16_','P18_','第六轮']):
        print(json.dumps(a,ensure_ascii=False))
