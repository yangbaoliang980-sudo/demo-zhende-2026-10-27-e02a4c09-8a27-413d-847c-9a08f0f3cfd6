"""Author tests only. These are not P32/P35 independent acceptance."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import unittest
sys.path.insert(0,str(Path(__file__).parent))
from native_fixture import NativeFixture,p16_preview_fixture,support,ROOT
from upstream.P13.runtime.framework.yltt_framework.contracts import validate
from upstream.P13.runtime.framework.yltt_framework.codec import fingerprint,ContractError

class NativeCommandContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        result=subprocess.run(['node','tools/export_ui_commands.mjs'],cwd=ROOT,capture_output=True,text=True,check=True)
        cls.export=json.loads(result.stdout)
        cls.frames=json.loads((ROOT/'tests/battle_ui_unit/fixtures/native_frames.json').read_text())

    def test_ui_emitted_commands_match_original_P13_validator(self):
        for c in self.export['commands']:validate(c,'BattleCommand')

    def test_javascript_python_command_hashes_equal(self):
        self.assertEqual([fingerprint(c) for c in self.export['commands']],self.export['sha256'])

    def test_actual_ui_play_accepted_by_unmodified_owners(self):
        f=NativeFixture();reply=f.submit(self.export['commands'][0]);self.assertEqual(reply['result'],'COMMITTED')
        self.assertEqual(f.read()['snapshot'],self.export['snapshots'][0])

    def test_ui_play_commits_exactly_one_energy_spend(self):
        f=NativeFixture();r=f.submit(self.export['commands'][0]);self.assertEqual(sum(e['event_type']=='ENERGY_SPENT' for e in r['commit']['events']),1)

    def test_duplicate_ui_request_cannot_spend_or_damage_twice(self):
        f=NativeFixture();c=self.export['commands'][0];f.submit(c);before=f.core.state().raw
        r=f.submit(c);self.assertEqual(r['result'],'DUPLICATE_NO_OP');self.assertEqual(f.core.state().raw,before)

    def test_changed_target_with_same_id_rejected_without_change(self):
        f=NativeFixture();c=json.loads(json.dumps(self.export['commands'][0]));f.submit(c);before=f.core.state().raw
        c['payload']['target_ids']=['hero_a'];r=f.submit(c);self.assertEqual(r['result'],'REJECTED');self.assertEqual(f.core.state().raw,before)

    def test_ui_end_turn_accepted_and_scheduler_only_in_test_host(self):
        f=NativeFixture();f.submit(self.export['commands'][0]);r=f.submit(self.export['commands'][1])
        self.assertEqual(r['commit']['snapshot']['phase'],'ENEMY_READY')
        self.assertEqual(f.read()['snapshot'],self.export['snapshots'][1])
        self.assertEqual({c['kind'] for c in f.user_submissions},{'PLAY_CARD','END_TURN'})

    def test_duplicate_end_turn_cannot_add_enemy_action(self):
        f=NativeFixture();f.submit(self.export['commands'][0]);f.submit(self.export['commands'][1]);before=f.core.state().raw
        r=f.submit(self.export['commands'][1]);self.assertEqual(r['result'],'DUPLICATE_NO_OP');self.assertEqual(f.core.state().raw,before)

    def test_wrong_revision_never_changes_state(self):
        f=NativeFixture();c=json.loads(json.dumps(self.export['commands'][0]));c['expected_revision']=0;before=f.core.state().raw
        self.assertEqual(f.submit(c)['code'],'REVISION_CONFLICT');self.assertEqual(f.core.state().raw,before)

    def test_injected_system_command_cannot_reach_core(self):
        f=NativeFixture();before=f.core.state().raw;c=support.command(f.read()['snapshot'],kind='SYSTEM_ENEMY_ACTION').value
        with self.assertRaises(ValueError):f.submit(c)
        self.assertEqual(f.core.state().raw,before)

    def test_injected_hp_field_fails_original_schema(self):
        f=NativeFixture();c=json.loads(json.dumps(self.export['commands'][0]));c['payload']['hp']=0
        with self.assertRaises(ContractError):f.submit(c)

    def test_readonly_affordance_queries_do_not_advance_core_or_rng(self):
        f=NativeFixture();before=f.core.state().raw
        for _ in range(10):f.read()
        self.assertEqual(f.core.state().raw,before)

    def test_p16_candidate_targets_and_amount_are_original(self):
        f=p16_preview_fixture();v=f['p16_original_view'];i=f['context']['intents'][0]
        self.assertEqual(i['target_ids'],v['action']['target_ids']);self.assertEqual(i['base_amount'],v['action']['base_amount_per_hit'])
        self.assertTrue(v['requires_owner_commit']);self.assertEqual(i['provenance'],'P16_PREVIEW_CANDIDATE_ONLY')

    def test_p13_has_no_committed_intent_or_card_cost_fields(self):
        schema=json.loads((ROOT/'upstream/P13/contracts/internal/internal_dto.schema.json').read_text())
        props=schema['$defs']['BattleSnapshot']['properties'];self.assertNotIn('intents',props);self.assertNotIn('affordances',props)
        self.assertNotIn('cost',schema['$defs']['CardInstance']['properties'])

    def test_original_P13_path_mapping_does_not_authorize_P19_production(self):
        mapping=json.loads((ROOT/'upstream/P13/architecture/actual_path_mapping.json').read_text())
        own=[r for r in mapping['mappings'] if r['owner']=='P19'];self.assertEqual(len(own),3)
        self.assertTrue(all(r['actual_production_path'] is None and r['write_allowed'] is False for r in own))

    def test_preserved_upstream_bytes_match_actual_source_receipt(self):
        receipt=json.loads((ROOT/'source_input_receipt.json').read_text())
        for entry in receipt['upstream_files']:
            b=(ROOT/entry['package_relative_path']).read_bytes()
            self.assertEqual(len(b),entry['size_bytes']);self.assertEqual(hashlib.sha256(b).hexdigest(),entry['sha256'])

    def test_generated_fixtures_are_reproducible(self):
        from generate_fixtures import build
        self.assertEqual(build(),self.frames)

    def test_fixture_terminal_win_is_authoritative_and_disables_intent(self):
        f=NativeFixture()
        for n in range(35):
            frame=f.read();s=frame['snapshot']
            if s['outcome']!='ONGOING':break
            attack=next((c for c in frame['context']['cards'] if c['enabled'] and c['category']=='ATTACK'),None)
            c=support.command(s,request_id=f'fixture:win:{n}',kind='PLAY_CARD' if attack else 'END_TURN',
                instance_id=attack['instance_id'] if attack else None,targets=attack['allowed_target_sets'][0] if attack else None)
            self.assertEqual(f.submit(c.value)['result'],'COMMITTED')
        final=f.read();self.assertEqual(final['snapshot']['outcome'],'WIN');self.assertEqual(final['context']['intents'],[])

if __name__=='__main__':unittest.main(verbosity=2)
