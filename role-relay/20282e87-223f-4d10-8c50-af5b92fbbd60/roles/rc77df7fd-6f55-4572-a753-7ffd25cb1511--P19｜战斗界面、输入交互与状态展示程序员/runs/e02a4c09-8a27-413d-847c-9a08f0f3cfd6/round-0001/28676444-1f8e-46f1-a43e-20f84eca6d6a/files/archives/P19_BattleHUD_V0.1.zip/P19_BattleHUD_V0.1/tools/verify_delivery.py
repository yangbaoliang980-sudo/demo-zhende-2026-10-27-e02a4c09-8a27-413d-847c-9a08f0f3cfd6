"""Verify package bytes and unchanged upstream inputs; never modify the package."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_file(relative: str) -> Path:
    item = PurePosixPath(relative)
    if item.is_absolute() or '..' in item.parts or '\\' in relative:
        raise ValueError('unsafe relative path: ' + relative)
    path = ROOT / relative
    if path.is_symlink() or ROOT not in path.resolve().parents:
        raise ValueError('outside package or symlink: ' + relative)
    return path


def main() -> int:
    manifest_path = ROOT / 'delivery_manifest.json'
    if not manifest_path.is_file():
        print(json.dumps({'status': 'FAIL', 'errors': ['delivery_manifest.json missing']}))
        return 1
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    errors = []
    listed = set()
    for row in manifest['files']:
        relative = row['relative_path']
        if relative in listed:
            errors.append('duplicate manifest path: ' + relative)
        listed.add(relative)
        try:
            path = safe_file(relative)
            if not path.is_file():
                errors.append('missing file: ' + relative)
            elif path.stat().st_size != row['size_bytes'] or sha256(path) != row['sha256']:
                errors.append('byte mismatch: ' + relative)
        except ValueError as exc:
            errors.append(str(exc))
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    expected = listed | {'delivery_manifest.json'}
    if actual != expected:
        errors.append({'unlisted_files': sorted(actual - expected),
                       'missing_listed_files': sorted(expected - actual)})
    sources = json.loads((ROOT / 'source_input_receipt.json').read_text(encoding='utf-8'))
    for row in sources['upstream_files']:
        path = safe_file(row['package_relative_path'])
        if not path.is_file() or path.stat().st_size != row['size_bytes'] or sha256(path) != row['sha256']:
            errors.append('upstream source modified: ' + row['package_relative_path'])
    for run in ['author_all_final', 'browser_final']:
        recorded = json.loads((ROOT / f'evidence/runs/{run}/source_hashes.json').read_text(encoding='utf-8'))
        for row in recorded:
            path = safe_file(row['path'])
            if not path.is_file() or path.stat().st_size != row['size_bytes'] or sha256(path) != row['sha256']:
                errors.append('final tested source mismatch: ' + run + ': ' + row['path'])
    print(json.dumps({
        'format': 'P19-DELIVERY-VERIFICATION/0.1.0',
        'status': 'FAIL' if errors else 'PASS',
        'listed_file_count': len(listed), 'actual_file_count': len(actual),
        'upstream_file_count': len(sources['upstream_files']),
        'manifest_sha256': sha256(manifest_path),
        'self_binding': 'Manifest excludes itself; external P19_delivery_receipt.json binds its bytes and the ZIP.',
        'errors': errors
    }, ensure_ascii=False, indent=2))
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
