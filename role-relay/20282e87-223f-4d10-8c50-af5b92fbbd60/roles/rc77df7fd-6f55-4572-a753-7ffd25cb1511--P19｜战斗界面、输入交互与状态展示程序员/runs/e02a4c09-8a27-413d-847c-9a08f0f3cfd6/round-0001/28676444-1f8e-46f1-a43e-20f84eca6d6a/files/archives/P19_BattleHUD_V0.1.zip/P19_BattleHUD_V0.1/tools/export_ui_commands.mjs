/** Execute the actual UI command controller and print commands for Python owner tests. */
import {ready,selectAttack,fixture,copy} from '../tests/battle_ui_unit/helpers.mjs';
import {fingerprint} from '../ui/battle/widgets/wire.mjs';
const a=await ready();selectAttack(a.hud);await a.hud.play();
const b=await ready({frame:fixture.after_play,options:{idFactory:()=>fixture.end_command.command_id},
  submit:async(c,s)=>{s.frame=copy(fixture.next_turn);return copy(fixture.end_reply);}});
await b.hud.endTurn();
const commands=[...a.state.calls,...b.state.calls];
console.log(JSON.stringify({format:'P19-ACTUAL-UI-COMMANDS/0.1.0',source:'HudController.play/endTurn',
  commands,sha256:await Promise.all(commands.map(fingerprint)),snapshots:[a.hud.snapshot,b.hud.snapshot]}));
