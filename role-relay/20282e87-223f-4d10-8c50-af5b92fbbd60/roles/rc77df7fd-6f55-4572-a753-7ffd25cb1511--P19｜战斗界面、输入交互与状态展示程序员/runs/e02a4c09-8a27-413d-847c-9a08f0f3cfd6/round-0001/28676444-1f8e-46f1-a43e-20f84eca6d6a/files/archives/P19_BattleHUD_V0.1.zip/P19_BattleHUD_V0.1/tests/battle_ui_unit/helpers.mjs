import {readFileSync} from 'node:fs';
import {createWireGuard,clone,freeze} from '../../ui/battle/widgets/wire.mjs';
import {HudController} from '../../ui/battle/widgets/hud_controller.mjs';
export const fixture=JSON.parse(readFileSync(new URL('./fixtures/native_frames.json',import.meta.url)));
export const schema=JSON.parse(readFileSync(new URL('../../upstream/P13/contracts/internal/internal_dto.schema.json',import.meta.url)));
export const guard=createWireGuard(schema);
export const copy=clone;
export const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
export function replyFor(command, original=fixture.play_reply){
  const r=copy(original);r.command_id=command.command_id;
  if(r.commit){r.commit.command_id=command.command_id;r.commit.events.forEach(e=>e.command_id=command.command_id);}
  return r;
}
export async function ready({frame=fixture.initial,submit,read,options={}}={}){
  const state={frame:copy(frame),calls:[],reads:0};
  const port={read:async()=>{state.reads++;return read?read(state):copy(state.frame);},
    submit:async c=>{state.calls.push(copy(c));if(submit)return submit(c,state);state.frame=copy(fixture.after_play);return replyFor(c);}};
  const hud=new HudController({port,guard,idFactory:()=>fixture.play_command.command_id,...options});
  await hud.refresh();
  return {hud,state,port};
}
export function selectAttack(hud){const c=fixture.play_command;hud.selectCard(c.payload.card_instance_id);hud.selectTarget(c.payload.target_ids[0]);}
export async function settled(){await new Promise(r=>setTimeout(r,0));}
