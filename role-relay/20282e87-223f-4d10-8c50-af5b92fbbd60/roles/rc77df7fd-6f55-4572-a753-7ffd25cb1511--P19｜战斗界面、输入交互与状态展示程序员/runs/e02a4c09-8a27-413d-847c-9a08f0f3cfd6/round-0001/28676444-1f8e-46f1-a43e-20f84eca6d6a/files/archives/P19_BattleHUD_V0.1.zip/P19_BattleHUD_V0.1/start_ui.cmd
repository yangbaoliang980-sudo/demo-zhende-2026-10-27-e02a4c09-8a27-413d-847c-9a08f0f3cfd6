@echo off
cd /d "%~dp0"
echo P19 isolated HUD. Open http://127.0.0.1:8765 after READY.
where py >nul 2>nul
if errorlevel 1 (python -B run_ui.py) else (py -3 -B run_ui.py)
pause
