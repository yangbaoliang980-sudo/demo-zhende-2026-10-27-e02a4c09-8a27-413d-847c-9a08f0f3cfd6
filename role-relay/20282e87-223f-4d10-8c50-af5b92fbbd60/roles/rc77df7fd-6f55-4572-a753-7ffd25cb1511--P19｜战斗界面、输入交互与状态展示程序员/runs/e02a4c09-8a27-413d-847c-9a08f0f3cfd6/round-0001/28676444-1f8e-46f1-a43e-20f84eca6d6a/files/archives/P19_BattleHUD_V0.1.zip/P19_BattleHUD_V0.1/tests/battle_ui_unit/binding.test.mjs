import test from 'node:test';
import assert from 'node:assert/strict';
import {ready,fixture,copy,deferred,settled} from './helpers.mjs';
import {canonical,fingerprint} from '../../ui/battle/widgets/wire.mjs';

test('stale snapshot is ignored with no HP regression',async()=>{const {hud}=await ready({frame:fixture.after_play});const old=canonical(hud.snapshot);assert.equal(await hud.acceptSnapshot(fixture.initial.snapshot),'STALE_IGNORED');assert.equal(canonical(hud.snapshot),old);});
test('same-revision same bytes accepted idempotently',async()=>{const {hud}=await ready();assert.equal(await hud.acceptSnapshot(copy(fixture.initial.snapshot),{context:fixture.initial.context}),'IDENTICAL');});
test('same revision conflicting payload is rejected',async()=>{const {hud}=await ready();const s=copy(fixture.initial.snapshot);s.energy++;await assert.rejects(hud.acceptSnapshot(s),{code:'REVISION_COLLISION'});assert.equal(hud.snapshot.energy,fixture.initial.snapshot.energy);});
test('different battle never silently replaces live session',async()=>{const {hud}=await ready();const s=copy(fixture.initial.snapshot);s.battle_id='foreign';await assert.rejects(hud.acceptSnapshot(s),{code:'BATTLE_ID_MISMATCH'});});
test('higher revision cannot regress event high watermark',async()=>{const {hud}=await ready();const s=copy(fixture.after_play.snapshot);s.last_event_seq=0;await assert.rejects(hud.acceptSnapshot(s),{code:'EVENT_HIGH_WATERMARK_REGRESSION'});});
test('snapshot copies cannot be mutated by caller or view',async()=>{const f=copy(fixture.initial);const {hud}=await ready({frame:f});f.snapshot.units[0].hp=0;assert.notEqual(hud.snapshot.units[0].hp,0);assert.throws(()=>hud.view().snapshot.units[0].hp=0);});
test('missing sidecar keeps authoritative HP and disables only card selection',async()=>{const f=copy(fixture.initial);f.context=null;const {hud}=await ready({frame:f});assert.equal(hud.snapshot.energy,3);assert.equal(hud.view().canSelect,false);assert.equal(hud.view().canEndTurn,true);});
for(const [name,change] of [
  ['old revision',c=>c.revision--],['foreign battle',c=>c.battle_id='foreign'],['wrong hash',c=>c.snapshot_sha256='0'.repeat(64)],
  ['unapproved owner status',c=>c.source_kind='OWNER_APPROVED'],['unknown version',c=>c.format='v2'],
  ['different actor',c=>c.cards[0].actor_id='enemy1'],['duplicate card',c=>c.cards.push(copy(c.cards[0]))],
  ['invented instance',c=>c.cards[0].instance_id='unknown'],['unknown target',c=>c.cards[0].allowed_target_sets=[['bad']]],
  ['enabled without targets',c=>{c.cards[0].enabled=true;c.cards[0].allowed_target_sets=[];}],
  ['intent at old revision',c=>c.intents[0].expected_revision--],['intent foreign target',c=>c.intents[0].target_ids=['bad']],
  ['intent pretends committed',c=>c.intents[0].provenance='AUTHORITATIVE'],['damage labels mistaken for HP',c=>c.intents[0].damage_label='HP_LOSS'],
])test(`invalid display context ${name} cannot replace valid numbers or enable cards`,async()=>{const f=copy(fixture.initial);change(f.context);const {hud}=await ready({frame:f});assert.equal(hud.context,null);assert.deepEqual(hud.snapshot,f.snapshot);assert.equal(hud.view().canSelect,false);assert.ok(hud.error);});
test('P16 original preview can only be labeled candidate in the sidecar',async()=>{const {hud}=await ready({frame:fixture.p16_preview});assert.equal(hud.context.intents[0].provenance,'P16_PREVIEW_CANDIDATE_ONLY');assert.deepEqual(hud.context.intents[0].target_ids,fixture.p16_preview.p16_original_view.action.target_ids);});
test('new snapshot clears old card selection and old intent',async()=>{const {hud}=await ready();hud.selectCard(fixture.initial.context.cards[0].instance_id);await hud.acceptSnapshot(fixture.after_play.snapshot);assert.equal(hud.selection,null);assert.equal(hud.context,null);});
test('terminal, aborted and faulted snapshots always disable input',async()=>{
  for(const [phase,outcome] of [['TERMINAL','WIN'],['ABORTED','ABORTED'],['FAULTED','FAULTED']]){const f=copy(fixture.initial);f.snapshot.phase=phase;f.snapshot.outcome=outcome;f.context=null;const {hud}=await ready({frame:f});assert.equal(hud.view().canEndTurn,false);assert.equal(hud.view().canPlay,false);}
});
test('older asynchronous refresh cannot replace newer refresh',async()=>{
  const {hud}=await ready();const a=deferred(),b=deferred();let i=0;hud.port.read=()=>++i===1?a.promise:b.promise;
  const p=hud.refresh(),q=hud.refresh();b.resolve(copy(fixture.after_play));await q;a.resolve(copy(fixture.initial));await p;assert.equal(hud.snapshot.revision,2);assert.equal(hud.stale,false);
});
test('repeated history ingestion never repeats actual damage log',async()=>{const {hud}=await ready({frame:fixture.after_play});const count=hud.logs.filter(l=>l.code==='DAMAGE_APPLIED').length;await hud.refresh();await hud.refresh();assert.equal(hud.logs.filter(l=>l.code==='DAMAGE_APPLIED').length,count);assert.equal(count,1);});
test('foreign event cannot be shown as historical damage',async()=>{const {hud}=await ready();const b=copy(fixture.play_reply.commit);b.events.forEach(e=>e.battle_id='foreign');const before=hud.logs.length;hud.ingestLog([b]);assert.equal(hud.logs.filter(l=>l.code==='DAMAGE_APPLIED').length,0);assert.equal(hud.logs.at(-1).code,'HISTORY_UNAVAILABLE');});
test('frame schema version mismatch stays read only',async()=>{const f=copy(fixture.initial);f.format='old';const {hud}=await ready({frame:f});assert.equal(hud.snapshot,null);assert.equal(hud.error,'FRAME_VERSION');});
