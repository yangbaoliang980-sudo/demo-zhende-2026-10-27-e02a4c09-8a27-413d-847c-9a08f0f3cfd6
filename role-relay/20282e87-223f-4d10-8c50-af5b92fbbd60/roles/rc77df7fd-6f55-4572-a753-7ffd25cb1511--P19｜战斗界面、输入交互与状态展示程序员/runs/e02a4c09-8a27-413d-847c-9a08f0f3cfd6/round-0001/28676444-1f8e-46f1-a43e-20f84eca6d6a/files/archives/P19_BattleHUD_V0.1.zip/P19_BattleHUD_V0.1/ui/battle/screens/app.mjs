import {createWireGuard,parseWireJson} from '../widgets/wire.mjs';
import {HudController} from '../widgets/hud_controller.mjs';
import {FixtureHttpPort} from '../widgets/http_port.mjs';
import {mountHud} from '../widgets/hud_renderer.mjs';
import {PresentationBridge} from '../widgets/presentation_adapter.mjs';

async function start(){
  const [schema,bootstrap]=await Promise.all(['/api/schema','/api/bootstrap'].map(async u=>{
    const r=await fetch(u,{cache:'no-store'});if(!r.ok)throw Error('BOOTSTRAP_UNAVAILABLE');
    // JSON Schema itself contains $defs/$ref keys, not P13 data-profile keys.
    return u==='/api/schema'?r.json():parseWireJson(await r.text());
  }));
  const port=new FixtureHttpPort(bootstrap.token);
  let renderer;
  const presentation=new PresentationBridge({anchors:()=>renderer?.anchors()||{}});
  const controller=new HudController({port,guard:createWireGuard(schema),presentation});
  renderer=mountHud(controller);
  const visibility=()=>controller.setVisibility(document.hidden);
  document.addEventListener('visibilitychange',visibility);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const motionPreference=()=>{if(reduced.matches){document.getElementById('motion-mode').value='reduced';controller.setPresentationMode('reduced');}};
  reduced.addEventListener('change',motionPreference);motionPreference();
  window.addEventListener('pagehide',()=>{controller.dispose();renderer.unmount();document.removeEventListener('visibilitychange',visibility);reduced.removeEventListener('change',motionPreference);},{once:true});
  await controller.refresh();
  // No global command/state handle is exposed. Browser tests use visible DOM
  // and the fixture host's read-only diagnostics endpoint.
}
start().catch(e=>{const banner=document.getElementById('connection-banner');banner.classList.add('warning');banner.textContent=`界面启动未完成：${e.message}。请通过 run_ui.py 启动本地验证台。`;});
