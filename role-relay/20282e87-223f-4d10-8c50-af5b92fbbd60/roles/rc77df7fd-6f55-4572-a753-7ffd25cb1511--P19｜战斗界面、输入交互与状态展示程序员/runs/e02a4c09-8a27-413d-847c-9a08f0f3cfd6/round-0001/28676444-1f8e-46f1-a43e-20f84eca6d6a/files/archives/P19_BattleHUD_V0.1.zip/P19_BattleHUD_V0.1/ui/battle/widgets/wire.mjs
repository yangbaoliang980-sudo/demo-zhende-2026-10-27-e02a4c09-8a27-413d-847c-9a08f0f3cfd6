/** Read-only P13 wire boundary. No battle rules or state mutation. */
export const CONTRACT = 'YLTT-INTERNAL/0.1.0-isolated';
export class ViewError extends Error {
  constructor(code) { super(code); this.name = 'ViewError'; this.code = code; }
}
export function requireView(ok, code) { if (!ok) throw new ViewError(code); }
const own = (o,k) => Object.prototype.hasOwnProperty.call(o,k);
const object = x => x !== null && typeof x === 'object' && !Array.isArray(x);
export const clone = x => JSON.parse(JSON.stringify(x));
export function freeze(x) {
  if (x && typeof x === 'object' && !Object.isFrozen(x)) {
    Object.values(x).forEach(freeze); Object.freeze(x);
  }
  return x;
}
export function canonical(value) {
  let count = 0;
  const walk = (x, depth = 0) => {
    requireView(++count <= 100000 && depth <= 32, 'JSON_COMPLEXITY_LIMIT');
    if (x === null || typeof x === 'boolean') return JSON.stringify(x);
    if (typeof x === 'number') {
      requireView(Number.isSafeInteger(x), 'UNSAFE_NUMBER'); return JSON.stringify(x);
    }
    if (typeof x === 'string') {
      // P13 forbids controls and lone surrogates; valid UTF-8 values are kept.
      requireView(!/[\x00-\x1f\x7f\ud800-\udfff]/u.test(x), 'UNSAFE_STRING');
      return JSON.stringify(x);
    }
    if (Array.isArray(x)) return '[' + x.map(v => walk(v, depth + 1)).join(',') + ']';
    requireView(object(x), 'UNSUPPORTED_JSON_VALUE');
    return '{' + Object.keys(x).sort().map(k => {
      requireView(/^[A-Za-z_][A-Za-z0-9_]*$/.test(k), 'NON_ASCII_SCHEMA_KEY');
      return JSON.stringify(k) + ':' + walk(x[k], depth + 1);
    }).join(',') + '}';
  };
  const text = walk(value);
  requireView(new TextEncoder().encode(text).length <= 1048576, 'FRAME_SIZE_LIMIT');
  return text;
}
export async function fingerprint(value) {
  const bytes = new TextEncoder().encode(canonical(value));
  const hash = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(hash)].map(x => x.toString(16).padStart(2,'0')).join('');
}
export function parseWireJson(text) {
  requireView(typeof text === 'string' && new TextEncoder().encode(text).length <= 1048576, 'FRAME_SIZE_LIMIT');
  let offset=0,nodes=0;
  const ws=()=>{while(/[\x20\x09\x0a\x0d]/.test(text[offset]||'!'))offset++;};
  const string=()=>{
    requireView(text[offset]==='"','JSON_STRING');const start=offset++;
    while(offset<text.length){
      if(text[offset]==='\\'){offset+=2;continue;}
      if(text[offset++]==='"'){
        let value;try{value=JSON.parse(text.slice(start,offset));}catch{throw new ViewError('INVALID_JSON');}
        requireView(!/[\x00-\x1f\x7f\ud800-\udfff]/u.test(value),'UNSAFE_STRING');return value;
      }
    }
    throw new ViewError('INVALID_JSON');
  };
  const value=depth=>{
    requireView(++nodes<=100000&&depth<=32,'JSON_COMPLEXITY_LIMIT');ws();const c=text[offset];
    if(c==='"')return string();
    if(c==='{'||c==='['){
      const isObject=c==='{',end=isObject?'}':']',out=isObject?Object.create(null):[],keys=new Set();offset++;ws();
      if(text[offset]===end){offset++;return out;}
      while(offset<text.length){
        ws();let key;
        if(isObject){key=string();requireView(!keys.has(key),'DUPLICATE_JSON_KEY');keys.add(key);requireView(/^[A-Za-z_][A-Za-z0-9_]*$/.test(key),'NON_ASCII_SCHEMA_KEY');ws();requireView(text[offset++]===':','INVALID_JSON');}
        const child=value(depth+1);if(isObject)out[key]=child;else out.push(child);
        ws();if(text[offset]===end){offset++;return out;}requireView(text[offset++ ]===',','INVALID_JSON');
      }
      throw new ViewError('INVALID_JSON');
    }
    for(const [literal,decoded]of [['true',true],['false',false],['null',null]])if(text.startsWith(literal,offset)){offset+=literal.length;return decoded;}
    const match=/^-?(?:0|[1-9][0-9]*)/.exec(text.slice(offset));requireView(match,'INVALID_JSON');offset+=match[0].length;
    const number=Number(match[0]);requireView(Number.isSafeInteger(number),'UNSAFE_NUMBER');return number;
  };
  const result=value(0);ws();requireView(offset===text.length,'INVALID_JSON');return result;
}
export function createWireGuard(schema) {
  const keywords = new Set(['$schema','$id','$defs','title','description','$ref','type','properties','required',
    'additionalProperties','items','minItems','maxItems','minimum','maximum','minLength','maxLength','pattern','const','enum','oneOf','anyOf']);
  const shape = (v, s) => {
    requireView(Object.keys(s).every(k => keywords.has(k)), 'SCHEMA_KEYWORD_UNSUPPORTED');
    if (s.$ref) { requireView(s.$ref.startsWith('#/$defs/') && own(schema.$defs,s.$ref.slice(8)), 'SCHEMA_REF'); shape(v,schema.$defs[s.$ref.slice(8)]); }
    const matches = sub => {try {shape(v,sub); return true;} catch {return false;}};
    if (s.oneOf) requireView(s.oneOf.filter(matches).length === 1, 'SCHEMA_ONE_OF');
    if (s.anyOf) requireView(s.anyOf.some(matches), 'SCHEMA_ANY_OF');
    if (own(s,'const')) requireView(v === s.const, 'SCHEMA_CONST');
    if (s.enum) requireView(s.enum.includes(v), 'SCHEMA_ENUM');
    if (s.type) {
      const checks = {object: object(v), array: Array.isArray(v), string: typeof v === 'string',
        integer: Number.isSafeInteger(v), boolean: typeof v === 'boolean', null: v === null};
      requireView(checks[s.type], 'SCHEMA_TYPE');
    }
    if (object(v)) {
      for (const k of s.required || []) requireView(own(v,k), 'SCHEMA_REQUIRED');
      if (s.additionalProperties === false) requireView(Object.keys(v).every(k => own(s.properties || {}, k)), 'SCHEMA_EXTRA_FIELD');
      for (const [k, spec] of Object.entries(s.properties || {})) if (own(v,k)) shape(v[k],spec);
    }
    if (Array.isArray(v)) {
      if (s.minItems !== undefined) requireView(v.length >= s.minItems, 'SCHEMA_MIN_ITEMS');
      if (s.maxItems !== undefined) requireView(v.length <= s.maxItems, 'SCHEMA_MAX_ITEMS');
      if (s.items) v.forEach(x => shape(x,s.items));
    }
    if (typeof v === 'number') {
      if (s.minimum !== undefined) requireView(v >= s.minimum, 'SCHEMA_MINIMUM');
      if (s.maximum !== undefined) requireView(v <= s.maximum, 'SCHEMA_MAXIMUM');
    }
    if (typeof v === 'string') {
      if (s.minLength !== undefined) requireView(v.length >= s.minLength, 'SCHEMA_MIN_LENGTH');
      if (s.maxLength !== undefined) requireView(v.length <= s.maxLength, 'SCHEMA_MAX_LENGTH');
      if (s.pattern) requireView(new RegExp(s.pattern,'u').test(v), 'SCHEMA_PATTERN');
    }
  };
  const guard = (value, type) => {
    canonical(value); requireView(value.dto_type === type, 'DTO_TYPE');
    requireView(own(schema.$defs,type), 'DTO_UNKNOWN'); shape(value,schema.$defs[type]);
    if (type === 'BattleSnapshot') {
      const ids = value.units.map(u => u.unit_id), slots = value.units.map(u => u.side+':'+u.slot);
      requireView(new Set(ids).size === ids.length && new Set(slots).size === slots.length, 'UNIT_ID_OR_SLOT_DUPLICATE');
      value.units.forEach(u => {
        requireView(u.hp <= u.max_hp, 'HP_ABOVE_MAX');
        requireView(new Set(u.statuses.map(x=>x.status_instance_id)).size === u.statuses.length, 'STATUS_DUPLICATE');
        requireView(u.statuses.every(x=>x.source_unit_id === null || ids.includes(x.source_unit_id)), 'STATUS_SOURCE');
      });
      const cards = value.card_instances.map(c => c.instance_id), zones = Object.values(value.zones).flat();
      requireView(new Set(cards).size === cards.length, 'CARD_DUPLICATE');
      requireView(new Set(zones).size === zones.length && zones.length === cards.length && zones.every(x=>cards.includes(x)), 'ZONE_PARTITION');
      requireView(value.card_instances.every(c => value.units.some(u=>u.unit_id === c.owner_unit_id && u.side === 'PLAYER')), 'CARD_OWNER_MISSING');
      requireView(new Set(value.boss_states.map(b=>b.unit_id)).size === value.boss_states.length &&
        value.boss_states.every(b => value.units.some(u=>u.unit_id === b.unit_id && u.side === 'ENEMY')), 'BOSS_REFERENCE');
      const outcomes = {TERMINAL:['WIN','LOSS','DRAW'],ABORTED:['ABORTED'],FAULTED:['FAULTED']};
      requireView((outcomes[value.phase] || ['ONGOING']).includes(value.outcome), 'PHASE_OUTCOME_MISMATCH');
    }
    return freeze(clone(value));
  };
  return guard;
}
