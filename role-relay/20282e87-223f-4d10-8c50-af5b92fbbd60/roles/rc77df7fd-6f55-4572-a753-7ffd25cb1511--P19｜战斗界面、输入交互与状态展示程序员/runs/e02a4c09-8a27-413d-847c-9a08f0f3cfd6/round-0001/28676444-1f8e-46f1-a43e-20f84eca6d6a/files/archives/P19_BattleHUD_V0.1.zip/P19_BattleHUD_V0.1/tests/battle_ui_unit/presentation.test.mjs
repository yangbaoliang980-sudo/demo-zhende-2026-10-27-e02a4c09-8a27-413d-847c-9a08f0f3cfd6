import test from 'node:test';
import assert from 'node:assert/strict';
import {PresentationBridge} from '../../ui/battle/widgets/presentation_adapter.mjs';
import {ready,fixture,copy,selectAttack,replyFor,deferred,settled} from './helpers.mjs';
import {canonical} from '../../ui/battle/widgets/wire.mjs';

test('missing P29 driver still permits complete play and final HP',async()=>{const {hud}=await ready();selectAttack(hud);await hud.play();assert.deepEqual(hud.snapshot,fixture.after_play.snapshot);assert.equal(hud.pending,null);});
for(const mode of ['none','reduced','normal','fast'])test(`${mode} produces identical command and authoritative final state`,async()=>{const {hud,state}=await ready();hud.setPresentationMode(mode);selectAttack(hud);await hud.play();assert.deepEqual(state.calls,[fixture.play_command]);assert.deepEqual(hud.snapshot,fixture.after_play.snapshot);});
test('missing event seq resets presentation but keeps full final state',async()=>{const p=new PresentationBridge();p.setMode('normal');const b=copy(fixture.play_reply.commit);b.events.splice(1,1);await p.present(b,fixture.initial.snapshot.last_event_seq,b.snapshot);assert.equal(p.status,'SEQUENCE_GAP_SNAP_TO_FINAL');assert.equal(p.lastSeq,b.snapshot.last_event_seq);});
test('duplicated event seq cannot animate twice',async()=>{let n=0;const p=new PresentationBridge({driver:{present:()=>n++}});p.setMode('normal');const b=copy(fixture.play_reply.commit);b.events[1].seq=b.events[0].seq;await p.present(b,fixture.initial.snapshot.last_event_seq,b.snapshot);assert.equal(n,0);});
test('old revision events cannot animate against new final snapshot',async()=>{let n=0;const p=new PresentationBridge({driver:{present:()=>n++}});p.setMode('normal');const b=copy(fixture.play_reply.commit);b.events[0].revision--;await p.present(b,fixture.initial.snapshot.last_event_seq,b.snapshot);assert.equal(n,0);});
test('throwing driver degrades without rolling back snapshot',async()=>{const p=new PresentationBridge({driver:{present:()=>{throw Error('broken')}}});p.setMode('normal');await p.present(fixture.play_reply.commit,fixture.initial.snapshot.last_event_seq,fixture.after_play.snapshot);assert.equal(p.status,'DRIVER_FAILED_STATIC_FINAL');});
test('never-resolving driver does not block next input',async()=>{const p=new PresentationBridge({driver:{present:()=>new Promise(()=>{})}});p.setMode('normal');const {hud}=await ready({options:{presentation:p}});selectAttack(hud);await hud.play();assert.equal(hud.pending,null);assert.equal(hud.view().canEndTurn,true);});
test('skip preserves HP shield energy and piles exactly',async()=>{const {hud}=await ready({frame:fixture.after_play});const before=canonical(hud.snapshot);hud.skipPresentation();assert.equal(canonical(hud.snapshot),before);assert.equal(hud.presentation.status,'SKIPPED_TO_FINAL');});
test('late completion cannot overwrite a newer cancellation status',async()=>{const gate=deferred();const p=new PresentationBridge({driver:{present:()=>gate.promise}});p.setMode('normal');const q=p.present(fixture.play_reply.commit,fixture.initial.snapshot.last_event_seq,fixture.after_play.snapshot);p.cancel('BACKGROUND');gate.resolve();await q;assert.equal(p.status,'BACKGROUND');});
test('driver receives frozen copy and numeric anchors only',async()=>{
  let seen;const anchors={units:[{id:'enemy1',x:1,y:2,width:100,height:200}],cards:[]};
  const p=new PresentationBridge({driver:{present:x=>seen=x},anchors:()=>anchors});p.setMode('normal');await p.present(fixture.play_reply.commit,fixture.initial.snapshot.last_event_seq,fixture.after_play.snapshot);
  assert.equal('snapshot' in seen,false);assert.equal('controller' in seen,false);assert.equal('port' in seen,false);assert.throws(()=>seen.events[0].seq=99);anchors.units[0].x=88;assert.equal(seen.anchors.units[0].x,1);
});
test('unknown speed or mode is rejected',()=>assert.throws(()=>new PresentationBridge().setMode('simulation-speed-999')));
