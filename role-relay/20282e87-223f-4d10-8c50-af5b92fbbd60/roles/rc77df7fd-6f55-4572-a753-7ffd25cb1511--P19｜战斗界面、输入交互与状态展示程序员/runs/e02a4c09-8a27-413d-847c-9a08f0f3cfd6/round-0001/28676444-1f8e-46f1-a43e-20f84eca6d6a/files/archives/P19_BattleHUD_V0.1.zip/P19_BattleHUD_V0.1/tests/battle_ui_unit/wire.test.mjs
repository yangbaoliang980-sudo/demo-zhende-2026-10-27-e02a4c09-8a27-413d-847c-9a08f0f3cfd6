import test from 'node:test';
import assert from 'node:assert/strict';
import {guard,fixture,copy} from './helpers.mjs';
import {canonical,fingerprint,parseWireJson} from '../../ui/battle/widgets/wire.mjs';

test('native P13 snapshots, command, reply and P16 candidate snapshot retain original shape',()=>{
  for(const name of ['initial','after_play','next_turn','p16_preview'])assert.equal(guard(fixture[name].snapshot,'BattleSnapshot').dto_type,'BattleSnapshot');
  guard(fixture.play_command,'BattleCommand');guard(fixture.play_reply,'BattleReply');
});
for(const [name,mutate] of [
  ['negative HP',s=>s.units[0].hp=-1],['HP above max',s=>s.units[0].hp=s.units[0].max_hp+1],
  ['boolean energy',s=>s.energy=true],['floating HP',s=>s.units[0].hp=1.5],['unsafe integer',s=>s.revision=2**53],
  ['old version',s=>s.contract_version='old'],['extra intent field',s=>s.intents=[]],
  ['duplicate unit',s=>s.units.push(copy(s.units[0]))],['duplicate slot',s=>s.units[1].slot=s.units[0].slot],
  ['missing unit',s=>s.units.splice(0,1)],['duplicate card',s=>s.card_instances.push(copy(s.card_instances[0]))],
  ['card in two zones',s=>s.zones.draw.push(s.zones.hand[0])],['missing zone card',s=>s.zones.hand.pop()],
  ['foreign boss',s=>s.boss_states=[{unit_id:'unknown',current_phase_id:'one',proposed_phase_ids:[]}]],
  ['false terminal',s=>s.phase='TERMINAL'],['closed with ongoing outcome',s=>s.phase='ABORTED'],
  ['unknown phase',s=>s.phase='ANIMATION'],['status with missing source',s=>s.units[0].statuses=[{status_instance_id:'s1',status_id:'s',source_unit_id:'other',stacks:1,remaining_triggers:1,insert_order:0}]],
])test(`snapshot rejects ${name}`,()=>{const s=copy(fixture.initial.snapshot);mutate(s);assert.throws(()=>guard(s,'BattleSnapshot'));});
test('snapshot binding fingerprint equals P13 original Python canonical hash',async()=>{
  assert.equal(await fingerprint(fixture.initial.snapshot),fixture.initial.context.snapshot_sha256);
  assert.equal(await fingerprint(fixture.after_play.snapshot),fixture.after_play.context.snapshot_sha256);
});
test('canonical allows UTF8 values and sorted ASCII keys',()=>assert.equal(canonical({z:'言灵',a:1}),'{'+'"a":1,"z":"言灵"}'));
test('canonical rejects non-JSON values and surrogate controls',()=>{
  for(const x of [NaN,Infinity,undefined,{a:()=>1},{a:'\ud800'},{a:'\u0000'},{'中文':1}])assert.throws(()=>canonical(x));
});
test('guard returns deep-frozen defensive copy',()=>{const s=copy(fixture.initial.snapshot),v=guard(s,'BattleSnapshot');s.units[0].hp=1;assert.notEqual(v.units[0].hp,1);assert.throws(()=>v.units[0].hp=0);});
test('strict transport parser roundtrips original frame',()=>assert.equal(canonical(parseWireJson(JSON.stringify(fixture.initial))),canonical(fixture.initial)));
for(const [name,source]of [['duplicate keys','{"hp":1,"hp":2}'],['escaped duplicate keys','{"hp":1,"\\u0068p":2}'],['fraction','{"hp":1.0}'],['exponent','{"hp":1e3}'],['trailing comma','[1,]'],['unclosed string','{"x":"oops}'],['trailing data','{}{}'],['unsafe number','9007199254740992']])test(`transport rejects ${name}`,()=>assert.throws(()=>parseWireJson(source)));
test('parser stores prototype-like data keys without mutating prototypes',()=>{const v=parseWireJson('{"__proto__":{"polluted":true}}');assert.equal(Object.getPrototypeOf(v),null);assert.equal({}.polluted,undefined);});
