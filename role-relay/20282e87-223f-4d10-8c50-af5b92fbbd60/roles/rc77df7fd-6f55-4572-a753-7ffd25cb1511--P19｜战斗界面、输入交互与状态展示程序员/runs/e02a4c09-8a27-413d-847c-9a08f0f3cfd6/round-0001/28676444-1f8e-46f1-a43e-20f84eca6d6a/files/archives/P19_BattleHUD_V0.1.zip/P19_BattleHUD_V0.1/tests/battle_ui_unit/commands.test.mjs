import test from 'node:test';
import assert from 'node:assert/strict';
import {ready,selectAttack,fixture,copy,deferred,replyFor,settled} from './helpers.mjs';
import {canonical} from '../../ui/battle/widgets/wire.mjs';

test('UI emits only original PLAY_CARD command fields, state changes only on snapshot',async()=>{
  const gate=deferred();const {hud,state}=await ready({submit:async(c,s)=>{await gate.promise;s.frame=copy(fixture.after_play);return replyFor(c);}});
  selectAttack(hud);const before=canonical(hud.snapshot);const promise=hud.play();
  assert.equal(state.calls.length,1);assert.deepEqual(state.calls[0],fixture.play_command);assert.equal(canonical(hud.snapshot),before);
  gate.resolve();await promise;assert.deepEqual(hud.snapshot,fixture.after_play.snapshot);assert.equal(hud.pending,null);
});
test('synchronous double click submits once',async()=>{
  const gate=deferred();const {hud,state}=await ready({submit:async(c,s)=>{await gate.promise;s.frame=copy(fixture.after_play);return replyFor(c);}});
  selectAttack(hud);const a=hud.play(),b=hud.play();assert.equal(state.calls.length,1);gate.resolve();await Promise.all([a,b]);
});
test('end-turn while card response pending does not become second operation',async()=>{
  const gate=deferred();const {hud,state}=await ready({submit:async(c,s)=>{await gate.promise;s.frame=copy(fixture.after_play);return replyFor(c);}});
  selectAttack(hud);const a=hud.play();await hud.endTurn();assert.equal(state.calls.length,1);gate.resolve();await a;
});
test('unknown/invalid target never submits or edits HP',async()=>{
  const {hud,state}=await ready();selectAttack(hud);const s=canonical(hud.snapshot);hud.clearSelection();hud.selectCard(fixture.play_command.payload.card_instance_id);hud.selectTarget('missing');await hud.play();assert.equal(state.calls.length,0);assert.equal(canonical(hud.snapshot),s);
});
test('enemy card refuses ally target using owner-provided affordance',async()=>{
  const {hud,state}=await ready();hud.selectCard(fixture.play_command.payload.card_instance_id);const r=hud.selectTarget('hero_a');assert.equal(r.code,'TARGET_INVALID');await hud.play();assert.equal(state.calls.length,0);
});
test('END_TURN has empty payload and never emits system AI commands',async()=>{
  const {hud,state}=await ready({frame:fixture.after_play,options:{idFactory:()=>fixture.end_command.command_id},submit:async(c,s)=>{s.frame=copy(fixture.next_turn);return copy(fixture.end_reply);}});
  await hud.endTurn();assert.deepEqual(state.calls,[fixture.end_command]);assert.equal(hud.snapshot.turn_number,2);
});
test('SYSTEM command rejected before port',async()=>{const {hud,state}=await ready();assert.equal((await hud.dispatch('SYSTEM_ENEMY_ACTION',{},hud.snapshot.revision)).code,'USER_COMMAND_ONLY');assert.equal(state.calls.length,0);});
test('stale DOM revision cannot submit a new end turn',async()=>{const {hud,state}=await ready();assert.equal((await hud.endTurn(0)).code,'STALE_INPUT');assert.equal(state.calls.length,0);});
test('rejected command neither spends energy nor leaves pending lock',async()=>{
  const {hud}=await ready({submit:async c=>({...copy(fixture.rejected_reply),command_id:c.command_id,observed_revision:fixture.initial.snapshot.revision})});
  selectAttack(hud);const before=canonical(hud.snapshot);await hud.play();assert.equal(canonical(hud.snapshot),before);assert.equal(hud.pending,null);assert.equal(hud.error,'REVISION_CONFLICT');
});
test('repeated rejected gesture at same revision is debounced',async()=>{
  let counter=0;const {hud,state}=await ready({options:{now:()=>1000,idFactory:()=>`test:${++counter}`},submit:async c=>({...copy(fixture.rejected_reply),command_id:c.command_id,observed_revision:1})});
  selectAttack(hud);await hud.play();await hud.play();assert.equal(state.calls.length,1);assert.equal(hud.error,'INPUT_DEBOUNCED');
});
test('timeout keeps exact command and prevents newly identified retry',async()=>{
  const {hud,state}=await ready({options:{timeoutMs:15},submit:async()=>new Promise(()=>{})});selectAttack(hud);await hud.play();assert.equal(hud.pending.state,'UNKNOWN');assert.equal(state.calls.length,1);await hud.endTurn();assert.equal(state.calls.length,1);
});
test('lost reply retry reuses entire command and accepts DUPLICATE_NO_OP',async()=>{
  let calls=0;const {hud,state,port}=await ready({submit:async(c,s)=>{calls++;s.frame=copy(fixture.after_play);if(calls===1)throw Error('lost');return {...copy(fixture.duplicate_reply),command_id:c.command_id};}});
  selectAttack(hud);await hud.play();await hud.retryPending();assert.equal(state.calls.length,2);assert.deepEqual(state.calls[0],state.calls[1]);assert.equal(hud.pending,null);assert.deepEqual(hud.snapshot,fixture.after_play.snapshot);assert.equal(hud.error,null);
});
test('double retry while one retry is in flight submits only one retry',async()=>{
  const gate=deferred();let count=0;const {hud,state}=await ready({submit:async(c,s)=>{if(++count===1)throw Error('lost');await gate.promise;s.frame=copy(fixture.after_play);return {...copy(fixture.duplicate_reply),command_id:c.command_id};}});
  selectAttack(hud);await hud.play();const a=hud.retryPending(),b=hud.retryPending();assert.equal(state.calls.length,2);gate.resolve();await Promise.all([a,b]);
});
test('wrong reply identity quarantines outcome and does not replace snapshot',async()=>{
  const {hud}=await ready({submit:async c=>({...replyFor(c),command_id:'wrong'})});selectAttack(hud);const old=canonical(hud.snapshot);await hud.play();assert.equal(hud.pending.state,'UNKNOWN');assert.equal(canonical(hud.snapshot),old);
});
test('commit wrong previous revision cannot replace snapshot',async()=>{
  const {hud}=await ready({submit:async c=>{const r=replyFor(c);r.commit.previous_revision=0;return r;}});selectAttack(hud);await hud.play();assert.equal(hud.error,'COMMIT_BINDING');assert.equal(hud.snapshot.revision,1);
});
test('duplicate reply without full current snapshot remains locked',async()=>{
  const {hud}=await ready({submit:async c=>({...copy(fixture.duplicate_reply),command_id:c.command_id})});selectAttack(hud);await hud.play();assert.equal(hud.error,'REPLY_SNAPSHOT_NOT_CURRENT');assert.equal(hud.pending.state,'UNKNOWN');
});
test('disconnected UI cannot issue commands',async()=>{const {hud,state}=await ready();hud.port.read=async()=>{throw Error('offline')};await hud.refresh();await hud.endTurn();assert.equal(state.calls.length,0);assert.equal(hud.view().canEndTurn,false);});
test('background locks input; fresh resume restores snapshot',async()=>{
  const {hud,state}=await ready();await hud.setVisibility(true);await hud.endTurn();assert.equal(state.calls.length,0);state.frame=copy(fixture.after_play);await hud.setVisibility(false);assert.equal(hud.snapshot.revision,2);assert.equal(hud.stale,false);assert.equal(hud.selection,null);
});
test('resume after failure remains stale',async()=>{const {hud}=await ready();await hud.setVisibility(true);hud.port.read=async()=>{throw Error('offline')};await hud.setVisibility(false);assert.equal(hud.stale,true);assert.equal(hud.view().canSelect,false);});
test('late response after dispose cannot update or send again',async()=>{
  const gate=deferred();const {hud,state}=await ready({submit:async(c,s)=>{await gate.promise;s.frame=copy(fixture.after_play);return replyFor(c);}});selectAttack(hud);const p=hud.play();hud.dispose();gate.resolve();await p;assert.equal(hud.snapshot.revision,1);
});
test('local request id collision is blocked even after prior rejection',async()=>{
  let t=0;const {hud,state}=await ready({options:{now:()=>t},submit:async c=>({...copy(fixture.rejected_reply),command_id:c.command_id,observed_revision:1})});selectAttack(hud);await hud.play();t=1000;await hud.play();assert.equal(state.calls.length,1);assert.equal(hud.error,'LOCAL_COMMAND_ID_COLLISION');
});
test('multiple selected targets follow owner-provided ordered target set',async()=>{
  const f=copy(fixture.initial);const chosen=f.context.cards.find(c=>c.instance_id===fixture.play_command.payload.card_instance_id);chosen.allowed_target_sets=[['hero_b','hero_a']];
  const {hud,state}=await ready({frame:f,submit:async c=>({...copy(fixture.rejected_reply),command_id:c.command_id,observed_revision:1})});
  hud.selectCard(chosen.instance_id);hud.selectTarget('hero_a');hud.selectTarget('hero_b');await hud.play();assert.deepEqual(state.calls[0].payload.target_ids,['hero_b','hero_a']);
});
test('successful reconnection clears stale error while retaining historical evidence',async()=>{
  const {hud,port}=await ready();const read=port.read;port.read=async()=>{throw Error('offline')};await hud.refresh();assert.equal(hud.error,'CONNECTION_LOST');port.read=read;await hud.refresh();assert.equal(hud.error,null);assert.equal(hud.view().canEndTurn,true);assert.ok(hud.logs.some(l=>l.code==='CONNECTION_LOST'));
});
