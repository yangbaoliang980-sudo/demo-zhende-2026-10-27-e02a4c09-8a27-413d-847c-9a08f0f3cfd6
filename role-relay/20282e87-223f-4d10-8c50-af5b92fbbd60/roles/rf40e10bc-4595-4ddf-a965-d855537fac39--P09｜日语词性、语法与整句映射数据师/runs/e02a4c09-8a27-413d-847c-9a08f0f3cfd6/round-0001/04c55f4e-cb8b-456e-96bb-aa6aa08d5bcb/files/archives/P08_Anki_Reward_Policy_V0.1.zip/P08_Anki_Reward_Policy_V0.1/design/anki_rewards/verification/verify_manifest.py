#!/usr/bin/env python3
"""Verify complete package coverage except the manifest itself, fixed by outer receipt."""
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

ROOT=Path(__file__).resolve().parents[3]
MANIFEST='design/anki_rewards/delivery_manifest.sha256.tsv'

def verify(root=ROOT):
    root=Path(root)
    with (root/MANIFEST).open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
    seen=set()
    for r in rows:
        rel=r['relative_path'];parts=PurePosixPath(rel)
        if parts.is_absolute() or '..' in parts.parts or rel in seen:raise ValueError('Invalid manifest path: '+rel)
        seen.add(rel);p=root/rel
        if not p.is_file() or p.is_symlink():raise ValueError('Missing file/symlink: '+rel)
        b=p.read_bytes()
        if len(b)!=int(r['actual_bytes']) or hashlib.sha256(b).hexdigest()!=r['sha256']:raise ValueError('Hash/size mismatch: '+rel)
        if r['actual_engine_write_authorized']!='false':raise ValueError('Unexpected write authorization')
        if not r['source_input_hashes_json'] or not r['receivers'] or not r['modify_whitelist']:raise ValueError('Incomplete per-file record')
        json.loads(r['source_input_hashes_json'])
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual!=seen|{MANIFEST}:raise ValueError('Manifest coverage mismatch: '+str(sorted(actual^(seen|{MANIFEST}))))
    return {'status':'PASS','scope':'DELIVERY_BYTES_ONLY','files_verified':len(rows),'manifest_self_hash':'SEE_OUTER_DELIVERY_RECEIPT'}

if __name__=='__main__':
    try:print(json.dumps(verify(),ensure_ascii=False,indent=2))
    except Exception as exc:
        print(json.dumps({'status':'FAIL','error':str(exc)},ensure_ascii=False),file=sys.stderr);sys.exit(1)
