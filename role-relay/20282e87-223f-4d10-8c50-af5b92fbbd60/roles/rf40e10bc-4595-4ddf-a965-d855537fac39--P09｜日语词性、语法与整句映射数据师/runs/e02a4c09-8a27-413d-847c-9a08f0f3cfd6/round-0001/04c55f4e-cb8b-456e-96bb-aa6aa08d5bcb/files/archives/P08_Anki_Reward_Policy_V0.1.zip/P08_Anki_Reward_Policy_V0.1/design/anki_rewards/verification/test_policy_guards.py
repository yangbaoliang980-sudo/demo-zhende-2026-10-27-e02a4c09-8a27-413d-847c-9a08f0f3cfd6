"""Author tests: deliberate invalid artifacts must be refused, not runtime tests."""
import csv
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
import verify_policy_artifacts as validator
import verify_sources

class PolicyArtifactGuards(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='p08-author-guard-')
        self.root = Path(self.temp.name)/'package'
        shutil.copytree(validator.ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__'))
        self.spec = self.root/'spec/anki/reward_semantics'

    def tearDown(self):
        self.temp.cleanup()

    def mutate_json(self, path, edit):
        p=self.spec/path
        d=json.loads(p.read_text(encoding='utf-8'));edit(d)
        p.write_text(json.dumps(d,ensure_ascii=False)+'\n',encoding='utf-8')

    def mutate_matrix(self, edit):
        p=self.spec/'rating_matrix_data.json'
        d=json.loads(p.read_text(encoding='utf-8'));edit(d['rows'])
        p.write_text(json.dumps(d,ensure_ascii=False)+'\n',encoding='utf-8')
        with (self.spec/'four_rating_policy_matrix.tsv').open('w',encoding='utf-8',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(d['rows'][0]),delimiter='\t',lineterminator='\n')
            w.writeheader();w.writerows(d['rows'])

    def assert_rejected(self):
        with self.assertRaises(validator.ValidationError):
            validator.validate(self.root)

    def test_valid_static_package(self):
        result=validator.validate(self.root)
        self.assertEqual(result['rating_matrix_rows'],84)
        self.assertEqual(result['runtime_cases_executed'],0)

    def test_unsigned_policy_cannot_authorize_awards(self):
        self.mutate_json('policy_record.proposal.json',lambda d:d.update(production_authorized=True))
        self.assert_rejected()

    def test_invented_real_rating_amount_refused(self):
        self.mutate_json('policy_record.proposal.json',lambda d:d['formal_rating_amounts'].update(Easy=1))
        self.assert_rejected()

    def test_easy_advantage_refused_even_with_consistent_source_table(self):
        self.mutate_matrix(lambda rows:next(r for r in rows if r['condition_id']=='FRESH_VERIFIED' and r['rating']=='Easy').update(candidate_right_expression='DOUBLE_B'))
        self.assert_rejected()

    def test_missing_again_refused(self):
        self.mutate_matrix(lambda rows:rows.pop(next(i for i,r in enumerate(rows) if r['condition_id']=='FRESH_VERIFIED' and r['rating']=='Again')))
        self.assert_rejected()

    def test_duplicate_case_id_refused(self):
        self.mutate_json('policy_cases.json',lambda d:d['cases'][1].update(case_id=d['cases'][0]['case_id']))
        self.assert_rejected()

    def test_unrun_case_cannot_claim_pass(self):
        self.mutate_json('policy_cases.json',lambda d:d['cases'][0].update(execution_status='PASS'))
        self.assert_rejected()

    def test_negative_quantity_refused(self):
        self.mutate_json('compensation_arithmetic_cases.json',lambda d:d['cases'][0]['values'].update(A=-1))
        self.assert_rejected()

    def test_unbalanced_recovery_refused(self):
        self.mutate_json('compensation_arithmetic_cases.json',lambda d:d['cases'][2]['values'].update(R=4))
        self.assert_rejected()

    def test_offset_double_credit_refused(self):
        self.mutate_json('compensation_arithmetic_cases.json',lambda d:d['future_offset_examples'][0].update(w=5))
        self.assert_rejected()

    def test_restore_full_grant_refused_even_if_equations_balance(self):
        self.mutate_json('compensation_arithmetic_cases.json',lambda d:d['cases'][4]['values'].update(G=20,A=10,U=7))
        self.assert_rejected()

    def test_readonly_snapshot_tamper_refused(self):
        p=self.root/'design/anki_rewards/evidence/readonly_sources/p01_decisions_pending.tsv'
        with p.open('ab') as f:f.write(b'CORRUPTED')
        with self.assertRaises(ValueError):verify_sources.verify(self.root)

    def test_unapproved_path_mapping_refused(self):
        p=self.root/'design/anki_rewards/path_mapping_request.json'
        d=json.loads(p.read_text(encoding='utf-8'));d['actual_paths']={'fake':'runtime/anki'}
        p.write_text(json.dumps(d),encoding='utf-8')
        self.assert_rejected()

    def test_unknown_resource_fallback_required(self):
        p=self.spec/'resource_mapping_candidates.tsv'
        p.write_text('\n'.join(x for x in p.read_text(encoding='utf-8').splitlines() if not x.startswith('UNKNOWN\t'))+'\n',encoding='utf-8')
        self.assert_rejected()

    def test_registry_status_must_match_document(self):
        self.mutate_json('policy_registry.json',lambda d:d['policies'][0].update(policy_status='PENDING'))
        self.assert_rejected()

    def test_null_cap_not_silently_zero_or_unlimited(self):
        self.mutate_json('policy_record.proposal.json',lambda d:d['cap_policy'].update(daily_limit=0))
        self.assert_rejected()

if __name__=='__main__':unittest.main(verbosity=2)
