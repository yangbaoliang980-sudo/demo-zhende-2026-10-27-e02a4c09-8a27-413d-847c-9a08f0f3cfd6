#!/usr/bin/env python3
"""Validate static policy data and exact arithmetic. No runtime/event engine."""
import argparse
import csv
from fractions import Fraction
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[3]
RATINGS = {'Again','Hard','Good','Easy'}
STATUSES = {'CONFIRMED','PROPOSAL','PENDING'}
CONDITIONS = {'FRESH_VERIFIED','NATURAL_SAME_CARD','EXACT_REPLAY','IDENTITY_CONFLICT',
 'IDENTITY_UNPROVEN','UNDO_UNOBSERVABLE','POLICY_UNAPPROVED','UNKNOWN_WITH_CONTRACT',
 'MAPPING_ABSENT','RESTORE_PROVEN','REDO_UNLINKED','NEXT_DAY_NEW','NEXT_DAY_REPLAY',
 'CAP_FULL','UNDO_BEFORE_CREDIT','UNDO_UNSPENT','UNDO_SPENT','OFFLINE_LATE',
 'DAY_AMBIGUOUS','NOT_COMPLETED','TRANSACTION_UNKNOWN'}

class ValidationError(ValueError):
    pass

def require(ok, message):
    if not ok:
        raise ValidationError(message)

def load(root, rel):
    return json.loads((root/rel).read_text(encoding='utf-8'))

def validate_arithmetic(data):
    ids = set()
    for row in data['cases']:
        require(row['case_id'] not in ids, 'Duplicate arithmetic ID')
        ids.add(row['case_id'])
        require(row['fixture_only'] is True and row['formal_award_amount'] is None, 'Fixture became a formal amount')
        require(row['runtime_execution_status']=='NOT_RUN', 'Math fixture claims runtime execution')
        require(set(row['values'])=={'G','R','S','A','T','U','K','M'}, 'Wrong arithmetic variables')
        require(all(type(v) is int for v in row['values'].values()), 'Noninteger or boolean arithmetic input')
        v={k:Fraction(n) for k,n in row['values'].items()}
        require(all(n>=0 for n in v.values()), 'Negative quantity')
        require(v['A']+v['S']==v['G']-v['R'], 'Physical conservation failed')
        require(v['G']-v['R']+v['M']==v['T']+v['U']+v['K'], 'Entitlement reconciliation failed')
        require(not(v['U']>0 and v['M']>0), 'Unresolved excess and deficit coexist')
    lookup={r['case_id']:r['values'] for r in data['cases']}
    require(lookup['P08-MATH-A03']==lookup['P08-MATH-A04'], 'Repeated Undo changed totals')
    require(lookup['P08-MATH-A05']['G']-lookup['P08-MATH-A03']['G']==3, 'Restore issued full grant instead of difference')
    require(lookup['P08-MATH-A06']['R']-lookup['P08-MATH-A05']['R']==3, 'Repeated cycle over-recovered')
    for row in data['future_offset_examples']:
        require(row['fixture_only'] and row['runtime_execution_status']=='NOT_RUN', 'Offset became runtime evidence')
        require(row['n']==row['h']+row['w'], 'Offset income is double counted')
        require(0<=row['h']<=min(row['n'],row['D_before']), 'Offset exceeds income or exposure')
        require(row['D_after']==row['D_before']-row['h']>=0, 'Offset remaining balance invalid')
    return len(ids)+len(data['future_offset_examples'])

def validate(root=ROOT):
    root=Path(root)
    spec='spec/anki/reward_semantics/'
    registry=load(root,spec+'policy_registry.json')['policies']
    policy_ids={p['policy_id'] for p in registry}
    require(len(policy_ids)==len(registry), 'Duplicate policy IDs')
    sources=load(root,'design/anki_rewards/source_input_receipt.json')
    source_ids={x['source_id'] for x in sources['resolved_inputs']}
    for row in registry:
        require(row['policy_status'] in STATUSES, 'Unknown policy status')
        require(row['production_authorized'] is False, 'Registry grants production authority')
        require(set(row['source_ids'])<=source_ids, 'Unknown source reference')
        text=(root/row['document']).read_text(encoding='utf-8')
        require(f"### {row['policy_id']}｜{row['policy_status']}：{row['title']}" in text, 'Registry/document mismatch')
    doc_ids=set()
    for name in {p['document'] for p in registry}:
        doc_ids.update(re.findall(r'^### (P08-[CPUQD]\d+)｜(?:CONFIRMED|PROPOSAL|PENDING)：', (root/name).read_text(encoding='utf-8'),re.M))
    require(doc_ids==policy_ids, 'Unindexed policy rule')
    record=load(root,spec+'policy_record.proposal.json')
    require(record['production_authorized'] is False and record['policy_status']=='PROPOSAL', 'Unsigned draft authorizes production')
    require(set(record['formal_rating_amounts'])==RATINGS, 'Missing rating')
    require(all(x is None for x in record['formal_rating_amounts'].values()), 'Invented formal award amount')
    require(record['user_approval'] is None and record['p01_receipt'] is None, 'Fabricated policy approval')
    for key in ['selected_reward_profile','formal_resource_ids','category_mapping_version','undo_spent_policy','source_spend_attribution_contract','zero_study_day_policy','effective_from','retroactive_scope']:
        require(record[key] is None, 'Unapproved policy selected: '+key)
    require(all(x is None for x in record['cap_policy'].values()), 'Unapproved cap policy')
    require(all(x is None for x in record['reward_day_policy'].values()), 'Invented target day policy')
    require(all(x is None for k,x in record.items() if k.endswith('_receipt')), 'Fabricated receipt')
    require(all(x is True for x in record['inherited_constraints'].values()), 'Inherited guard disabled')
    with (root/(spec+'four_rating_policy_matrix.tsv')).open(encoding='utf-8',newline='') as f:
        matrix=list(csv.DictReader(f,delimiter='\t'))
    require(matrix==load(root,spec+'rating_matrix_data.json')['rows'], 'TSV differs from authoring data')
    require({r['condition_id'] for r in matrix}==CONDITIONS, 'Missing/extra condition')
    require(len({r['case_id'] for r in matrix})==len(matrix), 'Duplicate matrix ID')
    groups={c:[r for r in matrix if r['condition_id']==c] for c in CONDITIONS}
    for condition,rows in groups.items():
        require(len(rows)==4 and {r['rating'] for r in rows}==RATINGS,'Four-key coverage missing: '+condition)
        for r in rows:
            require(r['policy_status'] in STATUSES and r['amount_status']=='PENDING', 'Unlabelled rating policy')
            require(r['current_real_award_authorized']=='false','Matrix authorizes real award')
            require(r['formal_amount']=='UNSET','Matrix invents actual amount')
            require(r['equal_base_across_four']=='true','Rating incentive not neutral')
            require(r['runtime_execution_status']=='NOT_RUN','Matrix claims runtime PASS')
            require(r['policy_ref'] in policy_ids,'Unknown policy in matrix')
        comparable=[{k:v for k,v in r.items() if k not in ['case_id','rating']} for r in rows]
        require(all(x==comparable[0] for x in comparable), 'Rating-dependent incentive/outcome')
    require(groups['FRESH_VERIFIED'][0]['candidate_right_expression']=='ONE_RIGHT_VECTOR_B','Fresh Again base excluded')
    for c in ['EXACT_REPLAY','NEXT_DAY_REPLAY']:
        require(groups[c][0]['candidate_right_expression']=='NO_ADDITIONAL_RIGHT','Replay adds rights')
    for c in ['IDENTITY_UNPROVEN','UNDO_UNOBSERVABLE']:
        require(groups[c][0]['candidate_outcome']=='QUARANTINE_SOURCE','Capability failure not quarantined')
    cases=load(root,spec+'policy_cases.json')['cases']
    require(len(cases)>=40 and len(cases)==len({c['case_id'] for c in cases}),'Case coverage/IDs invalid')
    for c in cases:
        require(c['policy_status'] in STATUSES and c['execution_status']=='NOT_RUN','Unrun case claims success')
        require(c['actual_output'] is None and c['actual_log_sha256'] is None,'Fabricated runtime output')
        require(set(c['policy_refs'])<=policy_ids,'Unknown policy in cases')
        require(c['preconditions'] and c['operations'] and c['expected'],'Case only names a title')
    arithmetic_count=validate_arithmetic(load(root,spec+'compensation_arithmetic_cases.json'))
    with (root/(spec+'resource_mapping_candidates.tsv')).open(encoding='utf-8',newline='') as f:
        resources=list(csv.DictReader(f,delimiter='\t'))
    require(len(resources)==8 and any(r['category_semantic']=='UNKNOWN' for r in resources),'Resource category/fallback missing')
    require(all(r['formal_resource_id']=='UNSET' and r['formal_quantity']=='UNSET' and r['production_authorized']=='false' for r in resources),'Invented formal resource config')
    path=load(root,'design/anki_rewards/path_mapping_request.json')
    require(path['actual_paths'] is None and path['actual_engine_write_whitelist']==[],'Invented actual path authorization')
    return {'status':'PASS','scope':'AUTHOR_STATIC_POLICY_AND_ARITHMETIC_ONLY','policies':len(registry),
            'rating_conditions':len(groups),'rating_matrix_rows':len(matrix),'logical_runtime_cases':len(cases),
            'arithmetic_examples_checked':arithmetic_count,'runtime_cases_executed':0,
            'real_anki_events':0,'real_awards':0,'independent_review':'NOT_RUN'}

def formal_preflight(root=ROOT):
    evidence=load(Path(root),'design/anki_rewards/formal_prerequisites.json')
    missing=[{'id':r['id'],'owner':r['owner'],'required_artifacts':r['required_artifacts'],'status':r['status']} for r in evidence['checks'] if r['verified_receipt'] is None]
    return {'status':'BLOCKED','scope':'DELIVERY_EVIDENCE_ONLY','reason':'Unsigned proposal cannot authorize actual rewards',
            'production_authorized':False,'missing_evidence':missing,'target_machine_probe':'NOT_RUN'}

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--formal',action='store_true')
    args=ap.parse_args()
    try:
        result=validate()
        if args.formal:
            print(json.dumps(formal_preflight(),ensure_ascii=False,indent=2));sys.exit(3)
        print(json.dumps(result,ensure_ascii=False,indent=2))
    except ValidationError as exc:
        print(json.dumps({'status':'FAIL','owner':'P08','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        sys.exit(1)
