"""P05 author-level deterministic unit tests. Not P32 independent acceptance."""
import hashlib
import importlib.util
import json
import unittest
from pathlib import Path

MOD = Path(__file__).with_name('fixed_seed_simulation.py')
spec = importlib.util.spec_from_file_location('p05_model', MOD)
p05 = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = p05
spec.loader.exec_module(p05)


class P05Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cards, cls.people, cls.deck_rows, cls.costs, cls.params = p05.load_inputs()
        cls.char_ids = [c['character_id'] for c in cls.people['characters']]

    def test_01_hash_pins(self):
        p05.sha_check()
        self.assertEqual(len(p05.EXPECTED_HASHES), 6)

    def test_02_source_versions(self):
        self.assertEqual(self.cards['format_version'], 'P03-CARDS-0.1.0-draft')
        self.assertEqual(self.people['format_version'], 'P04-SKELETON-0.1.0-draft')

    def test_03_p03_active_and_disabled(self):
        self.assertEqual(len([c for c in self.cards['cards'] if c['mock_playable']]), 8)
        self.assertEqual(len([c for c in self.cards['cards'] if not c['mock_playable']]), 2)

    def test_04_p04_party_not_fourth_character(self):
        self.assertEqual(len(self.people['characters']), 3)
        self.assertNotIn('MOCK_P03_CHAR_D', self.char_ids)

    def test_05_deck_9_instances(self):
        d = p05.build_deck(self.deck_rows, self.cards)
        self.assertEqual(len(d), 9)
        self.assertEqual(d.count('MOCK_P03_CARD_STRIKE'), 2)

    def test_06_growth_reference_no_card_buff(self):
        a = self.people['characters'][0]
        self.assertEqual(a['base_stats']['max_hp']+2*a['per_level_growth']['max_hp'],120)
        self.assertEqual(a['base_stats']['attack']+2*a['per_level_growth']['attack'],25)
        c = next(c for c in self.cards['cards'] if c['card_id']=='MOCK_P03_CARD_A_EDGE')
        eff = next(e for e in self.cards['effects'] if e['effect_id']==c['effect_ids'][0])
        self.assertEqual(eff['amount'],6)

    def test_07_rational_signature_efficiency(self):
        cards = {c['card_id']:c for c in self.cards['cards']}
        effects = {e['effect_id']:e for e in self.cards['effects']}
        ratio = lambda c: effects[cards[c]['effect_ids'][0]]['amount']/cards[c]['cost']['amount']
        self.assertGreater(ratio('MOCK_P03_CARD_STRIKE'),ratio('MOCK_P03_CARD_A_EDGE'))
        self.assertGreater(ratio('MOCK_P03_CARD_BARRIER'),ratio('MOCK_P03_CARD_B_WALL'))
        self.assertGreater(ratio('MOCK_P03_CARD_RECOVER'),ratio('MOCK_P03_CARD_C_MEND'))

    def test_08_shield_absorbs_first(self):
        u=p05.Unit.fresh('U',20,8)
        self.assertEqual(p05.apply_damage(u,10),(8,2))
        self.assertEqual((u.hp,u.shield),(18,0))

    def test_09_heal_cap(self):
        u=p05.Unit.fresh('U',20)
        u.hp=17
        self.assertEqual(p05.apply_heal(u,12),3)
        self.assertEqual(u.hp,20)

    def test_10_no_dead_heal(self):
        u=p05.Unit.fresh('U',20);u.hp=0
        self.assertEqual(p05.apply_heal(u,12),0)

    def test_11_shield_cap(self):
        u=p05.Unit.fresh('U',50)
        self.assertEqual(sum(p05.apply_shield(u,4,40) for _ in range(100)),40)
        self.assertEqual(u.shield,40)

    def test_12_no_negative_hp(self):
        u=p05.Unit.fresh('U',7,3)
        self.assertEqual(p05.apply_damage(u,100),(3,7))
        self.assertEqual((u.hp,u.shield),(0,0))

    def test_13_rng_reproducible(self):
        a=p05.RNG(20261028);b=p05.RNG(20261028)
        self.assertEqual([a.next() for _ in range(100)],[b.next() for _ in range(100)])

    def test_14_rng_zero_forbidden(self):
        with self.assertRaises(ValueError):p05.RNG(0)

    def test_15_baseline_battle_normal(self):
        o=p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'normal',20261028)
        self.assertEqual(o['outcome'],'WIN')
        self.assertEqual(o['turns'],4)

    def test_16_boss_20_rounds(self):
        o=p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'boss',20261028)
        self.assertEqual((o['outcome'],o['turns']),('WIN',20))
        self.assertEqual(o['damage_hp_to_enemy'],125)

    def test_17_level_only_affects_hp_in_model(self):
        a=p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'boss',20261028,level=1)
        b=p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'boss',20261028,level=5)
        self.assertEqual(a['turns'],b['turns'])
        self.assertEqual(a['damage_hp_to_enemy'],b['damage_hp_to_enemy'])
        self.assertGreater(b['party_hp_remaining'],a['party_hp_remaining'])

    def test_18_one_turn_bad_boss(self):
        o=p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'boss_ohko',20261028,mode='attack')
        self.assertEqual((o['outcome'],o['turns']),('WIN',1))

    def test_19_no_study_same_battle_inputs(self):
        results = {r['scenario']:r for r in p05.make_rows(20261028)}
        a,b=results['boss_long_zero_study'],results['boss_long_again20_shadow']
        for key in ('turns','damage_hp_to_enemy','party_hp_remaining','outcome','cards_played'):
            self.assertEqual(a[key],b[key])

    def test_20_replay_idempotency(self):
        s=p05.shadow_ledger(p05.make_events('REPLAY1000'),{'Again':1,'Hard':1,'Good':1,'Easy':1})
        self.assertEqual((s['valid_unique_events'],s['deduplicated_attempts'],s['shadow_net']),(1,999,1))

    def test_21_collision(self):
        s=p05.shadow_ledger(p05.make_events('COLLISION100'),{'Again':1,'Hard':1,'Good':1,'Easy':1})
        self.assertEqual((s['valid_unique_events'],s['id_collisions'],s['shadow_net']),(1,100,1))

    def test_22_undo(self):
        s=p05.shadow_ledger(p05.make_events('UNDO6'),{'Again':1,'Hard':1,'Good':1,'Easy':1})
        self.assertEqual((s['valid_unique_events'],s['undo_events'],s['shadow_net']),(12,6,6))

    def test_23_untrusted_events_quarantined(self):
        s=p05.shadow_ledger(p05.make_events('UNTRUSTED100'),{'Again':1,'Hard':1,'Good':1,'Easy':1})
        self.assertEqual((s['untrusted_quarantined'],s['shadow_net']),(100,0))

    def test_24_again_good_policy_same_base(self):
        d={'Again':1,'Hard':1,'Good':1,'Easy':1}
        a=p05.shadow_ledger(p05.make_events('AGAIN20'),d)
        b=p05.shadow_ledger(p05.make_events('GOOD20'),d)
        self.assertEqual(a['shadow_net'],b['shadow_net'])

    def test_25_bad_again_bonus(self):
        d={'Again':2,'Hard':1,'Good':1,'Easy':1}
        a=p05.shadow_ledger(p05.make_events('AGAIN20'),d)
        b=p05.shadow_ledger(p05.make_events('GOOD20'),d)
        self.assertEqual((a['shadow_net'],b['shadow_net']),(40,20))

    def test_26_p04_xp_gate(self):
        a=p05.project_progression(1515,21,self.costs,self.char_ids)
        self.assertEqual((a['level_upgrades'],a['skill_upgrades']),(3,0))
        self.assertEqual(a['token_balance'],1503)

    def test_27_p04_all_levels_skill_cost(self):
        a=p05.project_progression(180,70,self.costs,self.char_ids)
        self.assertEqual((a['level_upgrades'],a['skill_upgrades'],a['token_balance']),(12,6,0))

    def test_28_zero_study_stage_budget(self):
        self.assertEqual(p05.stage_budget(self.params),(15,21))
        self.assertEqual(p05.project_progression(15,21,self.costs,self.char_ids)['level_upgrades'],3)

    def test_29_results_deterministic(self):
        a=p05.csv_bytes(p05.make_rows(20261028))
        b=p05.csv_bytes(p05.make_rows(20261028))
        self.assertEqual(a,b)
        self.assertEqual(a,(p05.ROOT/'analysis/simulations/simulation_results.csv').read_bytes())

    def test_30_simulate_positive_seed_validation(self):
        with self.assertRaises(ValueError):
            p05.basic_battle(self.cards,self.people,self.deck_rows,self.params,'normal',0)

    def test_31_violations_not_claimed_as_game(self):
        statuses={r['status'] for r in p05.make_rows(20261028)}
        self.assertEqual(statuses,{'LOCAL_MOCK_SIMULATION_ONLY'})

    def test_32_expected_sensitivity(self):
        rows={r['scenario']:r for r in p05.make_rows(20261028)}
        self.assertEqual(rows['damage_80']['outcome'],'LOSS')
        self.assertEqual(rows['energy_2']['outcome'],'LOSS')
        self.assertEqual(rows['boss_defense_priority']['outcome'],'TURN_LIMIT')

    def test_33_stress_recommendation_not_approval(self):
        rows={r['scenario']:r for r in p05.make_rows(20261028)}
        self.assertEqual(rows['shield_100_casts_cap40']['shield_granted'],40)
        self.assertEqual(rows['shield_100_casts_no_practical_cap']['shield_granted'],400)
        self.assertIn('97 requests',rows['same_turn_100_card_requests']['notes'])


if __name__=='__main__':
    unittest.main(verbosity=2)
