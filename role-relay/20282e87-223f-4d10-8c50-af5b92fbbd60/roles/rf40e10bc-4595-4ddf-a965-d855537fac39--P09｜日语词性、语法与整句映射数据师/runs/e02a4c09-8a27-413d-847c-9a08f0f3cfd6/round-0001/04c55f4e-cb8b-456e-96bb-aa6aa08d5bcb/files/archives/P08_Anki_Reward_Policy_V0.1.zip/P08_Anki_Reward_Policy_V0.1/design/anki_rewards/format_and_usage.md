# P08｜数据格式与下游使用

任务P08-S04-S05-POLICY-001，版本P08-REWARD-POLICY/0.1.0-proposal。以下为本包格式定义，不定义P12正式Envelope。

## 文件格式

正文为UTF-8 Markdown。所有自有TSV为UTF-8、首行字段名、Tab分隔、LF换行；无合并单元格、无Excel公式。JSON用UTF-8与标准JSON null/true/false。只读来源保留原始字节，不统一换行、编码或重排列。

四键TSV每行由condition_id和rating唯一确定。rating使用语义名，不提供按钮数值编码。candidate_outcome与candidate_right_expression是候选语义，不是可执行金额或账本枚举。formal_amount=UNSET表示未批准/未知；ZERO_NEW_RIGHT只描述特定不授新增权益的分支，不代表四键正式价格=0。

policy_status取CONFIRMED/PROPOSAL/PENDING；amount_status=PENDING；current_real_award_authorized=false。equal_base_across_four=true表示同条件四键基础方案一致，不表示所有不同条件都给同量。runtime_execution_status=NOT_RUN不会被静态检查改为PASS。

rating_matrix_data.json是TSV作者输入的逐行对应副本，用于检测转换损坏；核心语义另由验证器检查四键齐全、差额对称、无实际奖额与无假运行结果。两份都被同样错误修改也不能绕过全部语义检查；16项作者测试包括同步改Easy差额的反例。

## 测试边界

policy_cases.json每例包含preconditions、operations、expected、policy_refs、实现owner、独立执行者与状态。它没有假造P12字段或实际程序适配器；下游需取得正式合同后建立适配，分别记录实际输出和日志。58例当前运行执行数为0。

compensation_arithmetic_cases.json的数量是合成整数单位，formal_award_amount始终null。校验器只验证12个闭合状态的非负/守恒/恢复差额和1个未来抵扣分解，未实现事件处理、幂等数据库或存档。

## 接收顺序

先核验完整包与外层回执，再读主规则、四键表、补偿与隔离规则，再核对source_input_receipt与对应源快照。准备接收的每个角色通过downstream_handoff定位自己的文件与SHA。

当收到正式上游新版本时，创建新的P08提案版本并保留本包。不得在只读源快照内“修正”上游，也不得直接将未签policy_record的production_authorized改true。P13 actual_path_mapping出具前，本包所有规划路径均不授权工程写入。
