#!/usr/bin/env python3
"""Read-only byte/provenance verification. Does not execute any upstream code."""
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def require(ok, message):
    if not ok:
        raise ValueError(message)

def safe_name(name):
    p = PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and '\\' not in name,
            'Unsafe archive/manifest path: ' + name)

def read_chain(data, members):
    for member in members:
        safe_name(member)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            data = z.read(member)
    return data

def verify(root=ROOT):
    root = Path(root)
    receipt = json.loads((root/'design/anki_rewards/source_input_receipt.json').read_text(encoding='utf-8'))
    roots = {}
    queue = []
    for row in receipt['archive_inputs']:
        p = root / row['package_path']
        data = p.read_bytes()
        require(len(data) == row['size_bytes'] and digest(data) == row['sha256'],
                'Root archive mismatch: ' + row['source_id'])
        roots[row['source_id']] = data
        queue.append((row['source_id'], data))
    seen = set()
    archives = []
    while queue:
        origin, data = queue.pop(0)
        h = digest(data)
        if h in seen:
            continue
        seen.add(h)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            require(len(names) == len(set(names)), 'Duplicate ZIP member: ' + origin)
            for info in z.infolist():
                safe_name(info.filename)
                require((info.external_attr >> 16) & 0o170000 != 0o120000, 'ZIP symlink')
            require(z.testzip() is None, 'CRC error: ' + origin)
            checks = []
            if 'manifest.json' in names:
                obj = json.loads(z.read('manifest.json'))
                for row in obj.get('files', []):
                    safe_name(row['path'])
                    b = z.read(row['path'])
                    require(len(b) == row['size'] and digest(b) == row['sha256'],
                            'Relay manifest mismatch: ' + row['path'])
                    checks.append(row['path'])
            # files/* are loose attachments, whose manifest is already checked above.
            # A rooted owner manifest is verified only in its complete inner archive.
            for manifest in names:
                if manifest.startswith('files/') or not manifest.endswith(('manifest.sha256.tsv', 'delivery_manifest.sha256.tsv')):
                    continue
                rows = list(csv.DictReader(io.StringIO(z.read(manifest).decode('utf-8-sig')), delimiter='\t'))
                require(bool(rows), 'Empty owner manifest: ' + manifest)
                for row in rows:
                    rel = row['relative_path']
                    safe_name(rel)
                    prefixes = [''] + [str(p)+'/' for p in PurePosixPath(manifest).parents if str(p) != '.']
                    matches = list(dict.fromkeys(pre+rel for pre in prefixes if pre+rel in names))
                    require(len(matches) == 1, 'Unresolved/ambiguous manifest entry: ' + manifest + ': ' + rel)
                    b = z.read(matches[0])
                    require(len(b) == int(row['actual_bytes']) and digest(b) == row['sha256'],
                            'Owner manifest mismatch: ' + origin + ': ' + rel)
                    checks.append(matches[0])
            archives.append({'origin': origin, 'size_bytes':len(data), 'sha256':h,
                             'member_count':len(names), 'crc':'PASS',
                             'manifest_items_verified':len(checks)})
            for name in names:
                if name.lower().endswith('.zip'):
                    queue.append((origin+'!'+name, z.read(name)))
    sources = []
    for row in receipt['resolved_inputs']:
        data = (root/row['package_path']).read_bytes()
        require(len(data) == row['size_bytes'] and digest(data) == row['sha256'],
                'Snapshot mismatch: ' + row['source_id'])
        o = row['origin']
        if 'root_archive_source' in o:
            source = read_chain(roots[o['root_archive_source']], o['member_chain'])
            require(data == source, 'Snapshot not identical to archive member: ' + row['source_id'])
        else:
            blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            require(blob == o['git_blob_sha1'], 'Git blob mismatch: ' + row['source_id'])
            require(len(o['commit']) == 40, 'Unpinned Git source')
        sources.append({'source_id':row['source_id'],'sha256':row['sha256'],'status':'PASS'})
    return {'scope':'AUTHOR_BYTES_AND_PROVENANCE_ONLY','status':'PASS',
            'unique_archives':len(archives),'manifest_items_verified':sum(a['manifest_items_verified'] for a in archives),
            'source_snapshots_verified':len(sources),'archives':archives,'sources':sources,
            'runtime_or_independent_acceptance':'NOT_RUN'}

if __name__ == '__main__':
    try:
        print(json.dumps(verify(),ensure_ascii=False,indent=2))
    except Exception as exc:
        print(json.dumps({'status':'FAIL','owner':'P08','error':str(exc)},ensure_ascii=False),file=sys.stderr)
        sys.exit(1)
