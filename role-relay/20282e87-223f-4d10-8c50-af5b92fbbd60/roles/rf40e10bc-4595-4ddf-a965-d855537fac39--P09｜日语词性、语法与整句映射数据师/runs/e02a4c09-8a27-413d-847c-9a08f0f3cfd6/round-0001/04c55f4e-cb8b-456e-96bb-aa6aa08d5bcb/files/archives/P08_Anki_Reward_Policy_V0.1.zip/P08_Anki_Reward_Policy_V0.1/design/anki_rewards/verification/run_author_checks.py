#!/usr/bin/env python3
"""Record real subprocess stdout/stderr, exit codes and hashes; never sign gates."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[3]
VERIFY=Path('design/anki_rewards/verification')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    evidence=ROOT/'design/anki_rewards/evidence'
    i=1
    while (evidence/f'author_run_{i:03d}').exists():i+=1
    out=evidence/f'author_run_{i:03d}';out.mkdir(parents=True)
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    commands=[
        ('sources',[sys.executable,str(VERIFY/'verify_sources.py')],0,'AUTHOR_SOURCE_BYTES'),
        ('policy_static',[sys.executable,str(VERIFY/'verify_policy_artifacts.py')],0,'AUTHOR_STATIC_AND_MATH'),
        ('validator_guards',[sys.executable,'-m','unittest','discover','-s',str(VERIFY),'-p','test_*.py','-v'],0,'AUTHOR_VALIDATOR_TESTS'),
        ('formal_preflight',[sys.executable,str(VERIFY/'verify_policy_artifacts.py'),'--formal'],3,'DELIVERY_PREREQUISITES_ONLY')]
    results=[]
    for name,cmd,expected,scope in commands:
        start=datetime.now(timezone.utc).isoformat()
        proc=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,check=False)
        so=out/(name+'.stdout.log');se=out/(name+'.stderr.log')
        so.write_bytes(proc.stdout);se.write_bytes(proc.stderr)
        result={'check':name,'scope':scope,'command':cmd,'cwd':str(ROOT),'started_at_utc':start,
                'finished_at_utc':datetime.now(timezone.utc).isoformat(),'exit_code':proc.returncode,
                'expected_exit_code':expected,'expectation_matched':proc.returncode==expected,
                'status':('BLOCKED' if name=='formal_preflight' and proc.returncode==3 else 'PASS' if proc.returncode==expected else 'FAIL'),
                'stdout_path':str(so.relative_to(ROOT)),'stdout_sha256':sha(so),
                'stderr_path':str(se.relative_to(ROOT)),'stderr_sha256':sha(se)}
        results.append(result)
        print(json.dumps({'check':name,'exit_code':proc.returncode,'status':result['status']},ensure_ascii=False))
    tracked=[p for p in ROOT.rglob('*') if p.is_file() and (str(p.relative_to(ROOT)).startswith('spec/') or str(p.relative_to(ROOT)).startswith('design/anki_rewards/verification/')) and '__pycache__' not in p.parts]
    report={'task_id':'P08-S04-S05-POLICY-001','evidence_type':'P08_AUTHOR_CHECKS_NOT_INDEPENDENT_ACCEPTANCE',
            'results':results,'checked_artifact_hashes':{str(p.relative_to(ROOT)):sha(p) for p in sorted(tracked)},
            'runtime_cases_executed':0,'independent_review':'NOT_RUN'}
    (out/'run_receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return 0 if all(r['expectation_matched'] for r in results) else 1

if __name__=='__main__':sys.exit(main())
